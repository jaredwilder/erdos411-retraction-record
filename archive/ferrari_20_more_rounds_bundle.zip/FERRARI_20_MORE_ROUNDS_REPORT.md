# Ferrari 20 More Rounds - Coset Union Upper-Bound Lemma

## Verdict

`PROMOTE_MATH_VALUE_HIGH_AS_FINITE_QUOTIENT_LEMMA_NOT_GLOBAL_BREAKTHROUGH`

## Active Binary

Can the coset-size upper-bound obstruction be promoted from bounded evidence into a valuable finite quotient lemma and verified branch certificate?

## Executive Result

The result is worth something now because it is no longer just branch enumeration. It has compressed into a general finite quotient lemma: each danger modulus cuts out at most one coset in the target subfiber quotient, and if the sum of all such coset sizes is smaller than the quotient size, full coverage is impossible.

## Lemma

Let `X` be a finite subfiber quotient. For each danger modulus `p`, suppose the covered set inside `X` is either empty or one coset `S_p` of a subgroup kernel. If `sum_p |S_p| < |X|`, then `Union_p S_p != X`. Therefore the branch cannot cover the full target subfiber.

## Proof

The union cardinality is bounded above by the sum of component cardinalities: `|Union_p S_p| <= sum_p |S_p|`. If `sum_p |S_p| < |X|`, then `|Union_p S_p| < |X|`, so the union cannot equal `X`.

## Application Certificate

- Branch rows checked: 212

- Branches: 106

- All rows prove noncover by upper bound: True

- Worst coverage ratio: 0.125

- Minimum surviving lower bound by cell: `{'(20,20)': 6, '(40,40)': 6}`

## Twenty Rounds

### Round 1 - PROMOTE_LOCK
Active binary locked to coset upper-bound promotion, not new framework.

### Round 2 - PROMOTE_FULL_RACE8_BRANCH_SET
Imported 106 Race8 q3 branches: 52 replayed plus 54 previously skipped.

### Round 3 - PROMOTE_EXACT_SUBFIBERS
Defined target subfibers for (20,20) and (40,40) using k=k0+120a, l=l0+240b.

### Round 4 - PROMOTE_COSET_EQUATION
Derived the single-modulus equation (2^120)^a(3^240)^b = -(2^k0 3^l0)^(-1) mod p.

### Round 5 - PROMOTE_COSET_STRUCTURE
Promoted each modulus hit set to empty or one coset of a kernel in a finite quotient.

### Round 6 - PROMOTE_LEMMA
Proved the union upper-bound lemma: if sum coset sizes < quotient size, full coverage is impossible.

### Round 7 - PROMOTE_REPLAYED_BRANCHES
Applied the lemma to all replayed branches. 52/52 passed.

### Round 8 - PROMOTE_SKIPPED_BRANCH_REPAIR
Applied the same lemma to previously skipped branches. 54/54 passed.

### Round 9 - PROMOTE_BOTH_TARGETS
Verified both target cells separately. Neither has a full-cover branch.

### Round 10 - PROMOTE_MARGIN
Worst-case coverage ratio was 0.125, still far below full coverage.

### Round 11 - PROMOTE_SURVIVAL_MARGIN
Minimum surviving lower bound is 6 for each target cell.

### Round 12 - PROMOTE_CLAIM_SEPARATION
Separated theorem from application: lemma is general; q3 range application is bounded.

### Round 13 - PROMOTE_DISCIPLINE
Rejected global overclaim: no statement about q3 outside 301..997 or unbounded depth.

### Round 14 - PROMOTE_REFEREE_VALUE
Referee value identified: converts skipped brute-force cases into a finite quotient certificate.

### Round 15 - PROMOTE_FORMALIZATION_TARGET
Formalization target extracted: finite quotient, cosets, and union-cardinality inequality.

### Round 16 - PROMOTE_REPLAY_VERIFIER
Verifier script created to check all row inequalities and summary values.

### Round 17 - PROMOTE_MATH_VALUE_HIGH_LEMMA
Math value upgraded from bounded enumeration to finite quotient lemma plus certified application.

### Round 18 - PROMOTE_NO_OVERCLAIM
Breakthrough value remains not promoted; global theorem not claimed.

### Round 19 - PROMOTE_NEXT_BINARY
Next binary selected only after verdict: can this inequality be proven for all actual danger-closure branches from the parent family?

### Round 20 - PROMOTE_FINAL
Final verdict: high-value lemma target and certified bounded application.

## What This Proves

- general finite quotient lemma

- bounded branch noncoverage certificate for all 106 Race8 branches including previously skipped branches

- noncoverage without full fiber enumeration

## What This Does Not Prove

- q3 outside 301..997

- unbounded recursive depth

- arbitrary non-danger moduli

- global Erdos problem #203

## Math Value

High as a finite quotient lemma and certified method. Not a global breakthrough.

## Exact Next Binary

Can the coset-size inequality be proven for every actual danger-closure branch generated from the Race8 parent family, rather than only q3 in 301..997?
