#!/usr/bin/env python3
import json, sys, pandas as pd
from pathlib import Path
base=Path(sys.argv[1]) if len(sys.argv)>1 else Path('.')
cert=json.load(open(base/'twenty_more_rounds_certificate.json'))
rows=pd.read_csv(base/'twenty_more_rounds_row_ledger.csv')
errors=[]
if not bool(rows['upper_bound_proves_noncover'].all()):
    errors.append('ROW_WITHOUT_UPPER_BOUND_NONCOVER')
if len(rows)!=cert['branch_rows']:
    errors.append('ROW_COUNT_MISMATCH')
if abs(float(rows['ratio'].max())-float(cert['max_coverage_ratio']))>1e-12:
    errors.append('MAX_RATIO_MISMATCH')
for cell, min_lb in cert['min_surviving_lower_bound_by_cell'].items():
    sub=rows[rows['cell']==cell]
    if int(sub['surviving_lower_bound'].min()) != int(min_lb):
        errors.append(f'MIN_LB_MISMATCH_{cell}')
print(json.dumps({'status':'PASS' if not errors else 'FAIL','errors':errors,'rows':len(rows),'max_ratio':float(rows['ratio'].max())}, indent=2))
sys.exit(0 if not errors else 1)
