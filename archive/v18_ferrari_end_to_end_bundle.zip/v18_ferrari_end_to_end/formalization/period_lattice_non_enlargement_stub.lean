-- V18 Ferrari theorem-tax stub: exact period-lattice criterion.
-- Not a completed Lean proof. It states the actual compressed lemmas, not a fake world-shock claim.

import Mathlib.Data.Nat.Basic

-- For a base family M with periods K,L for bases 2,3.
-- Lemma target 1: q is non-enlarging iff ord_q(2) | K and ord_q(3) | L.
-- Lemma target 2: iff q divides gcd(2^K-1,3^L-1).
-- Lemma target 3: if q enlarges one coordinate, every base cell has a q-lift outside the q-mask.

-- The concrete computed case: M={5,7,11}, K=L=60,
-- gcd(2^60-1,3^60-1)=5^2*7*11*13*31*61.
