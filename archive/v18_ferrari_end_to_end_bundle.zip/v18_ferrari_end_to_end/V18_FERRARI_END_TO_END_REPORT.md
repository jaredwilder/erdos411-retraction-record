# V18 Ferrari End-to-End Result: Clean Compression, No Drama

## Verdict

The external review did not kill the machine. It compressed V17's classifier into an exact lemma.

Status from actual V18 Referee Forge verifier: `SCIENCE_PROMOTED_REFEREE_FORGE`.

## Earned result

For a fixed base modulus family `M`, define:

```text
K_M = lcm(ord_p(2) for p in M)
L_M = lcm(ord_p(3) for p in M)
```

An extension prime `q` fails to enlarge the exponent-period lattice iff:

```text
ord_q(2) | K_M and ord_q(3) | L_M
```

Equivalently:

```text
q | gcd(2^K_M - 1, 3^L_M - 1)
```

That is the closed-form reduction. The V17 classifier was not the law. This is.

## Concrete `(5, 7, 11)` computation

```text
K = 60
L = 60
gcd(2^60 - 1, 3^60 - 1) = 47322275
factorization = {'5': 2, '7': 1, '11': 1, '13': 1, '31': 1, '61': 1}
dangerous extension primes outside base = [13, 31, 61]
```

Base uncovered count: `2010`.

After adding all dangerous extension primes `[13, 31, 61]`, uncovered cells remain:

```text
1749
```

So the finite base obstruction is not killed by the entire initial dangerous-prime set.

## Important boundary

This does **not** prove global CRT-cover impossibility. Adding an enlarging prime changes the period lattice and can create new dangerous primes in the next layer.

That is the real next problem.

## One-step danger-closure probe after first enlarging prime

| first enlarging q | new dangerous primes | uncovered after q + new dangerous | status |
|---:|---|---:|---|
| 17 | [41, 241] | 12275 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |
| 19 | [37, 73, 181] | 14101 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |
| 23 | [67, 331, 661, 1321] | 205741 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |
| 29 | [43, 71, 211, 421] | 81123 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |
| 37 | [19, 73, 181] | 14101 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |
| 41 | [] | 3381 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |
| 43 | [29, 71, 211, 421] | 81123 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |
| 47 | [139, 277, 461, 691, 1381] | 914903 | SURVIVES_THIS_ONE_STEP_DANGER_CLOSURE |

## Next KBK binary

```text
Can recursive danger-closure over extension sequences find a branch that kills the residual uncovered set, or does a persistent cell survive all bounded closure branches?
```

No more gate names. The next executable machine is a recursive danger-closure search.

## Files

- `v18_ferrari_theorem_packet.json`
- `v18_referee_forge_packet_no_drama.json`
- `formalization/period_lattice_non_enlargement_stub.lean`
