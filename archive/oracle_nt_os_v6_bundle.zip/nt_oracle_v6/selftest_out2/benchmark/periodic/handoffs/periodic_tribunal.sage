# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 3, "coefficients": ["0", "0", "1"], "char_poly_coeffs": ["1", "0", "0", "-1"], "equations": 9, "unknowns": 3, "margin": 6, "minimal_on_prefix": true, "verified_terms": 12})
print('polynomial_claim', {})
