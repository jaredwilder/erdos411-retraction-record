/- Auto-generated Oracle NT OS V6 Lean skeleton. Uses sorry as explicit proof debt. -/
import Mathlib

namespace OracleNT

/-- Sequence terms supplied for periodic. Theorem scope: FINITE_PREFIX. -/
def observed : List Int := [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]
/-- Recurrence coefficients, newest to oldest: ['0', '0', '1']. -/
-- TODO: replace observed prefix with formal definition before infinite theorem claim.
theorem recurrence_prefix_certified : True := by
  -- proof debt: machine certificate over finite prefix from Python exact arithmetic
  trivial

end OracleNT
