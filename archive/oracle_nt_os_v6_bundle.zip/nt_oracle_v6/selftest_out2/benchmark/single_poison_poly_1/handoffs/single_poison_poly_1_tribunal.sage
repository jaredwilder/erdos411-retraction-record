# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 106, 11, 19, 29, 41, 55, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 5, "coefficients": ["3", "-3", "1", "0", "0"], "char_poly_coeffs": ["1", "-3", "3", "-1", "0", "0"], "equations": 9, "unknowns": 5, "margin": 4, "minimal_on_prefix": true, "verified_terms": 14})
print('polynomial_claim', {})
