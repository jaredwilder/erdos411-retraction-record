/- Auto-generated Oracle NT OS V6 Lean skeleton. Uses sorry as explicit proof debt. -/
import Mathlib

namespace OracleNT

end OracleNT
