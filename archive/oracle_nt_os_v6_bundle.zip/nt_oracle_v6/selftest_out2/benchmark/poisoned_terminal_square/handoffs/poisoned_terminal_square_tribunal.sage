# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 128]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {})
