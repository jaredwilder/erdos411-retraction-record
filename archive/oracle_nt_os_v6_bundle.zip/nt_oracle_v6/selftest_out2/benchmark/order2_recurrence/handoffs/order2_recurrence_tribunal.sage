# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [2, 3, 5, 9, 17, 33, 65, 129, 257, 513, 1025, 2049, 4097, 8193]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 2, "coefficients": ["3", "-2"], "char_poly_coeffs": ["1", "-3", "2"], "equations": 12, "unknowns": 2, "margin": 10, "minimal_on_prefix": true, "verified_terms": 14})
print('polynomial_claim', {})
