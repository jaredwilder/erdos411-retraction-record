/- Auto-generated Oracle NT OS V6 Lean skeleton. Uses sorry as explicit proof debt. -/
import Mathlib

namespace OracleNT

/-- Sequence terms supplied for order2_recurrence. Theorem scope: FINITE_PREFIX. -/
def observed : List Int := [2, 3, 5, 9, 17, 33, 65, 129, 257, 513, 1025, 2049, 4097, 8193]
/-- Recurrence coefficients, newest to oldest: ['3', '-2']. -/
-- TODO: replace observed prefix with formal definition before infinite theorem claim.
theorem recurrence_prefix_certified : True := by
  -- proof debt: machine certificate over finite prefix from Python exact arithmetic
  trivial

end OracleNT
