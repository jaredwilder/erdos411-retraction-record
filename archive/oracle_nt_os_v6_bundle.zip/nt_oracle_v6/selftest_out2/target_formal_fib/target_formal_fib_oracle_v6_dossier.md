# Oracle NT OS V6 Dossier: target_formal_fib

Version: `6.0.0-oracle-nt-os`
Scope: `FORMAL_DEFINITION`

## Verdict
Known/basic classification. No discovery-grade claim emitted.

Primary invariant: `linear_recurrence`

## Next
Normalize to Lucas/Lehmer indexing and reconcile prefix exceptions against BHV exception set.
