#!/usr/bin/env python3
"""
oracle_nt_os_v6.py

Oracle Number Theory OS V6: force, not costume.

V6 closes the V5 teardown as hard requirements:
  1. Formal object intake: observed finite prefix is not an infinite theorem source.
  2. Route-specific theorem gates: unrelated open routes cannot globally block ready routes.
  3. Hardened corruption detector: no clean-sequence ghost accusations.
  4. Scope discipline: FINITE_PREFIX, GENERATED_EXTENSION, FORMAL_DEFINITION, LITERATURE_VERIFIED.
  5. Known-family expansion plus OEIS/LMFDB hooks and cache fields.
  6. Murder benchmark suite: false corruption, route gates, scope safety, next action, transforms.
  7. State-machine KBK enforcement: required next action is mechanically checked.
  8. Proof-search engines: finite differences, recurrence GF, companion matrix, certificates.
  9. Primitive-divisor precision: indexing, Lucas normalization, exception audit.
 10. Binding tribunal escalation: unavailable external judges demote dependent claims.
 11. Corpus equivalence v2: shift, scale, difference, binomial, characteristic, GF fingerprints.
 12. Research scoring from measurements, not vibe labels.
 13. Boring classification suppression.
 14. Object-native engines: sequence, CRT cover, Diophantine quadratic.
 15. Killer next-data generator: exact terms/residues/moduli/literature checks.

No fake theorem. No global open-condition blocker. No GTH from raw finite prefixes.
"""
from __future__ import annotations

import argparse
import dataclasses
import fractions
import hashlib
import itertools
import json
import math
import os
import re
import shutil
import sqlite3
import statistics
import subprocess
import sys
import textwrap
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import sympy as sp  # type: ignore
except Exception:  # pragma: no cover
    sp = None

Fraction = fractions.Fraction
VERSION = "6.0.0-oracle-nt-os"

SCOPE_FINITE = "FINITE_PREFIX"
SCOPE_GENERATED = "GENERATED_EXTENSION"
SCOPE_FORMAL = "FORMAL_DEFINITION"
SCOPE_LITERATURE = "LITERATURE_VERIFIED"

STATUS_OBSERVED = "OBSERVED_ONLY"
STATUS_PREFIX = "PREFIX_CERTIFIED"
STATUS_ELIGIBLE = "THEOREM_ELIGIBLE"
STATUS_READY = "THEOREM_READY"
STATUS_PROOF_EXACT = "PROOF_OBLIGATION_EXACT"
STATUS_BLOCKED = "GTH_BLOCKED_BY_OPEN_CONDITION"

# ---------------------------------------------------------------------------
# Basic utilities
# ---------------------------------------------------------------------------

def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def stable_json(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, default=str)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def parse_int_sequence(raw: str) -> List[int]:
    found = re.findall(r"[-+]?\d+", raw or "")
    if not found:
        raise ValueError("No integers found in sequence input")
    return [int(x) for x in found]


def gcd_list(vals: Iterable[int]) -> int:
    g = 0
    for v in vals:
        g = math.gcd(g, abs(int(v)))
    return g


def lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return abs(a // math.gcd(a, b) * b)


def differences(seq: Sequence[int], order: int = 1) -> List[int]:
    cur = [int(x) for x in seq]
    for _ in range(order):
        cur = [cur[i + 1] - cur[i] for i in range(len(cur) - 1)]
    return cur


def finite_difference_table(seq: Sequence[int], max_order: Optional[int] = None) -> List[List[int]]:
    cur = [int(x) for x in seq]
    table = [cur]
    if max_order is None:
        max_order = max(0, len(seq) - 1)
    for _ in range(max_order):
        if len(cur) <= 1:
            break
        cur = differences(cur)
        table.append(cur)
    return table


def is_square(n: int) -> bool:
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def primes_upto(n: int) -> List[int]:
    if n < 2:
        return []
    sieve = bytearray(b"\x01") * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for p in range(2, math.isqrt(n) + 1):
        if sieve[p]:
            sieve[p*p:n+1:p] = b"\x00" * (((n - p*p)//p) + 1)
    return [i for i in range(n + 1) if sieve[i]]


def factorint(n: int) -> Dict[int, int]:
    n = int(n)
    if n == 0:
        return {0: 1}
    out: Dict[int, int] = {}
    if n < 0:
        out[-1] = 1
        n = -n
    if sp is not None:
        try:
            return {**out, **{int(k): int(v) for k, v in sp.factorint(n).items()}}
        except Exception:
            pass
    d = 2
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def solve_linear_fraction(A: List[List[Fraction]], b: List[Fraction]) -> Optional[List[Fraction]]:
    n = len(A)
    if n == 0 or len(b) != n or any(len(r) != n for r in A):
        return None
    M = [list(A[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            return None
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r == col:
                continue
            f = M[r][col]
            if f:
                M[r] = [M[r][c] - f * M[col][c] for c in range(n + 1)]
    return [M[i][-1] for i in range(n)]


def frac_str(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"

# ---------------------------------------------------------------------------
# Corpus state and KBK enforcement
# ---------------------------------------------------------------------------

class Corpus:
    def __init__(self, path: Path):
        self.path = path
        ensure_dir(path.parent)
        self.conn = sqlite3.connect(str(path))
        self.conn.row_factory = sqlite3.Row
        self._init()

    def _init(self) -> None:
        cur = self.conn.cursor()
        cur.execute("""
        CREATE TABLE IF NOT EXISTS objects(
          object_id TEXT PRIMARY KEY,
          label TEXT,
          object_type TEXT,
          scope TEXT,
          fingerprint TEXT,
          payload_json TEXT,
          created_at TEXT
        )""")
        cur.execute("""
        CREATE TABLE IF NOT EXISTS runs(
          run_id TEXT PRIMARY KEY,
          object_id TEXT,
          action TEXT,
          required_action_entering TEXT,
          satisfied_required INTEGER,
          report_json TEXT,
          created_at TEXT
        )""")
        cur.execute("""
        CREATE TABLE IF NOT EXISTS kbk_state(
          object_id TEXT PRIMARY KEY,
          required_action TEXT,
          required_reason TEXT,
          round_no INTEGER,
          updated_at TEXT
        )""")
        cur.execute("""
        CREATE TABLE IF NOT EXISTS equivalences(
          object_id TEXT,
          other_object_id TEXT,
          relation TEXT,
          evidence_json TEXT,
          created_at TEXT
        )""")
        cur.execute("""
        CREATE TABLE IF NOT EXISTS theorem_registry(
          theorem_key TEXT PRIMARY KEY,
          family TEXT,
          applicability_json TEXT,
          caveats_json TEXT,
          citation_stub TEXT
        )""")
        self.conn.commit()
        self.seed_registry()

    def seed_registry(self) -> None:
        rows = [
            ("finite_difference_newton", "polynomial_sequences", {"requires":"constant finite difference at order d"}, {"finite_prefix":"needs formal definition for infinite claim"}, "Newton series / finite differences"),
            ("linear_recurrence_gf", "linear_recurrences", {"requires":"constant coefficient recurrence and initial values"}, {"finite_prefix":"fit is not definition"}, "ordinary generating function recurrence theorem"),
            ("lucas_zsigmondy_bhv", "Lucas_Lehmer", {"requires":"normalized nondegenerate Lucas or Lehmer sequence"}, {"exceptions":"index and family specific"}, "Bilu-Hanrot-Voutier primitive divisor theorem"),
            ("lte", "p_adic", {"requires":"a,b,p satisfy LTE hypotheses"}, {"exceptions":"p=2 and divisibility conditions"}, "Lifting the Exponent lemma"),
            ("crt_cover", "covering_systems", {"requires":"compatible residue classes across moduli"}, {"finite_torus":"finite coverage does not imply infinite lift"}, "Chinese remainder theorem and covering systems"),
        ]
        cur = self.conn.cursor()
        for k,f,a,c,stub in rows:
            cur.execute("INSERT OR IGNORE INTO theorem_registry VALUES (?,?,?,?,?)", (k,f,json.dumps(a),json.dumps(c),stub))
        self.conn.commit()

    def upsert_object(self, object_id: str, label: str, object_type: str, scope: str, fingerprint: str, payload: Dict[str, Any]) -> None:
        self.conn.execute("""
        INSERT OR REPLACE INTO objects VALUES (?,?,?,?,?,?,?)
        """, (object_id, label, object_type, scope, fingerprint, stable_json(payload), utc_now()))
        self.conn.commit()

    def get_required_action(self, object_id: str) -> Optional[Dict[str, Any]]:
        row = self.conn.execute("SELECT * FROM kbk_state WHERE object_id=?", (object_id,)).fetchone()
        return dict(row) if row else None

    def set_required_action(self, object_id: str, action: str, reason: str, round_no: int) -> None:
        self.conn.execute("INSERT OR REPLACE INTO kbk_state VALUES (?,?,?,?,?)", (object_id, action, reason, round_no, utc_now()))
        self.conn.commit()

    def record_run(self, object_id: str, action: str, required: Optional[str], satisfied: bool, report: Dict[str, Any]) -> str:
        run_id = sha256_text(object_id + action + utc_now() + stable_json(report))[:16]
        self.conn.execute("INSERT INTO runs VALUES (?,?,?,?,?,?,?)", (run_id, object_id, action, required or "", 1 if satisfied else 0, stable_json(report), utc_now()))
        self.conn.commit()
        return run_id

    def add_equivalence(self, object_id: str, other_id: str, relation: str, evidence: Dict[str, Any]) -> None:
        self.conn.execute("INSERT INTO equivalences VALUES (?,?,?,?,?)", (object_id, other_id, relation, stable_json(evidence), utc_now()))
        self.conn.commit()

# ---------------------------------------------------------------------------
# Object intake and fingerprints
# ---------------------------------------------------------------------------

@dataclass
class MathObject:
    object_type: str
    label: str
    scope: str
    sequence: List[int] = field(default_factory=list)
    definition: Dict[str, Any] = field(default_factory=dict)
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def object_id(self) -> str:
        return sha256_text(stable_json({"type":self.object_type,"label":self.label,"scope":self.scope,"sequence":self.sequence,"definition":self.definition,"raw":self.raw}))[:24]


def infer_scope(args: argparse.Namespace) -> str:
    if getattr(args, "scope", None):
        return args.scope
    if getattr(args, "formal_recurrence", None) or getattr(args, "formal_formula", None):
        return SCOPE_FORMAL
    if getattr(args, "literature_verified", False):
        return SCOPE_LITERATURE
    return SCOPE_FINITE


def object_from_args(args: argparse.Namespace) -> MathObject:
    seq = parse_int_sequence(args.seq)
    definition: Dict[str, Any] = {}
    if getattr(args, "formal_recurrence", None):
        definition["formal_recurrence"] = parse_int_sequence(args.formal_recurrence)
        definition["recurrence_order"] = len(definition["formal_recurrence"])
    if getattr(args, "formal_formula", None):
        definition["formal_formula"] = args.formal_formula
    return MathObject("sequence", args.label, infer_scope(args), seq, definition, {})


def binomial_transform(seq: Sequence[int]) -> List[int]:
    out = []
    for n in range(len(seq)):
        s = 0
        for k in range(n + 1):
            s += math.comb(n, k) * int(seq[k])
        out.append(s)
    return out


def inverse_binomial_transform(seq: Sequence[int]) -> List[int]:
    out = []
    for n in range(len(seq)):
        s = 0
        for k in range(n + 1):
            s += ((-1) ** (n-k)) * math.comb(n, k) * int(seq[k])
        out.append(s)
    return out


def find_linear_recurrence(seq: Sequence[int], max_order: int = 8) -> Optional[Dict[str, Any]]:
    s = [Fraction(int(x)) for x in seq]
    n = len(s)
    if n < 3:
        return None
    for order in range(1, min(max_order, n // 2) + 1):
        rows, rhs = [], []
        for i in range(order, n):
            rows.append([s[i - j - 1] for j in range(order)])
            rhs.append(s[i])
        # Need margin: equations >= unknowns + 2 unless formal definition later upgrades.
        if len(rows) < order + 2:
            continue
        coeffs = None
        # Use first many square subsystems, then verify all.
        for idxs in itertools.combinations(range(len(rows)), order):
            sol = solve_linear_fraction([rows[i] for i in idxs], [rhs[i] for i in idxs])
            if sol is None:
                continue
            if all(sum(sol[j] * rows[r][j] for j in range(order)) == rhs[r] for r in range(len(rows))):
                coeffs = sol
                break
        if coeffs is None:
            continue
        # Prove smaller order fails on prefix.
        smaller = False
        for lo in range(1, order):
            if find_linear_recurrence(seq, lo) and find_linear_recurrence(seq, lo)["order"] == lo:
                smaller = True
                break
        char = [Fraction(1)] + [-c for c in coeffs]
        return {
            "order": order,
            "coefficients": [frac_str(c) for c in coeffs],
            "coefficients_fraction": coeffs,
            "char_poly_coeffs": [frac_str(c) for c in char],
            "equations": len(rows),
            "unknowns": order,
            "margin": len(rows) - order,
            "minimal_on_prefix": not smaller,
            "verified_terms": n,
        }
    return None


def recurrence_predict(seed: Sequence[int], coeffs: Sequence[Fraction], total: int) -> List[Fraction]:
    out = [Fraction(int(x)) for x in seed]
    k = len(coeffs)
    while len(out) < total:
        out.append(sum(coeffs[j] * out[-j-1] for j in range(k)))
    return out


def recurrence_generating_function(seq: Sequence[int], coeffs: Sequence[Fraction]) -> Dict[str, Any]:
    # If a_n = c1 a_{n-1}+...+ck a_{n-k}, denominator is 1 - c1 x - ... - ck x^k.
    k = len(coeffs)
    den = [Fraction(1)] + [-c for c in coeffs]
    # Numerator coefficients b_n = a_n - c1 a_{n-1} - ... for n < k.
    num: List[Fraction] = []
    for n in range(k):
        val = Fraction(int(seq[n]))
        for j in range(1, n + 1):
            val -= coeffs[j-1] * Fraction(int(seq[n-j]))
        num.append(val)
    return {"numerator": [frac_str(x) for x in num], "denominator": [frac_str(x) for x in den], "meaning": "ordinary generating function numerator / denominator in ascending x powers"}


def polynomial_finite_difference(seq: Sequence[int], max_degree: Optional[int] = None) -> Optional[Dict[str, Any]]:
    if len(seq) < 3:
        return None
    if max_degree is None:
        max_degree = min(6, max(2, len(seq)//2 - 1))
    table = finite_difference_table(seq)
    for d, row in enumerate(table[1:], start=1):
        if d > max_degree:
            break
        if row and len(set(row)) == 1:
            coeffs = [table[k][0] for k in range(d + 1)]
            # Newton series: a_n = sum_k Δ^k a_0 * C(n,k)
            return {
                "degree": d,
                "constant_difference": row[0],
                "binomial_basis_coefficients": coeffs,
                "formula": " + ".join([f"({c})*C(n,{k})" for k, c in enumerate(coeffs) if c != 0]) or "0",
                "verified_terms": len(seq),
                "certificate": "constant finite difference and Newton binomial basis formula produced",
            }
    return None


def eval_newton(coeffs: Sequence[int], n: int) -> int:
    return sum(int(c) * math.comb(n, k) for k, c in enumerate(coeffs) if n >= k)


def fingerprints(seq: Sequence[int]) -> Dict[str, str]:
    s = [int(x) for x in seq]
    fp: Dict[str, str] = {}
    fp["raw"] = sha256_text(stable_json(s))[:16]
    fp["diff1"] = sha256_text(stable_json(differences(s) if len(s)>1 else []))[:16]
    fp["diff2"] = sha256_text(stable_json(differences(s,2) if len(s)>2 else []))[:16]
    fp["shift_drop_first"] = sha256_text(stable_json(s[1:]))[:16]
    fp["shift_drop_last"] = sha256_text(stable_json(s[:-1]))[:16]
    g = gcd_list(s) or 1
    fp["scale_normalized"] = sha256_text(stable_json([x//g for x in s]))[:16]
    fp["binomial"] = sha256_text(stable_json(binomial_transform(s)))[:16]
    fp["inv_binomial"] = sha256_text(stable_json(inverse_binomial_transform(s)))[:16]
    rec = find_linear_recurrence(s)
    fp["recurrence_char"] = sha256_text(stable_json(rec["char_poly_coeffs"] if rec else []))[:16]
    poly = polynomial_finite_difference(s)
    fp["newton_coeffs"] = sha256_text(stable_json(poly["binomial_basis_coefficients"] if poly else []))[:16]
    return fp

# ---------------------------------------------------------------------------
# Known families and local literature/registry hooks
# ---------------------------------------------------------------------------

def fibs(n: int) -> List[int]:
    out = [1, 1]
    while len(out) < n:
        out.append(out[-1] + out[-2])
    return out[:n]


def lucas(n: int) -> List[int]:
    out = [2, 1]
    while len(out) < n:
        out.append(out[-1] + out[-2])
    return out[:n]


def catalan(n: int) -> List[int]:
    return [math.comb(2*k, k)//(k+1) for k in range(n)]


def bell(n: int) -> List[int]:
    tri = [[1]]
    for i in range(1, n):
        row = [tri[-1][-1]]
        for j in range(1, i+1):
            row.append(row[-1] + tri[-1][j-1])
        tri.append(row)
    return [tri[i][0] for i in range(n)]


def factorials(n: int) -> List[int]:
    out = []
    f = 1
    for k in range(n):
        if k > 0:
            f *= k
        out.append(f)
    return out


def primes_first(n: int) -> List[int]:
    out = []
    p = 2
    while len(out) < n:
        if all(p % q for q in range(2, math.isqrt(p)+1)):
            out.append(p)
        p += 1
    return out


def known_family_match(seq: Sequence[int]) -> Dict[str, Any]:
    s = [int(x) for x in seq]
    n = len(s)
    families = {
        "fibonacci_1_1": fibs(n),
        "lucas_2_1": lucas(n),
        "squares_n2_from_0": [k*k for k in range(n)],
        "squares_n2_from_1": [(k+1)*(k+1) for k in range(n)],
        "triangular_from_0": [k*(k+1)//2 for k in range(n)],
        "triangular_from_1": [(k+1)*(k+2)//2 for k in range(n)],
        "powers_2_from_0": [2**k for k in range(n)],
        "naturals_from_0": list(range(n)),
        "naturals_from_1": list(range(1, n+1)),
        "constants": [s[0]]*n if n else [],
        "catalan": catalan(n),
        "bell": bell(n),
        "factorials": factorials(n),
        "primes": primes_first(n),
    }
    exact = [name for name, vals in families.items() if vals == s]
    transforms = []
    # Shift detection against generated known families with offsets up to 5.
    for name, vals in families.items():
        base = vals + []
        # Already exact handled.
        if name in exact:
            continue
    # Difference matches known families.
    if n > 2:
        d1 = differences(s)
        dm = known_family_match(d1) if len(d1) < n else {"exact": []}
        if dm.get("exact"):
            transforms.append({"relation":"first_difference_known", "families": dm["exact"]})
    periodic = None
    for p in range(1, min(10, n//2 + 1)):
        if all(s[i] == s[i % p] for i in range(n)):
            periodic = {"period": p, "pattern": s[:p]}
            break
    return {
        "exact": exact,
        "transforms": transforms,
        "periodic": periodic,
        "oeis_hook": {
            "status": "HOOK_READY_NOT_QUERIED_BY_DEFAULT",
            "query_terms": s[:12],
            "cache_key": sha256_text(','.join(map(str, s[:12])))[:16],
            "note": "Online OEIS collision search must run before novelty-grade claim. V6 blocks novelty without it unless operator passes literature-verified scope."
        },
        "lmfdb_hook": {"status":"OBJECT_TYPE_DEPENDENT", "note":"Use for elliptic curves, modular forms, number fields, not raw simple sequences."},
    }

# ---------------------------------------------------------------------------
# Auditors, proof search, routes
# ---------------------------------------------------------------------------

def hardened_corruption_audit(seq: Sequence[int], known: Dict[str, Any]) -> Dict[str, Any]:
    s = [int(x) for x in seq]
    # Suppress all corruption if exact known family already matches.
    if known.get("exact"):
        return {"status":"SUPPRESSED_BY_KNOWN_FAMILY_EXACT_MATCH", "suspected": False}
    # If a clean simple law already fits full sequence, no corruption.
    full_poly = polynomial_finite_difference(s)
    full_rec = find_linear_recurrence(s)
    # Clean full law suppresses corruption only if it is simple enough.
    if full_poly or (full_rec and full_rec.get("order", 999) <= 3):
        return {"status":"NO_CORRUPTION_CLEAN_LAW_FITS_FULL_SEQUENCE", "suspected": False}
    candidates = []
    n = len(s)
    if n < 7:
        return {"status":"INSUFFICIENT_LENGTH_FOR_SINGLE_CORRUPTION", "suspected": False}
    for i in range(n):
        repaired_by = None
        predicted = None
        complexity = 999

        # Leave-one-out polynomial in the ORIGINAL n-coordinate, not reindexed deletion.
        for d in range(0, min(5, n-3) + 1):
            pts = [(j, Fraction(s[j])) for j in range(n) if j != i]
            # solve using first d+1 points, verify all remaining
            if len(pts) < d + 2:
                continue
            A = [[Fraction(x) ** k for k in range(d+1)] for x,_ in pts[:d+1]]
            b = [y for _,y in pts[:d+1]]
            sol = solve_linear_fraction(A,b)
            if sol is None:
                continue
            if all(sum(sol[k]*(Fraction(x)**k) for k in range(d+1)) == y for x,y in pts):
                pred = sum(sol[k]*(Fraction(i)**k) for k in range(d+1))
                if pred.denominator == 1:
                    predicted = int(pred)
                    repaired_by = "leave_one_out_polynomial_original_coordinate"
                    complexity = d
                    break
        # Leave-one-out recurrence: solve using recurrence equations not touching suspect index.
        if repaired_by is None:
            for order in range(1, min(4, n//2)+1):
                rows=[]; rhs=[]
                for j in range(order, n):
                    involved = [j] + [j-k-1 for k in range(order)]
                    if i in involved:
                        continue
                    rows.append([Fraction(s[j-k-1]) for k in range(order)])
                    rhs.append(Fraction(s[j]))
                if len(rows) < order + 2:
                    continue
                coeffs=None
                for idxs in itertools.combinations(range(len(rows)), order):
                    sol=solve_linear_fraction([rows[u] for u in idxs], [rhs[u] for u in idxs])
                    if sol is not None and all(sum(sol[k]*rows[r][k] for k in range(order)) == rhs[r] for r in range(len(rows))):
                        coeffs=sol; break
                if coeffs is None:
                    continue
                # predict suspect if previous clean terms available
                if i >= order and all((i-k-1)!=i for k in range(order)):
                    pred = sum(coeffs[k]*Fraction(s[i-k-1]) for k in range(order))
                    if pred.denominator == 1:
                        predicted = int(pred)
                        repaired_by = "leave_one_out_recurrence_original_coordinate"
                        complexity = order + 2
                        break
        if repaired_by and predicted is not None and int(predicted) != s[i]:
            edge_penalty = 2 if i in (0, n-1) else 0
            candidates.append({"index": i, "suspect_value": s[i], "predicted_value": int(predicted), "law_after_removal": repaired_by, "complexity": complexity + edge_penalty})
    if not candidates:
        return {"status":"NO_SINGLE_CORRUPTION_REPAIR_FOUND", "suspected": False}
    best = sorted(candidates, key=lambda c: (c["complexity"], c["index"] != n-1, c["index"]))[0]
    best["status"] = "SINGLE_CORRUPTION_SUSPECTED"
    best["suspected"] = True
    best["requirements_satisfied"] = [
        "full_simple_law_failed",
        "single deletion repaired simple law",
        "repaired law predicts deleted value differently",
        "known-family exact match did not suppress",
    ]
    return best


def minimal_recurrence_audit(seq: Sequence[int], rec: Optional[Dict[str, Any]], scope: str, definition: Dict[str, Any]) -> Dict[str, Any]:
    if not rec:
        return {"route":"linear_recurrence_minimality", "status":"NOT_APPLICABLE"}
    conditions = {
        "prefix_fit_exact": "PASS",
        "minimal_on_prefix": "PASS" if rec.get("minimal_on_prefix") else "OPEN",
        "margin_equations_minus_unknowns": rec.get("margin", 0),
        "formal_definition_supplied": "PASS" if scope in (SCOPE_FORMAL, SCOPE_LITERATURE) and definition.get("formal_recurrence") else "OPEN",
    }
    if conditions["formal_definition_supplied"] == "PASS":
        status = STATUS_READY
    else:
        status = STATUS_PREFIX
    return {"route":"linear_recurrence_minimality", "status":status, "conditions":conditions, "claim_scope": scope if status == STATUS_READY else SCOPE_FINITE}


def polynomial_certificate(seq: Sequence[int], poly: Optional[Dict[str, Any]], scope: str, definition: Dict[str, Any]) -> Dict[str, Any]:
    if not poly:
        return {"route":"finite_difference_polynomial", "status":"NOT_APPLICABLE"}
    coeffs = poly["binomial_basis_coefficients"]
    mismatches = []
    for n, val in enumerate(seq):
        pred = eval_newton(coeffs, n)
        if pred != val:
            mismatches.append((n,pred,val))
    conditions = {
        "constant_finite_difference": "PASS",
        "newton_binomial_formula_verified_on_prefix": "PASS" if not mismatches else "FAIL",
        "formal_definition_supplied": "PASS" if scope in (SCOPE_FORMAL, SCOPE_LITERATURE) and definition.get("formal_formula") else "OPEN",
    }
    status = STATUS_READY if conditions["formal_definition_supplied"] == "PASS" else STATUS_PREFIX
    return {"route":"finite_difference_polynomial", "status":status, "conditions":conditions, "formula": poly["formula"], "claim_scope": scope if status == STATUS_READY else SCOPE_FINITE}


def lucas_parameters(seq: Sequence[int], rec: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    if not rec or rec.get("order") != 2:
        return None
    coeffs = rec["coefficients_fraction"]
    c1, c2 = coeffs
    # Lucas U_n(P,Q): U_n = P U_{n-1} - Q U_{n-2}. Here c1=P, c2=-Q.
    P = c1
    Q = -c2
    disc = P*P - 4*Q
    family = "UNKNOWN"
    s = list(seq)
    if len(s) >= 2 and s[0] == 0 and s[1] == 1:
        family = "LUCAS_U_ZERO_BASED"
    elif len(s) >= 2 and s[0] == 2 and s[1] == int(P) if P.denominator == 1 else False:
        family = "LUCAS_V_ZERO_BASED"
    elif len(s) >= 2 and s[:2] == [1,1] and P == 1 and Q == -1:
        family = "FIBONACCI_SHIFTED_U_INDEX_STARTS_AT_1"
    return {"P": frac_str(P), "Q": frac_str(Q), "discriminant": frac_str(disc), "family": family, "nondegenerate_root_ratio": "PASS" if disc != 0 and Q != 0 else "OPEN"}


def primitive_prime_divisor_audit(seq: Sequence[int], rec: Optional[Dict[str, Any]], index_start: int = 0) -> Dict[str, Any]:
    params = lucas_parameters(seq, rec)
    if not params:
        return {"route":"primitive_divisor", "status":"NOT_APPLICABLE"}
    seen: set[int] = set()
    exceptions = []
    records = []
    for obs_i, a in enumerate(seq):
        theorem_i = obs_i + index_start
        aa = abs(int(a))
        if aa in (0,1):
            factors = []
            primitive = []
        else:
            fac = [p for p in factorint(aa).keys() if p > 1]
            primitive = [p for p in fac if p not in seen]
            factors = fac
        if theorem_i >= 3 and not primitive:
            exceptions.append({"observed_index": obs_i, "theorem_index": theorem_i, "value": int(a)})
        records.append({"observed_index":obs_i,"theorem_index":theorem_i,"value":int(a),"factors":factors,"primitive":primitive})
        for p in factors:
            seen.add(p)
    # Audit is prefix only unless literature/formal and full theorem conditions proven elsewhere.
    status = STATUS_PREFIX
    conditions = {
        "indexing_convention_declared": "PASS",
        "lucas_or_lehmer_normalization": "PASS" if params["family"] != "UNKNOWN" else "OPEN",
        "nondegenerate_root_ratio": params["nondegenerate_root_ratio"],
        "prefix_exception_audit_run": "PASS",
        "known_BHV_exception_reconciliation": "OPEN" if exceptions else "PASS_ON_PREFIX",
    }
    return {"route":"primitive_divisor", "status":status, "lucas_parameters":params, "conditions":conditions, "exceptions_on_prefix": exceptions, "records_sample": records[:20]}


def strong_divisibility_audit(seq: Sequence[int], index_start: int = 1) -> Dict[str, Any]:
    # Intended for positive-indexed sequences such as Fibonacci F_1=1,F_2=1.
    s = [abs(int(x)) for x in seq]
    failures = []
    n = len(s)
    for i in range(n):
        for j in range(n):
            ti, tj = i + index_start, j + index_start
            gidx = math.gcd(ti, tj) - index_start
            if 0 <= gidx < n:
                lhs = math.gcd(s[i], s[j])
                rhs = s[gidx]
                if lhs != rhs:
                    failures.append({"i":ti,"j":tj,"lhs":lhs,"rhs_index":gidx+index_start,"rhs":rhs})
                    if len(failures) > 10:
                        break
        if len(failures) > 10:
            break
    return {
        "route":"strong_divisibility",
        "status": STATUS_PREFIX if not failures else "FAILED_ON_PREFIX",
        "conditions": {
            "prefix_gcd_identity": "PASS" if not failures else "FAIL",
            "all_indices_proof": "OPEN",
            "route_specific_only": "PASS"
        },
        "failures": failures,
        "note": "This route never globally blocks recurrence or polynomial theorem claims. It blocks only strong-divisibility theorem GTH."
    }


def lte_candidate_audit(seq: Sequence[int]) -> Dict[str, Any]:
    # Conservative: looks for v_p(a_n) affine in v_p(n) for small primes. Prefix-only.
    records = []
    for p in [2,3,5,7]:
        pairs = []
        for n, a in enumerate(seq, start=1):
            if a == 0:
                continue
            vn = 0
            m = n
            while m % p == 0 and m:
                vn += 1; m //= p
            va = 0
            aa = abs(int(a))
            while aa and aa % p == 0:
                va += 1; aa //= p
            if vn or va:
                pairs.append((vn,va))
        if len(pairs) >= 4:
            records.append({"p":p,"pairs":pairs[:20],"hypothesis":"possible LTE valuation relation; requires a,b,p hypotheses, not asserted"})
    return {"route":"lte", "status": STATUS_OBSERVED if records else "NOT_APPLICABLE", "conditions":{"LTE_hypotheses_verified":"OPEN" if records else "NOT_APPLICABLE"}, "records":records}


def proof_search(seq: Sequence[int], poly: Optional[Dict[str, Any]], rec: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if poly:
        coeffs = poly["binomial_basis_coefficients"]
        out["polynomial"] = {
            "newton_formula": poly["formula"],
            "induction_plan": [
                "Define a(n)=sum_k c_k * Nat.choose n k.",
                f"Show Δ^{poly['degree']} a(n) is constant {poly['constant_difference']}.",
                "Use finite difference uniqueness after matching first d+1 values.",
            ],
            "killer_next_data": f"Need terms a({len(seq)}) through a({len(seq)+poly['degree']+2}) to stress the degree-{poly['degree']} law beyond the fitted prefix if no formal definition is supplied.",
        }
    if rec:
        coeffs = rec["coefficients_fraction"]
        gf = recurrence_generating_function(seq, coeffs)
        out["recurrence"] = {
            "generating_function": gf,
            "companion_matrix": companion_matrix(coeffs),
            "induction_plan": [
                "Define a by initial vector and recurrence.",
                "Prove recurrence extends all generated terms by construction.",
                "For observed data, theorem scope remains finite-prefix unless formal definition or literature source is supplied.",
            ],
            "killer_next_data": f"Need independently sourced terms a({len(seq)}) through a({len(seq)+max(10, 2*rec['order'])}) or a formal recurrence definition to upgrade from PREFIX_CERTIFIED to THEOREM_READY.",
        }
    return out


def companion_matrix(coeffs: Sequence[Fraction]) -> List[List[str]]:
    k = len(coeffs)
    if k == 0:
        return []
    M: List[List[Fraction]] = [[Fraction(0) for _ in range(k)] for __ in range(k)]
    M[0] = list(coeffs)
    for i in range(1, k):
        M[i][i-1] = Fraction(1)
    return [[frac_str(x) for x in row] for row in M]

# ---------------------------------------------------------------------------
# Scoring, invariants, claims
# ---------------------------------------------------------------------------

def invariant_candidates(obj: MathObject) -> List[Dict[str, Any]]:
    seq = obj.sequence
    poly = polynomial_finite_difference(seq)
    rec = find_linear_recurrence(seq)
    known = known_family_match(seq)
    corrupt = hardened_corruption_audit(seq, known)
    candidates = []
    n = len(seq)
    if known.get("exact") and not any(name in known.get("exact", []) for name in ["fibonacci_1_1", "squares_n2_from_0", "squares_n2_from_1", "powers_2_from_0", "triangular_from_0", "triangular_from_1"]):
        candidates.append({"name":"known_family_classification", "class":"known_family", "truth_score":1.0, "explanation_score":0.93, "complexity":1, "evidence":{"families":known.get("exact", [])}})
    def compression_from_complexity(c: float) -> float:
        return max(0.0, min(1.0, 1.0 - c / max(4.0, n)))
    if corrupt.get("suspected"):
        candidates.append({"name":"single_corruption_over_simple_law", "class":"data_quality", "truth_score":0.9, "explanation_score":0.88, "complexity":2, "evidence":corrupt})
    if poly:
        deg = poly["degree"]
        candidates.append({"name":"polynomial_finite_difference", "class":"polynomial", "truth_score":1.0, "explanation_score":compression_from_complexity(deg+1), "complexity":deg+1, "evidence":poly})
    if rec:
        # Penalize recurrence if a lower-complexity polynomial explains it.
        complexity = rec["order"] + 2
        explanation = compression_from_complexity(complexity)
        if poly and poly["degree"] + 1 <= complexity:
            explanation *= 0.55
        candidates.append({"name":"linear_recurrence", "class":"recurrence", "truth_score":1.0, "explanation_score":explanation, "complexity":complexity, "evidence":{k:v for k,v in rec.items() if k != "coefficients_fraction"}})
    if known.get("periodic"):
        candidates.append({"name":"periodic_finite_state", "class":"periodic", "truth_score":1.0, "explanation_score":0.92, "complexity":known["periodic"]["period"], "evidence":known["periodic"]})
    # Valuation profile only as secondary, not opportunistic primary if corruption exists.
    val_records = valuation_profile(seq)
    if val_records["signal_primes"]:
        candidates.append({"name":"p_adic_valuation_profile", "class":"p_adic", "truth_score":0.72, "explanation_score":0.38, "complexity":5, "evidence":val_records})
    if not candidates:
        candidates.append({"name":"unclassified_prefix", "class":"unknown", "truth_score":0.2, "explanation_score":0.1, "complexity":n, "evidence":{}})
    # Measurement-based scores.
    fps = fingerprints(seq)
    for c in candidates:
        c["novelty_score"] = 0.05 if known.get("exact") else 0.45
        c["known_family"] = known.get("exact", [])
        c["literature_collision_status"] = "BLOCKS_NOVELTY_UNTIL_OEIS_OR_LITERATURE_CHECK" if not obj.scope == SCOPE_LITERATURE else "LITERATURE_SCOPE_SUPPLIED"
        c["proof_readiness_score"] = 0.85 if obj.scope in (SCOPE_FORMAL, SCOPE_LITERATURE) else 0.35
        c["theorem_proximity_score"] = 0.7 if c["class"] in ("polynomial","recurrence") else 0.25
        c["research_value_score"] = measured_research_score(c, known, obj.scope, fps)
        c["jigsaw_score"] = round(0.35*c["explanation_score"] + 0.25*c["proof_readiness_score"] + 0.2*c["theorem_proximity_score"] + 0.2*c["research_value_score"], 4)
    return sorted(candidates, key=lambda x: (x["explanation_score"], x["truth_score"], -x["complexity"]), reverse=True)


def valuation_profile(seq: Sequence[int]) -> Dict[str, Any]:
    signal = []
    records = {}
    for p in [2,3,5,7,11]:
        vals = []
        for a in seq:
            if a == 0:
                vals.append(None)
            else:
                aa = abs(int(a)); v = 0
                while aa and aa % p == 0:
                    v += 1; aa //= p
                vals.append(v)
        records[p] = vals
        finite = [v for v in vals if v is not None]
        if finite and max(finite) >= 3 and len(set(finite)) > 2:
            signal.append(p)
    return {"records":records, "signal_primes":signal}


def measured_research_score(cand: Dict[str, Any], known: Dict[str, Any], scope: str, fps: Dict[str,str]) -> float:
    # Measurement components only, no free-floating hype.
    known_penalty = 0.55 if known.get("exact") else 0.0
    novelty_collision_penalty = 0.25 if cand.get("literature_collision_status","").startswith("BLOCKS") else 0.0
    compression = cand["explanation_score"]
    proof = cand["proof_readiness_score"]
    theorem = cand["theorem_proximity_score"]
    data_quality_bonus = 0.15 if cand["class"] == "data_quality" else 0.0
    formal_bonus = 0.2 if scope in (SCOPE_FORMAL, SCOPE_LITERATURE) else 0.0
    score = 0.35*compression + 0.25*proof + 0.25*theorem + data_quality_bonus + formal_bonus - known_penalty - novelty_collision_penalty
    return round(max(0.0, min(1.0, score)), 4)


def build_routes(obj: MathObject, poly: Optional[Dict[str, Any]], rec: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    routes = {
        "polynomial": polynomial_certificate(obj.sequence, poly, obj.scope, obj.definition),
        "recurrence": minimal_recurrence_audit(obj.sequence, rec, obj.scope, obj.definition),
        "primitive_divisor": primitive_prime_divisor_audit(obj.sequence, rec, index_start=1 if obj.sequence[:2] == [1,1] else 0),
        "strong_divisibility": strong_divisibility_audit(obj.sequence, index_start=1),
        "lte": lte_candidate_audit(obj.sequence),
    }
    return routes


def route_specific_claims(obj: MathObject, primary: Dict[str, Any], routes: Dict[str, Any], known: Dict[str, Any], tribunal: Dict[str, Any]) -> Dict[str, Any]:
    claims: Dict[str, Any] = {}
    boring_known = bool(known.get("exact")) and primary["research_value_score"] < 0.35
    classification_status = "FIRES_LOW_STAKES" if primary["truth_score"] >= 0.8 else "BLOCKED"
    if boring_known:
        classification_status = "CLASSIFIED_KNOWN_BASIC_SUPPRESSED_OUTPUT"
    claims["classification_gth"] = {
        "status": classification_status,
        "claim": f"Object classifies primarily as {primary['name']} on scope {obj.scope}.",
        "stakes": "low" if boring_known else "medium",
        "boring_suppression": boring_known,
    }
    # Theorem claims per route, no global blockers.
    theorem_routes = {}
    for key, route in routes.items():
        status = route.get("status")
        route_claim_scope = route.get("claim_scope", SCOPE_FINITE)
        external_dependency = key in ("primitive_divisor",) and tribunal.get("pari",{}).get("available") is False
        if status == STATUS_READY and obj.scope in (SCOPE_FORMAL, SCOPE_LITERATURE) and not external_dependency:
            fire = "FIRES_ROUTE_SPECIFIC"
        elif status == STATUS_PREFIX:
            fire = "BLOCKED_PREFIX_ONLY"
        elif external_dependency:
            fire = "BLOCKED_TRIBUNAL_UNAVAILABLE_FOR_ROUTE"
        elif status in ("FAILED_ON_PREFIX", "NOT_APPLICABLE"):
            fire = "NOT_APPLICABLE_OR_FAILED"
        else:
            fire = STATUS_BLOCKED
        theorem_routes[key] = {
            "gth_status": fire,
            "route_status": status,
            "claim_scope": route_claim_scope,
            "open_conditions": [k for k,v in route.get("conditions",{}).items() if isinstance(v,str) and v.startswith("OPEN") or v == "OPEN"],
            "note": "Route-specific gate. Open conditions here do not block other routes."
        }
    claims["theorem_gth_by_route"] = theorem_routes
    novelty_blockers = []
    if known.get("exact"):
        novelty_blockers.append("known_family_exact_match")
    if obj.scope != SCOPE_LITERATURE:
        novelty_blockers.append("literature_collision_search_not_verified")
    if primary["research_value_score"] < 0.65:
        novelty_blockers.append("research_value_below_novelty_threshold")
    claims["novelty_gth"] = {
        "status":"BLOCKED" if novelty_blockers else "FIRES",
        "blockers": novelty_blockers,
        "claim":"Novel research seam exists" if not novelty_blockers else "No novelty-grade claim permitted."
    }
    # Proof-target GTH can fire for exact proof debt even when theorem not proven.
    proof_targets = []
    for key, route in routes.items():
        for cond in [k for k,v in route.get("conditions",{}).items() if v == "OPEN" or (isinstance(v,str) and v.startswith("OPEN"))]:
            proof_targets.append({"route":key,"condition":cond,"target":proof_target_for_condition(key, cond)})
    claims["proof_target_gth"] = {
        "status":"FIRES" if proof_targets else "NO_OPEN_TARGETS",
        "targets": proof_targets[:8],
    }
    return claims


def proof_target_for_condition(route: str, cond: str) -> str:
    mapping = {
        ("recurrence","formal_definition_supplied"): "Supply formal recurrence definition or independently generated terms; otherwise claim remains finite-prefix.",
        ("polynomial","formal_definition_supplied"): "Supply formal formula or enough independent generated terms to upgrade Newton certificate.",
        ("primitive_divisor","known_BHV_exception_reconciliation"): "Normalize to Lucas/Lehmer indexing and reconcile prefix exceptions against BHV exception set.",
        ("primitive_divisor","lucas_or_lehmer_normalization"): "Prove sequence is U_n(P,Q), V_n(P,Q), or Lehmer sequence under declared indexing.",
        ("strong_divisibility","all_indices_proof"): "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route.",
        ("lte","LTE_hypotheses_verified"): "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling.",
    }
    return mapping.get((route, cond), f"Close open condition {cond} on route {route}.")

# ---------------------------------------------------------------------------
# External tribunal and handoffs
# ---------------------------------------------------------------------------

def run_cmd(cmd: List[str], timeout: int = 8) -> Dict[str, Any]:
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        return {"returncode":proc.returncode,"stdout":proc.stdout[-4000:],"stderr":proc.stderr[-4000:]}
    except Exception as e:
        return {"error":str(e)}


def external_tribunal(obj: MathObject, outdir: Path, rec: Optional[Dict[str, Any]], poly: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    handoff_dir = ensure_dir(outdir / "handoffs")
    seq = obj.sequence
    sage_path = handoff_dir / f"{obj.label}_tribunal.sage"
    pari_path = handoff_dir / f"{obj.label}_tribunal.gp"
    lean_path = handoff_dir / f"{obj.label}_proof_skeleton.lean"
    sage_path.write_text(generate_sage(seq, rec, poly), encoding="utf-8")
    pari_path.write_text(generate_pari(seq, rec), encoding="utf-8")
    lean_path.write_text(generate_lean(obj, rec, poly), encoding="utf-8")
    tribunal: Dict[str, Any] = {
        "handoffs": {"sage":str(sage_path),"pari_gp":str(pari_path),"lean":str(lean_path)},
        "sage": {"available": bool(shutil.which("sage"))},
        "pari": {"available": bool(shutil.which("gp"))},
        "lean": {"available": bool(shutil.which("lean"))},
        "binding_effects": [],
    }
    if tribunal["sage"]["available"]:
        tribunal["sage"]["run"] = run_cmd(["sage", str(sage_path)])
        tribunal["binding_effects"].append("sage_output_available_for_route_state")
    else:
        tribunal["binding_effects"].append("sage_unavailable_demotes_routes_requiring_number_field_or_factorization_judgment")
    if tribunal["pari"]["available"]:
        tribunal["pari"]["run"] = run_cmd(["gp", "-q", str(pari_path)])
        tribunal["binding_effects"].append("pari_output_available_for_arithmetic_route_state")
    else:
        tribunal["binding_effects"].append("pari_unavailable_blocks_or_demotes_primitive_divisor_and_heavy_factor_routes")
    if tribunal["lean"]["available"]:
        tribunal["lean"]["note"] = "Lean installed; skeleton can be checked manually with Mathlib adaptation."
    return tribunal


def generate_sage(seq: Sequence[int], rec: Optional[Dict[str, Any]], poly: Optional[Dict[str, Any]]) -> str:
    return f"""# Auto-generated Oracle NT OS V6 Sage tribunal
seq = {list(map(int,seq))}
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {json.dumps({k:v for k,v in (rec or {}).items() if k != 'coefficients_fraction'})})
print('polynomial_claim', {json.dumps(poly or {})})
"""


def generate_pari(seq: Sequence[int], rec: Optional[Dict[str, Any]]) -> str:
    return f"""\\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = {list(map(int,seq))};
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {json.dumps({k:v for k,v in (rec or {}).items() if k != 'coefficients_fraction'})});
"""


def generate_lean(obj: MathObject, rec: Optional[Dict[str, Any]], poly: Optional[Dict[str, Any]]) -> str:
    lines = ["/- Auto-generated Oracle NT OS V6 Lean skeleton. Uses sorry as explicit proof debt. -/", "import Mathlib", "", "namespace OracleNT", ""]
    if rec:
        coeffs = rec["coefficients"]
        lines += [
            f"/-- Sequence terms supplied for {obj.label}. Theorem scope: {obj.scope}. -/",
            f"def observed : List Int := {obj.sequence}",
            f"/-- Recurrence coefficients, newest to oldest: {coeffs}. -/",
            "-- TODO: replace observed prefix with formal definition before infinite theorem claim.",
            "theorem recurrence_prefix_certified : True := by",
            "  -- proof debt: machine certificate over finite prefix from Python exact arithmetic",
            "  trivial",
            "",
        ]
        if obj.scope == SCOPE_FORMAL:
            lines += [
                "theorem recurrence_all_indices_formal : True := by",
                "  -- sorry debt: encode formal recurrence, initial values, and induction proof.",
                "  sorry",
                "",
            ]
    if poly:
        lines += [
            f"/-- Newton binomial formula: {poly['formula']} -/",
            "theorem finite_difference_certificate : True := by",
            "  -- sorry debt: finite difference uniqueness / Newton series formalization.",
            "  sorry",
            "",
        ]
    lines += ["end OracleNT", ""]
    return "\n".join(lines)

# ---------------------------------------------------------------------------
# Next action compiler and KBK state machine
# ---------------------------------------------------------------------------

def compile_next_action(obj: MathObject, primary: Dict[str, Any], routes: Dict[str, Any], claims: Dict[str, Any]) -> Dict[str, Any]:
    # Priority: data quality, formal scope blocker, route-specific open target, literature collision, next data.
    if primary["class"] == "data_quality":
        return {"action":"repair_or_verify_suspected_corruption", "reason":"single corruption hypothesis is primary", "command": f"python oracle_nt_os_v6.py analyze-seq --seq '<corrected terms>' --label {obj.label}_corrected --out out"}
    for route_name in ["polynomial", "recurrence", "primitive_divisor", "strong_divisibility", "lte"]:
        route = routes.get(route_name, {})
        for cond, val in route.get("conditions", {}).items():
            if val == "OPEN" or (isinstance(val, str) and val.startswith("OPEN")):
                target = proof_target_for_condition(route_name, cond)
                return {
                    "action": f"close_{route_name}_{cond}",
                    "reason": target,
                    "command": command_for_condition(obj, route_name, cond),
                    "killer_next_data": killer_next_data(obj, route_name, cond),
                }
    if claims["novelty_gth"]["status"] == "BLOCKED" and "literature_collision_search_not_verified" in claims["novelty_gth"]["blockers"]:
        return {"action":"run_literature_collision_search", "reason":"novelty blocked until OEIS/literature collision is checked", "command": f"python oracle_nt_os_v6.py literature-check --seq '{','.join(map(str,obj.sequence[:20]))}' --label {obj.label} --out out"}
    return {"action":"generate_more_terms_or_stop", "reason":"classification complete, no research-grade seam surfaced", "command": f"python oracle_nt_os_v6.py request-data --label {obj.label} --needed-terms {len(obj.sequence)+20}"}


def command_for_condition(obj: MathObject, route: str, cond: str) -> str:
    seq_str = ",".join(map(str, obj.sequence))
    if cond == "formal_definition_supplied":
        return f"python oracle_nt_os_v6.py analyze-seq --seq '{seq_str}' --label {obj.label} --formal-recurrence '<coefficients>' --scope FORMAL_DEFINITION --out out"
    if route == "primitive_divisor":
        return f"python oracle_nt_os_v6.py analyze-seq --seq '{seq_str}' --label {obj.label} --action audit_primitive_divisor --out out"
    if route == "strong_divisibility":
        return f"python oracle_nt_os_v6.py analyze-seq --seq '{seq_str}' --label {obj.label} --action audit_strong_divisibility --out out"
    return f"python oracle_nt_os_v6.py analyze-seq --seq '{seq_str}' --label {obj.label} --action {route}_{cond} --out out"


def killer_next_data(obj: MathObject, route: str, cond: str) -> str:
    n = len(obj.sequence)
    if cond == "formal_definition_supplied":
        return f"Need formal definition OR independently sourced terms a({n})..a({n+20}) to separate finite-prefix fit from infinite law."
    if route == "primitive_divisor":
        return f"Need factorization of terms through theorem index {n+50} and declared Lucas/Lehmer indexing."
    if route == "strong_divisibility":
        return f"Need proof route, not more samples: derive Euclidean recurrence identity or rank-of-apparition theorem. Samples through n={n+30} are secondary."
    return f"Need route-specific data for {route}:{cond}."

# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------

def analyze_object(obj: MathObject, outdir: Path, corpus: Corpus, action: str = "classify", override_kbk: bool = False, quiet_boring: bool = False) -> Dict[str, Any]:
    ensure_dir(outdir)
    fp = fingerprints(obj.sequence) if obj.sequence else {"raw": sha256_text(stable_json(obj.raw))[:16]}
    object_fingerprint = fp.get("raw", sha256_text(stable_json(fp))[:16])
    corpus.upsert_object(obj.object_id, obj.label, obj.object_type, obj.scope, object_fingerprint, dataclasses.asdict(obj))

    required_state = corpus.get_required_action(obj.object_id)
    required_action = required_state["required_action"] if required_state else None
    satisfied = True
    enforcement = {"required_action_entering": required_action, "action_supplied": action, "satisfied": True, "override": override_kbk}
    if required_action and action == "classify" and not override_kbk:
        satisfied = False
        enforcement.update({"satisfied": False, "verdict":"REFUSED_FAKE_LOOP", "message": f"KBK state requires {required_action}; classify-only rerun is blocked. Use --action {required_action} or --override-kbk."})
        report = {"version":VERSION,"object":dataclasses.asdict(obj),"kbk_enforcement":enforcement}
        corpus.record_run(obj.object_id, action, required_action, False, report)
        (outdir / f"{obj.label}_REFUSED_FAKE_LOOP.json").write_text(stable_json(report), encoding="utf-8")
        return report

    known = known_family_match(obj.sequence)
    poly = polynomial_finite_difference(obj.sequence)
    rec = find_linear_recurrence(obj.sequence)
    candidates = invariant_candidates(obj)
    primary = candidates[0]
    routes = build_routes(obj, poly, rec)
    proof = proof_search(obj.sequence, poly, rec)
    tribunal = external_tribunal(obj, outdir, rec, poly)
    claims = route_specific_claims(obj, primary, routes, known, tribunal)
    next_action = compile_next_action(obj, primary, routes, claims)
    corpus.set_required_action(obj.object_id, next_action["action"], next_action["reason"], (required_state["round_no"] + 1 if required_state else 1))

    report = {
        "version": VERSION,
        "timestamp": utc_now(),
        "object": dataclasses.asdict(obj),
        "scope_discipline": {
            "scope": obj.scope,
            "theorem_claim_policy": "Raw observed prefixes cannot produce infinite theorem claims. Formal definition or verified literature source required.",
        },
        "kbk_enforcement": enforcement,
        "fingerprints": fp,
        "known_family_and_literature": known,
        "primary_invariant": primary,
        "all_invariants": candidates,
        "routes": routes,
        "proof_search": proof,
        "external_tribunal": tribunal,
        "claims": claims,
        "next_kbk_action": next_action,
        "boring_classification_suppression": bool(claims["classification_gth"].get("boring_suppression")),
        "claim_sep": build_claim_sep(obj, primary, claims),
    }
    corpus.record_run(obj.object_id, action, required_action, satisfied, report)
    write_outputs(obj, report, outdir, quiet_boring)
    return report


def build_claim_sep(obj: MathObject, primary: Dict[str, Any], claims: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "E_exact_computation": ["finite prefix fits verified by exact integer/rational arithmetic"],
        "COMP_computational": [primary["name"]],
        "COND_conditional": ["infinite theorem claims conditional on formal definition or literature verification"] if obj.scope == SCOPE_FINITE else [],
        "OPEN": [t["target"] for t in claims.get("proof_target_gth",{}).get("targets",[])],
        "BLOCKED": claims.get("novelty_gth",{}).get("blockers",[]),
    }


def write_outputs(obj: MathObject, report: Dict[str, Any], outdir: Path, quiet_boring: bool = False) -> None:
    ensure_dir(outdir)
    (outdir / f"{obj.label}_oracle_v6_report.json").write_text(stable_json(report), encoding="utf-8")
    md = render_markdown(report, quiet_boring=quiet_boring)
    (outdir / f"{obj.label}_oracle_v6_dossier.md").write_text(md, encoding="utf-8")
    (outdir / f"{obj.label}_kbk_packet.json").write_text(stable_json(report["next_kbk_action"]), encoding="utf-8")


def render_markdown(report: Dict[str, Any], quiet_boring: bool = False) -> str:
    obj = report["object"]
    primary = report["primary_invariant"]
    claims = report["claims"]
    boring = report["boring_classification_suppression"]
    lines = [f"# Oracle NT OS V6 Dossier: {obj['label']}", "", f"Version: `{report['version']}`", f"Scope: `{obj['scope']}`", ""]
    if boring and quiet_boring:
        lines += ["## Verdict", "Known/basic classification. No discovery-grade claim emitted.", "", f"Primary invariant: `{primary['name']}`", "", "## Next", report["next_kbk_action"]["reason"], ""]
        return "\n".join(lines)
    lines += ["## Primary invariant", "", f"`{primary['name']}`", "", f"Truth score: `{primary['truth_score']}`", f"Explanation score: `{primary['explanation_score']}`", f"Research value score: `{primary['research_value_score']}`", ""]
    lines += ["## GTH tiers", "", "### Classification", stable_json(claims["classification_gth"]), "", "### Theorem by route", stable_json(claims["theorem_gth_by_route"]), "", "### Novelty", stable_json(claims["novelty_gth"]), "", "### Proof target", stable_json(claims["proof_target_gth"]), ""]
    lines += ["## Next KBK action", "", "```bash", report["next_kbk_action"]["command"], "```", "", report["next_kbk_action"].get("killer_next_data", ""), ""]
    lines += ["## Claim separation", "", stable_json(report["claim_sep"]), ""]
    return "\n".join(lines)

# ---------------------------------------------------------------------------
# Object-native engines: CRT and Diophantine quadratic
# ---------------------------------------------------------------------------

def crt_lab(base1: int, base2: int, c: int, max_modulus: int, outdir: Path, label: str = "crt") -> Dict[str, Any]:
    ensure_dir(outdir)
    primes = primes_upto(max_modulus)
    rows = []
    compatibility_edges = []
    for p in primes:
        ord1 = multiplicative_order(base1 % p, p) if math.gcd(base1, p) == 1 else 1
        ord2 = multiplicative_order(base2 % p, p) if math.gcd(base2, p) == 1 else 1
        zero_pairs = []
        if math.gcd(base1*base2, p) == 1:
            for k in range(ord1):
                a = pow(base1, k, p)
                for l in range(ord2):
                    if (a * pow(base2, l, p) + c) % p == 0:
                        zero_pairs.append((k,l))
        coverage = len(zero_pairs) / max(1, ord1*ord2)
        rows.append({"p":p,"ord_base1":ord1,"ord_base2":ord2,"torus_size":ord1*ord2,"zero_pairs":zero_pairs[:100],"coverage":coverage})
    # Compatibility graph stub: edges when two primes both have zero pairs and CRT product is manageable.
    active = [r for r in rows if r["zero_pairs"]]
    for a,b in itertools.combinations(active[:30], 2):
        compatibility_edges.append({"p":a["p"],"q":b["p"],"compatible":"UNKNOWN_NEEDS_RESIDUE_CLASS_SELECTION", "note":"V6 exposes graph node; exact cover optimizer is next CRT action."})
    uncovered_persistence = [r for r in rows if not r["zero_pairs"]]
    lift_scan = []
    for r in active[:20]:
        p = r["p"]
        pp = p*p
        count = 0
        # scan bounded exponents modulo p(p-1) as a cheap lift sample
        lim = min(200, max(r["ord_base1"],1)*max(r["ord_base2"],1)*p)
        for k in range(lim):
            for l in range(min(lim, 200)):
                if (pow(base1,k,pp)*pow(base2,l,pp)+c) % pp == 0:
                    count += 1
                    break
            if count:
                break
        lift_scan.append({"p":p,"p2_has_sample_lift":bool(count)})
    report = {
        "version":VERSION,
        "object_type":"crt_cover",
        "expression":f"{base1}^k * {base2}^l + ({c})",
        "finite_torus_rows":rows,
        "uncovered_prime_rows":uncovered_persistence[:30],
        "compatibility_graph_edges_sample":compatibility_edges[:100],
        "prime_power_lift_scan":lift_scan,
        "verdict":"RECONNAISSANCE_NOT_COVER_CERTIFICATE",
        "next_kbk_action": {
            "action":"crt_cover_optimizer_and_lift_certificate",
            "reason":"Finite local zero data is not an infinite CRT cover. Need optimized compatible residue-class selection and lift-composability obstruction.",
            "killer_next_data": f"Search moduli among primes <= {max_modulus}, build compatibility graph over zero-pair residue classes, then prove uncovered class or produce cover certificate.",
        }
    }
    (outdir / f"{label}_crt_v6_report.json").write_text(stable_json(report), encoding="utf-8")
    return report


def multiplicative_order(a: int, m: int) -> int:
    if math.gcd(a, m) != 1:
        return 0
    x = 1
    for k in range(1, max(2, m*m)+1):
        x = (x*a) % m
        if x == 1:
            return k
    return 0


def diophantine_quadratic(A: int, B: int, C: int, bound: int, outdir: Path, label: str = "diophantine") -> Dict[str, Any]:
    # Ax^2 + By^2 = C, local obstruction + bounded search.
    ensure_dir(outdir)
    local = []
    for p in primes_upto(50):
        residues = {(A*x*x + B*y*y - C) % p for x in range(p) for y in range(p)}
        solvable = 0 in residues
        local.append({"p":p,"locally_solvable":solvable})
    sols = []
    for x in range(-bound, bound+1):
        for y in range(-bound, bound+1):
            if A*x*x + B*y*y == C:
                sols.append((x,y))
    report = {"version":VERSION,"object_type":"diophantine_quadratic","equation":f"{A}x^2 + {B}y^2 = {C}","local_obstructions":[r for r in local if not r["locally_solvable"]],"solutions_in_box":sols[:200],"next_kbk_action":{"action":"descent_or_local_global_route","reason":"Bounded search is not proof. Use local obstruction if present; otherwise route to quadratic form theory/descent.","killer_next_data":"Increase bound only after local/global route chosen."}}
    (outdir / f"{label}_diophantine_v6_report.json").write_text(stable_json(report), encoding="utf-8")
    return report

# ---------------------------------------------------------------------------
# Literature check hook and request data
# ---------------------------------------------------------------------------

def literature_check(seq: Sequence[int], label: str, outdir: Path) -> Dict[str, Any]:
    ensure_dir(outdir)
    known = known_family_match(seq)
    report = {
        "version":VERSION,
        "label":label,
        "local_known_family":known,
        "oeis_query_url_hint":"https://oeis.org/search?q=" + "%2C".join(map(str, seq[:12])) + "&fmt=json",
        "status":"LOCAL_ONLY_UNLESS_USER_RUNS_ONLINE_OR_PROVIDES_CACHE",
        "verdict":"NOVELTY_STILL_BLOCKED_WITHOUT_VERIFIED_EXTERNAL_COLLISION_SEARCH" if not known.get("exact") else "KNOWN_LOCALLY",
    }
    (outdir / f"{label}_literature_check_v6.json").write_text(stable_json(report), encoding="utf-8")
    return report

# ---------------------------------------------------------------------------
# Benchmarks
# ---------------------------------------------------------------------------

def run_benchmarks(outdir: Path) -> Dict[str, Any]:
    ensure_dir(outdir)
    corpus = Corpus(outdir / "bench_corpus.sqlite")
    tests = []
    def add(name: str, seq: List[int], expect_primary: str, scope: str = SCOPE_FINITE, formal_rec: Optional[List[int]] = None, expect_no_corruption: bool = True, expect_novelty_fire: bool = False):
        tests.append({"name":name,"seq":seq,"expect_primary":expect_primary,"scope":scope,"formal_rec":formal_rec,"expect_no_corruption":expect_no_corruption,"expect_novelty_fire":expect_novelty_fire})
    add("clean_fibonacci_no_corruption", fibs(12), "linear_recurrence", expect_no_corruption=True)
    add("formal_fibonacci_recurrence_scope", fibs(12), "linear_recurrence", scope=SCOPE_FORMAL, formal_rec=[1,1])
    add("squares_primary_polynomial", [n*n for n in range(12)], "polynomial_finite_difference")
    poisoned = [n*n for n in range(12)]; poisoned[-1] += 7
    add("poisoned_terminal_square", poisoned, "single_corruption_over_simple_law", expect_no_corruption=False)
    poisoned_fib = fibs(12); poisoned_fib[7] += 10
    add("poisoned_middle_fibonacci", poisoned_fib, "single_corruption_over_simple_law", expect_no_corruption=False)
    add("powers_known_no_novelty", [2**n for n in range(12)], "linear_recurrence")
    add("triangular_polynomial", [n*(n+1)//2 for n in range(12)], "polynomial_finite_difference")
    add("catalan_known", catalan(10), "known_family_classification")
    # Add hostile friendly/unfriendly cases.
    for d in range(1,6):
        add(f"polynomial_degree_{d}", [sum((k+1)*math.comb(n,k) for k in range(d+1)) for n in range(16)], "polynomial_finite_difference")
    add("periodic", [1,2,3,1,2,3,1,2,3,1,2,3], "periodic_finite_state")
    add("factorials_known", factorials(8), "known_family_classification")
    add("primes_known", primes_first(10), "known_family_classification")
    # recurrence non-polynomial
    seq = [2,3]
    for _ in range(12): seq.append(3*seq[-1]-2*seq[-2])
    add("order2_recurrence", seq, "linear_recurrence")
    # More traps
    for idx in range(10):
        base = [n*n + 3*n + 1 for n in range(14)]
        base[idx % len(base)] += 100 + idx
        add(f"single_poison_poly_{idx}", base, "single_corruption_over_simple_law", expect_no_corruption=False)
    results = []
    for t in tests:
        definition = {}
        if t["formal_rec"]:
            definition["formal_recurrence"] = t["formal_rec"]
        obj = MathObject("sequence", t["name"], t["scope"], t["seq"], definition, {})
        rep = analyze_object(obj, outdir / t["name"], corpus, action="classify", override_kbk=True, quiet_boring=True)
        primary = rep["primary_invariant"]["name"]
        corrupt = primary == "single_corruption_over_simple_law"
        novelty_fire = rep["claims"]["novelty_gth"]["status"] == "FIRES"
        # Scope theorem safety: finite prefix must not route theorem fire.
        finite_theorem_fires = [k for k,v in rep["claims"]["theorem_gth_by_route"].items() if v["gth_status"] == "FIRES_ROUTE_SPECIFIC"] if t["scope"] == SCOPE_FINITE else []
        route_specific_ok = True
        if t["name"] == "formal_fibonacci_recurrence_scope":
            route_specific_ok = rep["claims"]["theorem_gth_by_route"]["recurrence"]["gth_status"] == "FIRES_ROUTE_SPECIFIC"
        ok = primary == t["expect_primary"] and (not t["expect_no_corruption"] or not corrupt) and novelty_fire == t["expect_novelty_fire"] and not finite_theorem_fires and route_specific_ok
        results.append({"name":t["name"],"ok":ok,"primary":primary,"expected":t["expect_primary"],"finite_theorem_fires":finite_theorem_fires,"novelty_fire":novelty_fire,"route_specific_ok":route_specific_ok})
    passed = sum(1 for r in results if r["ok"])
    report = {"version":VERSION,"benchmark":passed,"benchmark_total":len(results),"results":results,"selftest":"PASS" if passed == len(results) else "FAIL"}
    (outdir / "benchmark_v6_report.json").write_text(stable_json(report), encoding="utf-8")
    return report

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cmd_analyze_seq(args: argparse.Namespace) -> Dict[str, Any]:
    outdir = ensure_dir(Path(args.out))
    corpus = Corpus(outdir / "oracle_v6_corpus.sqlite")
    obj = object_from_args(args)
    return analyze_object(obj, outdir, corpus, action=args.action, override_kbk=args.override_kbk, quiet_boring=args.quiet_boring)


def cmd_run(args: argparse.Namespace) -> Dict[str, Any]:
    outdir = ensure_dir(Path(args.out))
    corpus = Corpus(outdir / "oracle_v6_corpus.sqlite")
    obj = object_from_args(args)
    rounds = []
    action = args.action
    for r in range(1, args.rounds+1):
        rep = analyze_object(obj, outdir / f"round_{r}", corpus, action=action, override_kbk=(r == 1 or args.override_kbk), quiet_boring=args.quiet_boring)
        rounds.append({"round":r,"action":action,"primary":rep.get("primary_invariant",{}).get("name"),"next":rep.get("next_kbk_action")})
        nxt = rep.get("next_kbk_action",{}).get("action")
        if not nxt:
            break
        action = nxt
    report = {"version":VERSION,"rounds":rounds,"final_action_required":rounds[-1]["next"] if rounds else None}
    (outdir / "oracle_v6_run_summary.json").write_text(stable_json(report), encoding="utf-8")
    return report


def cmd_selftest(args: argparse.Namespace) -> Dict[str, Any]:
    outdir = ensure_dir(Path(args.out))
    bench = run_benchmarks(outdir / "benchmark")
    # Explicit targeted checks from V5 teardown.
    corpus = Corpus(outdir / "targeted.sqlite")
    fib_obj = MathObject("sequence","target_fib",SCOPE_FINITE,fibs(12),{}, {})
    fib_rep = analyze_object(fib_obj, outdir / "target_fib", corpus, override_kbk=True, quiet_boring=True)
    formal_obj = MathObject("sequence","target_formal_fib",SCOPE_FORMAL,fibs(12),{"formal_recurrence":[1,1]}, {})
    formal_rep = analyze_object(formal_obj, outdir / "target_formal_fib", corpus, override_kbk=True, quiet_boring=True)
    poison = [n*n for n in range(12)]; poison[-1] += 5
    poison_rep = analyze_object(MathObject("sequence","target_poison_square",SCOPE_FINITE,poison,{},{}), outdir / "target_poison_square", corpus, override_kbk=True, quiet_boring=True)
    summary = {
        "version":VERSION,
        "benchmark": bench["benchmark"],
        "benchmark_total": bench["benchmark_total"],
        "clean_fib_false_corruption": fib_rep["primary_invariant"]["name"] == "single_corruption_over_simple_law",
        "finite_prefix_theorem_fires": [k for k,v in fib_rep["claims"]["theorem_gth_by_route"].items() if v["gth_status"] == "FIRES_ROUTE_SPECIFIC"],
        "formal_recurrence_route_fires": formal_rep["claims"]["theorem_gth_by_route"]["recurrence"]["gth_status"] == "FIRES_ROUTE_SPECIFIC",
        "poisoned_square_detected": poison_rep["primary_invariant"]["name"] == "single_corruption_over_simple_law",
        "selftest":"PASS" if bench["selftest"] == "PASS" and fib_rep["primary_invariant"]["name"] != "single_corruption_over_simple_law" and not [k for k,v in fib_rep["claims"]["theorem_gth_by_route"].items() if v["gth_status"] == "FIRES_ROUTE_SPECIFIC"] and formal_rep["claims"]["theorem_gth_by_route"]["recurrence"]["gth_status"] == "FIRES_ROUTE_SPECIFIC" and poison_rep["primary_invariant"]["name"] == "single_corruption_over_simple_law" else "FAIL",
    }
    (outdir / "selftest_v6_summary.json").write_text(stable_json(summary), encoding="utf-8")
    print(stable_json(summary))
    return summary


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Oracle Number Theory OS V6")
    sub = p.add_subparsers(dest="cmd", required=True)
    def add_seq_args(q: argparse.ArgumentParser) -> None:
        q.add_argument("--seq", required=True)
        q.add_argument("--label", default="object")
        q.add_argument("--out", default="out")
        q.add_argument("--scope", choices=[SCOPE_FINITE,SCOPE_GENERATED,SCOPE_FORMAL,SCOPE_LITERATURE], default=None)
        q.add_argument("--formal-recurrence", default=None, help="Comma-separated recurrence coefficients, newest to oldest")
        q.add_argument("--formal-formula", default=None)
        q.add_argument("--literature-verified", action="store_true")
        q.add_argument("--action", default="classify")
        q.add_argument("--override-kbk", action="store_true")
        q.add_argument("--quiet-boring", action="store_true")
    a = sub.add_parser("analyze-seq"); add_seq_args(a); a.set_defaults(func=cmd_analyze_seq)
    r = sub.add_parser("run"); add_seq_args(r); r.add_argument("--rounds", type=int, default=5); r.set_defaults(func=cmd_run)
    c = sub.add_parser("crt-lab"); c.add_argument("--base1", type=int, required=True); c.add_argument("--base2", type=int, required=True); c.add_argument("--c", type=int, default=1); c.add_argument("--max-modulus", type=int, default=200); c.add_argument("--out", default="crt_out"); c.add_argument("--label", default="crt"); c.set_defaults(func=lambda args: crt_lab(args.base1,args.base2,args.c,args.max_modulus,ensure_dir(Path(args.out)),args.label))
    d = sub.add_parser("diophantine-quadratic"); d.add_argument("--A", type=int, required=True); d.add_argument("--B", type=int, required=True); d.add_argument("--C", type=int, required=True); d.add_argument("--bound", type=int, default=50); d.add_argument("--out", default="dio_out"); d.add_argument("--label", default="diophantine"); d.set_defaults(func=lambda args: diophantine_quadratic(args.A,args.B,args.C,args.bound,ensure_dir(Path(args.out)),args.label))
    l = sub.add_parser("literature-check"); l.add_argument("--seq", required=True); l.add_argument("--label", default="object"); l.add_argument("--out", default="out"); l.set_defaults(func=lambda args: literature_check(parse_int_sequence(args.seq), args.label, ensure_dir(Path(args.out))))
    b = sub.add_parser("selftest"); b.add_argument("--out", default="selftest_v6_out"); b.set_defaults(func=cmd_selftest)
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    res = args.func(args)
    if args.cmd not in ("selftest",):
        print(stable_json({"status":"ok", "version":VERSION, "summary": summarize_cli(res)}))
    return 0


def summarize_cli(res: Dict[str, Any]) -> Dict[str, Any]:
    if "primary_invariant" in res:
        return {"primary":res["primary_invariant"]["name"],"scope":res["object"]["scope"],"next_action":res["next_kbk_action"]["action"],"novelty":res["claims"]["novelty_gth"]["status"]}
    if "verdict" in res:
        return {"verdict":res.get("verdict"),"next_action":res.get("next_kbk_action",{}).get("action")}
    return {k:res[k] for k in list(res)[:5]}

if __name__ == "__main__":
    raise SystemExit(main())
