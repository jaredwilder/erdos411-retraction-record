# Oracle NT OS V6 Dossier: single_poison_poly_5

Version: `6.0.0-oracle-nt-os`
Scope: `FINITE_PREFIX`

## Primary invariant

`single_corruption_over_simple_law`

Truth score: `0.9`
Explanation score: `0.88`
Research value score: `0.358`

## GTH tiers

### Classification
{
  "boring_suppression": false,
  "claim": "Object classifies primarily as single_corruption_over_simple_law on scope FINITE_PREFIX.",
  "stakes": "medium",
  "status": "FIRES_LOW_STAKES"
}

### Theorem by route
{
  "lte": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "GTH_BLOCKED_BY_OPEN_CONDITION",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "LTE_hypotheses_verified"
    ],
    "route_status": "OBSERVED_ONLY"
  },
  "polynomial": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [],
    "route_status": "NOT_APPLICABLE"
  },
  "primitive_divisor": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_TRIBUNAL_UNAVAILABLE_FOR_ROUTE",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [],
    "route_status": "NOT_APPLICABLE"
  },
  "recurrence": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [],
    "route_status": "NOT_APPLICABLE"
  },
  "strong_divisibility": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "all_indices_proof"
    ],
    "route_status": "FAILED_ON_PREFIX"
  }
}

### Novelty
{
  "blockers": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "claim": "No novelty-grade claim permitted.",
  "status": "BLOCKED"
}

### Proof target
{
  "status": "FIRES",
  "targets": [
    {
      "condition": "all_indices_proof",
      "route": "strong_divisibility",
      "target": "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route."
    },
    {
      "condition": "LTE_hypotheses_verified",
      "route": "lte",
      "target": "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
    }
  ]
}

## Next KBK action

```bash
python oracle_nt_os_v6.py analyze-seq --seq '<corrected terms>' --label single_poison_poly_5_corrected --out out
```



## Claim separation

{
  "BLOCKED": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "COMP_computational": [
    "single_corruption_over_simple_law"
  ],
  "COND_conditional": [
    "infinite theorem claims conditional on formal definition or literature verification"
  ],
  "E_exact_computation": [
    "finite prefix fits verified by exact integer/rational arithmetic"
  ],
  "OPEN": [
    "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route.",
    "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
  ]
}
