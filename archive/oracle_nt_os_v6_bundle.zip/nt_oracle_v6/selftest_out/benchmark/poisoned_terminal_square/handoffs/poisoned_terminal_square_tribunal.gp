\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 128];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {});
