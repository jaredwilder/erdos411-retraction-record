# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 5, 11, 19, 29, 146, 55, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 13, "constant_difference": 135135, "binomial_basis_coefficients": [1, 4, 2, 0, 0, 105, -630, 2205, -5880, 13230, -26460, 48510, -83160, 135135], "formula": "(1)*C(n,0) + (4)*C(n,1) + (2)*C(n,2) + (105)*C(n,5) + (-630)*C(n,6) + (2205)*C(n,7) + (-5880)*C(n,8) + (13230)*C(n,9) + (-26460)*C(n,10) + (48510)*C(n,11) + (-83160)*C(n,12) + (135135)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
