\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 5, 11, 19, 29, 146, 55, 71, 89, 109, 131, 155, 181, 209];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {});
