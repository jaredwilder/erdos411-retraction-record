# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 9, "constant_difference": -237, "binomial_basis_coefficients": [2, 1, 1, -1, 3, -9, 23, -53, 115, -237], "formula": "(2)*C(n,0) + (1)*C(n,1) + (1)*C(n,2) + (-1)*C(n,3) + (3)*C(n,4) + (-9)*C(n,5) + (23)*C(n,6) + (-53)*C(n,7) + (115)*C(n,8) + (-237)*C(n,9)", "verified_terms": 10, "certificate": "constant finite difference and Newton binomial basis formula produced"})
