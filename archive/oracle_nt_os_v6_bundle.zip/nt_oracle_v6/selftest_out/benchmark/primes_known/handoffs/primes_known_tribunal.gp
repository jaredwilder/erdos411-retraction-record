\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {});
