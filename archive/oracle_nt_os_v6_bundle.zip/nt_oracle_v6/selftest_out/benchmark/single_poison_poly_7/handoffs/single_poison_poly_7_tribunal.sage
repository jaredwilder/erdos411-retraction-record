# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 5, 11, 19, 29, 41, 55, 178, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 13, "constant_difference": 183612, "binomial_basis_coefficients": [1, 4, 2, 0, 0, 0, 0, 107, -856, 3852, -12840, 35310, -84744, 183612], "formula": "(1)*C(n,0) + (4)*C(n,1) + (2)*C(n,2) + (107)*C(n,7) + (-856)*C(n,8) + (3852)*C(n,9) + (-12840)*C(n,10) + (35310)*C(n,11) + (-84744)*C(n,12) + (183612)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
