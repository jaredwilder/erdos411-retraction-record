# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 3, 8, 16, 27, 41, 58, 78, 101, 127, 156, 188, 223, 261, 302, 346]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 3, "coefficients": ["3", "-3", "1"], "char_poly_coeffs": ["1", "-3", "3", "-1"], "equations": 13, "unknowns": 3, "margin": 10, "minimal_on_prefix": true, "verified_terms": 16})
print('polynomial_claim', {"degree": 2, "constant_difference": 3, "binomial_basis_coefficients": [1, 2, 3], "formula": "(1)*C(n,0) + (2)*C(n,1) + (3)*C(n,2)", "verified_terms": 16, "certificate": "constant finite difference and Newton binomial basis formula produced"})
