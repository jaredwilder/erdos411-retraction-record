# Oracle NT OS V6 Dossier: factorials_known

Version: `6.0.0-oracle-nt-os`
Scope: `FINITE_PREFIX`

## Verdict
Known/basic classification. No discovery-grade claim emitted.

Primary invariant: `p_adic_valuation_profile`

## Next
Supply formal formula or enough independent generated terms to upgrade Newton certificate.
