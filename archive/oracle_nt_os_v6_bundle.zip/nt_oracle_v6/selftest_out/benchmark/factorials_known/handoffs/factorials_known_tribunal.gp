\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 1, 2, 6, 24, 120, 720, 5040];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {});
