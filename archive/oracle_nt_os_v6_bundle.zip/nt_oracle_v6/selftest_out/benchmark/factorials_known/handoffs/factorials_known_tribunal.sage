# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 1, 2, 6, 24, 120, 720, 5040]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 7, "constant_difference": 1854, "binomial_basis_coefficients": [1, 0, 1, 2, 9, 44, 265, 1854], "formula": "(1)*C(n,0) + (1)*C(n,2) + (2)*C(n,3) + (9)*C(n,4) + (44)*C(n,5) + (265)*C(n,6) + (1854)*C(n,7)", "verified_terms": 8, "certificate": "constant finite difference and Newton binomial basis formula produced"})
