# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 5, 113, 19, 29, 41, 55, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 6, "coefficients": ["3", "-3", "1", "0", "0", "0"], "char_poly_coeffs": ["1", "-3", "3", "-1", "0", "0", "0"], "equations": 8, "unknowns": 6, "margin": 2, "minimal_on_prefix": true, "verified_terms": 14})
print('polynomial_claim', {"degree": 13, "constant_difference": -7956, "binomial_basis_coefficients": [1, 4, 104, -306, 612, -1020, 1530, -2142, 2856, -3672, 4590, -5610, 6732, -7956], "formula": "(1)*C(n,0) + (4)*C(n,1) + (104)*C(n,2) + (-306)*C(n,3) + (612)*C(n,4) + (-1020)*C(n,5) + (1530)*C(n,6) + (-2142)*C(n,7) + (2856)*C(n,8) + (-3672)*C(n,9) + (4590)*C(n,10) + (-5610)*C(n,11) + (6732)*C(n,12) + (-7956)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
