# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 5, 11, 19, 29, 41, 55, 71, 197, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 13, "constant_difference": -138996, "binomial_basis_coefficients": [1, 4, 2, 0, 0, 0, 0, 0, 108, -972, 4860, -17820, 53460, -138996], "formula": "(1)*C(n,0) + (4)*C(n,1) + (2)*C(n,2) + (108)*C(n,8) + (-972)*C(n,9) + (4860)*C(n,10) + (-17820)*C(n,11) + (53460)*C(n,12) + (-138996)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
