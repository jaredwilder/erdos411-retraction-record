\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 1, 2, 3, 5, 8, 13, 31, 34, 55, 89, 144];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {});
