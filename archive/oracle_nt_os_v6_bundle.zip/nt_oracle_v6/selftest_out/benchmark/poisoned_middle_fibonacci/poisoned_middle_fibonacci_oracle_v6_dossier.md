# Oracle NT OS V6 Dossier: poisoned_middle_fibonacci

Version: `6.0.0-oracle-nt-os`
Scope: `FINITE_PREFIX`

## Primary invariant

`p_adic_valuation_profile`

Truth score: `0.72`
Explanation score: `0.38`
Research value score: `0.033`

## GTH tiers

### Classification
{
  "boring_suppression": false,
  "claim": "Object classifies primarily as p_adic_valuation_profile on scope FINITE_PREFIX.",
  "stakes": "medium",
  "status": "BLOCKED"
}

### Theorem by route
{
  "lte": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "GTH_BLOCKED_BY_OPEN_CONDITION",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "LTE_hypotheses_verified"
    ],
    "route_status": "OBSERVED_ONLY"
  },
  "polynomial": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_PREFIX_ONLY",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "formal_definition_supplied"
    ],
    "route_status": "PREFIX_CERTIFIED"
  },
  "primitive_divisor": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_TRIBUNAL_UNAVAILABLE_FOR_ROUTE",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [],
    "route_status": "NOT_APPLICABLE"
  },
  "recurrence": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [],
    "route_status": "NOT_APPLICABLE"
  },
  "strong_divisibility": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "all_indices_proof"
    ],
    "route_status": "FAILED_ON_PREFIX"
  }
}

### Novelty
{
  "blockers": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "claim": "No novelty-grade claim permitted.",
  "status": "BLOCKED"
}

### Proof target
{
  "status": "FIRES",
  "targets": [
    {
      "condition": "formal_definition_supplied",
      "route": "polynomial",
      "target": "Supply formal formula or enough independent generated terms to upgrade Newton certificate."
    },
    {
      "condition": "all_indices_proof",
      "route": "strong_divisibility",
      "target": "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route."
    },
    {
      "condition": "LTE_hypotheses_verified",
      "route": "lte",
      "target": "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
    }
  ]
}

## Next KBK action

```bash
python oracle_nt_os_v6.py analyze-seq --seq '1,1,2,3,5,8,13,31,34,55,89,144' --label poisoned_middle_fibonacci --formal-recurrence '<coefficients>' --scope FORMAL_DEFINITION --out out
```

Need formal definition OR independently sourced terms a(12)..a(32) to separate finite-prefix fit from infinite law.

## Claim separation

{
  "BLOCKED": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "COMP_computational": [
    "p_adic_valuation_profile"
  ],
  "COND_conditional": [
    "infinite theorem claims conditional on formal definition or literature verification"
  ],
  "E_exact_computation": [
    "finite prefix fits verified by exact integer/rational arithmetic"
  ],
  "OPEN": [
    "Supply formal formula or enough independent generated terms to upgrade Newton certificate.",
    "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route.",
    "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
  ]
}
