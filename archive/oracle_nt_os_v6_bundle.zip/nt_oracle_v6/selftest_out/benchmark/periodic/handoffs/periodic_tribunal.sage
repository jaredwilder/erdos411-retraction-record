# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 2, 3, 1, 2, 3, 1, 2, 3, 1, 2, 3]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 3, "coefficients": ["0", "0", "1"], "char_poly_coeffs": ["1", "0", "0", "-1"], "equations": 9, "unknowns": 3, "margin": 6, "minimal_on_prefix": true, "verified_terms": 12})
print('polynomial_claim', {"degree": 11, "constant_difference": 486, "binomial_basis_coefficients": [1, 1, 0, -3, 9, -18, 27, -27, 0, 81, -243, 486], "formula": "(1)*C(n,0) + (1)*C(n,1) + (-3)*C(n,3) + (9)*C(n,4) + (-18)*C(n,5) + (27)*C(n,6) + (-27)*C(n,7) + (81)*C(n,9) + (-243)*C(n,10) + (486)*C(n,11)", "verified_terms": 12, "certificate": "constant finite difference and Newton binomial basis formula produced"})
