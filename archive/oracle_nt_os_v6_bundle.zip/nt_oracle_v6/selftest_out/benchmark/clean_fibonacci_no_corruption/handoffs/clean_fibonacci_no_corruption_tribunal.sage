# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 2, "coefficients": ["1", "1"], "char_poly_coeffs": ["1", "-1", "-1"], "equations": 10, "unknowns": 2, "margin": 8, "minimal_on_prefix": true, "verified_terms": 12})
print('polynomial_claim', {"degree": 11, "constant_difference": -55, "binomial_basis_coefficients": [1, 0, 1, -1, 2, -3, 5, -8, 13, -21, 34, -55], "formula": "(1)*C(n,0) + (1)*C(n,2) + (-1)*C(n,3) + (2)*C(n,4) + (-3)*C(n,5) + (5)*C(n,6) + (-8)*C(n,7) + (13)*C(n,8) + (-21)*C(n,9) + (34)*C(n,10) + (-55)*C(n,11)", "verified_terms": 12, "certificate": "constant finite difference and Newton binomial basis formula produced"})
