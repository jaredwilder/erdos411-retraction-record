\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 2, "coefficients": ["1", "1"], "char_poly_coeffs": ["1", "-1", "-1"], "equations": 10, "unknowns": 2, "margin": 8, "minimal_on_prefix": true, "verified_terms": 12});
