# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 5, 11, 19, 29, 41, 161, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 13, "constant_difference": -181896, "binomial_basis_coefficients": [1, 4, 2, 0, 0, 0, 106, -742, 2968, -8904, 22260, -48972, 97944, -181896], "formula": "(1)*C(n,0) + (4)*C(n,1) + (2)*C(n,2) + (106)*C(n,6) + (-742)*C(n,7) + (2968)*C(n,8) + (-8904)*C(n,9) + (22260)*C(n,10) + (-48972)*C(n,11) + (97944)*C(n,12) + (-181896)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
