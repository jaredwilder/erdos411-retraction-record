\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 3, 8, 20, 48, 106, 213, 393, 675, 1093, 1686, 2498, 3578, 4980, 6763, 8991];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 5, "coefficients": ["5", "-10", "10", "-5", "1"], "char_poly_coeffs": ["1", "-5", "10", "-10", "5", "-1"], "equations": 11, "unknowns": 5, "margin": 6, "minimal_on_prefix": true, "verified_terms": 16});
