# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 3, 8, 20, 48, 106, 213, 393, 675, 1093, 1686, 2498, 3578, 4980, 6763, 8991]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 5, "coefficients": ["5", "-10", "10", "-5", "1"], "char_poly_coeffs": ["1", "-5", "10", "-10", "5", "-1"], "equations": 11, "unknowns": 5, "margin": 6, "minimal_on_prefix": true, "verified_terms": 16})
print('polynomial_claim', {"degree": 4, "constant_difference": 5, "binomial_basis_coefficients": [1, 2, 3, 4, 5], "formula": "(1)*C(n,0) + (2)*C(n,1) + (3)*C(n,2) + (4)*C(n,3) + (5)*C(n,4)", "verified_terms": 16, "certificate": "constant finite difference and Newton binomial basis formula produced"})
