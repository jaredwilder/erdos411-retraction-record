\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 1, 2, 5, 14, 42, 132, 429, 1430, 4862];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {});
