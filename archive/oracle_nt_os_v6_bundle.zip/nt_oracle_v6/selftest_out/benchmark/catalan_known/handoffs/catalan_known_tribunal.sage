# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 1, 2, 5, 14, 42, 132, 429, 1430, 4862]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 9, "constant_difference": 232, "binomial_basis_coefficients": [1, 0, 1, 1, 3, 6, 15, 36, 91, 232], "formula": "(1)*C(n,0) + (1)*C(n,2) + (1)*C(n,3) + (3)*C(n,4) + (6)*C(n,5) + (15)*C(n,6) + (36)*C(n,7) + (91)*C(n,8) + (232)*C(n,9)", "verified_terms": 10, "certificate": "constant finite difference and Newton binomial basis formula produced"})
