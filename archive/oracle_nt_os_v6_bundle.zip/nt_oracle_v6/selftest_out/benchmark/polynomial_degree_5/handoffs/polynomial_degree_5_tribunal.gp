\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 3, 8, 20, 48, 112, 249, 519, 1011, 1849, 3198, 5270, 8330, 12702, 18775, 27009];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 6, "coefficients": ["6", "-15", "20", "-15", "6", "-1"], "char_poly_coeffs": ["1", "-6", "15", "-20", "15", "-6", "1"], "equations": 10, "unknowns": 6, "margin": 4, "minimal_on_prefix": true, "verified_terms": 16});
