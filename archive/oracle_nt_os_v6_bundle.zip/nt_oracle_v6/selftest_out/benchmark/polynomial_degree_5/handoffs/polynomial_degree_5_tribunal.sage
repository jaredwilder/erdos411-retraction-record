# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 3, 8, 20, 48, 112, 249, 519, 1011, 1849, 3198, 5270, 8330, 12702, 18775, 27009]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 6, "coefficients": ["6", "-15", "20", "-15", "6", "-1"], "char_poly_coeffs": ["1", "-6", "15", "-20", "15", "-6", "1"], "equations": 10, "unknowns": 6, "margin": 4, "minimal_on_prefix": true, "verified_terms": 16})
print('polynomial_claim', {"degree": 5, "constant_difference": 6, "binomial_basis_coefficients": [1, 2, 3, 4, 5, 6], "formula": "(1)*C(n,0) + (2)*C(n,1) + (3)*C(n,2) + (4)*C(n,3) + (5)*C(n,4) + (6)*C(n,5)", "verified_terms": 16, "certificate": "constant finite difference and Newton binomial basis formula produced"})
