# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [101, 5, 11, 19, 29, 41, 55, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 4, "coefficients": ["3", "-3", "1", "0"], "char_poly_coeffs": ["1", "-3", "3", "-1", "0"], "equations": 10, "unknowns": 4, "margin": 6, "minimal_on_prefix": true, "verified_terms": 14})
print('polynomial_claim', {"degree": 13, "constant_difference": -100, "binomial_basis_coefficients": [101, -96, 102, -100, 100, -100, 100, -100, 100, -100, 100, -100, 100, -100], "formula": "(101)*C(n,0) + (-96)*C(n,1) + (102)*C(n,2) + (-100)*C(n,3) + (100)*C(n,4) + (-100)*C(n,5) + (100)*C(n,6) + (-100)*C(n,7) + (100)*C(n,8) + (-100)*C(n,9) + (100)*C(n,10) + (-100)*C(n,11) + (100)*C(n,12) + (-100)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
