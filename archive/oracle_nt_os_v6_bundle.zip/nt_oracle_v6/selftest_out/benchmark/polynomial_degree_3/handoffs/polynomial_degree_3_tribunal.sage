# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 3, 8, 20, 43, 81, 138, 218, 325, 463, 636, 848, 1103, 1405, 1758, 2166]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 4, "coefficients": ["4", "-6", "4", "-1"], "char_poly_coeffs": ["1", "-4", "6", "-4", "1"], "equations": 12, "unknowns": 4, "margin": 8, "minimal_on_prefix": true, "verified_terms": 16})
print('polynomial_claim', {"degree": 3, "constant_difference": 4, "binomial_basis_coefficients": [1, 2, 3, 4], "formula": "(1)*C(n,0) + (2)*C(n,1) + (3)*C(n,2) + (4)*C(n,3)", "verified_terms": 16, "certificate": "constant finite difference and Newton binomial basis formula produced"})
