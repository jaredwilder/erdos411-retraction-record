\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 3, 8, 20, 43, 81, 138, 218, 325, 463, 636, 848, 1103, 1405, 1758, 2166];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 4, "coefficients": ["4", "-6", "4", "-1"], "char_poly_coeffs": ["1", "-4", "6", "-4", "1"], "equations": 12, "unknowns": 4, "margin": 8, "minimal_on_prefix": true, "verified_terms": 16});
