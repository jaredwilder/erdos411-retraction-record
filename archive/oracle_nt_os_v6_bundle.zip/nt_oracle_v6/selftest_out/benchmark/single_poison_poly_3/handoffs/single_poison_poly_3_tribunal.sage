# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 5, 11, 122, 29, 41, 55, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 13, "constant_difference": 29458, "binomial_basis_coefficients": [1, 4, 2, 103, -412, 1030, -2060, 3605, -5768, 8652, -12360, 16995, -22660, 29458], "formula": "(1)*C(n,0) + (4)*C(n,1) + (2)*C(n,2) + (103)*C(n,3) + (-412)*C(n,4) + (1030)*C(n,5) + (-2060)*C(n,6) + (3605)*C(n,7) + (-5768)*C(n,8) + (8652)*C(n,9) + (-12360)*C(n,10) + (16995)*C(n,11) + (-22660)*C(n,12) + (29458)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
