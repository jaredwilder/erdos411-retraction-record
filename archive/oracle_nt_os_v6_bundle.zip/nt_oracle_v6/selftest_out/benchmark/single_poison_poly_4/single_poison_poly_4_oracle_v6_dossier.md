# Oracle NT OS V6 Dossier: single_poison_poly_4

Version: `6.0.0-oracle-nt-os`
Scope: `FINITE_PREFIX`

## Primary invariant

`polynomial_finite_difference`

Truth score: `1.0`
Explanation score: `0.0`
Research value score: `0.0125`

## GTH tiers

### Classification
{
  "boring_suppression": false,
  "claim": "Object classifies primarily as polynomial_finite_difference on scope FINITE_PREFIX.",
  "stakes": "medium",
  "status": "FIRES_LOW_STAKES"
}

### Theorem by route
{
  "lte": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "GTH_BLOCKED_BY_OPEN_CONDITION",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "LTE_hypotheses_verified"
    ],
    "route_status": "OBSERVED_ONLY"
  },
  "polynomial": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_PREFIX_ONLY",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "formal_definition_supplied"
    ],
    "route_status": "PREFIX_CERTIFIED"
  },
  "primitive_divisor": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_TRIBUNAL_UNAVAILABLE_FOR_ROUTE",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [],
    "route_status": "NOT_APPLICABLE"
  },
  "recurrence": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [],
    "route_status": "NOT_APPLICABLE"
  },
  "strong_divisibility": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "all_indices_proof"
    ],
    "route_status": "FAILED_ON_PREFIX"
  }
}

### Novelty
{
  "blockers": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "claim": "No novelty-grade claim permitted.",
  "status": "BLOCKED"
}

### Proof target
{
  "status": "FIRES",
  "targets": [
    {
      "condition": "formal_definition_supplied",
      "route": "polynomial",
      "target": "Supply formal formula or enough independent generated terms to upgrade Newton certificate."
    },
    {
      "condition": "all_indices_proof",
      "route": "strong_divisibility",
      "target": "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route."
    },
    {
      "condition": "LTE_hypotheses_verified",
      "route": "lte",
      "target": "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
    }
  ]
}

## Next KBK action

```bash
python oracle_nt_os_v6.py analyze-seq --seq '1,5,11,19,133,41,55,71,89,109,131,155,181,209' --label single_poison_poly_4 --formal-recurrence '<coefficients>' --scope FORMAL_DEFINITION --out out
```

Need formal definition OR independently sourced terms a(14)..a(34) to separate finite-prefix fit from infinite law.

## Claim separation

{
  "BLOCKED": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "COMP_computational": [
    "polynomial_finite_difference"
  ],
  "COND_conditional": [
    "infinite theorem claims conditional on formal definition or literature verification"
  ],
  "E_exact_computation": [
    "finite prefix fits verified by exact integer/rational arithmetic"
  ],
  "OPEN": [
    "Supply formal formula or enough independent generated terms to upgrade Newton certificate.",
    "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route.",
    "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
  ]
}
