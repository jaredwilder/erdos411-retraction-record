# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 5, 11, 19, 133, 41, 55, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 13, "constant_difference": -74360, "binomial_basis_coefficients": [1, 4, 2, 0, 104, -520, 1560, -3640, 7280, -13104, 21840, -34320, 51480, -74360], "formula": "(1)*C(n,0) + (4)*C(n,1) + (2)*C(n,2) + (104)*C(n,4) + (-520)*C(n,5) + (1560)*C(n,6) + (-3640)*C(n,7) + (7280)*C(n,8) + (-13104)*C(n,9) + (21840)*C(n,10) + (-34320)*C(n,11) + (51480)*C(n,12) + (-74360)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
