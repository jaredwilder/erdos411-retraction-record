\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [2, 3, 5, 9, 17, 33, 65, 129, 257, 513, 1025, 2049, 4097, 8193];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 2, "coefficients": ["3", "-2"], "char_poly_coeffs": ["1", "-3", "2"], "equations": 12, "unknowns": 2, "margin": 10, "minimal_on_prefix": true, "verified_terms": 14});
