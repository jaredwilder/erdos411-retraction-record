# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [2, 3, 5, 9, 17, 33, 65, 129, 257, 513, 1025, 2049, 4097, 8193]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 2, "coefficients": ["3", "-2"], "char_poly_coeffs": ["1", "-3", "2"], "equations": 12, "unknowns": 2, "margin": 10, "minimal_on_prefix": true, "verified_terms": 14})
print('polynomial_claim', {"degree": 13, "constant_difference": 1, "binomial_basis_coefficients": [2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], "formula": "(2)*C(n,0) + (1)*C(n,1) + (1)*C(n,2) + (1)*C(n,3) + (1)*C(n,4) + (1)*C(n,5) + (1)*C(n,6) + (1)*C(n,7) + (1)*C(n,8) + (1)*C(n,9) + (1)*C(n,10) + (1)*C(n,11) + (1)*C(n,12) + (1)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
