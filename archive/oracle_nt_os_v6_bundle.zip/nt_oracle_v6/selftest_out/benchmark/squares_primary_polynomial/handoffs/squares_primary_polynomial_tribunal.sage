# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 3, "coefficients": ["3", "-3", "1"], "char_poly_coeffs": ["1", "-3", "3", "-1"], "equations": 9, "unknowns": 3, "margin": 6, "minimal_on_prefix": true, "verified_terms": 12})
print('polynomial_claim', {"degree": 2, "constant_difference": 2, "binomial_basis_coefficients": [0, 1, 2], "formula": "(1)*C(n,1) + (2)*C(n,2)", "verified_terms": 12, "certificate": "constant finite difference and Newton binomial basis formula produced"})
