\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 3, "coefficients": ["3", "-3", "1"], "char_poly_coeffs": ["1", "-3", "3", "-1"], "equations": 9, "unknowns": 3, "margin": 6, "minimal_on_prefix": true, "verified_terms": 12});
