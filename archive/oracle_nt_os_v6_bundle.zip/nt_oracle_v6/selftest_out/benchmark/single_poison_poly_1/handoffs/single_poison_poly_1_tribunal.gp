\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 106, 11, 19, 29, 41, 55, 71, 89, 109, 131, 155, 181, 209];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 5, "coefficients": ["3", "-3", "1", "0", "0"], "char_poly_coeffs": ["1", "-3", "3", "-1", "0", "0"], "equations": 9, "unknowns": 5, "margin": 4, "minimal_on_prefix": true, "verified_terms": 14});
