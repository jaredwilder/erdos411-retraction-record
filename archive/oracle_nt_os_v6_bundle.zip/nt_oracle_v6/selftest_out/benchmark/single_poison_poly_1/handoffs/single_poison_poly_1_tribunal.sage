# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 106, 11, 19, 29, 41, 55, 71, 89, 109, 131, 155, 181, 209]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 5, "coefficients": ["3", "-3", "1", "0", "0"], "char_poly_coeffs": ["1", "-3", "3", "-1", "0", "0"], "equations": 9, "unknowns": 5, "margin": 4, "minimal_on_prefix": true, "verified_terms": 14})
print('polynomial_claim', {"degree": 13, "constant_difference": 1313, "binomial_basis_coefficients": [1, 105, -200, 303, -404, 505, -606, 707, -808, 909, -1010, 1111, -1212, 1313], "formula": "(1)*C(n,0) + (105)*C(n,1) + (-200)*C(n,2) + (303)*C(n,3) + (-404)*C(n,4) + (505)*C(n,5) + (-606)*C(n,6) + (707)*C(n,7) + (-808)*C(n,8) + (909)*C(n,9) + (-1010)*C(n,10) + (1111)*C(n,11) + (-1212)*C(n,12) + (1313)*C(n,13)", "verified_terms": 14, "certificate": "constant finite difference and Newton binomial basis formula produced"})
