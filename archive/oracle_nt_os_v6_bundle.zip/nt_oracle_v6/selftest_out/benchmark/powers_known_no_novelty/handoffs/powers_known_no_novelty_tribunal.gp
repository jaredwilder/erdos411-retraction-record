\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 1, "coefficients": ["2"], "char_poly_coeffs": ["1", "-2"], "equations": 11, "unknowns": 1, "margin": 10, "minimal_on_prefix": true, "verified_terms": 12});
