# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 1, "coefficients": ["2"], "char_poly_coeffs": ["1", "-2"], "equations": 11, "unknowns": 1, "margin": 10, "minimal_on_prefix": true, "verified_terms": 12})
print('polynomial_claim', {"degree": 11, "constant_difference": 1, "binomial_basis_coefficients": [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], "formula": "(1)*C(n,0) + (1)*C(n,1) + (1)*C(n,2) + (1)*C(n,3) + (1)*C(n,4) + (1)*C(n,5) + (1)*C(n,6) + (1)*C(n,7) + (1)*C(n,8) + (1)*C(n,9) + (1)*C(n,10) + (1)*C(n,11)", "verified_terms": 12, "certificate": "constant finite difference and Newton binomial basis formula produced"})
