# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {"order": 2, "coefficients": ["2", "-1"], "char_poly_coeffs": ["1", "-2", "1"], "equations": 14, "unknowns": 2, "margin": 12, "minimal_on_prefix": true, "verified_terms": 16})
print('polynomial_claim', {"degree": 1, "constant_difference": 2, "binomial_basis_coefficients": [1, 2], "formula": "(1)*C(n,0) + (2)*C(n,1)", "verified_terms": 16, "certificate": "constant finite difference and Newton binomial basis formula produced"})
