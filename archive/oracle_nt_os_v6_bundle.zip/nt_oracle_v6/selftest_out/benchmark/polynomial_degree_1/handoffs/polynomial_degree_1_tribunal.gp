\ Auto-generated Oracle NT OS V6 PARI/GP tribunal
seq = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31];
print("terms=", seq);
for(i=1, min(#seq, 20), print(i, factor(abs(seq[i]))));
print("recurrence=", {"order": 2, "coefficients": ["2", "-1"], "char_poly_coeffs": ["1", "-2", "1"], "equations": 14, "unknowns": 2, "margin": 12, "minimal_on_prefix": true, "verified_terms": 16});
