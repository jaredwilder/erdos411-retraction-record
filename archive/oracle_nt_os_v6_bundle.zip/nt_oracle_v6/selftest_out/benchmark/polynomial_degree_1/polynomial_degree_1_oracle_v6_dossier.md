# Oracle NT OS V6 Dossier: polynomial_degree_1

Version: `6.0.0-oracle-nt-os`
Scope: `FINITE_PREFIX`

## Primary invariant

`polynomial_finite_difference`

Truth score: `1.0`
Explanation score: `0.875`
Research value score: `0.3187`

## GTH tiers

### Classification
{
  "boring_suppression": false,
  "claim": "Object classifies primarily as polynomial_finite_difference on scope FINITE_PREFIX.",
  "stakes": "medium",
  "status": "FIRES_LOW_STAKES"
}

### Theorem by route
{
  "lte": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "GTH_BLOCKED_BY_OPEN_CONDITION",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "LTE_hypotheses_verified"
    ],
    "route_status": "OBSERVED_ONLY"
  },
  "polynomial": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_PREFIX_ONLY",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "formal_definition_supplied"
    ],
    "route_status": "PREFIX_CERTIFIED"
  },
  "primitive_divisor": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_PREFIX_ONLY",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "lucas_or_lehmer_normalization",
      "nondegenerate_root_ratio",
      "known_BHV_exception_reconciliation"
    ],
    "route_status": "PREFIX_CERTIFIED"
  },
  "recurrence": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "BLOCKED_PREFIX_ONLY",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "formal_definition_supplied"
    ],
    "route_status": "PREFIX_CERTIFIED"
  },
  "strong_divisibility": {
    "claim_scope": "FINITE_PREFIX",
    "gth_status": "NOT_APPLICABLE_OR_FAILED",
    "note": "Route-specific gate. Open conditions here do not block other routes.",
    "open_conditions": [
      "all_indices_proof"
    ],
    "route_status": "FAILED_ON_PREFIX"
  }
}

### Novelty
{
  "blockers": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "claim": "No novelty-grade claim permitted.",
  "status": "BLOCKED"
}

### Proof target
{
  "status": "FIRES",
  "targets": [
    {
      "condition": "formal_definition_supplied",
      "route": "polynomial",
      "target": "Supply formal formula or enough independent generated terms to upgrade Newton certificate."
    },
    {
      "condition": "formal_definition_supplied",
      "route": "recurrence",
      "target": "Supply formal recurrence definition or independently generated terms; otherwise claim remains finite-prefix."
    },
    {
      "condition": "lucas_or_lehmer_normalization",
      "route": "primitive_divisor",
      "target": "Prove sequence is U_n(P,Q), V_n(P,Q), or Lehmer sequence under declared indexing."
    },
    {
      "condition": "nondegenerate_root_ratio",
      "route": "primitive_divisor",
      "target": "Close open condition nondegenerate_root_ratio on route primitive_divisor."
    },
    {
      "condition": "known_BHV_exception_reconciliation",
      "route": "primitive_divisor",
      "target": "Normalize to Lucas/Lehmer indexing and reconcile prefix exceptions against BHV exception set."
    },
    {
      "condition": "all_indices_proof",
      "route": "strong_divisibility",
      "target": "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route."
    },
    {
      "condition": "LTE_hypotheses_verified",
      "route": "lte",
      "target": "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
    }
  ]
}

## Next KBK action

```bash
python oracle_nt_os_v6.py analyze-seq --seq '1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31' --label polynomial_degree_1 --formal-recurrence '<coefficients>' --scope FORMAL_DEFINITION --out out
```

Need formal definition OR independently sourced terms a(16)..a(36) to separate finite-prefix fit from infinite law.

## Claim separation

{
  "BLOCKED": [
    "literature_collision_search_not_verified",
    "research_value_below_novelty_threshold"
  ],
  "COMP_computational": [
    "polynomial_finite_difference"
  ],
  "COND_conditional": [
    "infinite theorem claims conditional on formal definition or literature verification"
  ],
  "E_exact_computation": [
    "finite prefix fits verified by exact integer/rational arithmetic"
  ],
  "OPEN": [
    "Supply formal formula or enough independent generated terms to upgrade Newton certificate.",
    "Supply formal recurrence definition or independently generated terms; otherwise claim remains finite-prefix.",
    "Prove sequence is U_n(P,Q), V_n(P,Q), or Lehmer sequence under declared indexing.",
    "Close open condition nondegenerate_root_ratio on route primitive_divisor.",
    "Normalize to Lucas/Lehmer indexing and reconcile prefix exceptions against BHV exception set.",
    "Prove gcd identity for all indices via Euclidean recurrence or rank-of-apparition route.",
    "Find explicit a,b,p and verify LTE hypotheses including p=2 exception handling."
  ]
}
