# Auto-generated Oracle NT OS V6 Sage tribunal
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 126]
print('terms', seq)
print('finite_difference_rows')
cur = seq[:]
for i in range(min(8, len(seq))):
    print(i, cur)
    cur = [cur[j+1]-cur[j] for j in range(len(cur)-1)]
print('recurrence_claim', {})
print('polynomial_claim', {"degree": 11, "constant_difference": 5, "binomial_basis_coefficients": [0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 5], "formula": "(1)*C(n,1) + (2)*C(n,2) + (5)*C(n,11)", "verified_terms": 12, "certificate": "constant finite difference and Newton binomial basis formula produced"})
