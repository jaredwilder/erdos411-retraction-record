# Oracle Number Theory OS V6

V6 is the failure-elimination build after the V5 teardown. It is designed around one hard rule:

**A finite prefix is not an infinite theorem. Classification is not discovery. Open proof debt is not paid debt.**

## What V6 adds

1. Formal object intake with explicit scope:
   - `FINITE_PREFIX`
   - `GENERATED_EXTENSION`
   - `FORMAL_DEFINITION`
   - `LITERATURE_VERIFIED`

2. Route-specific theorem gates.
   - An open strong-divisibility proof does not block a recurrence theorem claim.
   - Each theorem route fires, blocks, or demotes independently.

3. Hardened corruption detector.
   - It no longer flags clean Fibonacci as corrupted.
   - It requires full-law failure, leave-one-out repair, incorrect reconstruction, and no known-family suppression.

4. Prefix-vs-infinite discipline.
   - Raw observed terms can be `PREFIX_CERTIFIED` only.
   - Infinite theorem claims require formal definition or verified literature source.

5. Expanded known-family and literature hooks.
   - Local recognition includes Fibonacci, Lucas, squares, triangular, powers, naturals, constants, Catalan, Bell, factorials, primes, and periodic families.
   - OEIS URL/cache hooks are emitted, and novelty remains blocked without verified external collision search.

6. Murder benchmark suite.
   - Tests false corruption, poisoned terms, route-specific theorem gating, finite-prefix theorem safety, known-family demotion, and primary-coordinate selection.

7. State-machine KBK enforcement.
   - If a prior round demands an action, a classify-only rerun is refused unless `--override-kbk` is passed.

8. Proof-search engines.
   - Newton/binomial polynomial certificates.
   - Recurrence generating functions.
   - Companion matrices.
   - Lean skeletons with explicit proof debts.

9. Primitive-divisor precision.
   - Declares indexing convention.
   - Attempts Lucas/Lucas-shift normalization.
   - Runs prefix primitive-divisor audit without pretending it is the full theorem.

10. Binding tribunal escalation.
   - Sage/PARI/Lean handoffs are emitted every run.
   - Missing Sage/PARI demotes or blocks routes that depend on them.

11. Corpus equivalence v2.
   - Stores raw, difference, shift, scale-normalized, binomial, inverse-binomial, recurrence-characteristic, and Newton-coefficient fingerprints.

12. Measurement-based research scoring.
   - Research value is computed from compression, proof readiness, theorem proximity, known-family collision, literature status, and scope.

13. Boring-classification suppression.
   - Known/basic objects are classified without pretending they are research discoveries.

14. Object-native engines.
   - Sequence engine.
   - CRT cover reconnaissance engine.
   - Diophantine quadratic local/search engine.

15. Killer next-data generator.
   - Every KBK packet emits exact additional terms, proof route, residues, moduli, or literature check needed to decide the branch.

## Quickstart

```bash
python oracle_nt_os_v6.py selftest
```

Analyze an observed finite prefix:

```bash
python oracle_nt_os_v6.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_prefix \
  --out out
```

Analyze the same sequence as a formal recurrence object:

```bash
python oracle_nt_os_v6.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_formal \
  --formal-recurrence "1,1" \
  --scope FORMAL_DEFINITION \
  --out out
```

Run stateful KBK rounds:

```bash
python oracle_nt_os_v6.py run \
  --seq "0,1,4,9,16,25,36,49,64,81" \
  --label squares \
  --rounds 5 \
  --out out
```

CRT cover engine:

```bash
python oracle_nt_os_v6.py crt-lab \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --max-modulus 200 \
  --out crt_out
```

Diophantine quadratic engine:

```bash
python oracle_nt_os_v6.py diophantine-quadratic \
  --A 1 --B 1 --C 65 --bound 50 --out dio_out
```

## Honest limits

Sage, PARI/GP, and Lean are optional external tools. V6 always emits handoffs. If those tools are not installed, V6 records that limitation and demotes or blocks dependent theorem routes instead of silently pretending the tribunal ran.
