# Referee Checklist — Paper 2

## Named results to verify

1. Squarefree lattice membership theorem.
2. Synchronization defect quotient definition.
3. Subgroup-size formula through synchronization defect.
4. Two-prime \(\ell\)-rank defect determinant criterion.
5. Projective Kummer slope invariant.
6. Projective slope collision corollary.
7. Projective ratio field statement.
8. Star atom definition.
9. Rational Kummer independence lemma.
10. Rank-two Kummer degree corollary.
11. Kummer slope collision graph definition.
12. Worked CRT non-synchronization example.
13. Worked determinant-zero / determinant-nonzero examples.

## Claims not made

- No full EG203 resolution.
- No high-\(\ell\) PHNC theorem.
- No prime equidistribution theorem.
- No density-zero theorem.

## Submission actions

- Compile TeX.
- Add optional visual figures if desired.
- Keep examples in main text; they prevent referee confusion.
