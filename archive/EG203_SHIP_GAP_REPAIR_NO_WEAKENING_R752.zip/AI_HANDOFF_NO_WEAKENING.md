# AI HANDOFF — EG203 Ship-Gap Repair

## Mission

Continue from this packet. Do not narrow. Do not weaken. Do actual draft work.

## Start here

1. Compile Paper 2 submission draft.
2. Read `REFEREE_CHECKLIST_PAPER2.md`.
3. Fix TeX compile issues only; do not alter theorem claims unless mathematically necessary.
4. Package Paper 2 with cover letter.

## Then Paper 3

Open:
`PAPER3_CONDITIONAL_POLISH/03_DENSITY_ZERO_KUMMER_OBSTRUCTION_CONDITIONAL_DRAFT.tex`

Task:
- keep conditional status;
- do not insert fake Pappalardi theorem;
- either find exact theorem or leave `H:pappalardi_safe` as hypothesis;
- make second-moment normalization explicit.

## Then Paper 4

Open:
`PAPER4_CRITERION_READY/04_KUMMER_DISTRIBUTION_CRITERION_EG203_SUBMISSION_DRAFT.tex`

Task:
- ensure all analytic assumptions are hypotheses;
- sharpen conditional closure theorem;
- preserve high-\(\ell\) seam.

## Then R-notes

Found:
- `R660B-UNIFORM-PROOF.tex`
- `R682-GAMMA-FIBER-LOCAL-DENSITY.tex`

Missing under exact names:
- `R681-SLICE-JET-STEPANOV.tex`
- `R705-LATTICE-LARGE-SIEVE-FOR-GAMMA-D.tex`
- `R712-PAIRWISE-KUMMER-LARGE-SIEVE-CLOSE.tex`

Locate or upload before extracting publishable notes.

## Hard rule

Do not say "needs more work" without writing the exact next patch.
