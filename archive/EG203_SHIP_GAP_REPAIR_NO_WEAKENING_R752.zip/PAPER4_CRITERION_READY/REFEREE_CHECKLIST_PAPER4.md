# Referee Checklist — Paper 4

## Must be true for submission

1. PHNC is stated as a hypothesis, not a theorem.
2. Kummer-BV is stated as a hypothesis, not a theorem.
3. KRWS is stated as a hypothesis or conditional smoothing lemma.
4. Conditional closure theorem uses only named hypotheses.
5. High-\(\ell\) seam is named explicitly.
6. No sentence claims unconditional EG203 resolution.
7. Low-\(\ell\) discussion is marked literature-dependent unless exact theorem statements are verified.
8. Companion algebra papers are referenced as finite-algebra inputs.

## Strong framing

This is a criterion paper:
\[
\mathrm{PHNC}+\mathrm{KRWS}+\mathrm{Kummer\text{-}BV}\Rightarrow\mathrm{NEG\text{-}203}.
\]

## Blockers

- Any unverified theorem citation promoted to a proven input.
- Any claim that PHNC is known in full \((\log Q)^B\) range.
- Any claim that the criterion paper solves #203.
