# R-Numbered Note Triage — Actual Files Checked

## R660B-UNIFORM-PROOF.tex

**Status:** FOUND.

**Title:** R660B-Uniform Jet-Primitive Stepanov Auxiliary Theorem\\ {\small (Skeleton — Phase 30+ FINISH LINE, audit-response v0.1)

**Theorem/definition environments counted:** 11

**Sections:**
- Notation and good-prime hypotheses
- Definition of obstruction set $B_q(m)$
- Construction of $P_q$
- Linear-system dimension lower bound
- Jet-primitivity lemma
- Wronskian / non-degeneracy lemma
- Multiplicity lower bound on $B_q(m)$
- Degree upper bound
- Stepanov contradiction
- Explicit extraction of $\delta$
- Bad-prime handling
- Open writing tasks

**Abstract extraction:**

We prove that for every prime $q$ outside an explicit exceptional set, the multiplicative subgroup orbit $V_q = \{(2^k \bmod q, 3^\ell \bmod q) : 0 \le k < a_q,\ 0 \le \ell < b_q\}$ admits a jet-primitive Stepanov auxiliary polynomial of degree $D = O(h_q^{1/2}\log q)$ with explicit absolute constant. The proof follows the Bombieri (1973) Stepanov-method template adapted to the multiplicative-additive 2-parameter orbit relevant to Erd\H{o}s--Graham Problem \#203.

## R681-SLICE-JET-STEPANOV.tex

**Status:** NOT FOUND in `/mnt/data` under this exact name.

**Action:** upload or locate before draft extraction.

## R682-GAMMA-FIBER-LOCAL-DENSITY.tex

**Status:** FOUND.

**Title:** Exact $\Gamma$-Fiber Local Density and the Kummer-Character Remainder\\ {\small (Phase 30+ post-R682-R690 advance)

**Theorem/definition environments counted:** 11

**Sections:**
- Notation
- Lemma 1 --- Exact $\Gamma$-fiber formula (GPT R682)
- Lemma 2 --- Box-period local count (GPT R683)
- Lemma 3 --- Character expansion (GPT R684)
- Lemma 4 (Claude's contribution) --- $\Delta_m(q)$ closed form and Pappalardi bound
- Lemma 5 --- Distribution formula (GPT R685)
- Lemma 6 --- Squarefree modulus (GPT R686)
- Theorem (the new exact Gate 0) --- GPT R687
- The Cor 4.1\textquotedblright\ chain (with explicit gates)
- Empirical anchor (R682-VERIFY)
- Conclusion

**Abstract extraction:**

We replace the slice-jet Stepanov $|B_q(c)| \ll \sqrt{h_q}\log q$ bound with the exact group-theoretic formula $|B_q(c)| = \gcd(a_q, b_q) \cdot \mathbf{1}_{\Gamma_q}(c)$, where $\Gamma_q = \langle 2, 3 \rangle \subset \mathbb{F}_q^*$. By character orthogonality the local divisibility density splits as $\rho_m(q) = 1/(q-1) + \Delta_m(q)$, with $\Delta_m(q)$ a Kummer-character discrepancy that admits an explicit closed form, a Pappalardi-controlled pointwise bound, and empirical verification of cancellation on average over $q$. The remaining analytic problem is recast as a Bombieri-Vinogradov-style estimate for the Kummer-discrepancy sum.

## R705-LATTICE-LARGE-SIEVE-FOR-GAMMA-D.tex

**Status:** NOT FOUND in `/mnt/data` under this exact name.

**Action:** upload or locate before draft extraction.

## R712-PAIRWISE-KUMMER-LARGE-SIEVE-CLOSE.tex

**Status:** NOT FOUND in `/mnt/data` under this exact name.

**Action:** upload or locate before draft extraction.
