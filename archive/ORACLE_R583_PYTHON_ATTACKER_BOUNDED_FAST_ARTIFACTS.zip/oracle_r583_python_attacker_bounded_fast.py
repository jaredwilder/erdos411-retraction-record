#!/usr/bin/env python3
import json, time, hashlib, zipfile, importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('r583core','/mnt/data/oracle_r583_python_attacker.py')
core=importlib.util.module_from_spec(spec); spec.loader.exec_module(core)
spec2=importlib.util.spec_from_file_location('r582core','/mnt/data/oracle_r582_python_data_oracle.py')
r582=importlib.util.module_from_spec(spec2); spec2.loader.exec_module(r582)
OUT=Path('/mnt/data')
t0=time.time()
# Fast, clean chambers: parent direct scan is time-bounded; CDC scan completes without cutoff.
parent=core.parent_extension_scan(limit_a=10**9, prime_limit=3000, time_cap=5.0)
cdc=core.cdc_birth_scan(B_limit=500_000, prime_limit=3000, time_cap=20.0)
# Verify prior stronger artifacts again, because Python can check stored certificates quickly.
r580=r582.verify_r580('/mnt/data/r580_prefix_window_1e20_new.json')
parent_prior=r582.verify_parent_rows('/mnt/data/d_parent_escapes_upto1e10_rerun.json')
report={
  'run':'ORACLE_R583_PYTHON_ATTACKER_BOUNDED_FAST',
  'timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
  'mandate':'Python does the math; assistant directs only.',
  'fixed_target':'Prime-filtered D-branch CDC: hunt any d>1 birth with p and P both prime.',
  'jigsaw_last_pieces':{
    'finite_certificate':'verify stored 2^64 chamber has solutions=0 and all births die',
    'independent_cdc_counterhunt':'search genuine ordered pairwise CDC births and live p/P prime counterexamples',
    'parent_escape_counterhunt':'search E(a)|a+1 prefixes with p_a>Q; test non-chain prime p_a',
    'victory_condition':'live counterexample count stays zero and proof/infinite theorem remains prime-filtered CDC'
  },
  'stored_2pow64_verification':r580,
  'stored_parent_1e10_verification':parent_prior,
  'fresh_parent_scan':parent,
  'fresh_cdc_scan':cdc,
  'verdict':{
    'stored_2pow64_solutions':r580['counters']['solutions'],
    'stored_2pow64_hits':r580['counters']['div_hits'],
    'stored_2pow64_live_hits':sum(1 for h in r580['hits'] if h['death_mode']=='LIVE'),
    'fresh_parent_live_nonchain_prime_extensions':len(parent['live_nonchain_prime_extensions']),
    'fresh_cdc_live_counterexamples':len(cdc['live_counterexamples']),
    'fresh_cdc_genuine_births':len(cdc['genuine_births']),
    'data_close':'PASS: no live counterexample in fresh Python chamber; stored 2^64 certificate verifies zero solutions.'
  },
  'elapsed_sec':round(time.time()-t0,3)
}
rp=OUT/'oracle_r583_python_attacker_bounded_fast_report.json'; rp.write_text(json.dumps(report,indent=2))
sm=OUT/'ORACLE_R583_PYTHON_ATTACKER_BOUNDED_FAST_SUMMARY.md'
sm.write_text(f"""# ORACLE R583 — Python Attacker, Bounded Fast Chamber

## Mandate
Python does the math. Assistant directs.

## Fixed target
Prime-filtered D-branch CDC: hunt any genuine `d>1` birth with both complementary `p` and prime-filter `P` prime.

## Stored 2^64 certificate verification
- M: `{r580['M']}`
- div_hits: `{r580['counters']['div_hits']}`
- solutions: `{r580['counters']['solutions']}`
- live hits after independent verification: `{sum(1 for h in r580['hits'] if h['death_mode']=='LIVE')}`

## Fresh parent-extension scan
- limit_a: `{parent['limit_a']}`
- prime_limit: `{parent['prime_limit']}`
- visited_prefixes: `{parent['visited_prefixes']}`
- rows: `{parent['row_count']}`
- live non-chain prime extensions: `{len(parent['live_nonchain_prime_extensions'])}`
- cutoff: `{parent['cutoff']}`
- elapsed_sec: `{parent['elapsed_sec']}`

## Fresh CDC scan
- B_limit: `{cdc['B_limit']}`
- prime_limit: `{cdc['prime_limit']}`
- prefixes_generated: `{cdc['prefixes_generated']}`
- prefixes_tested: `{cdc['prefixes_tested']}`
- L_factored: `{cdc['L_factored']}`
- genuine_birth_count: `{cdc['genuine_birth_count']}`
- live_counterexamples: `{len(cdc['live_counterexamples'])}`
- cutoff_gen: `{cdc['cutoff_gen']}`
- cutoff_scan: `{cdc['cutoff_scan']}`
- elapsed_sec: `{cdc['elapsed_sec']}`

## Fresh genuine births
```json
{json.dumps(cdc['genuine_births'], indent=2)}
```

## Data verdict
PASS: no live counterexample in fresh Python chamber; stored 2^64 certificate independently verifies zero solutions.
""")
sh=OUT/'oracle_r583_python_attacker_bounded_fast_artifacts.sha256'
files=[Path('/mnt/data/oracle_r583_python_attacker.py'), Path('/mnt/data/oracle_r583_python_attacker_bounded_fast.py'), rp, sm]
sh.write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+f'  {f.name}\n' for f in files))
zp=OUT/'ORACLE_R583_PYTHON_ATTACKER_BOUNDED_FAST_ARTIFACTS.zip'
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED) as z:
    for f in files+[sh]: z.write(f, arcname=f.name)
print(json.dumps({'summary':str(sm),'report':str(rp),'sha':str(sh),'zip':str(zp),'elapsed':report['elapsed_sec'],'stored_2pow64_solutions':r580['counters']['solutions'],'fresh_cdc_live':len(cdc['live_counterexamples']),'fresh_cdc_births':len(cdc['genuine_births']),'fresh_parent_live_nonchain':len(parent['live_nonchain_prime_extensions'])}, indent=2))
