# ORACLE R583 — Python Attacker, Bounded Fast Chamber

## Mandate
Python does the math. Assistant directs.

## Fixed target
Prime-filtered D-branch CDC: hunt any genuine `d>1` birth with both complementary `p` and prime-filter `P` prime.

## Stored 2^64 certificate verification
- M: `18446744073709551615`
- div_hits: `4`
- solutions: `0`
- live hits after independent verification: `0`

## Fresh parent-extension scan
- limit_a: `1000000000`
- prime_limit: `3000`
- visited_prefixes: `6013478`
- rows: `5`
- live non-chain prime extensions: `0`
- cutoff: `True`
- elapsed_sec: `5.0`

## Fresh CDC scan
- B_limit: `500000`
- prime_limit: `3000`
- prefixes_generated: `50617`
- prefixes_tested: `50206`
- L_factored: `50206`
- genuine_birth_count: `1`
- live_counterexamples: `0`
- cutoff_gen: `False`
- cutoff_scan: `False`
- elapsed_sec: `7.134`

## Fresh genuine births
```json
[
  {
    "B": 2345,
    "factors_B": [
      5,
      7,
      67
    ],
    "A": 31,
    "L": 5571751,
    "L_factorization": "197*28283",
    "d": 197,
    "T": 28283,
    "r": 83,
    "r_prime": true,
    "p": 989,
    "p_prime": false,
    "p_factorization": "23*43",
    "genuine_ordered_pairwise": true,
    "invalid_reasons": [],
    "P": 256658687,
    "P_prime": false,
    "P_factorization": "10667*24061"
  }
]
```

## Data verdict
PASS: no live counterexample in fresh Python chamber; stored 2^64 certificate independently verifies zero solutions.
