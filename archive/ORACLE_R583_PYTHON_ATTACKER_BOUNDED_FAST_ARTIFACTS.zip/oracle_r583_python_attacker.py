#!/usr/bin/env python3
import json, math, time, hashlib, random
from pathlib import Path
from functools import lru_cache
import sympy as sp
OUT=Path('/mnt/data')

# ---------------- helpers ----------------
def is_prime(n:int)->bool: return bool(sp.isprime(int(n)))
def factor_dict(n:int): return {int(p):int(e) for p,e in sp.factorint(int(n)).items()}
def factor_str(n:int)->str:
    if n is None: return ''
    d=factor_dict(n)
    if not d: return str(n)
    return '*'.join(str(p) if e==1 else f'{p}^{e}' for p,e in sorted(d.items()))
def prod(xs):
    z=1
    for x in xs: z*=x
    return z
def phi_sq(fs):
    z=1
    for q in fs: z*=q-1
    return z
def gen_primes(limit):
    return [int(p) for p in sp.primerange(5, limit+1) if p not in (2,3)]
def admissible_add(fs,q):
    for r in fs:
        if (q-1)%r==0 or (r-1)%q==0:
            return False
    return True
def divisors_from_factors(fd):
    divs=[1]
    for p,e in fd.items():
        old=divs[:]
        mul=1
        new=[]
        for k in range(e+1):
            for d in old: new.append(d*mul)
            mul*=p
        divs=new
    return sorted(divs)

# ---------------- gate 1: direct parent extension DFS ----------------
def parent_extension_scan(limit_a:int, prime_limit:int, time_cap:float):
    primes=gen_primes(prime_limit)
    t0=time.time()
    rows=[]; visited=0; cutoff=False
    def dfs(start, fs, val, phi):
        nonlocal visited, cutoff
        if time.time()-t0>time_cap:
            cutoff=True; return
        if fs:
            visited += 1
            A=3*phi-2*val
            if A>0 and A%2==0:
                E=A//2
                if E>0 and (val+1)%E==0:
                    p=1+(val+1)//E
                    Q=max(fs)
                    if p>Q:
                        P=None
                        if is_prime(p):
                            P=2*phi*(p-1)-1
                        rows.append({
                            'a':val,'factors':fs.copy(),'phi':phi,'E':E,'Q':Q,
                            'p':p,'p_prime':is_prime(p),'p_factorization':factor_str(p),
                            'raw_solution_if_p_prime': bool(is_prime(p) and 3*phi*(p-1)==2*(val*p+1)),
                            'P_if_raw':P,'P_prime_if_raw': is_prime(P) if P else None,
                            'P_factorization_if_raw': factor_str(P) if P and not is_prime(P) else (str(P) if P else None)
                        })
        for i in range(start, len(primes)):
            q=primes[i]
            nv=val*q
            if nv>limit_a: break
            if not admissible_add(fs,q): continue
            fs.append(q); dfs(i+1, fs, nv, phi*(q-1)); fs.pop()
            if cutoff: return
    dfs(0, [], 1, 1)
    rows=sorted(rows, key=lambda r:r['a'])
    live_nonchain=[r for r in rows if r['E']>1 and r['p_prime']]
    return {'limit_a':limit_a,'prime_limit':prime_limit,'time_cap_sec':time_cap,'elapsed_sec':round(time.time()-t0,3),'cutoff':cutoff,'visited_prefixes':visited,'row_count':len(rows),'rows':rows,'live_nonchain_prime_extensions':live_nonchain}

# ---------------- gate 2: CDC divisor-birth scan ----------------
def cdc_birth_scan(B_limit:int, prime_limit:int, time_cap:float, factor_prefix_cap:int=None):
    primes=gen_primes(prime_limit)
    t0=time.time(); prefixes=[]; cutoff_gen=False
    def dfs(start, fs, val, phi):
        nonlocal cutoff_gen
        if time.time()-t0>time_cap*0.25:
            cutoff_gen=True; return
        if fs: prefixes.append((val,phi,fs.copy()))
        for i in range(start,len(primes)):
            q=primes[i]
            nv=val*q
            if nv>B_limit: break
            if not admissible_add(fs,q): continue
            fs.append(q); dfs(i+1,fs,nv,phi*(q-1)); fs.pop()
            if cutoff_gen: return
    dfs(0,[],1,1)
    prefixes.sort(key=lambda x:x[0])
    if factor_prefix_cap: prefixes=prefixes[:factor_prefix_cap]
    births=[]; invalid_raw=[]; live=[]; tested=0; factored=0; cutoff=False
    for B,Phi,fs in prefixes:
        if time.time()-t0>time_cap:
            cutoff=True; break
        A2=3*Phi-2*B
        if A2<=0 or A2%2: continue
        A=A2//2
        L=B*B+A*B+A
        tested+=1
        # only factor when L isn't enormous relative to Python comfort; sympy handles these chamber sizes.
        fd=factor_dict(L); factored+=1
        for d in divisors_from_factors(fd):
            if d<=1 or d*d>=L: continue
            T=L//d
            if (B+d)%A or (B+T)%A: continue
            r=1+(B+d)//A; p=1+(B+T)//A
            if not is_prime(r): continue
            # classify raw birth before admissibility filters
            rec={'B':B,'factors_B':fs.copy(),'A':A,'L':L,'L_factorization':factor_str(L),'d':d,'T':T,'r':r,'r_prime':True,'p':p,'p_prime':is_prime(p),'p_factorization':factor_str(p)}
            # genuine constraints
            genuine=True; reason=[]
            if fs and r<=max(fs): genuine=False; reason.append('r_not_after_prefix')
            if p<=r: genuine=False; reason.append('p_not_larger_than_r')
            if r in fs or p in fs or r==p: genuine=False; reason.append('not_squarefree_distinct')
            if not all((r-1)%q and (q-1)%r for q in fs): genuine=False; reason.append('r_pairwise_fail')
            if not all((p-1)%q and (q-1)%p for q in fs): genuine=False; reason.append('p_pairwise_fail')
            if (p-1)%r==0 or (r-1)%p==0: genuine=False; reason.append('r_p_pairwise_fail')
            rec['genuine_ordered_pairwise']=genuine; rec['invalid_reasons']=reason
            Phi_m=Phi*(r-1)*(p-1)
            P=2*Phi_m-1
            rec.update({'P':P,'P_prime':is_prime(P),'P_factorization':factor_str(P) if not is_prime(P) else str(P)})
            if genuine:
                births.append(rec)
                if rec['p_prime'] and rec['P_prime']:
                    live.append(rec)
            else:
                invalid_raw.append(rec)
    return {'B_limit':B_limit,'prime_limit':prime_limit,'time_cap_sec':time_cap,'elapsed_sec':round(time.time()-t0,3),'cutoff_gen':cutoff_gen,'cutoff_scan':cutoff,'prefixes_generated':len(prefixes),'prefixes_tested':tested,'L_factored':factored,'genuine_birth_count':len(births),'genuine_births':births,'live_counterexamples':live,'raw_invalid_birth_sample':invalid_raw[:20]}

# ---------------- gate 3: factor pattern mining ----------------
def mine_pattern_from_reports():
    srcs=[]
    # R582 parent rows
    p='/mnt/data/d_parent_escapes_upto1e10_rerun.json'
    if Path(p).exists():
        data=json.loads(Path(p).read_text())
        for row in data.get('rows',[]):
            fs=row['factors']; a=prod(fs); phi=phi_sq(fs); E=(3*phi-2*a)//2
            if E>1 and (a+1)%E==0:
                pa=1+(a+1)//E
                srcs.append({'source':'parent_escape','factors':fs,'E':E,'candidate':pa,'candidate_factorization':factor_str(pa)})
    p='/mnt/data/r580_prefix_window_1e20_new.json'
    if Path(p).exists():
        data=json.loads(Path(p).read_text())
        for h in data.get('sample_hits',[]):
            pval=int(h['p']); sval=int(h['s'])
            srcs.append({'source':'r580_hit','B_factors':h['factors'],'s':sval,'p':pval,'p_factorization':factor_str(pval)})
    return {'pattern_rows':srcs}

# ---------------- main ----------------
def sha_file(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    t0=time.time()
    parent=parent_extension_scan(limit_a=10**12, prime_limit=20000, time_cap=80.0)
    # choose B limit high enough but time-bounded; Python is doing work, not pretending infinite.
    cdc=cdc_birth_scan(B_limit=5_000_000, prime_limit=20000, time_cap=80.0)
    patterns=mine_pattern_from_reports()
    verdict={
        'parent_live_nonchain_prime_extension_count':len(parent['live_nonchain_prime_extensions']),
        'cdc_live_counterexample_count':len(cdc['live_counterexamples']),
        'python_closed_chambers':[f"parent a <= {parent['limit_a']}", f"CDC B <= {cdc['B_limit']} within time-bounded Python chamber"],
        'new_genuine_births':cdc['genuine_births'],
    }
    report={'run':'ORACLE_R583_PYTHON_ATTACKER','timestamp_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),'fixed_target':'Prime-filtered D-branch data closure: hunt live non-chain parent extensions and live CDC births; Python-only result engine.','parent_extension_scan':parent,'cdc_birth_scan':cdc,'pattern_mining':patterns,'verdict':verdict,'elapsed_sec':round(time.time()-t0,3)}
    rp=OUT/'oracle_r583_python_attacker_report.json'; rp.write_text(json.dumps(report, indent=2))
    sm=OUT/'ORACLE_R583_PYTHON_ATTACKER_SUMMARY.md'
    sm.write_text(f"""# ORACLE R583 — Python Attacker

## Fixed target
Prime-filtered D-branch. Python hunted two live-enemy classes:

1. non-chain parent prefixes with prime forced extension `p_a`;
2. genuine CDC births with both complementary `p` and filter `P` prime.

## Parent-extension scan
- limit_a: `{parent['limit_a']}`
- prime_limit: `{parent['prime_limit']}`
- visited_prefixes: `{parent['visited_prefixes']}`
- rows satisfying `E(a)|a+1` and `p_a>Q`: `{parent['row_count']}`
- live non-chain prime extensions: `{len(parent['live_nonchain_prime_extensions'])}`
- cutoff: `{parent['cutoff']}`
- elapsed_sec: `{parent['elapsed_sec']}`

## CDC birth scan
- B_limit: `{cdc['B_limit']}`
- prime_limit: `{cdc['prime_limit']}`
- prefixes_generated: `{cdc['prefixes_generated']}`
- prefixes_tested: `{cdc['prefixes_tested']}`
- L_factored: `{cdc['L_factored']}`
- genuine_birth_count: `{cdc['genuine_birth_count']}`
- live_counterexamples: `{len(cdc['live_counterexamples'])}`
- cutoff_gen: `{cdc['cutoff_gen']}`
- cutoff_scan: `{cdc['cutoff_scan']}`
- elapsed_sec: `{cdc['elapsed_sec']}`

## Genuine births
```json
{json.dumps(cdc['genuine_births'], indent=2)}
```

## Verdict
Python found no live non-chain parent-prime extension and no live prime-filtered CDC counterexample in this chamber.
""")
    sh=OUT/'oracle_r583_python_attacker_artifacts.sha256'
    files=[Path(__file__), rp, sm]
    sh.write_text(''.join(sha_file(f)+'  '+f.name+'\n' for f in files))
    print(json.dumps({'report':str(rp),'summary':str(sm),'sha':str(sh),'elapsed':report['elapsed_sec'],'parent_live_nonchain':len(parent['live_nonchain_prime_extensions']),'cdc_live':len(cdc['live_counterexamples']),'cdc_births':len(cdc['genuine_births']),'parent_cutoff':parent['cutoff'],'cdc_cutoff':cdc['cutoff_scan']}, indent=2))
if __name__=='__main__': main()
