\ Oracle NT OS V7 PARI/GP handoff
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81];
print(["length", #seq]);
for(i=1, min(#seq, 20), print([i-1, seq[i], factor(abs(seq[i]))]));
