# Oracle NT OS V7 Report: poisoned_squares

Version: `7.0.0-oracle-nt-os-nuclear`

Primary coordinate: **single_corruption_over_simple_law**
Verdict: **CORRUPTION_FIRST_NO_GTH**

## Claim Gates
```json
{
  "overall_verdict": "CORRUPTION_FIRST_NO_GTH",
  "classification_gth_allowed": false,
  "theorem_gth_allowed_routes": [],
  "novelty_gth_allowed": false,
  "proof_target_gth_allowed": false,
  "route_claims": [
    {
      "route": "polynomial_finite_difference",
      "status": "NOT_APPLICABLE",
      "theorem_gth_allowed": false,
      "blockers": [
        "no finite-difference polynomial detected"
      ],
      "open_conditions": []
    },
    {
      "route": "linear_recurrence",
      "status": "NOT_APPLICABLE",
      "theorem_gth_allowed": false,
      "blockers": [
        "no exact recurrence detected"
      ],
      "open_conditions": []
    },
    {
      "route": "strong_divisibility",
      "status": "PROOF_OBLIGATION_EXACT",
      "theorem_gth_allowed": false,
      "blockers": [],
      "open_conditions": [
        "prove all-index gcd identity via Euclidean recurrence/determinant route"
      ]
    },
    {
      "route": "primitive_divisor",
      "status": "NOT_APPLICABLE",
      "theorem_gth_allowed": false,
      "blockers": [
        "requires order-2 recurrence route"
      ],
      "open_conditions": []
    }
  ],
  "known_boring": false,
  "scope": "FINITE_PREFIX"
}
```

## KBK
```json
{
  "required_action": "attack_corruption_reconstruct_or_request_source_terms",
  "killer_next_data": "Verify term at index 9 and provide independently sourced neighboring terms.",
  "no_fake_loop_rule": "continue must run required_action; classify-only is refused unless override is supplied",
  "generated_at": "2026-05-21T21:20:00Z"
}
```
