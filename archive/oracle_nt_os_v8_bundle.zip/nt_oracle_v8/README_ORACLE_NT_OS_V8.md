# Oracle Number Theory OS V8 - Trust Boundary Build

V8 is a failure-elimination release. It does not claim to solve number theory. It closes the trust-boundary failures found in the V7 adversarial review.

## What V8 fixes

1. `--formal-recurrence` without an independent source no longer creates a formal theorem object. It becomes `GENERATED_EXTENSION` and cannot unlock theorem-grade claims.
2. Formal definitions that contradict supplied terms stop the run with `FORMAL_OBJECT_CONTRADICTION`.
3. High-order recurrences on short random prefixes are labeled `high_order_prefix_interpolation_risk`, not treated as explanation.
4. Acceptance tests now attack user-facing CLI semantics, not only internal constructors.
5. Proof debt statuses distinguish emitted artifacts from `NAMED_BUT_NOT_CLOSED` debt.
6. Theorem route readiness is explicitly separated from formal verification.
7. Strong divisibility tests canonical index shifts before killing a route.
8. Known-family recognition suppresses false corruption and coordinates theorem checks.
9. Literature collision remains conservative: novelty is blocked unless collision search clears.
10. Selftest is now a 24-check hostile trust-boundary suite.

## Run selftest

```bash
python oracle_nt_os_v8.py selftest --out v8_selftest_out
```

Expected:

```json
{
  "version": "8.0.0-oracle-nt-os-trust-boundary",
  "selftest": "PASS",
  "green_checks": 24,
  "total_checks": 24
}
```

## Hostile checks

Thin CLI formal recurrence is demoted:

```bash
python oracle_nt_os_v8.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_thin_cli \
  --formal-recurrence "1,1" \
  --out out
```

Result: `scope = GENERATED_EXTENSION`; no theorem-grade route fires.

Formal recurrence with an independent source:

```bash
python oracle_nt_os_v8.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_formal \
  --formal-recurrence "1,1" \
  --initial-terms "1,1" \
  --definition-source "manual formal definition" \
  --out out
```

Random high-order prefix interpolation risk:

```bash
python oracle_nt_os_v8.py analyze-seq \
  --seq "2,7,1,8,2,8,1,8,2,8,4,5" \
  --label randomish \
  --out out
```

Result: `primary_coordinate = high_order_prefix_interpolation_risk`; verdict `NO_GTH`.

## Status

V8 is not a world-shocking mathematical result. It is a trust-boundary hardening layer that prevents the specific V7 failures from resurfacing in normal CLI usage and internal acceptance tests.
