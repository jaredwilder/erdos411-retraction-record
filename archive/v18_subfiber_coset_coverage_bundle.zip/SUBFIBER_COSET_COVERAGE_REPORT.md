# Subfiber Coset Coverage Certificate

## Verdict

`PROMOTE_SUBFIBER_COVERAGE_OBSTRUCTION`

## Active binary

Does the union of actual q-danger cosets cover the full finite subfiber quotient for `(20,20)` or `(40,40)`, or is there a coset-cover obstruction?

## Result

- Branches tested: 52
- Full subfiber covers found: 0
- Minimum surviving lifts for `(20,20)`: 6
- Minimum surviving lifts for `(40,40)`: 6

## Exact identity used

For `k = k0 + 120a`, `l = l0 + 240b`, a modulus `q` covers a lift exactly when:

```text
(2^120)^a · (3^240)^b = -(2^k0 · 3^l0)^(-1) mod q
```

So each danger modulus cuts out one coset in the finite subfiber quotient. The branch covers the whole subfiber iff the union of those cosets covers every `(a,b)` in the quotient.

## Witnesses at the minimum survival branch

`(20,20)` min witness:

```json
{
  "q3": 577,
  "uncovered_witness": {
    "a": 0,
    "b": 0,
    "k": 80,
    "l": 80
  },
  "total_lifts": 6,
  "covered_count": 0
}
```

`(40,40)` min witness:

```json
{
  "q3": 577,
  "uncovered_witness": {
    "a": 0,
    "b": 0,
    "k": 40,
    "l": 160
  },
  "total_lifts": 6,
  "covered_count": 0
}
```

## What was tested

All 52 Race8 replayed actual q3 danger-closure branches from q3 in [301,997], both target subfibers, exact enumeration over each branch finite quotient.

## What was not tested

- Race8 skipped branches
- q3 outside [301,997] in this certificate
- unbounded recursive depth
- arbitrary non-danger modulus combinations

## Next binary

Can skipped and expanded q3 branches be reduced to the same coset-cover certificate, or does one produce a full target-subfiber cover?
