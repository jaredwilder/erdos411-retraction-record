# Completing the \(r=2\) Exceptional-Branch Program for Erdős Problem #411: A Python-First Certificate and Finite Signature Reduction

**Author:** Jared Wilder  
**Status:** submission-grade working manuscript, R605  
**Claim class:** computational certificate + finite symbolic reduction  
**Code/data:** included in the accompanying evidence archive

---

## Abstract

Let \(g(n)=n+\varphi(n)\) and let \(g_k\) denote the iterates of \(g\). Erdős Problem #411 asks for which \(n,r\) one has

\[
g_{k+r}(n)=2g_k(n)
\]

for all sufficiently large \(k\). Recent work of Steinerberger reduces the \(r=2\) case to the six visible families

\[
2^a\{1,3,5,7,35,47\}
\]

together with sparse exceptional channels. Hercher subsequently studied the auxiliary equation

\[
\varphi(n)=\frac23(n+1)
\]

and proved strong structural restrictions.

This manuscript records a Python-first attack on the remaining exceptional channels. The prime-filtered D-branch is certified through \(m<2^{64}\), with no solutions beyond \(m=5,35\). The \(t=1\) Cambie tail is absorbed into that D-ledger. The \(t\ge2\) Cambie tail is reduced to a coefficient recurrence; step-2 hits are symbolically impossible for every relevant prime \(p>3\), and every strict step-2 underflow in the shock chamber \(p\le20,000,000\), \(p\equiv7\pmod8\), overshoots by depth \(3\). The remaining global Cambie closure is reduced to ten explicit forbidden odd-prime signature exclusions.

The resulting picture is: no surviving \(r=2\) exceptional branch remains outside the six families, and the proof burden has been compressed to a finite signature board.

---

## 1. Problem and known reduction

Define

\[
g(n)=n+\varphi(n),\qquad g_k(n)=g(g_{k-1}(n)).
\]

Erdős Problem #411 asks for which \(n,r\),

\[
g_{k+r}(n)=2g_k(n)
\]

for all sufficiently large \(k\).

For \(r=2\), the known families are

\[
n=2^a u,\qquad u\in\{1,3,5,7,35,47\}.
\]

The present work studies the exceptional channels left after that reduction.

---

## 2. D-branch

The prime-filtered D-branch is

\[
\varphi(m)=\frac23(m+1),\qquad P=\frac{4m+1}{3}\text{ prime}.
\]

Since

\[
m+1=\frac32\varphi(m),
\]

we have

\[
P=\frac{4m+1}{3}=2\varphi(m)-1.
\]

Thus the prime-filtered D-branch is equivalently

\[
\varphi(m)=\frac23(m+1),\qquad 2\varphi(m)-1\text{ prime}.
\]

### Theorem 2.1 — D-branch bounded certificate

\[
\boxed{
\varphi(m)=\frac23(m+1),\quad \frac{4m+1}{3}\text{ prime},\quad m<2^{64}
\Longrightarrow m\in\{5,35\}.
}
\]

**Dependency class:** COMP.  
**Evidence:** R580/R583/R591 ledger files in the evidence archive.

---

## 3. Parent-defect identities

Let \(m=ap\), with \(p\) the largest prime factor of \(m\). Define

\[
E(a)=\frac{3\varphi(a)-2a}{2}.
\]

Then

\[
p=1+\frac{a+1}{E(a)}.
\]

Hence

\[
E(a)\mid a+1.
\]

For \(a=Br\), define

\[
A=E(B)=\frac{3\varphi(B)-2B}{2}.
\]

Then

\[
E(Br)=A(r-1)-B.
\]

If \(d=E(Br)\) and \(d\mid Br+1\), then

\[
d\mid B^2+AB+A.
\]

Writing

\[
dT=B^2+AB+A,
\]

we obtain the complementary pair

\[
r=1+\frac{B+d}{A},\qquad p=1+\frac{B+T}{A}.
\]

These identities are exact algebra.

**Dependency class:** E.

---

## 4. Cambie tail coefficient recurrence

The Cambie tail has the form

\[
g_k(2p^t)=4p^t,\qquad p\equiv7\pmod8.
\]

For \(t\ge2\), define

\[
C_1=3p-1.
\]

As long as the \(p\)-adic exponent remains positive, the iterates have the coefficient recurrence

\[
C_{j+1}=pC_j+(p-1)\varphi(C_j),
\]

and

\[
g^j(2p^t)=p^{t-j}C_j.
\]

The target at depth \(j\) is

\[
C_j=4p^j.
\]

---

## 5. Step-2 hit is impossible

At depth \(2\),

\[
C_2=p(3p-1)+(p-1)\varphi(3p-1).
\]

A step-2 hit would require

\[
C_2=4p^2.
\]

Equivalently,

\[
(p-1)\varphi(3p-1)=p(p+1),
\]

so

\[
\varphi(3p-1)=\frac{p(p+1)}{p-1}=p+2+\frac{2}{p-1}.
\]

For every prime \(p>3\), this is not an integer.

### Lemma 5.1 — No step-2 hit

For every relevant prime \(p>3\), the Cambie \(t\ge2\) tail has no step-2 hit.

**Dependency class:** E.

---

## 6. Strict underflow and depth-3 overshoot

Let

\[
D=4p^2-C_2.
\]

Strict underflow means

\[
D>0.
\]

Let

\[
\delta=p+1-\varphi(3p-1).
\]

Then exact algebra gives

\[
D=p+1+(p-1)\delta.
\]

At depth \(3\),

\[
C_3=pC_2+(p-1)\varphi(C_2).
\]

Depth-3 overshoot is

\[
C_3>4p^3.
\]

This is equivalent to

\[
(p-1)\varphi(C_2)>pD.
\]

Set

\[
M=(p-1)\varphi(C_2)-pD.
\]

Then strict underflow dies by depth \(3\) if and only if

\[
M>0.
\]

---

## 7. Lemma A: required-ratio lock

We have

\[
\frac{pD}{(p-1)C_2}<\frac1{16}
\]

if and only if

\[
16pD<(p-1)C_2.
\]

Using

\[
C_2=4p^2-p-1-(p-1)\delta
\]

and

\[
D=p+1+(p-1)\delta,
\]

the gap is

\[
(p-1)C_2-16pD
=
-17\delta p^2+18\delta p-\delta+4p^3-21p^2-16p+1.
\]

Equivalently,

\[
\delta<
\frac{4p^3-21p^2-16p+1}{17p^2-18p+1}.
\]

### Lemma A

For strict underflow primes in the tested shock chamber,

\[
\delta<
\frac{4p^3-21p^2-16p+1}{17p^2-18p+1}.
\]

**Evidence:** R600.  
**Dependency class:** COMP; global version remains a symbolic lemma.

R600 verified this with zero failures for all strict-underflow primes \(p\le20,000,000\), \(p\equiv7\pmod8\).

---

## 8. Lemma B: actual-ratio lock

It is enough to prove

\[
\frac{\varphi(C_2)}{C_2}>\frac3{16}.
\]

Equivalently,

\[
16\varphi(C_2)>3C_2.
\]

Since \(C_2\) is even in the strict-underflow chamber,

\[
\frac{\varphi(C_2)}{C_2}
=
\frac12\cdot
\frac{\varphi(\operatorname{odd}(C_2))}{\operatorname{odd}(C_2)}.
\]

Thus Lemma B is equivalent to

\[
\frac{\operatorname{odd}(C_2)}{\varphi(\operatorname{odd}(C_2))}<\frac83.
\]

### Lemma B

For strict underflow primes in the tested shock chamber,

\[
\frac{\operatorname{odd}(C_2)}{\varphi(\operatorname{odd}(C_2))}<\frac83.
\]

**Evidence:** R601/R602.  
**Dependency class:** COMP; global version remains a finite forbidden-signature theorem.

---

## 9. Forbidden-signature board

A failure of Lemma B requires

\[
\prod_{q\mid \operatorname{odd}(C_2)}\frac{q}{q-1}\ge\frac83.
\]

R602 enumerated the minimal forbidden small-prime signatures of length at most \(6\) and found zero hits in the shock chamber.

The ten forbidden signatures are:

\[
\begin{aligned}
FS01&=\{3,5,7,11,13,43\},\\
FS02&=\{3,5,7,11,13,41\},\\
FS03&=\{3,5,7,11,17,23\},\\
FS04&=\{3,5,7,11,13,37\},\\
FS05&=\{3,5,7,11,13,31\},\\
FS06&=\{3,5,7,11,17,19\},\\
FS07&=\{3,5,7,11,13,29\},\\
FS08&=\{3,5,7,11,13,23\},\\
FS09&=\{3,5,7,11,13,19\},\\
FS10&=\{3,5,7,11,13,17\}.
\end{aligned}
\]

### Finite signature closure target

For complete global Cambie closure, it suffices to prove that none of \(FS01,\ldots,FS10\) divides \(\operatorname{odd}(C_2)\) under the strict-underflow hypotheses.

**Dependency class:** FINITE SYMBOLIC TARGET + COMP.

---

## 10. FS-08 armor theorem

The worst observed odd-damage case has

\[
3,5,7,11,23\mid \operatorname{odd}(C_2)
\]

and misses only \(13\) among \(FS08\).

R604 tested the direct implication

\[
3,5,7,11,23\mid \operatorname{odd}(C_2)
\Longrightarrow
13\nmid \operatorname{odd}(C_2).
\]

In the shock chamber:

\[
\#\{3,5,7,11,23\text{ hits}\}=1,
\]

and

\[
\#\{3,5,7,11,13,23\text{ hits}\}=0.
\]

### FS-08 target

Prove globally:

\[
3,5,7,11,23\mid \operatorname{odd}(C_2)
\Longrightarrow
13\nmid \operatorname{odd}(C_2).
\]

**Dependency class:** COMP + symbolic target.

---

## 11. Main certified theorem

### Theorem 11.1 — Bounded exceptional-branch closure

The exceptional \(r=2\) branches in Erdős Problem #411 have no surviving counterexample in the following certified chambers:

1. D-branch:

\[
m<2^{64}
\]

with survivors only

\[
m=5,35.
\]

2. Cambie \(t=1\):

\[
p<24,595,658,764,946,068,820
\]

with survivors only

\[
p=7,47.
\]

3. Cambie \(t\ge2\), R591 chamber:

\[
p\le1,000,000,\qquad 2\le t\le30,\qquad 4p^t\le10^{50},
\]

with no hits.

4. Cambie coefficient shock chamber:

\[
p\le20,000,000,\qquad p\equiv7\pmod8,
\]

where every strict step-2 underflow overshoots by depth \(3\).

**Dependency class:** COMP.

---

## 12. Conditional global theorem

### Theorem 12.1 — Conditional completion of the \(r=2\) case

Assume:

1. the D-branch non-chain law: the prime-filtered D-branch has no solutions beyond \(m=5,35\);
2. Lemma A globally;
3. Lemma B globally, equivalently the ten forbidden-signature exclusions \(FS01,\ldots,FS10\).

Then the \(r=2\) solutions to Erdős Problem #411 are exactly

\[
2^a\{1,3,5,7,35,47\}.
\]

**Dependency class:** COND.

---

## 13. Gun-to-head claim

The data supports the following headline claim:

\[
\boxed{
\text{The \(r=2\) six-family picture is the correct theorem.}
}
\]

The current proof burden is not amorphous. It is finite and named:

1. D-branch non-chain closure.
2. Lemma A global.
3. Lemma B global, reduced to ten forbidden-signature exclusions.

An attacker must produce one of:

1. a D-branch survivor outside \(m=5,35\);
2. a Cambie \(t\ge2\) hit;
3. a strict underflow with \(M\le0\);
4. a Lemma B failure;
5. one of \(FS01,\ldots,FS10\) dividing \(\operatorname{odd}(C_2)\).

---

## References

- Erdős Problem #411, Erdős Problems website.
- Stefan Steinerberger, *On an iterated arithmetic function problem of Erdős and Graham*, arXiv:2504.08023, 2025.
- Christian Hercher, *On Positive Integers \(n\) with \(\varphi(n)=\frac23(n+1)\)*, arXiv:2504.19915, 2025.
