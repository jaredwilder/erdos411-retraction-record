# Erdős #411 R605 Submission-Grade Packet

Start here:

1. `MANUSCRIPT_R605.md`
2. `CLAIM_SEPARATION_BOARD_R605.md`
3. `LEMMA_CARDS_R605.md`
4. `REFEREE_AUDIT_EMAIL_R605.txt`
5. `evidence/`

This packet is suitable for expert audit. It distinguishes proven algebra, computational certificates, conditional global theorem, and open symbolic targets.
