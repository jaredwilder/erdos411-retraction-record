# Claim Separation Board

| Claim | Status | Dependency |
|---|---|---|
| Step-2 hit impossible for p>3 | Proven | E |
| Parent-defect identities | Proven | E |
| D-branch closure below 2^64 | Certified | COMP |
| Cambie t=1 absorbed by D-ledger | Certified | COMP + E |
| R591 t>=2 chamber no hits | Certified | COMP |
| R597 depth-3 shock chamber | Certified | COMP |
| Lemma A global | Open symbolic target | OPEN |
| Lemma B global | Open finite signature target | OPEN |
| Ten forbidden signatures sufficient for Lemma B | Formal reduction + computation | E + COMP |
| Full r=2 theorem | Conditional on D-law + Lemma A + Lemma B | COND |
