# Lemma Cards — Erdős #411 R605

## Card E1 — Step-2 Impossibility

**Statement.** For every prime \(p>3\), the Cambie \(t\ge2\) coefficient recurrence has no depth-2 hit.

**Proof.** A hit requires \(\varphi(3p-1)=p+2+2/(p-1)\), which is not integral for \(p>3\).

**Dependency class:** E.

---

## Card C1 — D-branch bounded certificate

**Statement.** If \(\varphi(m)=2(m+1)/3\), \((4m+1)/3\) is prime, and \(m<2^{64}\), then \(m\in\{5,35\}\).

**Dependency class:** COMP.

---

## Card C2 — R591 Cambie chamber

**Statement.** No Cambie \(t\ge2\) hit occurs for \(p\le10^6\), \(2\le t\le30\), \(4p^t\le10^{50}\).

**Dependency class:** COMP.

---

## Card C3 — R597 exact threshold split

**Statement.** In the shock chamber \(p\le20,000,000\), every strict underflow satisfies

\[
16\varphi(C_2)>3C_2,\qquad 16pD<(p-1)C_2.
\]

**Dependency class:** COMP.

---

## Card F1 — Forbidden signature board

**Statement.** Lemma B failure requires one of \(FS01,\ldots,FS10\) to divide \(\operatorname{odd}(C_2)\).

**Dependency class:** E + COMP enumeration.

---

## Card O1 — D-branch non-chain closure

**Statement.** The global prime-filtered D-branch has no solutions beyond \(m=5,35\).

**Dependency class:** OPEN symbolic target.

---

## Card O2 — Lemma A global

**Statement.** Strict underflow implies

\[
\delta<
\frac{4p^3-21p^2-16p+1}{17p^2-18p+1}.
\]

**Dependency class:** OPEN symbolic target; COMP through \(p\le20,000,000\).

---

## Card O3 — Lemma B global

**Statement.** Strict underflow implies

\[
\operatorname{odd}(C_2)/\varphi(\operatorname{odd}(C_2))<8/3.
\]

**Dependency class:** OPEN finite forbidden-signature target; COMP through \(p\le20,000,000\).
