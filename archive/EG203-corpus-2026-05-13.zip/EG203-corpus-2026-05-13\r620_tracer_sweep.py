"""R620 — Sweep m ≤ 10⁶ coprime to 6 for inH-count distribution.

For each m, count inH(m) = |{p prime, 5 ≤ p ≤ 100 : -m^{-1} ∈ ⟨2,3⟩ mod p}|.

23 primes in [5, 100]. Predicted: typical m has inH ≈ 20 (mean from random control).
Worst-case m's have inH ≥ 22.

GOAL:
1. Density of "structural tracers" (inH = 23/23) — predicted RARE
2. Where are they distributed in [1, 10⁶]?
3. Are they all prime, or composite?
4. Does the tracer density correlate with primality of m?

If tracer density is, say, ~1 in 10K, then there are ~100 tracers in [1, 10⁶].
This gives an EXPLICIT SET that contains the worst-case Proposition 9 m's.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

PRIMES_LIST = list(sympy.primerange(5, 101))  # 23 primes: 5, 7, ..., 97


def orbit_mod_p(p):
    """Compute <2, 3> mod p via BFS."""
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def main():
    print("R620 — Tracer sweep across m ≤ 10⁶ coprime to 6\n")
    print(f"Primes in [5, 100]: {len(PRIMES_LIST)} primes\n")

    # Precompute orbit mod each prime
    print("Precomputing orbits...")
    orbits = {p: orbit_mod_p(p) for p in PRIMES_LIST}

    # Sweep m ≤ 10⁶
    M_MAX = 1_000_000
    print(f"Sweeping m ≤ {M_MAX}...")

    inH_count = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0, 9: 0,
                  10: 0, 11: 0, 12: 0, 13: 0, 14: 0, 15: 0, 16: 0, 17: 0, 18: 0,
                  19: 0, 20: 0, 21: 0, 22: 0, 23: 0}

    tracers = []  # m with inH = 23
    near_tracers = []  # m with inH = 22

    t0 = time.time()
    n_processed = 0
    for m in range(1, M_MAX + 1):
        if math.gcd(m, 6) != 1:
            continue
        n_processed += 1
        cnt = 0
        for p in PRIMES_LIST:
            if math.gcd(m, p) == 1:
                m_inv = pow(m, -1, p)
                neg_m_inv = (-m_inv) % p
                if neg_m_inv in orbits[p]:
                    cnt += 1
        inH_count[cnt] += 1
        if cnt == 23:
            tracers.append(m)
        elif cnt == 22:
            near_tracers.append(m)
        if n_processed % 100000 == 0:
            elapsed = time.time() - t0
            print(f"  [{n_processed}/333,333] m={m:>7}, tracers found: {len(tracers)}, elapsed {elapsed:.0f}s")

    elapsed_total = time.time() - t0
    print(f"\nTotal compute: {elapsed_total:.0f}s")

    # Stats
    print(f"\n=== inH-COUNT DISTRIBUTION (m ≤ 10⁶ coprime to 6) ===")
    print(f"{'inH':>4} {'count':>8} {'frac':>8}")
    total = sum(inH_count.values())
    for k, v in sorted(inH_count.items()):
        if v > 0:
            print(f"{k:>4} {v:>8} {v/total*100:>7.3f}%")

    print(f"\nTotal m coprime to 6 in [1, 10⁶]: {total}")
    print(f"Tracers (inH = 23): {len(tracers)}")
    print(f"Near-tracers (inH = 22): {len(near_tracers)}")
    print(f"Tracer density: {len(tracers)/total*1e6:.1f} per million m")

    # Tracer analysis
    if tracers:
        print(f"\n=== TRACERS (first 30 of {len(tracers)}) ===")
        for m in tracers[:30]:
            is_prime = sympy.isprime(m)
            factors = list(sympy.factorint(m).items()) if not is_prime else []
            print(f"  m={m:>7}: {'PRIME' if is_prime else 'composite'}{factors if factors else ''}")

        # Primality enrichment
        prime_tracers = sum(1 for m in tracers if sympy.isprime(m))
        print(f"\nPrimes among tracers: {prime_tracers}/{len(tracers)} = {prime_tracers/len(tracers)*100:.1f}%")
        # Compare to expected: density of primes in [1, 10⁶] coprime to 6 is ~ pi(10⁶)/total
        # = 78498 / 333333 ≈ 23.5%
        expected = 78498 / 333333
        print(f"Expected if no enrichment: {expected*100:.1f}%")
        if prime_tracers/len(tracers) > expected * 1.5:
            print("*** PRIMALITY ENRICHMENT DETECTED: tracers preferentially prime ***")

    out = ROOT / "r620_results.json"
    out.write_text(json.dumps({
        "M_MAX": M_MAX,
        "primes_list": PRIMES_LIST,
        "inH_distribution": {str(k): v for k, v in inH_count.items()},
        "n_tracers": len(tracers),
        "tracers_first_100": tracers[:100],
        "near_tracers_first_100": near_tracers[:100],
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
