"""R645 — Push R641 Weil saturation to L=80 to verify delta -> 0.43.

R641: q=5003 at L=40/50/60 gave delta = 0.385/0.390/0.4137.
R645: extend L=70, 80 at q=5003 only (focus). Verify monotone increase
toward Linnik+Selberg+Vinogradov predicted delta_infty = 0.43.
"""
from __future__ import annotations
import json, math, sys, time, random
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent


def support_pairs(L):
    pairs = []
    log2_3 = math.log2(3)
    for k in range(L + 1):
        max_ell = int((L - k) / log2_3)
        for ell in range(max_ell + 1):
            pairs.append((k, ell))
    return pairs


def compute_max_S_q(q, L, sample_a=400, seed=42):
    pairs = support_pairs(L)
    N_phi = len(pairs)
    rng = random.Random(seed)
    candidates = []
    attempts = 0
    while len(candidates) < sample_a and attempts < sample_a * 5:
        a = rng.randint(1, q - 1)
        if math.gcd(a, q) == 1:
            candidates.append(a)
        attempts += 1
    pow2 = [pow(2, k, q) for k in range(L + 1)]
    pow3 = [pow(3, ell, q) for ell in range(L + 1)]
    max_S = 0
    for a in candidates:
        sr, si = 0.0, 0.0
        for (k, ell) in pairs:
            n = (a * pow2[k] * pow3[ell]) % q
            ang = 2 * math.pi * n / q
            sr += math.cos(ang); si += math.sin(ang)
        absS = math.sqrt(sr*sr + si*si)
        if absS > max_S:
            max_S = absS
    return max_S, N_phi


def main():
    print("R645 - Weil saturation push: q=5003, L=40,50,60,70,80")
    print(f"{'L':>4} {'N_phi':>8} {'max|S|':>10} {'|S|/N_phi':>11} {'delta_emp':>11} {'elapsed':>8}")
    q = 5003
    test_Ls = [40, 50, 60, 70, 80]
    results = []
    for L in test_Ls:
        t0 = time.time()
        max_S, N_phi = compute_max_S_q(q, L, sample_a=400, seed=42)
        elapsed = time.time() - t0
        ratio = max_S / N_phi if N_phi > 0 else 0
        delta = 1 - math.log(max_S)/math.log(N_phi) if max_S > 1 and N_phi > 1 else 1
        results.append({"L": L, "N_phi": N_phi, "max_S": max_S, "ratio": ratio, "delta": delta, "elapsed": elapsed})
        print(f"{L:>4} {N_phi:>8} {max_S:>10.3f} {ratio:>11.4f} {delta:>11.4f} {elapsed:>7.1f}s")

    print()
    deltas = [r["delta"] for r in results]
    trend = "MONOTONE_INCREASING" if all(deltas[i+1] >= deltas[i] - 0.005 for i in range(len(deltas)-1)) else "MIXED"
    print(f"Trend: {trend}, max delta = {max(deltas):.4f}")
    print(f"Linnik+Selberg+Vinogradov predicted delta_infty = 0.43")
    if max(deltas) >= 0.43:
        verdict = "WEIL_SATURATION_REACHED"
    elif max(deltas) >= 0.42:
        verdict = "WEIL_SATURATION_NEAR"
    else:
        verdict = "BELOW_PREDICTION"
    print(f"VERDICT: {verdict}")

    out = ROOT / "r645_results.json"
    out.write_text(json.dumps({"phase": "Phase 26 R645", "q": q, "results": results, "trend": trend, "verdict": verdict}, indent=2, default=str))
    print(f"Written {out}")


if __name__ == "__main__":
    main()
