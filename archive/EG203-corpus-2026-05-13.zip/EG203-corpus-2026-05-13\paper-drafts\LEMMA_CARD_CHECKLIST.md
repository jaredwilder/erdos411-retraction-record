# Lemma Card Checklist

## E-class: elementary / certified real

1. Finite abelian subgroup obstruction lemma.
2. Multiplication fiber theorem.
3. Unit-inversion bijection.
4. Character-annihilator expansion.
5. Exact moment law.
6. CRT orthogonality.
7. Weighted variance theorem.
8. Squarefree lattice membership.
9. Pair determinant criterion.
10. Rational Kummer independence.
11. Kummer character order exactly \(\ell\).
12. Non-real odd Kummer characters.
13. Power-stability of deficit.
14. Bad cyclic line consequence.

## C-class: classical theorem needed

1. Pappalardi subgroup-order theorem.
2. Effective Chebotarev / Thorner-Zaman low-range theorem.
3. GRH Chebotarev conditional variant.

## S-class: sieve formalization required

1. Density-zero exceptional set.
2. BVK/NEG-203 sieve closure.

## COND-class: conditional

1. PHNC implies Kummer-BV via random-walk smoothing.
2. Kummer-BV implies NEG-203.
3. Kummer-GRH implies PHNC.

## OPEN-class

1. High-\(\ell\) PHNC.
2. Finite-field Fourier gap from hyperplane non-concentration, if used without extra anti-atom assumptions.
