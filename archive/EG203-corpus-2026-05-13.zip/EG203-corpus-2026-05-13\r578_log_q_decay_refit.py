"""
R578 — Re-fit r577 discrepancy data with logarithmic q-decay model.

Per R577 results, polynomial q-decay was empirically absent (delta_q ~ 0.04, R^2 ~ 0.06).
Pre-registered follow-up: test logarithmic decay model
    log D ~ a + b * log(log q)
and compare with the polynomial model
    log D ~ a + b * log q
on R^2.

If log model wins on R^2 AND slope b is negative AND R^2 >= 0.6, confirms BLMV-style decay.

This is empirical regression only — does NOT prove BLMV-rate. But supports the framing.
"""

from __future__ import annotations
import json, math, sys
from pathlib import Path
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

def regress(xs, ys):
    """log-log style regression: returns (slope, intercept, R^2)."""
    xs_arr = np.array(xs, dtype=np.float64)
    ys_arr = np.array(ys, dtype=np.float64)
    if len(xs_arr) < 3:
        return 0.0, 0.0, 0.0
    n = len(xs_arr)
    xbar = xs_arr.mean()
    ybar = ys_arr.mean()
    Sxx = ((xs_arr - xbar) ** 2).sum()
    Sxy = ((xs_arr - xbar) * (ys_arr - ybar)).sum()
    Syy = ((ys_arr - ybar) ** 2).sum()
    if Sxx == 0:
        return 0.0, 0.0, 0.0
    b = Sxy / Sxx
    a = ybar - b * xbar
    r2 = (Sxy ** 2) / (Sxx * Syy) if Syy > 0 else 0.0
    return b, a, r2

def main():
    print("R578 — Logarithmic q-decay refit of R577 data\n")

    raw = json.loads((ROOT / "r577_results.json").read_text())
    M_LIST = raw["M_LIST"]
    Q_LIST = raw["Q_LIST"]
    L_LIST = raw["L_LIST"]
    results = raw["results"]

    print(f"M_LIST = {M_LIST}")
    print(f"Q_LIST = {Q_LIST}")
    print(f"L_LIST = {L_LIST}\n")

    refit = {}
    summary_poly_r2 = []
    summary_log_r2 = []
    summary_log_slope = []

    for m in M_LIST:
        refit[m] = {}
        print(f"--- m = {m} ---")
        for L in L_LIST:
            row = results[str(m)][str(L)]
            Ds = [row[str(q)]["D"] for q in Q_LIST]

            # Filter zeros
            qs2 = []
            ls2 = []  # log(D)
            for q, D in zip(Q_LIST, Ds):
                if D > 0:
                    qs2.append(q)
                    ls2.append(math.log(D))

            if len(qs2) < 3:
                continue

            # Polynomial model: log D ~ a + b * log q  (slope -delta_q)
            log_q = [math.log(q) for q in qs2]
            b_poly, a_poly, r2_poly = regress(log_q, ls2)
            delta_q = -b_poly

            # Logarithmic model: log D ~ a + b * log log q  (slope -gamma_q)
            log_log_q = [math.log(math.log(q)) for q in qs2]
            b_log, a_log, r2_log = regress(log_log_q, ls2)
            gamma_q = -b_log

            refit[m][L] = {
                "polynomial": {"slope_delta_q": delta_q, "R2": r2_poly},
                "logarithmic": {"slope_gamma_q": gamma_q, "R2": r2_log},
            }

            winner = "log" if r2_log > r2_poly else "poly"
            print(f"  L={L:4d}  poly: delta_q={delta_q:+.3f} R^2={r2_poly:.3f}  |  log: gamma_q={gamma_q:+.3f} R^2={r2_log:.3f}  | winner: {winner}")

            summary_poly_r2.append(r2_poly)
            summary_log_r2.append(r2_log)
            summary_log_slope.append(gamma_q)

    print("\n=== SUMMARY ===\n")
    poly_r2_mean = float(np.mean(summary_poly_r2)) if summary_poly_r2 else 0
    log_r2_mean = float(np.mean(summary_log_r2)) if summary_log_r2 else 0
    log_slope_mean = float(np.mean(summary_log_slope)) if summary_log_slope else 0
    print(f"Polynomial model:    R^2 avg = {poly_r2_mean:.3f}")
    print(f"Logarithmic model:   R^2 avg = {log_r2_mean:.3f}   slope avg = {log_slope_mean:+.3f}")

    # Winner verdict
    print()
    if log_r2_mean > poly_r2_mean + 0.05 and log_slope_mean > 0 and log_r2_mean >= 0.6:
        verdict = "LOG_MODEL_FAVORED"
        msg = "Logarithmic q-decay model fits significantly better than polynomial. Supports BLMV-style log savings empirically."
    elif log_r2_mean > poly_r2_mean and log_slope_mean > 0:
        verdict = "LOG_MODEL_WEAKLY_FAVORED"
        msg = "Logarithmic model wins on R^2 but neither model fits well. Likely sub-logarithmic decay (even weaker than BLMV)."
    elif poly_r2_mean > log_r2_mean + 0.05:
        verdict = "POLY_MODEL_FAVORED"
        msg = "Polynomial model fits better. Conjecture B'-style decay would be empirically supported (but R577 already showed delta_q is small)."
    else:
        verdict = "NEITHER_FITS"
        msg = "Neither model fits well. q-direction signal is essentially noise at this scale."

    print(f"VERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r578_results.json"
    out.write_text(json.dumps({
        "refit": {str(m): {str(L): v for L, v in refit[m].items()} for m in M_LIST},
        "summary": {
            "polynomial_r2_mean": poly_r2_mean,
            "logarithmic_r2_mean": log_r2_mean,
            "logarithmic_slope_mean": log_slope_mean,
            "verdict": verdict,
            "interpretation": msg,
        }
    }, indent=2, default=str))
    print(f"\nWritten {out}")

if __name__ == "__main__":
    main()
