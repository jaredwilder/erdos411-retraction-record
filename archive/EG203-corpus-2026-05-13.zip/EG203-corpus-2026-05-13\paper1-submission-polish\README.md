
# EG203 Paper 1 — Oracle Submission Polish Packet

This packet contains the Oracle-polished submission draft for Paper 1:

**A Subgroup Obstruction Calculus for Two-Generator Exponential Congruences**

## Files

- `01_SUBGROUP_OBSTRUCTION_CALCULUS_SUBMISSION_DRAFT.tex`
- `COVER_LETTER.md`
- `REFEREE_CHECKLIST.md`
- `BUILD_NOTES.md`
- `ORACLE_RUN_LOG_PAPER1.md`

## What changed

The paper now foregrounds the strongest safe theorem package:

\[
\boxed{\text{complete finite probability calculus for subgroup obstructions}}
\]

including:
- exact local density;
- scaled Bernoulli law;
- all raw moments;
- total variation;
- chi-square divergence;
- KL divergence;
- character-annihilator expansion;
- exact centered moments;
- CRT orthogonality;
- weighted variance.

## Honest boundary

This paper does not solve Erdős–Graham Problem #203.  It gives the finite local obstruction calculus that the broader program uses.
