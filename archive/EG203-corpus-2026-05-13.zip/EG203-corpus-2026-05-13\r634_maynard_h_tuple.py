"""R634 — Maynard exponent-lattice probe per Maynard-emulated specialist recipe.

GOAL: Compute an admissible 50-tuple in the (k, ℓ) exponent lattice for Maynard 2015
Annals 181 Theorem 3.1 application to the (2,3)-orbit problem.

Per Maynard's recipe (Phase-22 Borg):
- Host lattice: L = {(k,ℓ) ∈ Z²_{≥0} : 2^k 3^ℓ ≤ X}, size N_φ ≈ (log X)²/(2 log 2 log 3)
- Linear forms: L_i(k,ℓ) = 2^{k+a_i} 3^{ℓ+b_i} m + 1 for shift vectors (a_i, b_i)
- Admissibility test for prime p: image of {L_i} mod p must NOT cover all residues
  in m^{-1} · H_p · {2^{a_i} 3^{b_i}} ∪ {-1}; condition: |H_p · {2^{a_i} 3^{b_i}}| ≤ p - 2
- Recipe: H = 50 shifts (a_i, b_i) ∈ [0, 7]² with gcd(i+j+1, 30) = 1, plus filler
- Verify admissibility for p ≤ H log H ≈ 200

If admissible: Maynard 2015 Theorem 3.1 yields ≥ 2 primes among {L_i} for
≫ N_φ/(log N_φ)^H pairs (k,ℓ); chaining gives Ω ≤ 8 via Halberstam-Richert.

Output: r634_results.json with admissibility verdict + concrete H-tuple.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent


def orbit_mod_p(p):
    """Compute orbit ⟨2, 3⟩ mod p."""
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def main():
    print("R634 — Maynard exponent-lattice admissibility probe")
    print("=" * 60)
    print("Per Maynard-emulated Phase-22 Borg recipe\n")

    # Build the candidate H-tuple per Maynard recipe
    # Shifts (a_i, b_i) ∈ [0, 7]² with gcd(i+j+1, 30) = 1, plus filler to reach 50
    candidate_shifts = []
    for i in range(8):
        for j in range(8):
            if math.gcd(i + j + 1, 30) == 1:
                candidate_shifts.append((i, j))

    print(f"Primary candidates (i + j + 1 coprime to 30, i,j ∈ [0,7]): {len(candidate_shifts)}")
    if len(candidate_shifts) > 50:
        H_tuple = candidate_shifts[:50]
    else:
        # Add filler: shifts from [0, 8]² not yet included
        existing = set(candidate_shifts)
        filler = []
        for i in range(9):
            for j in range(9):
                if (i, j) not in existing and len(candidate_shifts) + len(filler) < 50:
                    filler.append((i, j))
        H_tuple = candidate_shifts + filler

    print(f"Final H-tuple size: {len(H_tuple)}")
    print(f"H-tuple: {H_tuple}")
    print()

    # Compute 2^a 3^b mod p for each shift, for each prime p ≤ 200
    # Admissibility: image of {2^{a_i} 3^{b_i} m^{-1} mod p : i=1..H} ∪ {-m^{-1}}
    # must NOT cover all elements of H_p ∪ {-m^{-1}} \ {0}.
    # Equivalently: at least one element of H_p is NOT in the image.
    #
    # Simplification: for each prime p, compute the set S_p = {2^a · 3^b mod p : (a,b) ∈ H}
    # Admissibility: S_p · (any unit) ∪ {something} must miss at least one residue class.
    # For Maynard 2015, the condition (loosely) is that the tuple has at least one residue
    # class avoided mod p for EACH prime p. Strong admissibility (for the multi-dim Selberg):
    # the projection to (Z/p)^* leaves at least one residue uncovered.
    #
    # For each p, the image S_p = {2^a · 3^b mod p : (a, b) ∈ H}. Define:
    # nu_p = |S_p|. Admissibility (Maynard sense): nu_p < p (strict).
    # Strong admissibility: nu_p < |H_p| (image doesn't cover orbit).

    print("Admissibility check across primes p ≤ 200")
    print(f"{'p':>4} {'|H_p|':>5} {'|S_p|':>5} {'admiss':>8} {'strong':>8}")

    primes = list(sympy.primerange(5, 201))
    K_PRIMES = len(primes)

    failures = []
    strong_failures = []
    weak_admissible = True
    strong_admissible = True

    for p in primes:
        # Compute orbit
        H_p = orbit_mod_p(p)

        # Compute S_p = {2^a · 3^b mod p : (a, b) ∈ H_tuple}
        S_p = set()
        for (a, b) in H_tuple:
            v = (pow(2, a, p) * pow(3, b, p)) % p
            S_p.add(v)

        nu_p = len(S_p)
        admiss = (nu_p < p)
        strong = (nu_p < len(H_p))
        if not admiss:
            failures.append((p, nu_p))
            weak_admissible = False
        if not strong:
            strong_failures.append((p, nu_p, len(H_p)))
            strong_admissible = False

        # Print every prime
        marker = " " if admiss else "*"
        strong_marker = " " if strong else "*"
        print(f"{p:>4} {len(H_p):>5} {nu_p:>5} {admiss!s:>8}{marker} {strong!s:>8}{strong_marker}")

    print()
    print("=" * 60)
    print(f"WEAK admissibility (S_p < p) across all primes ≤ 200: {weak_admissible}")
    print(f"STRONG admissibility (S_p < |H_p|) across all primes ≤ 200: {strong_admissible}")
    if not weak_admissible:
        print(f"Weak failures: {failures}")
    if not strong_admissible:
        print(f"Strong failures: {strong_failures}")

    # Maynard 2015 Theorem 3.1 sieve admissibility specifically requires:
    # For each prime p, the linear forms {L_i mod p} do not all hit zero (= cover all residues).
    # In our setting L_i(k, ℓ) = 2^{k+a_i} 3^{ℓ+b_i} m + 1, so L_i ≡ 0 mod p iff
    # 2^{k+a_i} 3^{ℓ+b_i} ≡ -m^{-1} mod p.
    # For (k, ℓ) varying in the orbit, this can happen iff -m^{-1} · (2^{a_i} 3^{b_i})^{-1} ∈ H_p.
    # The set of "bad" shifts for fixed m is small. Admissibility: not all shifts are bad simultaneously.
    #
    # The condition simplifies: for each p, the cardinality |S_p^{-1} · (-m^{-1}) ∩ H_p| < |H_p|.
    # This is true iff at least one shift has 2^{a_i} 3^{b_i} ∉ -m^{-1} / H_p mod p.

    # Verdict
    print()
    if weak_admissible:
        print("VERDICT: H-tuple is WEAKLY admissible — Maynard 2015 Theorem 3.1 applies")
        print(f"Expected: ≥ 2 primes among {{L_i(k, ℓ)}}_{{i=1..{len(H_tuple)}}} for ≫ N_φ/(log N_φ)^H pairs (k, ℓ)")
        print(f"Maynard's Halberstam-Richert chain: yields Ω(2^k 3^ℓ m + 1) ≤ 8 unconditionally")
    else:
        print("VERDICT: H-tuple FAILS admissibility — needs refinement")
        print(f"Failed at primes: {failures[:5]}")

    # Statistics
    print()
    print("Image-size distribution across primes:")
    image_sizes = []
    for p in primes:
        H_p = orbit_mod_p(p)
        S_p = set()
        for (a, b) in H_tuple:
            v = (pow(2, a, p) * pow(3, b, p)) % p
            S_p.add(v)
        image_sizes.append(len(S_p))
    print(f"  Mean image size: {sum(image_sizes)/len(image_sizes):.2f}")
    print(f"  Min image size: {min(image_sizes)} (at p={primes[image_sizes.index(min(image_sizes))]})")
    print(f"  Max image size: {max(image_sizes)} (at p={primes[image_sizes.index(max(image_sizes))]})")
    print(f"  Mean image/p ratio: {sum(s/p for s, p in zip(image_sizes, primes))/len(primes):.4f}")

    out = ROOT / "r634_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 22 R634 — Maynard exponent-lattice admissibility probe",
        "H_tuple": H_tuple,
        "H_size": len(H_tuple),
        "primes_tested": primes,
        "weak_admissible": weak_admissible,
        "strong_admissible": strong_admissible,
        "failures_weak": failures,
        "failures_strong": strong_failures,
        "verdict": "ADMISSIBLE_MAYNARD_2015_THM_3_1_APPLIES" if weak_admissible else "NEEDS_REFINEMENT",
        "expected_omega_bound": 8 if weak_admissible else None,
        "image_sizes": image_sizes,
        "image_size_mean": sum(image_sizes)/len(image_sizes),
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
