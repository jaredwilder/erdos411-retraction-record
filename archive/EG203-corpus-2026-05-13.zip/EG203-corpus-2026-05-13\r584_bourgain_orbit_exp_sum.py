"""
R584 — Empirical Bourgain orbit exponential sum exponent.

Bourgain (GAFA 2005) gives: for multiplicative subgroup H <= (Z/p)^* with |H| >= p^delta,
    max_{a coprime to p} |sum_{x in H} e_p(a*x)|  <=  |H|^{1 - eta(delta)}
for some explicit eta(delta) > 0. Bourgain's eta(delta) is small and complicated; the EMPIRICAL eta(delta)
for our orbit H = <2, 3> mod p tells us how much actual cancellation is available.

For each prime p, compute:
    S(p) := max_{a in [1, p-1]} |sum_{x in H_p} e_p(a*x)|
    |H_p| := |<2, 3> mod p|
    delta(p) := log_p |H_p|

Then fit eta(delta) := 1 - log(S(p)) / log(|H_p|).

If eta(delta) > 0 robustly across our prime range, Bourgain-type cancellation is empirically real
and the path through Bourgain in the Type II error bound is viable.

If eta(delta) ~ 0 (trivial bound saturated), the cancellation is too weak for our purposes.

This is the heart of the Type II error bound in the Manuscript v4 §3-4 Möbius cancellation.
"""

from __future__ import annotations
import cmath, json, math, sys, time
from pathlib import Path
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

P_LIST = [17, 41, 67, 127, 257, 509, 1021, 2039, 4093, 8191, 16381, 32749, 65521]


def orbit_2_3_mod_p(p):
    """Return |<2, 3> mod p| and the orbit as a numpy array."""
    orbit = set()
    x = 1
    # Multiplicative orbit: starts at 1, multiply by 2 and 3 in BFS
    queue = [1]
    while queue:
        v = queue.pop()
        if v in orbit:
            continue
        orbit.add(v)
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                queue.append(w)
    return len(orbit), np.array(sorted(orbit), dtype=np.int64)


def max_exp_sum(p, orbit):
    """Compute max_{a in [1, p-1]} |sum_{x in orbit} e_p(a*x)| using FFT trick."""
    # We want to compute, for each a in 1..p-1, S_a = sum_x e_p(a*x).
    # Equivalent: indicator I[x] = 1 if x in orbit, else 0. Then S_a = sum_x I[x] e_p(a*x).
    # This is the DFT of I evaluated at -a (up to sign), so we use numpy FFT.
    I = np.zeros(p, dtype=np.complex128)
    for x in orbit:
        I[x] = 1.0
    F = np.fft.fft(I)  # F[k] = sum_x I[x] exp(-2 pi i k x / p)
    # |F[k]| for k = 1..p-1
    abs_F = np.abs(F[1:])
    return float(abs_F.max())


def main():
    print("R584 — Bourgain orbit exponential sum empirical fit\n")
    print(f"P_LIST = {P_LIST}\n")

    results = {}
    t0 = time.time()
    for p in P_LIST:
        t1 = time.time()
        H_size, orbit = orbit_2_3_mod_p(p)
        S = max_exp_sum(p, orbit)
        # Trivial bound: |S| <= |H|
        # Bourgain savings: |S| / |H|
        savings = S / H_size if H_size > 0 else 1.0
        # delta and eta:
        delta = math.log(H_size) / math.log(p) if H_size > 1 else 0
        # eta_emp := 1 - log(S) / log(H)
        if H_size > 1 and S > 1:
            eta_emp = 1.0 - math.log(S) / math.log(H_size)
        else:
            eta_emp = float('nan')
        elapsed = time.time() - t1
        results[p] = {
            "H_size": H_size,
            "max_exp_sum": S,
            "savings_S_over_H": savings,
            "delta": delta,
            "eta_emp": eta_emp,
            "trivial_bound": H_size,
        }
        print(f"  p={p:>5} |H|={H_size:>5} delta={delta:.3f} S_max={S:>10.4f} S/|H|={savings:.4f} eta_emp={eta_emp:+.4f}  t={elapsed:.2f}s")

    print(f"\nTotal compute: {time.time() - t0:.1f}s\n")

    # Aggregate
    etas = [r["eta_emp"] for r in results.values() if not math.isnan(r["eta_emp"])]
    deltas = [r["delta"] for r in results.values() if not math.isnan(r["eta_emp"])]
    savings = [r["savings_S_over_H"] for r in results.values()]

    print(f"=== AGGREGATE ===")
    print(f"Mean eta_emp   = {float(np.mean(etas)):+.4f}")
    print(f"Median eta_emp = {float(np.median(etas)):+.4f}")
    print(f"Min eta_emp    = {float(np.min(etas)):+.4f}")
    print(f"Max eta_emp    = {float(np.max(etas)):+.4f}")
    print(f"Mean S/|H|     = {float(np.mean(savings)):.4f}")

    # Verdict
    if all(e > 0.05 for e in etas):
        verdict = "BOURGAIN_SAVINGS_ROBUST"
        msg = f"All primes show eta_emp > 0.05. Empirical Bourgain-style cancellation IS available. Mean savings factor S/|H| = {float(np.mean(savings)):.4f}."
    elif sum(e > 0.05 for e in etas) >= len(etas) * 0.7:
        verdict = "BOURGAIN_SAVINGS_PARTIAL"
        msg = f"{sum(e>0.05 for e in etas)}/{len(etas)} primes show eta_emp > 0.05. Cancellation present but uneven."
    else:
        verdict = "BOURGAIN_SAVINGS_WEAK"
        msg = f"Few primes show meaningful cancellation. Empirical eta_emp distribution: {[f'{e:.3f}' for e in etas]}"

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r584_results.json"
    out.write_text(json.dumps({
        "P_LIST": P_LIST,
        "results": {str(p): r for p, r in results.items()},
        "summary": {
            "mean_eta_emp": float(np.mean(etas)),
            "median_eta_emp": float(np.median(etas)),
            "min_eta_emp": float(np.min(etas)),
            "max_eta_emp": float(np.max(etas)),
            "mean_savings": float(np.mean(savings)),
            "verdict": verdict,
            "interpretation": msg,
        },
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
