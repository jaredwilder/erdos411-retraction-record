"""R642 — Empirical verification of Linnik-Phase-24 Theorem 17 claim:
    overline{C(Q)} ~ Q^{-1/14} on q-average.

For primes q in multiple magnitude buckets, compute C(q) = D_N^w(q) · N^{0.65} at L=40.
Then compute average C bucketed by Q, and test scaling overline{C} · Q^{1/14}.

Linnik's prediction (if Theorem 17 holds): the q-averaged C(Q) should DECAY at rate Q^{-1/14}
unconditionally. Equivalently overline{C(Q)} · Q^{1/14} should be BOUNDED.

This is the cleanest empirical test of Conjecture B''-weak (on q-average) closing.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

L_TEST = 40


def support_pairs(L):
    pairs = []
    log2_3 = math.log2(3)
    for k in range(L + 1):
        max_ell = int((L - k) / log2_3)
        for ell in range(max_ell + 1):
            pairs.append((k, ell))
    return pairs


def orbit_mod_q(q):
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % q
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def compute_D_N_w(q, L, m=1):
    """Compute 2D weighted discrepancy at modulus q, support 2^L."""
    pairs = support_pairs(L)
    N_phi = len(pairs)
    H_q = orbit_mod_q(q)
    H_size = len(H_q)

    # Hann window weights
    log2_3 = math.log2(3)
    weights = [0.5 * (1 + math.cos(math.pi * (k + ell * log2_3) / L)) for (k, ell) in pairs]
    total_weight = sum(weights)

    # Histogram residues
    residue_weight = {}
    for i, (k, ell) in enumerate(pairs):
        val = (pow(2, k, q) * pow(3, ell, q) * m) % q
        residue_weight[val] = residue_weight.get(val, 0) + weights[i]

    # Discrepancy
    target_frac = 1 / H_size
    max_dev = 0
    for a in H_q:
        frac = residue_weight.get(a, 0) / total_weight
        dev = abs(frac - target_frac)
        if dev > max_dev:
            max_dev = dev

    return max_dev, N_phi


def main():
    print("R642 — Empirical verification of Linnik Theorem 17 (B''-weak on q-average)")
    print("=" * 70)
    print(f"L = {L_TEST}")
    print()

    # Generate primes in multiple buckets
    # Buckets at increasing magnitude
    bucket_caps = [50, 200, 1000, 5000, 30000, 200000]
    primes_to_test = []
    for cap in bucket_caps:
        bucket_primes = [p for p in sympy.primerange(max(5, bucket_caps[bucket_caps.index(cap) - 1] if bucket_caps.index(cap) > 0 else 5), cap + 1)]
        # Sample up to ~15 primes per bucket
        if len(bucket_primes) > 15:
            step = len(bucket_primes) // 15
            bucket_primes = bucket_primes[::step][:15]
        primes_to_test.extend([(p, cap) for p in bucket_primes])

    print(f"Testing {len(primes_to_test)} primes across {len(bucket_caps)} buckets")
    print(f"Buckets: caps at {bucket_caps}")
    print()

    # Compute C(q) for each prime
    print("Computing C(q) = D_N^w(q) · N^0.65 ...")
    print(f"{'q':>8} {'bucket':>8} {'D_N^w':>10} {'N_φ':>6} {'C(q)':>10}")

    results_by_bucket = {cap: [] for cap in bucket_caps}
    t0 = time.time()
    for p, cap in primes_to_test:
        D_N_w, N_phi = compute_D_N_w(p, L_TEST, m=1)
        C_q = D_N_w * (N_phi ** 0.65)
        results_by_bucket[cap].append({
            "q": p,
            "D_N_w": D_N_w,
            "N_phi": N_phi,
            "C_q": C_q,
        })
        # Print less frequently for speed
        if len(results_by_bucket[cap]) % 5 == 0 or p > 10000:
            print(f"{p:>8} {cap:>8} {D_N_w:>10.5f} {N_phi:>6} {C_q:>10.4f}")

    elapsed = time.time() - t0
    print(f"\nElapsed: {elapsed:.1f}s")

    # Compute mean C per bucket
    print("\n" + "=" * 70)
    print("=== Mean C(Q) per bucket ===\n")
    print(f"{'Q_max':>8} {'mean_log_Q':>12} {'mean C':>10} {'count':>8} "
          f"{'C · Q^{1/14}':>18} {'C · log(Q)^{-1/2}':>20}")

    bucket_stats = []
    for cap in bucket_caps:
        results = results_by_bucket[cap]
        if not results:
            continue
        mean_C = np.mean([r["C_q"] for r in results])
        mean_log_q = np.mean([math.log(r["q"]) for r in results])
        mean_q = np.exp(mean_log_q)
        # Linnik prediction: C(Q) ~ (log Q)^{1/2} · Q^{-1/14}
        # Test: mean_C · Q^{1/14} should be bounded by O((log Q)^{1/2})
        scaled_by_q = mean_C * (mean_q ** (1/14))
        scaled_by_log = mean_C / math.sqrt(mean_log_q)
        bucket_stats.append({
            "Q_cap": cap, "mean_log_Q": float(mean_log_q),
            "mean_C": float(mean_C), "count": len(results),
            "C_times_Q_1_14": float(scaled_by_q),
            "C_div_logQ_1_2": float(scaled_by_log),
        })
        print(f"{cap:>8} {mean_log_q:>12.3f} {mean_C:>10.4f} {len(results):>8} "
              f"{scaled_by_q:>18.4f} {scaled_by_log:>20.4f}")

    # Scaling analysis: fit log(mean_C) vs log(Q)
    print("\n=== Scaling analysis ===")
    log_Qs = [s["mean_log_Q"] for s in bucket_stats]
    mean_Cs = [s["mean_C"] for s in bucket_stats]
    log_Cs = [math.log(c) for c in mean_Cs]

    if len(log_Qs) >= 3:
        n = len(log_Qs)
        mx = sum(log_Qs)/n
        my = sum(log_Cs)/n
        num = sum((log_Qs[i] - mx)*(log_Cs[i] - my) for i in range(n))
        den = sum((log_Qs[i] - mx)**2 for i in range(n))
        slope = num/den if den > 0 else 0
        # δ_emp such that C ~ Q^{-δ}
        delta_emp = -slope
        # Linnik's prediction: δ = 1/14 ≈ 0.0714
        delta_linnik = 1/14
        print(f"Empirical δ from slope of log C(Q) vs log Q: {delta_emp:.4f}")
        print(f"Linnik's Th 17 prediction δ = 1/14 = {delta_linnik:.4f}")
        print(f"Diff: {abs(delta_emp - delta_linnik):.4f}")

        if delta_emp > 0.03:
            verdict = "POLYNOMIAL_DECAY_OBSERVED"
            print(f"\nVERDICT: {verdict}")
            print(f"Mean C(Q) decays polynomially in Q with δ ≈ {delta_emp:.3f}.")
            if abs(delta_emp - delta_linnik) < 0.05:
                print(f"→ MATCHES Linnik's Th 17 prediction δ = 1/14 within 0.05.")
                print(f"→ Empirical support for Conjecture B'' WEAK on q-average unconditional.")
        elif delta_emp > -0.03:
            verdict = "FLAT_NO_DECAY"
            print(f"\nVERDICT: {verdict}")
            print(f"Mean C(Q) is essentially flat — does NOT show polynomial decay.")
            print(f"→ Linnik's Th 17 prediction NOT empirically supported at this scale.")
        else:
            verdict = "INCREASING"
            print(f"\nVERDICT: {verdict}")
            print(f"Mean C(Q) INCREASING with Q — unexpected, requires analysis.")

    out = ROOT / "r642_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 24 R642 — Linnik Theorem 17 empirical verification",
        "L": L_TEST,
        "primes_tested": [(p, cap) for p, cap in primes_to_test],
        "bucket_stats": bucket_stats,
        "delta_emp": float(delta_emp) if len(log_Qs) >= 3 else None,
        "delta_linnik_prediction": 1/14,
        "verdict": verdict,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
