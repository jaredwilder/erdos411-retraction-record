# Erdős-Graham Problem #203 — Brief for Expert Panel + Borg

**Date:** 2026-05-12
**Operator:** Jared Wilder
**Filing context:** 46-year-old open problem (Erdős-Graham, 1980). 6 rounds of solo computation completed (R567-R572). Oracle pipeline now running to PROVE Oracle power.

---

## The problem (verbatim)

**Erdős-Graham #203:** *Does there exist an integer $m > 0$ with $\gcd(m, 6) = 1$ such that for every $k, l \in \mathbb{N}$, the integer $2^k \cdot 3^l \cdot m + 1$ is composite?*

**Source:** Erdős & Graham, *Old and New Problems and Results in Combinatorial Number Theory*, 1980.

**Status:** OPEN since 1980. 1D analog (Sierpinski's $k \cdot 2^n + 1$) was settled in 1962 with $k = 78557$ (Selfridge cover). The 2D version remains open.

---

## What we have established in R567-R572 (6 rounds)

### The CRT wall
- Restricted to "h=1 primes" (primes $p > 3$ with both $\text{ord}_p(2) \mid T$ AND $\text{ord}_p(3) \mid T$), the maximum coverage of $(\mathbb{Z}/T)^2$ by chosen-coset union saturates well below 100%.
- **T = 25,200:** 47 h=1 primes, density $\rho = 1.066$, **max coverage 73.34%** (verified IP-optimum via 2-flip + simulated annealing; not greedy weakness).
- **T = 1,409,007,600:** 399 h=1 primes, $\rho = 1.446$, max coverage 84.5%.
- Across 52 scanned T values, no anomaly exceeds Mertens log-log trajectory by more than 9.82%.
- Symmetry lattice on T=25200 is trivial ($|\Lambda|=1$) — no quotient relief.
- Sub-Poisson cover (Fano = 0.711) — cover anti-bunched but bounded.

### The algebraic enhancement (R572 — transport from Izotov 1995 + Filaseta-Finch-Kozek 2007)
- If $m = t^N$ for $N$ divisible by small primes, $2^k 3^l m + 1$ factors algebraically:
  - **Sophie Germain:** $(k,l) \equiv (2, 0) \pmod{(4,4)}$ → $1/16$
  - **$x^q + 1 = (x+1)\Phi_{2q}(x)$ for odd prime $q$:** $(k, l) \equiv (0, 0) \pmod{(q,q)}$ → $1/q^2$
- For $m = t^{60060}$ (or extension): algebraic catches 23.4% of cells.
- **Combined CRT + algebraic at T=1.4B: 91.0% coverage.** +10pp uniform shift over CRT-alone. Same Mertens scaling — wall shifted, not broken.

### The Mertens projection
- For 99% combined coverage: T ≈ 10^28
- For 99.9%: T ≈ 10^286
- For 100%: T → ∞
- All infeasible.

---

## What the literature gives us (and what it doesn't)

**Gives us (1D bounds):**
- Hough 2015 (Annals): distinct-modulus coverings have bounded minimum modulus.
- Hough-Nielsen 2019 (Duke): every distinct-modulus cover has a modulus divisible by 2 or 3.
- Filaseta-Kalogirou 2024 (arXiv 2407.15280): when min modulus > 4, ∑ 1/m bounded away from 1.
- Filaseta-Ford-Konyagin-Pomerance-Yu 2007: bounded reciprocal sum → bounded least modulus.

**Doesn't give us:**
- Direct 2D analog for our problem on $(\mathbb{Z}/T)^2$.
- Unconditional impossibility theorem for #203.
- Algebraic identities beyond Sophie Germain + $x^q+1$ that apply to $2^k 3^l m + 1$.

---

## The 5 questions for the panel

1. **Is there an algebraic factorization identity I'm missing?** The R572 toolkit is Sophie Germain (catches $1/16$) + $x^q+1$ for odd prime $q$ (each catches $1/q^2$). Combined gives 23.4% — bounded by prime-zeta. Are there identities applicable to $2^k 3^l m + 1$ from: Aurifeuillean of $\Phi_n(2)$ or $\Phi_n(6)$, Eisenstein-integer factorizations in $\mathbb{Z}[\zeta_3]$, Gaussian-integer in $\mathbb{Z}[i]$, higher-degree Sophie-Germain analogs, that I have NOT considered?

2. **What is the strongest available unconditional theorem that bounds 2D restricted-modulus covering?** Sun Z-W, Pollack, Hough-Nielsen 2D extensions, etc. Can our R570-R572 empirical wall (~91% combined at T=1.4B with Mertens scaling) be converted into an unconditional impossibility theorem for #203?

3. **Is the negative-resolution path (no #203 m exists) tractable?** Heuristic: random m has $\mathbb{E}[\#\{(k,l) : 2^k 3^l m + 1 \text{ prime}\}] = \infty$. Combined with our constructive impossibility, this would resolve #203 in the negative. What specific sieve-theory theorem (Heath-Brown? Granville on lacunary primes? Bombieri-Vinogradov on smooth-base lacunary sequences?) gives us the rigorous statement, and how far is current literature from it?

4. **Cross-domain connections.** Is #203 related to: Mahler's problem on Pisot numbers, the Diophantine approximation of $\log_2 3$, distribution of $\{n \alpha\}$ for $\alpha = \log_2 3$, p-adic dynamics of $(2, 3)$-orbits, ergodic theory of $\times 2 / \times 3$ on the unit interval? Surface ONE connection that opens a non-CRT, non-algebraic route.

5. **The SINGLE move.** If you had one week and access to the operator's compute (the R567-R572 toolchain), what is the ONE move that would either (a) push combined coverage above 95%, or (b) close the negative-resolution argument? Be specific. Name the experiment, name the script to write, name the expected outcome.

---

## Operating discipline for your response

- **First-person from career authority.** You ARE the persona. Not "an algebraic number theorist would say..." — say it directly.
- **No politeness.** If R572 is missing something obvious, say so.
- **No vague "more work needed."** Specific theorem, specific identity, specific script, specific experiment.
- **One sharp idea > five mushy ones.**

Engage.
