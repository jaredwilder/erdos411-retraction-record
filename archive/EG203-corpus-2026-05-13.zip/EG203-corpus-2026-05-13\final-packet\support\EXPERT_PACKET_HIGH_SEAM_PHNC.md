# MINIMAL EXPERT PACKET — HIGH-SEAM PHNC QUESTION

## Context

I have developed an exact local obstruction framework for the Erdős–Graham #203 sequence
\[
m2^k3^\ell+1.
\]
The local algebra and CRT synchronization pieces are elementary.  A conditional route to the full problem reduces to a fixed-radical Kummer non-concentration estimate.

I am **not** asking for endorsement and not claiming this theorem is known.  I am asking whether the analytic estimate below is known, false, or plausibly new.

## Exact question

Let
\[
K_\ell=\mathbb Q(\zeta_\ell),
\qquad
\chi_{r,s}
=
\left(\frac{2}{\cdot}\right)_\ell^r
\left(\frac{3}{\cdot}\right)_\ell^s
\]
for nonzero \((r,s)\in\mathbb F_\ell^2\).

For fixed \(B>0\), does there exist \(C=C(B)>0\) such that, uniformly for all primes
\[
\ell\le(\log Q)^B
\]
and all nonzero \((r,s)\), one has
\[
\#\{q\le Q:q\equiv1\bmod\ell,\ \chi_{r,s}(q)=1\}
\le
(1-\ell^{-C})\pi(Q;\ell,1)?
\]

Equivalently:
\[
\mathbb P_{q\le Q,\ q\equiv1\bmod\ell}[\chi_{r,s}(q)=1]\le1-\ell^{-C}.
\]

## What I believe is known

Effective Chebotarev/log-free Hecke estimates appear to cover a lower range where the field/conductor parameter is dominated by \(\log Q\), roughly
\[
\ell\log\ell\ll\log Q.
\]
The hard seam is
\[
(\log Q)^{1-\varepsilon}<\ell\le(\log Q)^B.
\]

## Three specific questions

1. Is there a known Hecke/Siegel-Walfisz/Chebotarev theorem that gives the above non-concentration uniformly in this growing family?
2. If not, is there a known obstruction showing fixed-field ineffective Chebotarev cannot be made uniform enough here?
3. Is the right replacement an average-over-\(\ell\) large sieve for these fixed-radical Kummer characters rather than pointwise Chebotarev?

## One-sentence ask

Would you be willing to give a blunt technical reaction: known / false / plausible but open / misformulated?
