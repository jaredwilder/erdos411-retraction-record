# NO-OVERCLAIM RULES — FINAL

## Forbidden claims

Do not claim:

1. “Erdős–Graham #203 is solved.”
2. “PHNC is proved for all \(\ell\le(\log Q)^B\).”
3. “Density-zero exceptional set solves #203.”
4. “BFI supplies the needed Kummer bad-character bound.”
5. “Fixed-field ineffective Chebotarev gives the needed growing-family uniformity.”
6. “The Oracle verified the theorem by swarm consensus.”

## Allowed claims

You may claim:

1. Exact local subgroup densities.
2. Exact finite moment identities.
3. Character-annihilator expansion.
4. CRT synchronization criterion.
5. Pair determinant/projective slope criterion.
6. Rational Kummer independence.
7. Verified finite examples.
8. A density-zero theorem schema pending exact sieve/Pappalardi insertion.
9. A conditional Kummer distribution criterion for #203.
10. A precise open high-seam PHNC problem.

## One-sentence safe pitch

> I developed an exact subgroup-obstruction calculus for two-generator exponential congruence problems, with applications to Erdős–Graham #203 and a precise Kummer non-concentration criterion for the full problem.
