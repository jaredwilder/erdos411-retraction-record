"""
R576 — Polignac empirical corollary.

Polignac's conjecture (1849): every odd integer m can be written as m = |2^n - p|
for some prime p and n >= 0. Equivalently: for every odd m, the set
{n : m + 2^n is prime} is infinite.

Our unified dichotomy v3 §7 predicts: for each odd m, either (I) a finite cover
makes m+2^n composite for all n, or (II) {n : m+2^n prime} is infinite (conditional).

Compute tau_P(m) := min{n : m + 2^n is prime} for sampled m. Cover-Sierpinski m
will have tau_P infinite.
"""

from __future__ import annotations
import json, math, random, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

N_MAX = 200
M_BOUND = 1_000_000
N_SAMPLES = 5_000


def find_tau_P(m: int, n_max: int):
    for n in range(0, n_max + 1):
        val = m + (1 << n)
        if val > 2 and sympy.isprime(val):
            return n
    return None


def main():
    rng = random.Random(204)
    m_values = set()
    while len(m_values) < N_SAMPLES:
        m = rng.randint(1, M_BOUND)
        if m % 2 == 1:  # odd
            m_values.add(m)
    m_values = sorted(m_values)
    print(f"Polignac empirical: {len(m_values)} odd m in [1, {M_BOUND}], n_max={N_MAX}")

    t0 = time.time()
    taus = []
    no_prime = []
    for i, m in enumerate(m_values):
        t = find_tau_P(m, N_MAX)
        if t is None:
            no_prime.append(m)
        else:
            taus.append((m, t))
        if (i+1) % 500 == 0:
            elapsed = time.time() - t0
            print(f"  [{i+1}/{len(m_values)}] elapsed={elapsed:.0f}s, no_prime_so_far={len(no_prime)}")

    print(f"\nTotal: {time.time()-t0:.0f}s")
    print(f"\n=== STATS ===")
    print(f"m tested: {len(m_values)}")
    print(f"tau found: {len(taus)}")
    print(f"NO prime within n<={N_MAX}: {len(no_prime)}")
    if no_prime:
        print(f"  Polignac-resistant candidates (small sample): {no_prime[:30]}")

    if taus:
        tau_values = [t for m, t in taus]
        # histogram
        from collections import Counter
        hist = Counter(tau_values)
        max_tau = max(tau_values)
        print(f"\ntau_P distribution:")
        for t in sorted(hist.keys()):
            if t <= 50 or t == max_tau:
                print(f"  tau = {t:>4}: {hist[t]} m values ({100*hist[t]/len(taus):.2f}%)")
        print(f"\nmax tau_P = {max_tau}")
        print(f"mean tau_P / log m = {sum(t/math.log(m) for m,t in taus if m > 1)/len(taus):.4f}")

    out = ROOT / "r576_polignac_results.json"
    out.write_text(json.dumps({
        "n_samples": N_SAMPLES,
        "m_bound": M_BOUND,
        "n_max": N_MAX,
        "n_no_prime": len(no_prime),
        "no_prime_m": no_prime[:200],
        "tau_distribution": dict(Counter([t for m, t in taus])),
        "max_tau": max(t for m,t in taus) if taus else None,
    }, indent=2, default=str))
    print(f"\nWritten to {out}")

if __name__ == "__main__":
    main()
