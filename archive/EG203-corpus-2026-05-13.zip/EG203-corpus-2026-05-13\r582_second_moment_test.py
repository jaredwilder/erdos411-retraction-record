"""
R582 — Second-moment empirical verification for Corollary 4.1 proof.

Computes
    A(q, L) := (1/q) * sum_{m=0}^{q-1} |W_m(q, L)|^2
where
    W_m(q, L) := sum_{(k, l): 2^k 3^l <= 2^L} phi(k, l) * e_q(2^k 3^l m)
    phi(k, l) = Hann(k/L) * Hann(l log_2(3)/L)
    e_q(x) = exp(2 pi i x / q)

Predicted asymptotic (Parseval orthogonality):
    A(q, L) = N_phi + N_phi^2 / |<2,3> mod q|
where N_phi = sum phi.

The pre-registered verdict:
    PASS: empirical A(q, L) / (N_phi + N_phi^2/O_q) is in [0.5, 2.0] for >= 80% of (q, L) pairs.
    FAIL: ratio is outside [0.1, 10] for >= 30% of pairs.
    AMBIGUOUS: otherwise.

This validates Step 2 of the Corollary 4.1 sketch in manuscript v4.1 §6.2.
"""

from __future__ import annotations
import cmath, math, sys, time, json
from pathlib import Path
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

LOG2_3 = math.log2(3.0)
Q_LIST = [17, 41, 67, 127, 257, 509, 1021]  # primes; restrict to smaller for tractable second-moment
L_LIST = [50, 100, 200]


def hann(x):
    if x < 0 or x > 1:
        return 0.0
    return math.cos(math.pi * x / 2.0) ** 2


def enumerate_support(L):
    pts = []
    for k in range(L + 1):
        lmax = math.floor((L - k) / LOG2_3)
        for l in range(lmax + 1):
            pts.append((k, l))
    return pts


def second_moment_average(q, L):
    """Compute (1/q) sum_{m=0}^{q-1} |W_m(q, L)|^2 and the predicted value."""
    pts = enumerate_support(L)
    # Precompute b(k, l) = 2^k 3^l mod q and phi(k, l)
    pow2 = [1] * (L + 1)
    for k in range(1, L + 1):
        pow2[k] = (pow2[k-1] * 2) % q
    pow3 = [1] * (L + 1)
    for l in range(1, L + 1):
        pow3[l] = (pow3[l-1] * 3) % q

    bs = []
    ws = []
    for (k, l) in pts:
        w = hann(k / L) * hann((l * LOG2_3) / L)
        if w == 0:
            continue
        bs.append((pow2[k] * pow3[l]) % q)
        ws.append(w)

    N_phi = sum(ws)
    bs = np.array(bs, dtype=np.int64)
    ws = np.array(ws, dtype=np.float64)

    # Sum_m |W_m|^2 = sum_{(k1,l1), (k2,l2)} phi phi * sum_m e_q(m * (b1 - b2))
    # = q * sum_{(k1,l1), (k2,l2)} phi phi * 1[b1 == b2]
    # So (1/q) Sum_m |W_m|^2 = sum_{(k1,l1), (k2,l2)} phi phi * 1[b1 == b2]
    # = sum over residues a of (sum_{(k,l) with b=a} phi)^2

    # Compute (sum_{(k,l): b == a} phi)^2 for each a
    bin_sums = np.zeros(q, dtype=np.float64)
    for b, w in zip(bs, ws):
        bin_sums[b] += w
    A = float((bin_sums ** 2).sum())

    # Compute orbit size
    orbit = set()
    for k in range(L + 1):
        for l in range(L + 1):
            orbit.add((pow2[k] * pow3[l]) % q)
            if len(orbit) >= q:
                break
        if len(orbit) >= q:
            break
    orbit_size = len(orbit)

    # Predicted A = N_phi + N_phi^2 / orbit_size
    predicted = N_phi + N_phi ** 2 / orbit_size

    return A, predicted, N_phi, orbit_size


def main():
    print("R582 — Second-moment empirical verification\n")
    print(f"Q_LIST = {Q_LIST}")
    print(f"L_LIST = {L_LIST}\n")

    results = {}
    ratios = []
    t0 = time.time()

    for L in L_LIST:
        results[L] = {}
        print(f"--- L = {L} ---")
        for q in Q_LIST:
            t1 = time.time()
            A, pred, N_phi, orbit = second_moment_average(q, L)
            ratio = A / pred if pred > 0 else float('nan')
            elapsed = time.time() - t1
            results[L][q] = {
                "A_empirical": A,
                "A_predicted": pred,
                "ratio": ratio,
                "N_phi": N_phi,
                "orbit_size": orbit,
            }
            ratios.append(ratio)
            print(f"  q={q:>5} orbit={orbit:>4} N_phi={N_phi:>8.1f} A_emp={A:>10.2e} A_pred={pred:>10.2e} ratio={ratio:.4f}  t={elapsed:.2f}s")

    print(f"\nTotal compute: {time.time() - t0:.1f}s")

    # ============================================================
    # VERDICT
    # ============================================================
    print("\n=== SECOND-MOMENT VERDICT ===\n")
    ratios_arr = np.array(ratios)
    pct_in_band_strict = float((np.abs(ratios_arr - 1.0) < 1.0).mean())  # within [0, 2]
    pct_in_band_tight = float(((ratios_arr > 0.5) & (ratios_arr < 2.0)).mean())  # [0.5, 2]
    pct_out_of_loose_band = float(((ratios_arr < 0.1) | (ratios_arr > 10.0)).mean())

    mean_ratio = float(ratios_arr.mean())
    median_ratio = float(np.median(ratios_arr))
    std_ratio = float(ratios_arr.std())

    print(f"Mean ratio (empirical/predicted): {mean_ratio:.4f}")
    print(f"Median ratio: {median_ratio:.4f}")
    print(f"Stdev ratio: {std_ratio:.4f}")
    print(f"Fraction in tight band [0.5, 2.0]: {pct_in_band_tight:.2%}")
    print(f"Fraction OUT of loose band [0.1, 10.0]: {pct_out_of_loose_band:.2%}")

    if pct_in_band_tight >= 0.8:
        verdict = "PASS"
        interp = "Second-moment matches predicted asymptotic. Step 2 of Corollary 4.1 proof empirically validated."
    elif pct_out_of_loose_band >= 0.3:
        verdict = "FAIL"
        interp = "Second-moment far from predicted. Corollary 4.1 proof needs revisiting."
    else:
        verdict = "AMBIGUOUS"
        interp = "Empirical matches expected scaling but with non-trivial offset. Investigate."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {interp}")

    # Save
    out = ROOT / "r582_results.json"
    out.write_text(json.dumps({
        "Q_LIST": Q_LIST,
        "L_LIST": L_LIST,
        "results": {str(L): {str(q): v for q, v in results[L].items()} for L in L_LIST},
        "summary": {
            "mean_ratio": mean_ratio,
            "median_ratio": median_ratio,
            "stdev_ratio": std_ratio,
            "pct_in_tight_band": pct_in_band_tight,
            "pct_out_of_loose_band": pct_out_of_loose_band,
            "verdict": verdict,
            "interpretation": interp,
        }
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
