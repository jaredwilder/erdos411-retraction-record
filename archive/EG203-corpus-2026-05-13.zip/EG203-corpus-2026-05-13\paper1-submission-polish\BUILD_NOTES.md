
# Build Notes

Compile with:

```bash
pdflatex 01_SUBGROUP_OBSTRUCTION_CALCULUS_SUBMISSION_DRAFT.tex
pdflatex 01_SUBGROUP_OBSTRUCTION_CALCULUS_SUBMISSION_DRAFT.tex
```

The document uses:
- amsmath
- amssymb
- amsthm
- mathtools
- enumitem
- hyperref
- cleveref

If `cleveref` is unavailable, remove:
```latex
\usepackage[nameinlink,capitalize]{cleveref}
```
and replace `\cref{...}` with `Theorem~\ref{...}`, `Lemma~\ref{...}`, etc.
