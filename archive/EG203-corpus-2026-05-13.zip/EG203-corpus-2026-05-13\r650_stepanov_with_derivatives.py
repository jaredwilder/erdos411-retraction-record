"""R650 — UPGRADED Stepanov polynomial construction WITH derivative constraints
baked into the linear system from the start.

R648 found ANY P vanishing on V_q. R649 confirmed that polynomial has r = 0.
The Stepanov-method needs P with simultaneous derivative-vanishing constraints.

For each prime q and target derivative order r:
  - Constraint matrix has |V_q| × (r+1)(r+2)/2 rows
    (one row for each (point, derivative order (dx, dy) with dx+dy ≤ r))
  - Variable space: monomials of total degree ≤ D, dim = (D+1)(D+2)/2
  - Need dim > #constraints for nontrivial solution
  - Find minimal (D, r) such that the system is underdetermined AND a nontrivial P
    with that derivative-vanishing exists

This empirically anchors Section §4 of Theorem 22 manuscript: derivative order
m_q = c_0 log h_q at the Bombieri-Stepanov-Heath-Brown-Konyagin predicted rate.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent


def orbit_points(q):
    seen_x = []
    x = 1
    while True:
        seen_x.append(x)
        x = (x * 2) % q
        if x == 1:
            break
    seen_y = []
    y = 1
    while True:
        seen_y.append(y)
        y = (y * 3) % q
        if y == 1:
            break
    return {(xv, yv) for xv in seen_x for yv in seen_y}


def monomial_basis(D):
    return [(i, j) for i in range(D + 1) for j in range(D + 1) if i + j <= D]


def derivative_constraint_row(xv, yv, monomials, dx, dy, q):
    """Row of constraint matrix corresponding to (∂_X^dx ∂_Y^dy P)(xv, yv) = 0."""
    row = []
    for (i, j) in monomials:
        if i < dx or j < dy:
            row.append(0)
            continue
        # Falling factorial
        fx = 1
        for t in range(dx):
            fx = (fx * (i - t)) % q
        fy = 1
        for t in range(dy):
            fy = (fy * (j - t)) % q
        row.append((fx * fy * pow(xv, i - dx, q) * pow(yv, j - dy, q)) % q)
    return row


def find_stepanov_polynomial(q, V_q, D, r):
    """Find P ∈ F_q[X,Y] of deg ≤ D such that ∂_X^dx ∂_Y^dy P vanishes on V_q
    for all dx+dy ≤ r. Returns (coefs, monomials) or (None, None) if no nontrivial solution."""
    monomials = monomial_basis(D)
    n_monomials = len(monomials)

    # Build constraint matrix
    rows = []
    for (xv, yv) in V_q:
        for dx in range(r + 1):
            for dy in range(r - dx + 1):
                rows.append(derivative_constraint_row(xv, yv, monomials, dx, dy, q))

    n_rows = len(rows)
    n_cols = n_monomials

    if n_cols <= n_rows:
        return None, None  # no slack

    # Gaussian elimination over F_q
    pivot_row = [None] * n_cols
    pivot_col = [None] * n_rows
    cur_row = 0
    for c in range(n_cols):
        if cur_row >= n_rows:
            break
        pivot = None
        for s in range(cur_row, n_rows):
            if rows[s][c] % q != 0:
                pivot = s
                break
        if pivot is None:
            continue
        rows[cur_row], rows[pivot] = rows[pivot], rows[cur_row]
        inv = pow(rows[cur_row][c], -1, q)
        rows[cur_row] = [(v * inv) % q for v in rows[cur_row]]
        for s in range(n_rows):
            if s != cur_row and rows[s][c] % q != 0:
                factor = rows[s][c]
                rows[s] = [(rows[s][k] - factor * rows[cur_row][k]) % q for k in range(n_cols)]
        pivot_row[c] = cur_row
        pivot_col[cur_row] = c
        cur_row += 1

    free_cols = [c for c in range(n_cols) if pivot_row[c] is None]
    if not free_cols:
        return None, None

    coefs = [0] * n_cols
    coefs[free_cols[0]] = 1
    for c in range(n_cols):
        if pivot_row[c] is not None:
            r_idx = pivot_row[c]
            coefs[c] = (-rows[r_idx][free_cols[0]]) % q

    return coefs, monomials


def main():
    print("R650 — Upgraded Stepanov polynomial with derivative-vanishing constraints")
    print("=" * 80)

    primes = [5, 7, 11, 13, 17, 23, 31]
    print(f"\nTarget: find min D such that P of deg ≤ D vanishes on V_q with derivative")
    print(f"order ≥ r predicted by Heath-Brown-Konyagin: r ≈ 0.25 log h_q\n")

    print(f"{'q':>4} {'|V_q|':>6} {'r_target':>9} {'D_min':>6} {'D/sqrt|V_q|':>13} {'D^2/((r+1)|V_q|)':>17}")

    results = []
    for q in primes:
        V_q = orbit_points(q)
        h_q = len(V_q)
        # Target derivative order from HB-Konyagin prediction
        r_target = max(1, int(math.log(h_q) / 4))

        # Find minimum D for which the system with r_target derivative constraints
        # has nontrivial solution
        n_constraints_per_pt = (r_target + 1) * (r_target + 2) // 2
        total_constraints = h_q * n_constraints_per_pt
        # Need (D+1)(D+2)/2 > total_constraints
        D_min_lower = int(math.sqrt(2 * total_constraints))
        D_min = D_min_lower
        found = False
        while D_min <= 4 * D_min_lower and D_min < 40:
            coefs, monomials = find_stepanov_polynomial(q, V_q, D_min, r_target)
            if coefs is not None:
                found = True
                break
            D_min += 1

        if found:
            sqrt_V = math.sqrt(h_q)
            ratio_D_sqrt = D_min / sqrt_V
            bezout_ratio = (D_min ** 2) / ((r_target + 1) * h_q)
            print(f"{q:>4} {h_q:>6} {r_target:>9} {D_min:>6} {ratio_D_sqrt:>13.3f} {bezout_ratio:>17.3f}")
            results.append({
                "q": q, "h_q": h_q, "r_target": r_target,
                "D_min": D_min, "D_over_sqrt_h": ratio_D_sqrt,
                "bezout_ratio": bezout_ratio,
            })
        else:
            print(f"{q:>4} {h_q:>6} {r_target:>9} {'NA':>6}")

    print("\n=== Stepanov-Bombieri sharp-bound verification ===")
    if results:
        # Stepanov-Bombieri: D^2 / ((r+1)|V_q|) should be ≈ 1 (Bezout tight) or > 1 (slack)
        avg_bezout = sum(r["bezout_ratio"] for r in results) / len(results)
        print(f"Mean D^2/((r+1)|V_q|): {avg_bezout:.3f}")
        print(f"Stepanov-Bombieri sharp prediction: ≈ 1 (Bezout tight bound)")

        # Check scaling: log(D_min) vs log(h_q) at fixed r-target-rate
        log_h = [math.log(r["h_q"]) for r in results]
        log_D = [math.log(r["D_min"]) for r in results]
        n = len(log_h)
        mx = sum(log_h) / n
        my = sum(log_D) / n
        num = sum((log_h[i] - mx) * (log_D[i] - my) for i in range(n))
        den = sum((log_h[i] - mx) ** 2 for i in range(n))
        slope = num / den if den > 0 else 0
        print(f"\nSlope log(D_min) vs log(h_q): {slope:.4f}")
        print(f"Stepanov-Bombieri prediction with derivative order r ~ log h: slope = 1/2 (D ~ h^{{1/2}})")
        print(f"Empirical: {slope:.3f}")

    out = ROOT / "r650_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 27 R650 — Stepanov polynomial with derivative-vanishing constraints",
        "primes_tested": primes,
        "results": results,
        "HB_Konyagin_r_target_formula": "r = floor(log(h_q) / 4)",
        "stepanov_bombieri_bezout_prediction": "D^2 / ((r+1)|V_q|) ≈ 1",
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
