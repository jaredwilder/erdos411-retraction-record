"""R602 — Asymptotic L-scaling verification for worst-case m.

For 10 worst-case m's from R599, compute P(m, L) for L in {30, 40, 50, 60, 70}.
Test whether P(m, L) grows LINEARLY with N_phi(L) (orbit support size).

If P/N_phi stays roughly constant across L (≈ S(m)/log(2^L m)), then:
  A(m) is INFINITE empirically (with rate matching heuristic).

This is the strongest empirical statement we can make about A(m) being infinite
for specific m.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

LOG2_3 = math.log2(3.0)


def count_primes_in_orbit(m, L):
    cnt = 0
    n_pairs = 0
    for k in range(L + 1):
        pow2k = 1 << k
        pow3l = 1
        l = 0
        while True:
            val = pow2k * pow3l
            if val > (1 << L):
                break
            n = val * m + 1
            n_pairs += 1
            if sympy.isprime(n):
                cnt += 1
            pow3l *= 3
            l += 1
    return cnt, n_pairs


def main():
    print("R602 — Asymptotic L-scaling for worst-case m\n")

    # Top 10 worst-case from R599
    r599 = json.loads((ROOT / "r599_results.json").read_text())
    worst_10 = r599["worst_100"][:10]
    print(f"Worst 10 m's from R599: {[w[0] for w in worst_10]}\n")

    L_LIST = [30, 40, 50, 60, 70]
    results = {}

    t0 = time.time()
    for entry in worst_10:
        m = entry[0]
        row = {}
        print(f"--- m = {m} ---")
        for L in L_LIST:
            t1 = time.time()
            P, N_phi = count_primes_in_orbit(m, L)
            density = P / N_phi if N_phi > 0 else 0
            elapsed = time.time() - t1
            row[L] = {"P": P, "N_phi": N_phi, "density": density}
            # Heuristic prediction: density ~ 1/log(2^L m)
            heur_density = 1.0 / (L * math.log(2) + math.log(m))
            # Singular series estimate (just rough multiplier ~ 2.5 for these m's)
            print(f"  L={L:>3}: P={P:>5}, N_phi={N_phi:>6}, density={density:.5f}, heur_density_ratio={density / heur_density:.3f}, t={elapsed:.1f}s")
        results[m] = row

    elapsed_total = time.time() - t0
    print(f"\nTotal compute: {elapsed_total:.0f}s\n")

    # Analyze: is P linear in N_phi?
    print("=== ASYMPTOTIC SCALING ANALYSIS ===\n")
    import numpy as np
    all_growth_rates = []
    for m, row in results.items():
        # Linear fit of P vs N_phi
        Ls = sorted(row.keys())
        Ns = [row[L]["N_phi"] for L in Ls]
        Ps = [row[L]["P"] for L in Ls]
        # Linear regression P ~ a * N_phi + b
        N_arr = np.array(Ns, dtype=np.float64)
        P_arr = np.array(Ps, dtype=np.float64)
        if len(N_arr) >= 2:
            slope = float(np.cov(N_arr, P_arr, bias=False)[0, 1] / np.var(N_arr))
            intercept = float(P_arr.mean() - slope * N_arr.mean())
            # R^2
            ss_res = float(((P_arr - (slope * N_arr + intercept))**2).sum())
            ss_tot = float(((P_arr - P_arr.mean())**2).sum())
            r2 = 1 - ss_res/ss_tot if ss_tot > 0 else 0
            all_growth_rates.append(slope)
            print(f"  m={m:>7}: P ≈ {slope:.4f} * N_phi + {intercept:.1f}, R^2 = {r2:.4f}")

    print(f"\n  Mean growth rate (slope): {sum(all_growth_rates)/len(all_growth_rates):.4f}")
    print(f"  Min growth rate: {min(all_growth_rates):.4f}")
    print(f"  Max growth rate: {max(all_growth_rates):.4f}")

    # Verdict
    min_slope = min(all_growth_rates)
    if min_slope > 0.01:
        verdict = "ASYMPTOTIC_LINEAR_GROWTH_CONFIRMED"
        msg = f"All 10 worst-case m show P(m, L) growing LINEARLY in N_phi(L). Min growth rate = {min_slope:.4f} > 0. A(m) is empirically INFINITE for every worst-case m."
    else:
        verdict = "SUBLINEAR"
        msg = f"Some m show sublinear growth. Min slope = {min_slope:.4f}."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r602_results.json"
    out.write_text(json.dumps({
        "L_LIST": L_LIST,
        "worst_10_m": [w[0] for w in worst_10],
        "results": {str(m): row for m, row in results.items()},
        "growth_rates": all_growth_rates,
        "verdict": verdict,
        "msg": msg,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
