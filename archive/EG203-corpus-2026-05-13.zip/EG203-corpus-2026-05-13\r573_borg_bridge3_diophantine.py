"""
R573 — Borg Bridge 3: Diophantine structure of the 73.34% residual.

The cross-domain panelist proposed: the 169,301,077 uncovered cells of T=25200
are precisely the cells (k, l) where {k + l*log_2(3) + log_2(m^{1/n_p}) mod 1}
lies in the rational-approximation gap of log_2(3).

Specifically, for each prime p in the h=1 reservoir, the prime's coverage coset is
   a_p*k + b_p*l ≡ c_p (mod n_p)
which projects to a finite-dimensional torus residue class. Cumulatively, the
"covered cells" should densely fill the unit interval [0, 1) in {(k log 2 + l log 3 + log m_p) mod 1}
EXCEPT at points avoided by Diophantine gaps of log_2(3).

This script tests: does the residual cell set correlate with Diophantine
approximation gaps of log_2(3)?

Method:
  1. Reconstruct the residual cell set from h=1 prime data on T=25200.
  2. For each residual cell (k, l), compute alpha(k, l) = {k log 2 + l log 3} mod 1.
  3. Histogram alpha over the residual.  Compare to:
     (a) histogram over ALL of (Z/25200)^2 (uniform reference).
     (b) histogram over the COVERED cells.
  4. Check whether the residual histogram concentrates in specific intervals.
  5. Compare against Diophantine gaps of log_2(3) (continued fraction convergents).

Pre-spec verdict gate:
  PASS (ergodic bridge real): residual histogram shows >2x enrichment in
       Diophantine-gap intervals compared to uniform.
  FAIL (bridge illusory): residual is roughly uniform in alpha, no Diophantine
       structure.
"""

from __future__ import annotations

import csv
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent
H1_CSV = ROOT.parent / "gptruns" / "r568_h1_rows.csv"

T = 25200
N_SAMPLES = 1_000_000  # sample cells, not full enumeration
LOG2_3 = math.log(3) / math.log(2)  # log_2(3)


def load_h1_rows():
    rows = []
    with H1_CSV.open() as f:
        for r in csv.DictReader(f):
            rows.append({
                "p": int(r["p"]),
                "n": int(r["n"]),
                "a": int(r["a"]),
                "b": int(r["b"]),
                "c": int(r["c"]),
            })
    return rows


def main():
    rows = load_h1_rows()
    print(f"Loaded {len(rows)} h=1 primes for T={T}")
    print(f"log_2(3) = {LOG2_3:.15f}")

    # Continued-fraction convergents of log_2(3)
    # log_2(3) ≈ 1.5849625...
    # CF: [1; 1, 1, 2, 2, 3, 1, 5, ...]  (well-known)
    # Convergents:  1, 2, 3/2, 8/5, 19/12, 65/41, 84/53, 485/306, ...
    # Compute first few computationally
    convergents = []
    x = LOG2_3
    a = int(x)
    convergents.append((a, 1))
    p_prev, q_prev = 1, 0
    p_curr, q_curr = a, 1
    x = 1 / (x - a)
    for _ in range(20):
        a = int(x)
        p_next = a * p_curr + p_prev
        q_next = a * q_curr + q_prev
        convergents.append((p_next, q_next))
        p_prev, q_prev = p_curr, q_curr
        p_curr, q_curr = p_next, q_next
        if x == a or q_next > 10**10:
            break
        x = 1 / (x - a)
    print(f"Continued-fraction convergents of log_2(3): {convergents[:8]}")

    # Sample N cells uniformly from (Z/T)^2.  Compute coverage indicator and alpha.
    print(f"\nSampling {N_SAMPLES:,} cells")
    rng = np.random.default_rng(42)
    sk = rng.integers(0, T, size=N_SAMPLES, dtype=np.int64)
    sl = rng.integers(0, T, size=N_SAMPLES, dtype=np.int64)

    # Compute coverage indicator from the h=1 rows
    covered = np.zeros(N_SAMPLES, dtype=bool)
    for r in rows:
        a, b, c, n = r["a"], r["b"], r["c"], r["n"]
        residue = (a * sk + b * sl) % n
        covered |= residue == c

    uncovered = ~covered
    n_unc = int(uncovered.sum())
    print(f"  Coverage by 47 h=1 primes: {covered.mean():.5f}")
    print(f"  Uncovered: {n_unc:,} of {N_SAMPLES:,} ({n_unc/N_SAMPLES:.5f})")
    print(f"  Expected: ~0.26660 (matches R571)")

    # Compute alpha = {k + l*log_2(3) mod 1} (Furstenberg orbit phase)
    # For numerical stability, do the addition in Python floats (sufficient precision for k+l*log_2(3))
    alpha = (sk + sl * LOG2_3) % 1.0

    # Histogram alpha for all cells, covered, uncovered
    N_BINS = 200
    bins = np.linspace(0, 1, N_BINS + 1)
    hist_all, _ = np.histogram(alpha, bins=bins)
    hist_covered, _ = np.histogram(alpha[covered], bins=bins)
    hist_uncovered, _ = np.histogram(alpha[uncovered], bins=bins)

    # Normalize
    hist_all_norm = hist_all / N_SAMPLES
    hist_covered_norm = hist_covered / max(int(covered.sum()), 1)
    hist_uncovered_norm = hist_uncovered / max(n_unc, 1)

    # Compute enrichment: how much more does uncovered concentrate in each bin vs uniform?
    expected_unc_per_bin = 1.0 / N_BINS
    enrichment = hist_uncovered_norm / expected_unc_per_bin
    max_enrichment = enrichment.max()
    min_enrichment = enrichment.min()
    print(f"\nUncovered alpha histogram ({N_BINS} bins):")
    print(f"  max bin enrichment: {max_enrichment:.3f}x uniform")
    print(f"  min bin enrichment: {min_enrichment:.3f}x uniform")
    print(f"  std of enrichment: {enrichment.std():.5f}")
    print(f"  IS uncovered set uniformly distributed in alpha? "
          f"{'NO (structured)' if (max_enrichment > 1.5 or min_enrichment < 0.5) else 'YES (uniform)'}")

    # Check correlation with Diophantine gaps
    # Convergent p/q means |log_2(3) - p/q| < 1/q^2.
    # Near rational p/q in [0,1), the orbit has slower equidistribution.
    # Specifically, the gap structure of {k log_2(3) mod 1} is governed by 3-distance theorem.

    # For each convergent (p, q), check if uncovered concentrates near k/q (mod 1) for small k.
    for (p_conv, q_conv) in convergents[:6]:
        if q_conv <= 1:
            continue
        # For each k in [0, q), the "gap point" is k * LOG2_3 mod 1.
        # Equivalently, k * (p/q) mod 1 = (k*p mod q) / q.  Same set.
        gap_points = sorted(((k * LOG2_3) % 1) for k in range(min(q_conv, 100)))
        # Compute fraction of uncovered alpha within distance 0.01/q from any gap point
        radius = 0.01 / max(q_conv, 1)
        in_gap = 0
        for ap in alpha[uncovered]:
            # Find closest gap point
            dists = [(min(abs(ap - g), 1 - abs(ap - g))) for g in gap_points]
            if min(dists) < radius:
                in_gap += 1
        frac_in_gap = in_gap / max(n_unc, 1)
        expected_uniform = 2 * radius * len(gap_points)  # 2*radius per point, times # points
        ratio = frac_in_gap / max(expected_uniform, 1e-12)
        print(f"  convergent p/q = {p_conv}/{q_conv}: "
              f"radius={radius:.6f}, frac_in_gap={frac_in_gap:.5f}, "
              f"expected_uniform={expected_uniform:.5f}, ratio={ratio:.3f}")

    # Save result
    result = {
        "T": T,
        "n_samples": N_SAMPLES,
        "log2_3": LOG2_3,
        "convergents": [list(c) for c in convergents[:10]],
        "n_uncovered": n_unc,
        "uncovered_fraction": n_unc / N_SAMPLES,
        "max_enrichment_in_alpha_histogram": float(max_enrichment),
        "min_enrichment_in_alpha_histogram": float(min_enrichment),
        "enrichment_std": float(enrichment.std()),
        "enrichment_per_bin": [float(e) for e in enrichment],
    }
    out_path = ROOT / "r573_borg_bridge3_diophantine.json"
    out_path.write_text(json.dumps(result, indent=2))
    print(f"\nResult written to {out_path}")

    # PRE-SPEC VERDICT
    print("\n=== PRE-SPEC VERDICT ===")
    print(f"  PASS (ergodic bridge real): residual histogram shows >2x enrichment in some bins.")
    print(f"    Observed max enrichment: {max_enrichment:.3f}x")
    print(f"  FAIL (bridge illusory): residual is roughly uniform in alpha.")
    print(f"    Observed range: [{min_enrichment:.3f}, {max_enrichment:.3f}]")
    if max_enrichment > 2.0:
        print(f"  ⇒ VERDICT: PASS — ergodic bridge has empirical support")
    elif max_enrichment < 1.5:
        print(f"  ⇒ VERDICT: FAIL — residual is uniform in alpha, bridge illusory")
    else:
        print(f"  ⇒ VERDICT: AMBIGUOUS — borderline, needs more samples or different alpha")


if __name__ == "__main__":
    main()
