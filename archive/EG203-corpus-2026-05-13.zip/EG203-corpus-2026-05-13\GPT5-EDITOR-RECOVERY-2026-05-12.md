# Recovered Content — 3 GPT 5.5 Pro Editor Calls

**Date:** 2026-05-12
**Cost:** ~$14 (3 × ~$4.61 calls)
**Status:** Content safe on disk; key passages distilled here for fast retrieval. GPT 5.5 Pro is BANNED from future swarms per operator (use Gemini Pro / Flash / DeepSeek instead).

The three GPT 5.5 Pro editor calls during Harvest Pass 1 produced the most editorially precise output in the corpus. Total: 121KB of editorial analysis across Inventiones / JNT / Math. Comp. lenses.

---

## §1. INVENTIONES EDITOR — Bottom Line

**Only two genuinely Inventiones-grade candidates** in the manifest, plus one quarantined:

| # | Candidate | Verdict |
|---|---|---|
| I-1 | **Theorem 21 / Paper D — reduction of NEG-203 to one weighted dispersion inequality** | Potential Inventiones/Compositio. Must be written as a clean theorem with definitions, not "KBK final form" language. If only a sufficient condition, do NOT call it equivalence. |
| I-2 | **Theorem 4 / Paper B — Conditional resolution under Kummer-GRH / KBV / BSZ-type input** | Potential Inventiones. Strongest if conditioned on recognizable standard hypotheses (GRH/GEH for Kummer tower), weaker if conditioned on bespoke KBV. |
| I-3 | **Theorem 17 / Theorem 20 — Unconditional q-average power-saving / Kummer-BV closure** | QUARANTINE. R642 empirically refutes T17. T20 is logically inconsistent with "KBV is single open gate" — if T20 is real, it closes the problem. Do not submit until logically resolved. |
| I-4 | **Theorem 22 — Uniform jet-primitive Stepanov auxiliary** | Compositio / IMRN / Finite Fields Appl. NOW; Inventiones only if it closes the dispersion gate. Current empirical certificates not enough. |

**Editorial mandate:** Strip ALL "Oracle / Borg / Fields-medal assault / Patent V" language from mathematical submissions. Inventiones will desk-reject prose that sounds like internal campaign notes. **Keep that language for the methodology paper.**

### Inventiones editor's TOP-10 (Pass 6 — peer review lens):

> *"Iwaniec lens: the almost-prime/sieve theorem and density-zero theorem are valuable, but only with correct logarithmic scale and explicit parity handling. Theorem 2 as stated will be attacked immediately."*
>
> *"Granville lens: singular series, local obstructions, Mertens/parity tracer mechanism, and probabilistic model are publishable. Granville would demand exact constants and a random model."*
>
> *"Bombieri lens: the Stepanov auxiliary framework is publishable only after the uniform linear-algebra existence theorem is proved. Empirical 13/13 primes is evidence, not theorem."*

---

## §2. JNT EDITOR — Bottom Line

**The safest first publication is not the full density-zero theorem. It is:**

> *"Local fiber formulae, moment identities, and CRT synchronization defects for the ⟨2,3⟩-orbit modulo primes."*

This paper absorbs:
- Claude L6–L8 (mean vanishing, CRT cross-moment vanishing, variance sum)
- Claude L13–L15 (universal $2^{r-1}$ defect, ℓ-primary generalization, n=2 Kummer-Chebotarev)
- R682, R691, R700, R701, R702 (empirical anchors)
- Possibly Theorem 1 (singular series positivity)

**Writeup: 80–140 hours. Target: JNT, Acta Arithmetica, Research in Number Theory.**

### JNT editor's red flags

- **Theorem 17 should be killed or renamed** — explicitly contradicted by R642 (measured exponent 0.016 vs predicted 0.0714)
- **Theorem 20 not publishable from manifest alone** — needs real written proof; "claimed unconditional but unsupported in the manifest"
- **Theorem 22 is two different things; split** — computational certificate data publishable, uniform theorem not yet completed
- **Theorem 16 — remove "probabilistic primality test" language** until proven error bounds
- **Theorem 21 — "equivalence" dangerous**; call it sufficient criterion until necessity direction is rigorous

### JNT editor's promotion recommendations (Pass 2 — hidden/mislabeled)

1. **R682 should be promoted to a theorem**, not "empirical at 259 pairs"
2. **R691 moment identities are exact corollaries**, not experimental facts; prove algebraically
3. **Claude L13/L14 are paper-grade, not footnotes** (universal $2^{r-1}$ + $\ell$-primary generalization)
4. **Claude L15 is a clean special-case theorem** ($n=2$ Kummer-Chebotarev base case)
5. **Theorem 14′ over-targeted but publishable** at Exp Math, not Acta
6. **Theorem 16 weaker version IS publishable** (small-prime depletion profile + Halász/T-K + PNT)

---

## §3. MATH. COMP. EDITOR — Bottom Line

**Write Paper E first.** Strongest Math. Comp. submission is the combination:

**MC-1** ($m \le 10^6$ verification, $\tau \le 5$) + **MC-4** (rank-3/4 saturation) + **MC-6/8** (tracer set + monotone enrichment) + **MC-13/14** (Stepanov certificates) + **MC-15/16/18/19** (Γ-fiber + moments + defect)

### Critical reproducibility requirements

| Requirement | Status |
|---|---|
| Witness table for every $m \le 10^6$ | Need to produce |
| ECPP / Pocklington / deterministic primality certificates | Need to produce |
| Code hash + independent verifier | Need to set up |
| Algorithm description with complexity bound | Need to write |
| Reproduction package (Zenodo deposit) | Recommended this week |

### Math. Comp. editor's complete 21-item empirical inventory

MC-1 through MC-21 covers every R-script result. Most consequential:

- **MC-1** (\\(m\le10^6\\)) — core theorem
- **MC-4** (rank-3: max $\tau_3 = 7$, 99.81% have $\tau_3 \le 5$)
- **MC-13** (R660B 8/8 at Bombieri-tight degree)
- **MC-14** (R681 slice-jet 13/13 at Bombieri-tight degree)
- **MC-15** ($\Gamma$-fiber 259 pairs)
- **MC-16** (R691 moment identities, 23 primes + 15 pairs, $\le 10^{-16}$)
- **MC-18** (R700: 45 local-full pairs all have $\kappa \in \{2, 4\}$)
- **MC-20** (R702 $n=2$ Chebotarev for 13 $m$ × 4 $Q$, matches $\exp(-c\sqrt{\log Q})$)

### Critical conflict caught by Math. Comp. editor

**Tracer-set numbers conflict:** Manifest §2 R620 says 65% prime / 2.77× enrichment; §1 Theorem 16 says 67.5% / 2.87× at top. **Reconcile before publication.** (One uses 87 tested $m$, one uses 333,333 — different cohorts.)

### Math. Comp. editor's reproducibility-hardening checklist for Paper E

1. Run independent verifier against witness table
2. Convert any floating-point "$10^{-16}$" verifications to exact rational/integer
3. Make all empirical $\tau$-bounds **finite** statements (not "for all $X \ge X_0$")
4. State limits explicitly: $m \le 10^6$, $k + \ell \le 50$, $L \le 80$
5. Include null/failure results (R642 negative diagnostic, R651-JET $D=5$ failure)

---

## §4. CROSS-EDITOR CONSENSUS

All three GPT 5.5 Pro editors agreed:

### Immediate action (this week)
1. **Deposit corpus on Zenodo with DOI** — establishes priority on everything
2. **Start Paper E (Math. Comp. empirical)** — lowest risk, 90% acceptance, 3 months
3. **Start Local Algebra Paper (JNT/Acta)** — Claude L6-L8 + L13-L15 + R682/R691/R700-R702

### Items to KILL/DEMOTE before any submission
- Theorem 17 (R642 empirical negative)
- Theorem 22 "uniform-in-$q$" claim (only 8/8 finite)
- Theorem 16 "probabilistic primality test" language
- Theorem 21 "equivalence" framing → "sufficient criterion"
- Theorem 2 lower bound $\gg (\log X)^2$ at fixed $\Omega \le 3$ (wrong scale)
- All "Oracle/Borg/Fields-medal/Patent V" language in math submissions

### Items to PROMOTE / claim more strongly
- $\Gamma$-fiber formula (theorem, not 259-pair verification)
- Claude L7 (CRT cross-moment) standalone (IMRN/Combinatorica)
- Claude L13 universal $2^{r-1}$ defect (EJC/Discrete Math)
- Claude L15 $n=2$ Kummer-Chebotarev (JNT note)
- R645 $\delta = 0.4407$ (Math. Comp. note, "most undersold item")

### Items to MERGE
- Claude L6-L8 + R682/R691 → "Local algebra paper"
- Claude L13/L14 + R700/R701 → "CRT defect paper" (or merge with above)
- Claude L15 + R702 → could merge with above or stand alone
- Theorem 9 + R573/R599/R600 + Theorem 10 + R637/R643/R644 → "Paper E Math Comp"
- Theorem 14′ + R620-R624 + R699 → "Tracer paper" or section in Paper E

### Items to SPLIT
- Theorem 22 → certified Stepanov computations (Math Comp) + uniform-in-$q$ open conjecture
- Theorem 21 → reduction theorem (sufficiency) + equivalence conjecture (separately)

---

## §5. THE THREE-EDITOR CONSENSUS RANKED TOP 10

Aggregated from Inventiones / JNT / Math. Comp. editorial verdicts:

| Rank | Item | Best venue | Hours | Acceptance |
|---|---|---|---|---|
| 1 | Local algebra paper (Γ-fiber + moment + CRT defect) | **JNT / Acta** | 80–220 | **75%** |
| 2 | Paper E — Math. Comp. empirical $m \le 10^6$ | **Math. Comp.** | 120–250 | **90%** |
| 3 | Density-zero exceptional set (Cor 4.1') | **JNT / Acta** | 350–700 | 70% (with critical proof audit) |
| 4 | Methodology paper (KBK/ZENITH/Borg) | **Comm. AMS / Notices** | 120–250 | 60-80% |
| 5 | KBK reduction (Theorem 21, as "sufficiency") | **Compositio / Mathematika** | 250–600 | 50% |
| 6 | Singular series positivity | **JNT** | 40–100 | 70% |
| 7 | Conditional NEG-203 under Kummer-GRH | **Inventiones aspirational** | 600–1400 | 30-40% |
| 8 | Tracer/Mertens-parity paper | **Experimental Math** | 60–220 | 75% |
| 9 | Stepanov certified computation | **Math. Comp. / FFA** | 120–250 | 70% |
| 10 | $n=2$ Kummer-Chebotarev base case | **JNT note** | 60–120 | 70% |

---

## §6. WHY THIS RECOVERY MATTERS

The 3 GPT 5.5 Pro editor calls produced **the strongest editorial filter applied to the corpus** — more rigorous than the Pass 1 mathematician personas because the editors are explicitly looking for what gets rejected, not just what's interesting.

Without GPT 5.5 Pro available going forward, the editorial discipline must come from:

1. **Manual reading of these 3 recovered files** (`editor-{jnt,inventiones,mathcomp}-harvest.md`)
2. **Internal Claude editorial pass** (I can serve as editor in lieu of GPT 5.5 Pro at no API cost)
3. **Gemini Pro for similar quality** (cheaper but slightly less editorially sharp)

**These 3 files are the highest-value swarm output in the entire session.** Treat them as the operational referees for any Paper A/E/etc. before submission.

---

## §7. SUMMARY

| GPT 5.5 Pro call | Latency | Chars | Cost (est.) | File |
|---|---|---|---|---|
| editor-jnt-harvest | 494s | 40801 | ~$4.61 | `findings/harvest-swarm/editor-jnt-harvest.md` |
| editor-mathcomp-harvest | 592s | 47385 | ~$4.61 | `findings/harvest-swarm/editor-mathcomp-harvest.md` |
| editor-inventiones-harvest | 607s | 32785 | ~$4.61 | `findings/harvest-swarm/editor-inventiones-harvest.md` |

**Total recovered: ~121KB of editorial gold. The orchard now has its sorters.**
