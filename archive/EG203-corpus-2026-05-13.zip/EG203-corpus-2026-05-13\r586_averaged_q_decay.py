"""
R586 — Averaged-over-q discrepancy: does \\bar{C}(Q) decay as Q grows?

The BV-relevant quantity isn't per-q C(p) but the AVERAGE:
    bar_C(Q) := (1/pi(Q)) * sum_{p prime <= Q} C(p)
where pi(Q) is the prime-counting function.

If bar_C(Q) -> 0 as Q -> infty: BV-style averaging works empirically.
Schmidt-genericity predicts bar_C(Q) ~ 1/sqrt(pi(Q)) (variance reduction from uncorrelated C(p)).

This requires C(p) data for many more primes than R577 used.
We'll compute C(p) directly here for primes up to Q_max, using a fixed L.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import numpy as np
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

LOG2_3 = math.log2(3.0)
L_TEST = 100  # support cap (smaller for the wider Q range, since L=200 was overkill for small p)
ETA_FIT = 0.65  # from R577
Q_MAX = 100000  # extended from 10000


def hann(x):
    if x < 0 or x > 1:
        return 0.0
    return math.cos(math.pi * x / 2.0) ** 2


def discrepancy_for_p_L(p, L):
    """Compute tilde_D_N^w(p, L) for m=1, returns (D, orbit_size, N_phi)."""
    pow2 = [1] * (L + 1)
    for k in range(1, L + 1):
        pow2[k] = (pow2[k-1] * 2) % p
    pow3 = [1] * (L + 1)
    for l in range(1, L + 1):
        pow3[l] = (pow3[l-1] * 3) % p

    C_arr = np.zeros(p, dtype=np.float64)
    N_phi = 0.0
    for k in range(L + 1):
        wk = hann(k / L)
        if wk == 0:
            continue
        lmax = math.floor((L - k) / LOG2_3)
        for l in range(lmax + 1):
            wl = hann((l * LOG2_3) / L)
            w = wk * wl
            if w == 0:
                continue
            a = (pow2[k] * pow3[l]) % p
            C_arr[a] += w
            N_phi += w

    # Orbit
    orbit = set()
    for k in range(L + 1):
        for l in range(L + 1):
            orbit.add((pow2[k] * pow3[l]) % p)
            if len(orbit) >= p:
                break
        if len(orbit) >= p:
            break
    orbit_size = len(orbit)

    target = 1.0 / orbit_size
    D = 0.0
    for a in orbit:
        diff = abs(C_arr[a] / N_phi - target)
        if diff > D:
            D = diff

    return D, orbit_size, N_phi


def regress(xs, ys):
    xs_arr = np.array(xs, dtype=np.float64)
    ys_arr = np.array(ys, dtype=np.float64)
    if len(xs_arr) < 3:
        return 0.0, 0.0, 0.0
    xbar = xs_arr.mean()
    ybar = ys_arr.mean()
    Sxx = ((xs_arr - xbar) ** 2).sum()
    Sxy = ((xs_arr - xbar) * (ys_arr - ybar)).sum()
    Syy = ((ys_arr - ybar) ** 2).sum()
    if Sxx == 0:
        return 0.0, 0.0, 0.0
    b = Sxy / Sxx
    a = ybar - b * xbar
    r2 = (Sxy ** 2) / (Sxx * Syy) if Syy > 0 else 0.0
    return b, a, r2


def main():
    print("R586 — Averaged-over-q discrepancy decay\n")

    # Sample primes at multiple scales: 5 to Q_MAX (using sympy)
    Q_BINS = [50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, Q_MAX]
    prime_list = []
    n = 5
    while n < max(Q_BINS) + 1:
        if sympy.isprime(n) and n > 3:  # coprime to 6
            prime_list.append(n)
        n += 1

    print(f"Will compute C(p) for {len(prime_list)} primes up to {max(Q_BINS)}.")
    print(f"L = {L_TEST}, eta = {ETA_FIT}.\n")

    # Compute C(p) for each prime
    C_p = {}
    t0 = time.time()
    for i, p in enumerate(prime_list):
        D, orbit, N = discrepancy_for_p_L(p, L_TEST)
        C = D * (N ** ETA_FIT) if D > 0 else 0.0
        C_p[p] = {"D": D, "orbit": orbit, "N": N, "C": C}
        if (i+1) % 100 == 0:
            elapsed = time.time() - t0
            print(f"  [{i+1}/{len(prime_list)}] p={p:>5}: D={D:.4e} orbit={orbit:>5} C={C:.4f}  t={elapsed:.1f}s")

    elapsed = time.time() - t0
    print(f"\nTotal compute: {elapsed:.1f}s for {len(prime_list)} primes.\n")

    # Compute \\bar{C}(Q) for each Q bin
    print("=== AVERAGED C OVER PRIME RANGE [3, Q] ===\n")
    print(f"{'Q':>8} {'count':>6} {'mean C':>10} {'median C':>10} {'std C':>10}")
    bin_data = []
    for Q in Q_BINS:
        Cs = [C_p[p]["C"] for p in prime_list if p <= Q and C_p[p]["C"] > 0]
        if not Cs:
            continue
        mean_C = float(np.mean(Cs))
        median_C = float(np.median(Cs))
        std_C = float(np.std(Cs))
        bin_data.append({"Q": Q, "count": len(Cs), "mean": mean_C, "median": median_C, "std": std_C})
        print(f"{Q:>8} {len(Cs):>6} {mean_C:>10.4f} {median_C:>10.4f} {std_C:>10.4f}")

    # Regression: log(mean C) vs log Q (or vs log pi(Q))
    xs = [math.log(b["Q"]) for b in bin_data]
    ys_mean = [math.log(b["mean"]) if b["mean"] > 0 else 0 for b in bin_data]
    ys_median = [math.log(b["median"]) if b["median"] > 0 else 0 for b in bin_data]

    slope_mean, _, r2_mean = regress(xs, ys_mean)
    slope_median, _, r2_median = regress(xs, ys_median)
    print(f"\nRegression mean_C vs Q:    slope = {slope_mean:+.3f}, R^2 = {r2_mean:.3f}")
    print(f"Regression median_C vs Q:  slope = {slope_median:+.3f}, R^2 = {r2_median:.3f}")

    # Variance-reduction prediction: if C(p) are uncorrelated with mean ~ 0.2,
    # then mean over N primes has stdev ~ 0.1 / sqrt(N). Mean stays constant.
    # We want SLOPE OF MEAN to be NEGATIVE for true decay.

    slope = slope_mean
    r2 = r2_mean
    if (-1.0 <= slope <= -0.3) and r2 >= 0.8:
        verdict = "PASS-STRONG"
        msg = f"Strong polynomial decay of \\bar{{C}}(Q). Slope = {slope:.3f}, R^2 = {r2:.3f}. BV-style averaging EMPIRICALLY VALIDATED."
    elif (-1.0 <= slope <= -0.05) and r2 >= 0.6:
        verdict = "PASS"
        msg = f"Measurable averaged decay. Slope = {slope:.3f}, R^2 = {r2:.3f}."
    elif abs(slope) < 0.03 or r2 < 0.2:
        verdict = "FAIL"
        msg = f"\\bar{{C}}(Q) is essentially flat. No averaged decay. Slope = {slope:.3f}, R^2 = {r2:.3f}. ZENITH required."
    else:
        verdict = "AMBIGUOUS"
        msg = f"Partial signal. Slope = {slope:.3f}, R^2 = {r2:.3f}."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r586_results.json"
    out.write_text(json.dumps({
        "L": L_TEST,
        "eta_fit": ETA_FIT,
        "n_primes": len(prime_list),
        "Q_BINS": Q_BINS,
        "C_p": {str(p): v for p, v in C_p.items()},
        "bin_data": bin_data,
        "regression": {"slope_mean": slope_mean, "r2_mean": r2_mean,
                       "slope_median": slope_median, "r2_median": r2_median,
                       "verdict": verdict, "interpretation": msg},
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
