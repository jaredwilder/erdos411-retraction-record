"""
R594 — Universal k-prime orbit scaling law.

Compute tau_k(m) := min{sum_i e_i : prod p_i^{e_i} * m + 1 is prime}
for k = 2 (primes 2, 3), k = 3 (2, 3, 5), k = 4 (2, 3, 5, 7), k = 5 (2, 3, 5, 7, 11).

Test the Compensation Manifold Law's universal scaling prediction:
    max_m tau_k(m) scales as 1/k (logarithmic with k-th prime addition reducing tau by factor).

If max tau_k drops monotonically as k grows: UNIVERSAL k-prime acceleration law confirmed.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

K_PRIMES = {
    2: [2, 3],
    3: [2, 3, 5],
    4: [2, 3, 5, 7],
    5: [2, 3, 5, 7, 11],
}


def tau_k(m, primes, max_sum=15):
    """Smallest sum of exponents e_1 + ... + e_k with prod p_i^{e_i} * m + 1 prime."""
    n_primes = len(primes)
    for s in range(0, max_sum + 1):
        # Enumerate (e_1, ..., e_k) with sum = s, e_i >= 0
        if not enum_compositions(s, n_primes, primes, m):
            continue
        for exps in enum_compositions_iter(s, n_primes):
            val = m
            for p, e in zip(primes, exps):
                val *= p ** e
            val += 1
            if val > 2 and sympy.isprime(val):
                return s, exps
    return None, None


def enum_compositions(s, n, primes, m):
    """Quick check: there exists at least one composition."""
    return True  # Always true for s >= 0


def enum_compositions_iter(s, n):
    """Generate all (e_1, ..., e_n) with e_i >= 0 and sum = s."""
    if n == 1:
        yield (s,)
        return
    for e1 in range(s + 1):
        for rest in enum_compositions_iter(s - e1, n - 1):
            yield (e1,) + rest


def main():
    print("R594 — Universal k-prime orbit scaling law\n")
    M_LIST = [m for m in range(1, 2001) if math.gcd(m, 2 * 3 * 5 * 7 * 11) == 1]
    print(f"Testing {len(M_LIST)} m values coprime to 2*3*5*7*11 = 2310, in [1, 2000]\n")

    results = {}
    for k, primes in K_PRIMES.items():
        print(f"--- k = {k} (primes = {primes}) ---")
        t0 = time.time()
        taus = []
        no_prime = []
        for m in M_LIST:
            t, exps = tau_k(m, primes, max_sum=10)
            if t is None:
                no_prime.append(m)
            else:
                taus.append((m, t))
        elapsed = time.time() - t0

        tau_values = [t for m, t in taus]
        if tau_values:
            max_t = max(tau_values)
            from collections import Counter
            hist = Counter(tau_values)
            mean_t = sum(tau_values) / len(tau_values)
        else:
            max_t = None
            hist = {}
            mean_t = None

        print(f"  Compute: {elapsed:.1f}s")
        print(f"  n_no_prime: {len(no_prime)}")
        print(f"  max tau_{k}: {max_t}")
        print(f"  mean tau_{k}: {mean_t}")
        print(f"  Distribution: {dict(sorted(hist.items())) if hist else 'N/A'}")

        results[k] = {
            "k": k,
            "primes": primes,
            "n_m_tested": len(M_LIST),
            "n_no_prime": len(no_prime),
            "max_tau": max_t,
            "mean_tau": mean_t,
            "distribution": dict(hist),
        }
        print()

    # Scaling test
    print("=== UNIVERSAL SCALING TEST ===")
    print(f"{'k':>3} {'max tau_k':>10} {'mean tau_k':>10}")
    for k in sorted(results.keys()):
        r = results[k]
        if r["max_tau"] is not None:
            print(f"{k:>3} {r['max_tau']:>10} {r['mean_tau']:>10.2f}")

    # Test for monotonic decrease
    max_taus = [results[k]["max_tau"] for k in sorted(results.keys()) if results[k]["max_tau"] is not None]
    if all(max_taus[i] >= max_taus[i+1] for i in range(len(max_taus) - 1)):
        verdict = "UNIVERSAL_SCALING_CONFIRMED"
        msg = f"max tau monotonically DECREASES with k: {max_taus}. Compensation Manifold Law universal scaling confirmed across k=2,3,4,5."
    else:
        verdict = "PARTIAL"
        msg = f"max tau values: {max_taus}. Not strictly monotonic."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r594_results.json"
    out.write_text(json.dumps({
        "results": results,
        "max_taus": max_taus,
        "verdict": verdict,
        "msg": msg,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
