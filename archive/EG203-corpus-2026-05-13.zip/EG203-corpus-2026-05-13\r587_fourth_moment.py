"""
R587 — 4th moment of W_m distribution: Gaussian, sub-Gaussian, or heavy-tailed?

For each prime q and support L, compute:
    M_2(q, L) := (1/q) sum_{m=0}^{q-1} |W_m(q, L)|^2
    M_4(q, L) := (1/q) sum_{m=0}^{q-1} |W_m(q, L)|^4
    K(q, L) := M_4 / M_2^2  (kurtosis ratio)

For a complex Gaussian random variable X with mean 0: E[|X|^4] = 2 E[|X|^2]^2, so K = 2.
For real Gaussian: E[X^4] = 3 E[X^2]^2, so K = 3.

For the m -> W_m distribution, the relevant prediction is COMPLEX Gaussian (K = 2)
if W_m has independent random-phase structure across the orbit.

If K ≈ 2 across primes: distribution is complex Gaussian → strong tail bounds.
If K << 2: sub-Gaussian → even better.
If K >> 2: heavy-tail → exceptional outlier m's, would FAIL Corollary 4.1 framework.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

LOG2_3 = math.log2(3.0)
Q_LIST = [17, 41, 67, 127, 257, 509, 1021]  # same as R582
L_LIST = [50, 100, 200]


def hann(x):
    if x < 0 or x > 1:
        return 0.0
    return math.cos(math.pi * x / 2.0) ** 2


def moments_2_and_4(q, L):
    """Compute M_2 = (1/q) sum_m |W_m|^2 and M_4 = (1/q) sum_m |W_m|^4 via FFT."""
    pow2 = [1] * (L + 1)
    for k in range(1, L + 1):
        pow2[k] = (pow2[k-1] * 2) % q
    pow3 = [1] * (L + 1)
    for l in range(1, L + 1):
        pow3[l] = (pow3[l-1] * 3) % q

    # Build D_b = sum_{(k,l): 2^k 3^l = b} phi(k,l)
    D = np.zeros(q, dtype=np.complex128)
    N_phi = 0.0
    for k in range(L + 1):
        wk = hann(k / L)
        if wk == 0:
            continue
        lmax = math.floor((L - k) / LOG2_3)
        for l in range(lmax + 1):
            wl = hann((l * LOG2_3) / L)
            w = wk * wl
            if w == 0:
                continue
            a = (pow2[k] * pow3[l]) % q
            D[a] += w
            N_phi += w

    # W_m = sum_b D_b e_q(b m) = q * IFFT(D)[m] in numpy convention
    # numpy.fft.fft computes sum_n x[n] exp(-2 pi i k n / N)
    # We want W_m = sum_b D[b] exp(2 pi i b m / q), which is IFFT(D)[m] * q
    W = np.fft.ifft(D) * q  # length-q array
    # EXCLUDE m=0 (trivial character) — it corresponds to the main term not the error term
    # For prime q, m in [1, q-1] are the non-trivial characters.
    W_nontrivial = W[1:]  # m = 1, 2, ..., q-1
    W_abs = np.abs(W_nontrivial)
    W2 = W_abs ** 2
    W4 = W_abs ** 4

    M_2 = float(W2.mean())
    M_4 = float(W4.mean())
    return M_2, M_4, N_phi


def main():
    print("R587 — 4th moment / kurtosis of W_m distribution\n")
    print(f"Q_LIST = {Q_LIST}")
    print(f"L_LIST = {L_LIST}\n")

    results = {}
    K_ratios = []
    t0 = time.time()
    for L in L_LIST:
        results[L] = {}
        print(f"--- L = {L} ---")
        for q in Q_LIST:
            t1 = time.time()
            M_2, M_4, N_phi = moments_2_and_4(q, L)
            K = M_4 / (M_2 ** 2) if M_2 > 0 else float('nan')
            results[L][q] = {"M_2": M_2, "M_4": M_4, "K": K, "N_phi": N_phi}
            K_ratios.append(K)
            elapsed = time.time() - t1
            print(f"  q={q:>5} N_phi={N_phi:>8.1f} M_2={M_2:.4e} M_4={M_4:.4e} K={K:.4f}  t={elapsed:.2f}s")

    elapsed = time.time() - t0
    print(f"\nTotal compute: {elapsed:.1f}s\n")

    # Aggregate
    K_arr = np.array(K_ratios)
    K_mean = float(K_arr.mean())
    K_median = float(np.median(K_arr))
    K_min = float(K_arr.min())
    K_max = float(K_arr.max())

    print(f"=== KURTOSIS RATIO M_4 / M_2^2 ===")
    print(f"  Mean = {K_mean:.4f}, Median = {K_median:.4f}")
    print(f"  Min  = {K_min:.4f}, Max  = {K_max:.4f}")
    print(f"  (Complex Gaussian prediction: K = 2; sub-Gaussian: K < 2; heavy-tail: K >> 2)")

    # Verdict
    pct_gaussian = float(((K_arr >= 1.5) & (K_arr <= 2.5)).mean())
    pct_subgaussian = float(((K_arr >= 0.8) & (K_arr <= 1.4)).mean())
    pct_heavy = float((K_arr > 5).mean())

    print(f"\n  Fraction K in [1.5, 2.5] (Gaussian): {pct_gaussian:.2%}")
    print(f"  Fraction K in [0.8, 1.4] (sub-Gaussian): {pct_subgaussian:.2%}")
    print(f"  Fraction K > 5 (heavy-tail): {pct_heavy:.2%}")

    if pct_gaussian >= 0.8:
        verdict = "GAUSSIAN"
        msg = f"Distribution of W_m is COMPLEX GAUSSIAN ({pct_gaussian:.0%} in tight band). Strong tail bounds available. Corollary 4.1 has sharp Chebyshev applicable."
    elif pct_subgaussian >= 0.5:
        verdict = "SUB-GAUSSIAN"
        msg = f"Distribution is SUB-GAUSSIAN. Even better than Gaussian — exponential tail bounds available."
    elif pct_heavy >= 0.3:
        verdict = "HEAVY-TAIL"
        msg = f"Heavy-tailed distribution — Corollary 4.1 framework needs revision. ZENITH required."
    else:
        verdict = "AMBIGUOUS"
        msg = f"Mixed distribution. Mean K = {K_mean:.3f}, median = {K_median:.3f}."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r587_results.json"
    out.write_text(json.dumps({
        "Q_LIST": Q_LIST,
        "L_LIST": L_LIST,
        "results": {str(L): {str(q): v for q, v in results[L].items()} for L in L_LIST},
        "summary": {
            "K_mean": K_mean,
            "K_median": K_median,
            "K_min": K_min,
            "K_max": K_max,
            "pct_gaussian": pct_gaussian,
            "pct_subgaussian": pct_subgaussian,
            "pct_heavy": pct_heavy,
            "verdict": verdict,
            "interpretation": msg,
        },
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
