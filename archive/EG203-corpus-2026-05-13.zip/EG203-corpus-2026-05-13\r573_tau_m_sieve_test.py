"""
R573 — Sieve theorist's tau(m) experiment for Erdős-Graham #203.

For each m coprime to 6 in a sample, compute
   tau(m) = min{k + l : 2^k * 3^l * m + 1 is prime},   (k, l) in [0, K_MAX]^2

Heuristic prediction (NEG-203 supported): tau(m) = O(log m), no growing anomaly.
Anomaly signal: some m with tau(m) > (log m)^2 → candidate #203 witness.

Cheap decisive test of the sieve theorist's negative-resolution prediction.
"""

from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import sympy

sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent
K_MAX = 200  # max (k, l) component
KL_MAX = 300  # max k + l (limits search depth)

# m values to test: sample of m coprime to 6, including known "hard" 1D Sierpinski candidates
m_values = []
# Smallest m coprime to 6
m_values += [m for m in range(1, 200) if math.gcd(m, 6) == 1]
# A few larger m to test log-scaling
m_values += [505, 757, 1001, 2503, 5005, 7777, 10003, 25001, 50051, 99989]
# Known 1D Sierpinski-candidate range (1D bad m's that might be 2D bad too?)
m_values += [10223, 21181, 22699, 24737, 55459, 67607, 78557]  # 1D Sierpinski + unresolved
# Also include 1D Riesel and other notable
m_values += [509203, 2293, 9221]
# Deduplicate
m_values = sorted(set([m for m in m_values if math.gcd(m, 6) == 1]))

print(f"Testing {len(m_values)} m values, k+l up to {KL_MAX}")


def find_tau(m: int, kl_max: int) -> tuple[int, int, int] | None:
    """Find smallest k + l such that 2^k * 3^l * m + 1 is prime.
    Returns (k, l, kl_total) or None if not found within kl_max."""
    for kl in range(0, kl_max + 1):
        for k in range(0, kl + 1):
            l = kl - k
            if k > K_MAX or l > K_MAX:
                continue
            val = (1 << k) * (3 ** l) * m + 1
            if sympy.isprime(val):
                return (k, l, kl)
    return None


t_start = time.time()
results = []
for i, m in enumerate(m_values):
    t0 = time.time()
    res = find_tau(m, KL_MAX)
    elapsed = time.time() - t0
    log_m = math.log(m) if m > 1 else 0
    if res is None:
        tau = None
        ratio = None
        status = "NO_PRIME_FOUND"
    else:
        k, l, tau = res
        ratio = tau / log_m if log_m > 0 else None
        status = "OK"
    results.append({
        "m": m,
        "tau": tau,
        "k_l": [res[0], res[1]] if res else None,
        "log_m": log_m,
        "ratio_tau_over_log_m": ratio,
        "elapsed_s": elapsed,
        "status": status,
    })
    if (i + 1) % 10 == 0 or i < 30 or status == "NO_PRIME_FOUND":
        log_str = f"log m = {log_m:.2f}" if log_m > 0 else "log m = -"
        ratio_str = f"ratio={ratio:.3f}" if ratio is not None else "ratio=-"
        if res:
            print(f"  [{i+1}/{len(m_values)}] m={m:>6}: tau=(k={res[0]}, l={res[1]}) = {tau}, "
                  f"{log_str}, {ratio_str}, elapsed={elapsed:.2f}s")
        else:
            print(f"  [{i+1}/{len(m_values)}] m={m:>6}: NO_PRIME_FOUND within kl<={KL_MAX}, "
                  f"{log_str}, elapsed={elapsed:.2f}s")

t_total = time.time() - t_start
print(f"\nTotal elapsed: {t_total:.1f}s")

# Summary statistics
taus_seen = [r["tau"] for r in results if r["tau"] is not None]
ratios = [r["ratio_tau_over_log_m"] for r in results if r["ratio_tau_over_log_m"] is not None and r["ratio_tau_over_log_m"] > 0]
no_prime = [r for r in results if r["status"] == "NO_PRIME_FOUND"]

print(f"\n=== STATS ===")
print(f"  m values tested: {len(results)}")
print(f"  m with tau found: {len(taus_seen)}")
print(f"  m with NO prime found within kl <= {KL_MAX}: {len(no_prime)}")
if no_prime:
    print(f"  ANOMALY m values: {[r['m'] for r in no_prime]}")
if ratios:
    print(f"  tau/log(m) ratio: min={min(ratios):.3f}, max={max(ratios):.3f}, mean={sum(ratios)/len(ratios):.3f}")
    print(f"  Largest tau/log(m): {sorted(((r['ratio_tau_over_log_m'], r['m']) for r in results if r['ratio_tau_over_log_m']), reverse=True)[:5]}")
print(f"  Max tau: {max(taus_seen) if taus_seen else None}")

# Pre-spec verdict gate
print(f"\n=== VERDICT ===")
print(f"  NEG-203 (heuristic predicts tau(m) = O(log m)):")
print(f"    Expected: tau/log(m) bounded by ~constant; few outliers.")
print(f"    Observed: max ratio = {max(ratios) if ratios else 'N/A'}")
print(f"  #203 candidate signal:")
print(f"    Look for: m with tau > (log m)^2.")
candidates = [(r['m'], r['tau']) for r in results if r['tau'] is not None and r['log_m'] > 0 and r['tau'] > r['log_m'] ** 2]
if candidates:
    print(f"    CANDIDATES FOUND: {candidates}")
else:
    print(f"    None found in this sample.")
no_prime_anomaly = [r['m'] for r in no_prime]
if no_prime_anomaly:
    print(f"  EXTREME ANOMALY (no prime within kl<={KL_MAX}): {no_prime_anomaly}")

out_path = ROOT / "r573_tau_m_results.json"
out_path.write_text(json.dumps({
    "K_MAX": K_MAX,
    "KL_MAX": KL_MAX,
    "n_m_tested": len(results),
    "results": results,
    "anomaly_m": no_prime_anomaly,
    "candidate_m": candidates,
}, indent=2))
print(f"\nWritten to {out_path}")
