"""R660A — Bombieri-grade Stepanov auxiliary dimension test.

Phase 30 Oracle-reversal corrected the auxiliary class: not P = A(X^a-1) + B(Y^b-1)
(rank-1), but the FULL polynomial space of degree ≤ D in F_q[X, Y] vanishing on V_q
to order m. This is the actual Stepanov-Bombieri-Heath-Brown-Konyagin-Bombieri-1973
auxiliary.

For each prime q with q ∤ 6:
  a = ord_q(2), b = ord_q(3)
  V_q = {(2^k mod q, 3^l mod q) : 0 ≤ k < a, 0 ≤ l < b}
  |V_q| = a·b (since the pairs are distinct as multi-orders)

  Skip if V_q fills the full torus F_q* × F_q* (i.e., 2 and 3 both primitive roots).

  Bombieri degree: D = ⌈√|V_q| · log q⌉
  Bombieri jet order: m = ⌈log|V_q| / 2⌉  (we use small m to start; can scale)

  Test: does there exist non-zero P ∈ F_q[X, Y] with total degree ≤ D
  such that all jets of P up to order m-1 vanish on V_q?

  Empirically: compute the constraint matrix rank in F_q. Kernel dim = N_unk − rank.
  If kernel_dim > 0: jet-primitive Stepanov auxiliary EXISTS at Bombieri degree.

Output: per-prime certificate + summary slope check (D_min vs √|V_q| log q).
"""

import json
import math
from pathlib import Path
from sympy import isprime

OUT = Path(__file__).with_suffix('.json')


def order_mod(g, q):
    """Multiplicative order of g mod q."""
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def build_orbit(q):
    """V_q = {(2^k, 3^l) mod q : 0 ≤ k < a, 0 ≤ l < b}."""
    a = order_mod(2, q)
    b = order_mod(3, q)
    pts = []
    twos = [pow(2, k, q) for k in range(a)]
    threes = [pow(3, l, q) for l in range(b)]
    seen = set()
    for x in twos:
        for y in threes:
            if (x, y) not in seen:
                seen.add((x, y))
                pts.append((x, y))
    return a, b, pts


def monomial_basis(D):
    """All monomials X^i Y^j with i + j ≤ D."""
    return [(i, j) for i in range(D + 1) for j in range(D + 1 - i)]


def pow_mod(base, exp, q):
    if exp < 0:
        return 0
    return pow(base, exp, q) if base != 0 else (1 if exp == 0 else 0)


def falling(n, k):
    """n · (n-1) · ... · (n-k+1) for k ≥ 0; equals 0 if n < k for non-neg int n."""
    if k == 0:
        return 1
    r = 1
    for t in range(k):
        r *= (n - t)
    return r


def derivative_row(x, y, di, dj, basis, q):
    """Row of partial derivative ∂^{di+dj}/∂X^{di} ∂Y^{dj} evaluated at (x, y) on basis."""
    row = []
    for (i, j) in basis:
        if i < di or j < dj:
            row.append(0)
            continue
        coeff = falling(i, di) * falling(j, dj)
        val = (pow_mod(x, i - di, q) * pow_mod(y, j - dj, q)) % q
        row.append((coeff * val) % q)
    return row


def gauss_rank(M, q):
    """Rank of matrix M over F_q via Gaussian elimination."""
    if not M:
        return 0
    M = [list(r) for r in M]
    nrow = len(M)
    ncol = len(M[0]) if M else 0
    r = 0
    for c in range(ncol):
        pivot = None
        for rr in range(r, nrow):
            if M[rr][c] % q != 0:
                pivot = rr
                break
        if pivot is None:
            continue
        if pivot != r:
            M[r], M[pivot] = M[pivot], M[r]
        inv = pow(M[r][c] % q, -1, q)
        for cc in range(c, ncol):
            M[r][cc] = (M[r][cc] * inv) % q
        for rr in range(nrow):
            if rr != r and M[rr][c] % q != 0:
                f = M[rr][c] % q
                for cc in range(c, ncol):
                    M[rr][cc] = (M[rr][cc] - f * M[r][cc]) % q
        r += 1
        if r == min(nrow, ncol):
            break
    return r


def stepanov_dim_test(q, D, m):
    """Dimension of {P ∈ F_q[X,Y]_{deg ≤ D} : P vanishes on V_q to order m}.

    Returns: dict with prime, |V_q|, D, m, n_unknowns, n_constraints, rank, kernel_dim.
    """
    a, b, pts = build_orbit(q)
    V_size = len(pts)
    basis = monomial_basis(D)
    n_unknowns = len(basis)

    rows = []
    for (x, y) in pts:
        for di in range(m):
            for dj in range(m - di):
                rows.append(derivative_row(x, y, di, dj, basis, q))

    n_constraints = len(rows)
    rank = gauss_rank(rows, q) if rows else 0
    kernel_dim = n_unknowns - rank

    return {
        'q': q,
        'a': a,
        'b': b,
        'V_size': V_size,
        'D': D,
        'm': m,
        'n_unknowns': n_unknowns,
        'n_constraints': n_constraints,
        'rank': rank,
        'kernel_dim': kernel_dim,
        'auxiliary_exists': kernel_dim > 0,
    }


def main():
    print("R660A — Bombieri-grade Stepanov auxiliary dimension test")
    print("=" * 78)
    print()
    print(f"{'q':>4} {'a':>4} {'b':>4} {'|V_q|':>6} {'(q-1)^2':>8} {'D':>3} {'m':>3} "
          f"{'unk':>5} {'cnst':>6} {'rank':>5} {'ker':>5} {'cert':>5}")
    print("-" * 78)

    results = []
    for q in range(7, 100):
        if not isprime(q):
            continue
        if q in (2, 3):
            continue
        a = order_mod(2, q)
        b = order_mod(3, q)
        V_size = a * b
        torus_size = (q - 1) ** 2
        # Skip if V_q fills the torus (2 and 3 both primitive roots → V_q = F_q*^2)
        # Actually V_size = a*b can equal (q-1)^2 only if a=b=q-1 (both primitive roots)
        if V_size >= torus_size:
            print(f"{q:>4} {a:>4} {b:>4} {V_size:>6} {torus_size:>8}  -- skip (full torus) --")
            continue
        # Bombieri scaling: D ~ √|V_q| · log q
        D = max(2, int(math.ceil(math.sqrt(V_size) * math.log(q))))
        # Cap D to keep linear algebra tractable
        if D > 25:
            D = 25
        # Heath-Brown derivative order: m ~ log|V_q| / 4  (small to start)
        m = max(2, int(math.ceil(math.log(V_size) / 4)))
        # Cap m similarly
        if m > 4:
            m = 4

        try:
            r = stepanov_dim_test(q, D, m)
        except Exception as e:
            print(f"{q:>4} ERROR: {e}")
            continue

        cert = "YES" if r['auxiliary_exists'] else "no"
        print(f"{q:>4} {a:>4} {b:>4} {V_size:>6} {torus_size:>8} {D:>3} {m:>3} "
              f"{r['n_unknowns']:>5} {r['n_constraints']:>6} {r['rank']:>5} "
              f"{r['kernel_dim']:>5} {cert:>5}")
        results.append(r)

    print()
    n_total = len(results)
    n_cert = sum(1 for r in results if r['auxiliary_exists'])
    print(f"=== Certification summary ===")
    print(f"Stepanov auxiliary certified at Bombieri degree: {n_cert} / {n_total} primes")

    # Slope check: log(D_min) vs log(|V_q|) — Bombieri predicts slope 1/2
    if n_cert >= 4:
        cert_pts = [(r['V_size'], r['D']) for r in results if r['auxiliary_exists']]
        cert_pts.sort()
        # Find smallest D for each |V_q| (here D is uniform at Bombieri prediction)
        log_V = [math.log(v) for v, d in cert_pts]
        log_D = [math.log(d) for v, d in cert_pts]
        mean_V = sum(log_V) / len(log_V)
        mean_D = sum(log_D) / len(log_D)
        num = sum((lv - mean_V) * (ld - mean_D) for lv, ld in zip(log_V, log_D))
        den = sum((lv - mean_V) ** 2 for lv in log_V)
        slope = num / den if den > 0 else float('nan')
        print(f"Slope log(D) vs log(|V_q|): {slope:.4f} (Bombieri predicts 0.5)")
    else:
        slope = None

    out = {
        'phase': 'R660A — Bombieri-grade Stepanov auxiliary dimension test (Phase 30 followup)',
        'construction': 'P ∈ F_q[X,Y]_{deg ≤ D} vanishing on V_q to jet order m',
        'parameters': 'D = ⌈√|V_q| · log q⌉, m = ⌈log|V_q| / 4⌉, capped D ≤ 25, m ≤ 4',
        'results': results,
        'n_certified': n_cert,
        'n_total': n_total,
        'slope_log_D_vs_log_V': slope,
        'bombieri_predicted_slope': 0.5,
        'verdict': 'AUXILIARY_EXISTS_AT_BOMBIERI_DEGREE' if n_cert == n_total and n_total >= 5
                   else 'PARTIAL' if n_cert > 0 else 'AUXILIARY_FAILS_AT_BOMBIERI',
    }
    OUT.write_text(json.dumps(out, indent=2))
    print(f"\nWritten {OUT}")


if __name__ == '__main__':
    main()
