"""R660C — Empirical Stepanov degree D_emp(q) sweep test.

R660A used a uniform degree cap (D ≤ 25) which biased the slope analysis. R660C
sweeps D from small to large and finds D_emp(q), the smallest D at which the
Stepanov auxiliary EXISTS (kernel > 0) at fixed jet order m.

For each prime q with q ∤ 6, |V_q| < (q-1)^2:
  Sweep D = 2, 3, 4, ..., D_max where D_max = min(30, |V_q|/2 + 5)
  At each D, compute kernel dim of {P deg ≤ D : P vanishes on V_q to order m}
  Find smallest D where kernel > 0 → D_emp(q)
  Record (q, |V_q|, D_emp, kernel at D_emp)

Then regress log(D_emp) vs log(|V_q|).
Bombieri predicts slope 0.5.

This is the cleanest empirical anchor for the Stepanov-Bombieri-Heath-Brown
scaling on the universal arithmetic surface S_{2,3}.
"""

import json
import math
from pathlib import Path
from sympy import isprime

OUT = Path(__file__).with_suffix('.json')


def order_mod(g, q):
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def build_orbit(q):
    a = order_mod(2, q)
    b = order_mod(3, q)
    twos = [pow(2, k, q) for k in range(a)]
    threes = [pow(3, l, q) for l in range(b)]
    pts = []
    seen = set()
    for x in twos:
        for y in threes:
            if (x, y) not in seen:
                seen.add((x, y))
                pts.append((x, y))
    return a, b, pts


def monomial_basis(D):
    return [(i, j) for i in range(D + 1) for j in range(D + 1 - i)]


def pow_mod(base, exp, q):
    if exp < 0:
        return 0
    return pow(base, exp, q) if base != 0 else (1 if exp == 0 else 0)


def falling(n, k):
    if k == 0:
        return 1
    r = 1
    for t in range(k):
        r *= (n - t)
    return r


def derivative_row(x, y, di, dj, basis, q):
    row = []
    for (i, j) in basis:
        if i < di or j < dj:
            row.append(0)
            continue
        coeff = falling(i, di) * falling(j, dj)
        val = (pow_mod(x, i - di, q) * pow_mod(y, j - dj, q)) % q
        row.append((coeff * val) % q)
    return row


def gauss_rank(M, q):
    if not M:
        return 0
    M = [list(r) for r in M]
    nrow = len(M)
    ncol = len(M[0]) if M else 0
    r = 0
    for c in range(ncol):
        pivot = None
        for rr in range(r, nrow):
            if M[rr][c] % q != 0:
                pivot = rr
                break
        if pivot is None:
            continue
        if pivot != r:
            M[r], M[pivot] = M[pivot], M[r]
        inv = pow(M[r][c] % q, -1, q)
        for cc in range(c, ncol):
            M[r][cc] = (M[r][cc] * inv) % q
        for rr in range(nrow):
            if rr != r and M[rr][c] % q != 0:
                f = M[rr][c] % q
                for cc in range(c, ncol):
                    M[rr][cc] = (M[rr][cc] - f * M[r][cc]) % q
        r += 1
        if r == min(nrow, ncol):
            break
    return r


def kernel_dim_at(q, D, m, pts):
    basis = monomial_basis(D)
    n_unknowns = len(basis)
    rows = []
    for (x, y) in pts:
        for di in range(m):
            for dj in range(m - di):
                rows.append(derivative_row(x, y, di, dj, basis, q))
    rank = gauss_rank(rows, q) if rows else 0
    return n_unknowns - rank, n_unknowns, len(rows), rank


def find_emp_degree(q, m, pts, D_min=2, D_max=30):
    """Sweep D from D_min upward, find smallest D where kernel > 0."""
    for D in range(D_min, D_max + 1):
        kernel, _, _, _ = kernel_dim_at(q, D, m, pts)
        if kernel > 0:
            return D, kernel
    return None, 0


def main():
    print("R660C — Empirical Stepanov degree D_emp(q) sweep test")
    print("=" * 80)
    print()
    print("For each prime q ∤ 6, |V_q| < (q-1)^2: find smallest D where kernel > 0 (m=2)")
    print()
    print(f"{'q':>4} {'|V_q|':>6} {'D_emp':>6} {'kernel':>7} {'√|V_q|':>8} "
          f"{'log q':>7} {'D_pred':>7}")
    print("-" * 80)

    results = []
    for q in range(7, 200):
        if not isprime(q):
            continue
        a = order_mod(2, q)
        b = order_mod(3, q)
        V_size = a * b
        torus_size = (q - 1) ** 2
        if V_size >= torus_size:
            continue
        if V_size > 800:  # Heavy primes: skip for tractability
            continue
        _, _, pts = build_orbit(q)
        m = 2
        D_emp, kernel = find_emp_degree(q, m, pts, D_min=2, D_max=25)
        if D_emp is None:
            print(f"{q:>4} {V_size:>6} {'>25':>6}  (no kernel up to D=25)")
            continue
        sqrt_V = math.sqrt(V_size)
        log_q = math.log(q)
        D_pred = sqrt_V * log_q
        print(f"{q:>4} {V_size:>6} {D_emp:>6} {kernel:>7} {sqrt_V:>8.2f} "
              f"{log_q:>7.3f} {D_pred:>7.2f}")
        results.append({
            'q': q,
            'V_size': V_size,
            'D_emp': D_emp,
            'kernel_at_D_emp': kernel,
            'sqrt_V': sqrt_V,
            'log_q': log_q,
            'D_predicted_bombieri': D_pred,
        })

    print()
    print("=== Slope analysis ===")
    if len(results) >= 4:
        log_V = [math.log(r['V_size']) for r in results]
        log_D = [math.log(r['D_emp']) for r in results]
        mean_V = sum(log_V) / len(log_V)
        mean_D = sum(log_D) / len(log_D)
        num = sum((lv - mean_V) * (ld - mean_D) for lv, ld in zip(log_V, log_D))
        den = sum((lv - mean_V) ** 2 for lv in log_V)
        slope = num / den if den > 0 else float('nan')
        intercept = mean_D - slope * mean_V
        # R^2
        ss_tot = sum((ld - mean_D) ** 2 for ld in log_D)
        ss_res = sum((ld - (slope * lv + intercept)) ** 2 for lv, ld in zip(log_V, log_D))
        r2 = 1 - ss_res / ss_tot if ss_tot > 0 else float('nan')

        print(f"Linear fit: log(D_emp) = {slope:.4f} * log(|V_q|) + {intercept:.4f}")
        print(f"R^2 = {r2:.4f}")
        print(f"Bombieri prediction: slope = 0.5")
        print(f"|slope − 0.5| / 0.5 = {abs(slope - 0.5) / 0.5 * 100:.1f}%")
    else:
        slope = None
        intercept = None
        r2 = None

    out = {
        'phase': 'R660C — Empirical Stepanov degree sweep, m=2',
        'results': results,
        'n_certified': len(results),
        'slope_log_D_emp_vs_log_V': slope,
        'intercept': intercept,
        'r_squared': r2,
        'bombieri_predicted_slope': 0.5,
    }
    OUT.write_text(json.dumps(out, indent=2))
    print(f"\nWritten {OUT}")


if __name__ == '__main__':
    main()
