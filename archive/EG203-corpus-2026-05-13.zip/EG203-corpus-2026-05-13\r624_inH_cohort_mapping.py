"""R624 — Extended structural-tracer mapping across inH cohorts {19, 20, 21, 22, 23}.

R620 found 3,787 tracers (inH=23) with 65% primality, vs 23.5% baseline.

R624 question: how does the structural primality enrichment SCALE across inH?
- inH=23: 65% prime (2.77x enrichment) — confirmed
- inH=22: ??
- inH=21: ??
- inH=20: ?? (mode)
- inH=19: ??

If primality enrichment scales monotonically with inH, we have a STRUCTURAL THEOREM:
the inH count is a STRUCTURAL INDICATOR of primality.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

PRIMES_LIST = list(sympy.primerange(5, 101))


def orbit_mod_p(p):
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def main():
    print("R624 — Extended structural-tracer mapping (inH cohorts 19, 20, 21, 22, 23)\n")
    print("Loading R620 results...\n")

    # Load R620's full inH count distribution
    r620 = json.loads((ROOT / "r620_results.json").read_text())

    # We need to re-classify each m. Re-sweep but record inH per m.
    # This is fast (~4 sec from R620).
    M_MAX = 1_000_000
    print(f"Re-classifying m ≤ {M_MAX} by inH count...")

    orbits = {p: orbit_mod_p(p) for p in PRIMES_LIST}

    # Group by inH
    cohorts = {19: [], 20: [], 21: [], 22: [], 23: []}

    t0 = time.time()
    n_processed = 0
    for m in range(1, M_MAX + 1):
        if math.gcd(m, 6) != 1:
            continue
        n_processed += 1
        cnt = 0
        for p in PRIMES_LIST:
            if math.gcd(m, p) == 1:
                m_inv = pow(m, -1, p)
                neg_m_inv = (-m_inv) % p
                if neg_m_inv in orbits[p]:
                    cnt += 1
        if cnt in cohorts:
            cohorts[cnt].append(m)
        if n_processed % 100000 == 0:
            elapsed = time.time() - t0
            print(f"  [{n_processed}/333,333] elapsed {elapsed:.0f}s")

    print(f"Sweep done: {time.time()-t0:.0f}s")
    print()

    # Compute primality fraction in each cohort
    # For large cohorts, sample
    print("Computing primality fractions per cohort (sampling 1000 from each)...")
    import random
    rng = random.Random(123)
    cohort_stats = {}
    for inH, m_list in cohorts.items():
        if not m_list:
            continue
        # Sample 1000 (or all if smaller)
        n_total = len(m_list)
        sample = rng.sample(m_list, min(1000, n_total))
        n_prime = sum(1 for m in sample if sympy.isprime(m))
        frac_prime = n_prime / len(sample)
        cohort_stats[inH] = {
            "total_m_in_cohort": n_total,
            "sample_size": len(sample),
            "n_prime_in_sample": n_prime,
            "frac_prime": frac_prime,
        }
        print(f"  inH={inH}: cohort size {n_total}, sample {len(sample)}, prime fraction {frac_prime*100:.1f}%")

    # Baseline: 23.5% (pi(10^6) / 333,333)
    baseline = 78498 / 333333
    print(f"\nBaseline prime fraction (all m coprime to 6): {baseline*100:.1f}%")
    print(f"\n=== PRIMALITY ENRICHMENT BY inH COHORT ===")
    print(f"{'inH':>4} {'cohort_size':>12} {'prime%':>10} {'enrichment':>12}")
    for inH in sorted(cohort_stats.keys()):
        s = cohort_stats[inH]
        enrich = s["frac_prime"] / baseline
        print(f"{inH:>4} {s['total_m_in_cohort']:>12} {s['frac_prime']*100:>9.1f}% {enrich:>11.2f}x")

    # Check monotonicity
    enrichments = [(inH, cohort_stats[inH]["frac_prime"]/baseline) for inH in sorted(cohort_stats.keys())]
    is_monotone = all(enrichments[i][1] <= enrichments[i+1][1] for i in range(len(enrichments)-1))

    if is_monotone:
        verdict = "MONOTONE_ENRICHMENT_CONFIRMED"
        msg = f"Primality enrichment INCREASES monotonically with inH. NEW structural theorem: inH = structural indicator of primality."
    else:
        # Find peak
        max_enrich = max(enrichments, key=lambda x: x[1])
        verdict = "NON_MONOTONE"
        msg = f"Enrichment is non-monotone. Peak at inH={max_enrich[0]} with {max_enrich[1]:.2f}x. Enrichments: {enrichments}"

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r624_results.json"
    out.write_text(json.dumps({
        "M_MAX": M_MAX,
        "baseline_prime_fraction": baseline,
        "cohort_stats": {str(k): v for k, v in cohort_stats.items()},
        "verdict": verdict,
        "msg": msg,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
