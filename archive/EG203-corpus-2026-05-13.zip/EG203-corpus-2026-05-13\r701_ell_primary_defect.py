"""R701 — Empirical verification of Claude Lemma 14 (ℓ-primary defect generalization).

Claude Lemma 14: For squarefree d = q_1 ... q_r with all q_i ≥ 5 odd local-full,
and for each prime ℓ | gcd(n_1, ..., n_r):
    κ_ℓ(d) ≥ ℓ^{r - ρ_ℓ(d)}
where ρ_ℓ(d) = rank over F_ℓ of the 2×r matrix [u; v] mod ℓ.

For ℓ = 2: ρ_2 = 1 always (Lemma 13), κ_2 ≥ 2^{r-1}.
For ℓ ≥ 3: ρ_ℓ ∈ {0, 1, 2}; generically 2 (no defect), drops when (u), (v) F_ℓ-parallel.

This script verifies Lemma 14 for ℓ = 3, r = 2:
  - Find pairs (q_1, q_2) of local-full primes with 3 | gcd(q_1-1, q_2-1).
  - For each, compute the 3-primary rank ρ_3 = rank of [[u_1, u_2], [v_1, v_2]] mod 3.
  - Predict κ_3 ≥ 3^{2 - ρ_3}.
  - Compare to actual κ(d) factored over ℓ.
"""

import json
import math
from pathlib import Path
from sympy import isprime


def order_mod(g, q):
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def find_primitive_root(q):
    """Find smallest primitive root mod prime q."""
    phi = q - 1
    factors = []
    n = phi
    p = 2
    while p * p <= n:
        if n % p == 0:
            factors.append(p)
            while n % p == 0:
                n //= p
        p += 1
    if n > 1:
        factors.append(n)
    for g in range(2, q):
        if all(pow(g, phi // p, q) != 1 for p in factors):
            return g
    return -1


def discrete_log(g, h, q, ord_g):
    """Compute log_g(h) mod ord_g via baby-step giant-step (for small orders)."""
    h = h % q
    if ord_g <= 50000:
        x = 1
        for k in range(ord_g):
            if x == h:
                return k
            x = (x * g) % q
        return -1
    # Baby-step giant-step (for larger orders)
    m = int(math.ceil(math.sqrt(ord_g)))
    table = {}
    x = 1
    for j in range(m):
        if x not in table:
            table[x] = j
        x = (x * g) % q
    factor = pow(g, m * (ord_g - 1) % ord_g, q)  # g^{-m} mod q
    cur = h
    for i in range(m + 1):
        if cur in table:
            return (i * m + table[cur]) % ord_g
        cur = (cur * factor) % q
    return -1


def Gamma_d_size_via_lattice(q1, q2, u1, v1, u2, v2):
    """|Γ_d| via lattice: image of (k, ℓ) → (k u_1 + ℓ v_1, k u_2 + ℓ v_2) in Z/n1 × Z/n2.

    Equivalent: |Z/n1 × Z/n2| / |cokernel|.
    Direct: enumerate.
    """
    n1, n2 = q1 - 1, q2 - 1
    seen = set()
    # Just enumerate k mod lcm(n1, n2), ℓ mod lcm(n1, n2). Faster: enumerate (k, ℓ) mod (n1, n2)
    # since image is determined by exponents mod n_i.
    # Wait — k and ℓ are integers; the image depends on k mod n_i for each component.
    # So enumerate k ∈ [0, n_max), ℓ ∈ [0, n_max) where n_max is sufficient.
    # Cleaner: just check all (k mod n1, ℓ mod n1) × (k mod n2, ℓ mod n2) consistent triples.
    # Simpler: enumerate k ∈ [0, lcm(n1, n2)), ℓ ∈ [0, lcm(n1, n2))?
    # That's too big. Use the fact image = subgroup of Z/n1 × Z/n2 of size ≤ n1·n2.
    # Enumerate k from 0 to lcm(n1, n2)-1 and similarly for ℓ.
    L = math.lcm(n1, n2)
    for k in range(L):
        for ell in range(L):
            seen.add(((k * u1 + ell * v1) % n1, (k * u2 + ell * v2) % n2))
            if len(seen) == n1 * n2:
                return n1 * n2
    return len(seen)


def rank_mod_ell(matrix_rows, ell):
    """Compute rank over F_ℓ of 2×r matrix [u; v] where rows are mod ell."""
    rows = [[x % ell for x in row] for row in matrix_rows]
    # Gaussian elimination mod ℓ
    nrows = len(rows)
    ncols = len(rows[0]) if rows else 0
    r = 0
    for c in range(ncols):
        if r >= nrows:
            break
        pivot = None
        for rr in range(r, nrows):
            if rows[rr][c] != 0:
                pivot = rr
                break
        if pivot is None:
            continue
        if pivot != r:
            rows[r], rows[pivot] = rows[pivot], rows[r]
        inv = pow(rows[r][c], -1, ell)
        for cc in range(c, ncols):
            rows[r][cc] = (rows[r][cc] * inv) % ell
        for rr in range(nrows):
            if rr != r and rows[rr][c] != 0:
                f = rows[rr][c]
                for cc in range(c, ncols):
                    rows[rr][cc] = (rows[rr][cc] - f * rows[r][cc]) % ell
        r += 1
    return r


def main():
    print("R701 — Claude Lemma 14: ℓ-primary defect for ℓ = 3, r = 2")
    print("=" * 92)
    print()

    # Find local-full primes q ≤ 200 with 3 | q-1
    local_full_with_3 = []
    for q in range(5, 200):
        if not isprime(q):
            continue
        if (q - 1) % 3 != 0:
            continue
        if order_mod(2, q) == q - 1 and order_mod(3, q) == q - 1:
            local_full_with_3.append(q)
    print(f"Local-full primes with 3 | q-1: {local_full_with_3}")
    print()

    print(f"{'q1':>4} {'q2':>4} {'u1':>3} {'v1':>3} {'u2':>3} {'v2':>3} "
          f"{'rho3':>5} {'pred_κ3':>8} {'actual_κ3':>10}")
    print("-" * 80)

    results = []
    for i, q1 in enumerate(local_full_with_3):
        for q2 in local_full_with_3[i+1:]:
            n1, n2 = q1 - 1, q2 - 1
            if math.gcd(n1, n2) % 3 != 0:
                continue
            # Find primitive roots
            g1 = find_primitive_root(q1)
            g2 = find_primitive_root(q2)
            # Compute u_i = log_{g_i}(2), v_i = log_{g_i}(3)
            u1 = discrete_log(g1, 2, q1, n1)
            v1 = discrete_log(g1, 3, q1, n1)
            u2 = discrete_log(g2, 2, q2, n2)
            v2 = discrete_log(g2, 3, q2, n2)
            if u1 < 0 or v1 < 0 or u2 < 0 or v2 < 0:
                continue
            # ρ_3 = rank of [[u1, u2], [v1, v2]] mod 3
            rho3 = rank_mod_ell([[u1, u2], [v1, v2]], 3)
            pred_kappa_3 = 3 ** (2 - rho3)  # Lemma 14 prediction
            # Actual κ_3(d): factor of κ(d) at ℓ=3
            # Limit to small primes to keep enumeration tractable
            if q1 * q2 > 5000:
                continue
            g_d = Gamma_d_size_via_lattice(q1, q2, u1, v1, u2, v2)
            kappa = (n1 * n2) // g_d
            # Factor out the 3-part of kappa
            actual_kappa_3 = 1
            k = kappa
            while k % 3 == 0:
                actual_kappa_3 *= 3
                k //= 3
            print(f"{q1:>4} {q2:>4} {u1:>3} {v1:>3} {u2:>3} {v2:>3} "
                  f"{rho3:>5} {pred_kappa_3:>8} {actual_kappa_3:>10}")
            results.append({
                'q1': q1, 'q2': q2, 'u1': u1, 'v1': v1, 'u2': u2, 'v2': v2,
                'rho3': rho3, 'predicted_kappa3': pred_kappa_3,
                'actual_kappa3': actual_kappa_3,
                'lemma14_holds': actual_kappa_3 >= pred_kappa_3,
            })

    all_hold = all(r['lemma14_holds'] for r in results)
    print()
    print(f"Claude Lemma 14 (ℓ=3) holds for all {len(results)} pairs: {all_hold}")

    out = {
        'phase': 'R701 — Claude Lemma 14 ℓ-primary defect verification',
        'local_full_with_3': local_full_with_3,
        'results': results,
        'lemma14_holds_uniformly_at_ell_3': all_hold,
    }
    Path(__file__).with_suffix('.json').write_text(json.dumps(out, indent=2))
    print(f"\nWritten {Path(__file__).with_suffix('.json')}")


if __name__ == '__main__':
    main()
