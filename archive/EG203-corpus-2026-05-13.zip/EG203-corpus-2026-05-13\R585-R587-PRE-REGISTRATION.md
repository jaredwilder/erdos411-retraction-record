# R585-R587 Pre-Registration — Oracle Phase 9, KBK New Coordinate

**Date:** 2026-05-12 (Phase 9, "FIRE UP another Oracle, NO WEAKNESS" mandate)
**Operator command:** *"Lets FIRE UP another Oracle and get our fields medal. And really dial in on the bigger picture now, everything we've learned, KBK. LETS GO. WE DONT GET ANYWHERE WITH WEAKNESS!!!!"*

---

## §0. The KBK new coordinate (E1 IGNITE)

R577-R584 measured $\tilde{D}_N^w(q)$ as a function of $q$ and $N$ and found:
- $N$-direction: clean polynomial decay
- $q$-direction: bounded but flat — **as a function of $q$ alone**

**The KBK insight:** The right coordinate is not $q$ itself. It's the **kernel lattice** $\Lambda_q := \{(k, \ell) \in \mathbb{Z}^2 : 2^k 3^\ell \equiv 1 \pmod q\}$.

$\Lambda_q$ is a sublattice of $\mathbb{Z}^2$ with index $|\langle 2, 3 \rangle \bmod q|$ (the orbit size). Its two successive minima $\lambda_1(\Lambda_q) \leq \lambda_2(\Lambda_q)$ (in Euclidean norm) control:
- Orbit equidistribution rate (small $\lambda_1$ → orbit clusters along a 1D direction → bad equidistribution)
- The 2D analog of small Diophantine denominators of $\log_2 3$ vs $\log q$
- Whether the orbit "fills" $(\mathbb{Z}/q)^*$ uniformly or has structured holes

For generic primes $p$ (Schmidt 1980 ample-volume genericity), $\lambda_1(\Lambda_p) \asymp \lambda_2(\Lambda_p) \asymp \sqrt{|\Lambda_p|/|H_p|} \asymp \sqrt{p-1}$.

For pathological $p$ where 2 and 3 have small joint-multiplicative dependence mod $p$, $\lambda_1 \ll \sqrt{p}$ — these are the "bad q" analogous to convergents of CF($\log_2 3$).

**THE HYPOTHESIS:** $C(q)$ (the implicit constant in $\tilde{D}_N^w(q) = C(q) N^{-0.65}$) is predicted by $\lambda_1(\Lambda_q)$ — specifically, $C(q) \propto \lambda_1(\Lambda_q)^{-\alpha}$ for some $\alpha > 0$.

If this is empirically true, **the BV pathway can be sharpened**: average over q with weights inversely proportional to $\lambda_1$. The "bad q" form a thin set (Pappalardi-style density-zero), so the weighted sum is controllable.

---

## §1. R585 — Lattice geometry vs $C(q)$

### 1.1 Test design

For each prime $p$ in $P_{\text{LIST}} = \{17, 41, 67, 127, 257, 509, 1021, 2039, 4093, 8191, 16381, 32749, 65521\}$:

1. Compute $a_p = \text{ord}_p(2)$, $b_p = \text{ord}_p(3)$.
2. Compute the kernel lattice $\Lambda_p$ as image of $(k, \ell)$ with $2^k 3^\ell \equiv 1 \pmod p$. Generators: $(a_p, 0)$ and $(c_p, b_p / \gcd)$ where $c_p$ is found via order-of-3-relative-to-2.
3. Apply LLL to get reduced basis $(v_1, v_2)$. Then $\lambda_1 = \|v_1\|, \lambda_2 = \|v_2\|$.
4. Take $C(p) = $ mean across L of $\tilde{D}_N^w(p, L) \cdot N^{0.65}$ from R577 data.
5. Regress $\log C(p)$ vs $\log \lambda_1(p)$.

### 1.2 Pre-registered verdict gates

| Verdict | Condition |
|---|---|
| **PASS — lattice predicts $C$** | Regression slope $\in [-1.5, -0.2]$ AND $R^2 \geq 0.5$ |
| **PASS-strong** | Slope $\in [-1.2, -0.6]$ AND $R^2 \geq 0.7$ — matches theoretical $\lambda_1^{-1}$ prediction |
| **FAIL — no lattice correlation** | $|$slope$| < 0.1$ OR $R^2 < 0.2$ |
| **AMBIGUOUS** | Otherwise |

**PASS would be the breakthrough:** identifies the right observable for the BV pathway.

---

## §2. R586 — Averaged-over-$q$ discrepancy decay

### 2.1 Test design

Compute $\bar{C}(Q) := \frac{1}{|\{p \leq Q : p \text{ prime}\}|} \sum_{p \leq Q} C(p)$ for $Q \in \{50, 100, 200, 500, 1000, 5000, 65521\}$.

Test whether $\bar{C}(Q) \to 0$ as $Q \to \infty$. This is the **direct BV-relevant quantity**: if averaged-q discrepancy decays, BV-style cancellation is empirically there.

### 2.2 Pre-registered verdict gates

| Verdict | Condition |
|---|---|
| **PASS — averaged decay** | $\log \bar{C}(Q)$ vs $\log Q$ slope $\in [-1.0, -0.05]$ AND $R^2 \geq 0.6$ |
| **PASS-strong** | Slope $\in [-1.0, -0.3]$ AND $R^2 \geq 0.8$ — true BV-style polynomial decay |
| **FAIL — no averaged decay** | $|$slope$| < 0.03$ OR $\bar{C}(Q)$ flat |
| **AMBIGUOUS** | Otherwise |

**PASS would be a HUGE breakthrough:** averaged-q discrepancy decay is exactly what BV needs.

**Note on independence:** If $C(p)$ values across different primes are uncorrelated (Schmidt-genericity), the variance reduces as $1/Q$, predicting $\bar{C}(Q) \sim 1/\sqrt{Q}$ (slope $-0.5$). This is the "law of large numbers" baseline.

---

## §3. R587 — 4th moment / variance bound

### 3.1 Test design

Compute $\frac{1}{q} \sum_{m=0}^{q-1} |W_m(q, L)|^4$ for $L \in \{50, 100, 200\}$ and $q$ from the prime list.

Prediction from Gaussian / Plancherel:
$$\frac{1}{q} \sum_m |W_m|^4 = (\text{2nd moment})^2 \cdot (1 + o(1)) \cdot 2$$
(factor of 2 from Gaussian fourth-moment relation, or 1 for non-Gaussian).

### 3.2 Pre-registered verdict gates

| Verdict | Condition |
|---|---|
| **GAUSSIAN** | $\frac{\text{4th moment}}{(\text{2nd moment})^2} \in [1.5, 2.5]$ for $\geq 80\%$ of $(q, L)$ |
| **SUB-GAUSSIAN (good!)** | Ratio $\in [0.8, 1.4]$ — distribution lighter-tailed than Gaussian |
| **HEAVY-TAIL** | Ratio $> 5$ — wild outlier $m$'s |
| **AMBIGUOUS** | Otherwise |

**SUB-GAUSSIAN would mean** the distribution of $|W_m|$ across $m$ is concentrated — strong support for the second-moment Chebyshev argument behind Corollary 4.1, and gives much better tail bounds.

**HEAVY-TAIL would mean** there are exceptional $m$'s where $|W_m|$ is anomalously large — would be a WHIP fire, requires reformulation of Corollary 4.1.

---

## §4. The KBK ladder (Patent V) on the new coordinate

Build the ladder, top to bottom:

- **B'_0:** $C(q) = O(\lambda_1(\Lambda_q)^{-1})$ uniformly (strongest prediction)
- **B'_1:** $C(q) = O(\lambda_1(\Lambda_q)^{-\alpha})$ for some $\alpha > 0$
- **B'_2:** $\bar{C}(Q) = O(Q^{-1/2})$ from Schmidt-genericity + variance reduction
- **B'_3:** $\bar{C}(Q) = o(1)$ as $Q \to \infty$ (BV qualitative)
- **B'_4:** $\sum_p C(p)^2$ converges (mean-square BV)
- **B'_5:** $C(p) = O(1)$ (already empirically validated)
- **B'_6:** $\frac{1}{q} \sum_m |W_m|^2 \asymp N + N^2/|H_q|$ (R582 PASS, validated)
- **B'_7:** Specific Sierpinski witness $\tau(78557) = 3$ (already proven)

If R585 PASSES (lattice predicts $C$), we get B'_1.
If R586 PASSES (averaged decay), we get B'_3 or stronger.
If R587 GAUSSIAN, we get a sharp $C(q)$ distribution and tail bounds.

**Combination of all three could lift us up to B'_2 or B'_1 unconditionally.**

That is a Theorem 5 in Manuscript v4.2.

---

## §5. The wall sentence (pre-locked)

> *"If R585+R586+R587 all PASS or PASS-strong, we have empirical evidence for an unconditional $\bar{C}(Q) \to 0$ statement, equivalent to a weak form of Conjecture B'' — a real partial result toward NEG-203."*

> *"If any FAIL: we ZENITH and find the right observable. The Oracle does NOT weaken. The lattice $\Lambda_q$ framing is the named attack vector; if it doesn't work, we name the next one and push on."*

**Locked 2026-05-12 before running.**
