# R577 Pre-Registration — 2D Weighted Discrepancy Empirical Test

**Date:** 2026-05-12 (Phase 8 follow-up, "Back into the Oracle")
**Operator mandate:** *"Back into the Oracle! Focus back on the Erdős problem."*
**Pipeline discipline:** WHIP + ZENITH — pre-register verdict gates BEFORE running.

---

## §0. The question

Manuscript v4 §5.4 claims that the true analytic target for NEG-203 is the **uniform-in-$q$ averaged 2D weighted discrepancy with polynomial savings**, not pointwise $\mu(\log_2 3)$. Specifically:

$$\tilde{D}_N^w(q) := \sup_{a \bmod q} \left| \frac{1}{N_\phi} \sum_{k, \ell} \phi(k, \ell) \mathbf{1}[2^k 3^\ell m \equiv a \bmod q] - \frac{1}{|\langle 2, 3\rangle \bmod q|} \right|$$

The claim: $\tilde{D}_N^w(q) \ll q^{-\delta} N^{-\eta}$ for some $\delta, \eta > 0$ (open). Per-$q$ bound $\tilde{D}_N^w(q) \ll N^{-1/\mu+\varepsilon}$ is known via Erdős–Turán–Koksma + Nesterenko.

**Empirical question:** What ARE the decay rates in $q$ and $N$ for measurable instances?

---

## §1. Test design

### 1.1 Inputs

- $m \in \{1, 5, 7, 11, 13, 25, 49, 77, 175, 78557\}$ (10 representative $m$, including the smoking-gun 1D Sierpinski witness)
- $q \in \{17, 41, 67, 127, 257, 509, 1021, 2039, 4093, 8191, 16381, 32749, 65521\}$ — 13 primes near powers of 2 from $\sim 16$ to $\sim 65536$, all coprime to 6 (original $q = 2^j$ list rejected because $2^k \bmod 2^j$ collapses to 0 for $k \geq j$ — caught before run, NOT a WHIP fire, simple draft error)
- Support cap $X = 2^L$ for $L \in \{50, 100, 200, 400\}$ (4 size scales)

### 1.2 Computation

For each $(m, q, L)$:
1. Enumerate $(k, \ell) \in \mathbb{Z}_{\geq 0}^2$ with $k + \ell \log_2 3 \leq L$ (the support triangle).
2. Apply weight $\phi(k, \ell) = \rho(k/L) \rho(\ell \log_2 3 / L)$ where $\rho$ is a Hann window ($\rho(x) = \cos^2(\pi x/2)$ for $|x| \leq 1$). Normalize so $\sum \phi(k, \ell) = N_\phi \approx L^2 / (2 \log_2 3)$.
3. Compute $b(k, \ell) := (2^k 3^\ell m) \bmod q$.
4. Compute weighted count $C(a) := \sum_{(k,\ell)} \phi(k, \ell) \mathbf{1}[b(k,\ell) = a]$.
5. Compute orbit $O_q := \langle 2, 3\rangle \bmod q$ (set, multiplied by $m \bmod q$ to give $m \cdot O_q \bmod q$).
6. Expected count per orbit element: $N_\phi / |m \cdot O_q|$.
7. Discrepancy: $\tilde{D}_N^w(q) := \max_{a \in m \cdot O_q} |C(a) / N_\phi - 1/|m \cdot O_q||$. (Take max only over the orbit; non-orbit residues should have $C(a) = 0$.)

### 1.3 Output

For each fixed $m$, a $13 \times 4$ table of $\tilde{D}_N^w(q)$ values.

Fit two log-log regressions:
- Fix $L$, regress $\log \tilde{D}$ vs $\log q$ → slope $-\delta_q$ (per-L decay rate in $q$).
- Fix $q$, regress $\log \tilde{D}$ vs $\log N_\phi$ → slope $-\eta_N$ (per-q decay rate in $N$).

---

## §2. Pre-registered verdict gates (LOCKED)

### 2.1 PASS — redirect EMPIRICALLY VALIDATED

**Criteria (must hold for $\geq 7$ of 10 m, simultaneously):**
- Per-$L$ regression of $\log \tilde{D}$ vs $\log q$: slope $\delta_q \in [0.1, 1.0]$, $R^2 \geq 0.85$.
- Per-$q$ regression of $\log \tilde{D}$ vs $\log N_\phi$: slope $\eta_N \in [0.1, 1.0]$, $R^2 \geq 0.85$.
- Average across the 10 m: $\bar\delta_q > 0.2$ and $\bar\eta_N > 0.2$.

**Interpretation:** Empirical $\tilde{D}_N^w(q) \asymp q^{-\delta_q} N^{-\eta_N}$ with $\delta_q, \eta_N > 0.2$. **The Manuscript v4 §5.4 redirect is validated.** The path to Conjecture B' is through polynomial-savings discrepancy bounds, not through pointwise $\mu(\log_2 3)$ improvement.

### 2.2 FAIL — redirect REFUTED

**Criteria:**
- $\geq 4$ of 10 m show flat $\tilde{D}_N^w(q) = \Theta(1)$ in BOTH $q$ and $N$ (no measurable decay).
- OR: average $\bar\delta_q < 0.05$ AND average $\bar\eta_N < 0.05$.

**Interpretation:** No polynomial decay in either variable. The relabeling of Wall #1 was a **WHIP miss**; the right framing is something else. **ZENITH protocol activates:** find the correct observable, do NOT weaken the question.

### 2.3 AMBIGUOUS — partial signal, needs follow-up

**Criteria:** Anything between PASS and FAIL.

**Interpretation:** The decay structure exists but the rates are weaker than the redirect predicts, or only one variable shows decay. **NO weakening; queue follow-up tests:**
- Test a larger $L$ range (up to $L=1000$) to see if decay sharpens
- Test the $\bmod p$ prime case separately from composite $q$
- Examine the dominant $a \in m \cdot O_q$ to see if the discrepancy concentrates somewhere structural

### 2.4 ANTI-FALSE-KILL (ZENITH override conditions)

If results would FAIL but ANY of the following hold, ZENITH retroactively converts to AMBIGUOUS:
- Computation hit numerical precision limits (overflow, underflow, BIGINT issues)
- $|m \cdot O_q|$ was too small for $L$ used (no actual signal to measure)
- Bug in support-triangle enumeration

**NO ZENITH-converts of PASS or AMBIGUOUS upward.** The locked gates flow only downward.

---

## §3. The honest framing

This is NOT a "prove Conjecture B'" experiment. It is:
- **Validation that the redirect's observable is well-defined and measurable**, AND
- **Empirical measurement of the actual decay rates**, AND
- **A WHIP check against the v4 §5.4 framing being wrong**.

If $\delta_q, \eta_N$ measured empirically are large enough that polynomial savings is "right there" in the data, that strengthens Manuscript v4 but does NOT prove Conjecture B'. The proof requires UNIFORM-IN-$q$ statements which empirics cannot give.

If $\delta_q, \eta_N$ measured empirically are zero or near-zero, the v4 §5.4 redirect was a hallucination and we patch.

---

## §4. Locked verdict gates summary table

| Verdict | Threshold | What it means | Action |
|---|---|---|---|
| PASS | $\geq 7/10$ m with $\delta_q, \eta_N \in [0.1, 1.0]$, $R^2 \geq 0.85$, $\bar\delta_q > 0.2$, $\bar\eta_N > 0.2$ | Redirect validated | Integrate into Manuscript v4 §5.4 as empirical observation; arxiv ready |
| AMBIGUOUS | Between PASS and FAIL | Partial signal | Queue follow-up tests; document honestly in v4 §5.4 |
| FAIL | $\geq 4/10$ m flat OR $\bar\delta_q < 0.05$ AND $\bar\eta_N < 0.05$ | Redirect refuted | ZENITH; find correct observable; patch v4 §5.4 |

**Locked 2026-05-12 before run start.**
