"""
R591 — DECISIVE: worst-case m direct prime counting in orbit.

For each m with tau(m) >= 7 from the R575 10K sample (the worst, most likely
exceptional cases), count actual primes in {2^k 3^l m + 1 : 2^k 3^l <= X}
for X = 2^40 (orbit support ~ 1300 points).

If EVERY worst-case m has >= 10 primes in its orbit at X = 2^40: NEG-203 is
empirically IRON-CLAD across all m we can check, and the heuristic prediction
of singular_series * support_size primes is essentially confirmed.

This is the direct empirical answer to "does A(m) contain many primes for
every m we can test?"
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

LOG2_3 = math.log2(3.0)


def count_primes_in_orbit(m, L):
    """Count number of (k, l) with 2^k 3^l <= 2^L such that 2^k 3^l m + 1 is prime."""
    cnt = 0
    pairs_examined = 0
    for k in range(L + 1):
        pow2k = 1 << k
        pow3l = 1
        l = 0
        while True:
            val = pow2k * pow3l
            if val > (1 << L):
                break
            n = val * m + 1
            pairs_examined += 1
            if sympy.isprime(n):
                cnt += 1
            pow3l *= 3
            l += 1
    return cnt, pairs_examined


def main():
    print("R591 — Worst-case m direct prime count test\n")

    # Load R575 high-tau samples if available
    r575_path = ROOT / "r575_tau_m_extended_results.json"
    if r575_path.exists():
        r575 = json.loads(r575_path.read_text())
        # Find m with tau >= 7 (worst cases in 10K sample)
        # r575 has tau_results: list of [m, tau]
        worst_m = []
        if "tau_results" in r575:
            for entry in r575["tau_results"]:
                m, t = entry[0], entry[1]
                if t >= 7:
                    worst_m.append((m, t))
        worst_m.sort(key=lambda x: -x[1])  # sort by tau descending
        worst_m = worst_m[:20]  # top 20 worst
        print(f"Loaded R575: found {len(worst_m)} m with tau >= 7 (showing top 20)")
    else:
        # Fallback: manually-known worst cases
        print("R575 results not found; using manual candidates")
        worst_m = [(78557, 3), (10223, None), (21181, None), (22699, None), (24737, None),
                   (55459, None), (67607, None), (271129, None), (271577, None), (322523, None)]

    # Plus add 78557 (1D Sierpinski) and known small m for context
    plus_m = [1, 5, 7, 11, 13, 25, 49, 77, 175, 78557]
    test_m = list(set([x[0] for x in worst_m] + plus_m))

    print(f"\nTesting {len(test_m)} m values at L=40 (support 2^40 = ~10^12):")

    L_TEST = 40  # support 2^k 3^l <= 2^40
    # Support size: number of (k, l) with k + l*log_2(3) <= 40 is approx 40^2/(2 log_2 3) ~ 506

    t0 = time.time()
    results = []
    for m in sorted(test_m):
        t1 = time.time()
        cnt, n_pairs = count_primes_in_orbit(m, L_TEST)
        elapsed = time.time() - t1
        results.append({"m": m, "primes": cnt, "pairs": n_pairs, "time": elapsed})
        print(f"  m={m:>10}: {cnt:>4} primes / {n_pairs:>4} support points  (frac = {cnt/n_pairs:.4f})  t={elapsed:.1f}s")

    total_t = time.time() - t0
    print(f"\nTotal: {total_t:.1f}s")

    # Summary statistics
    prime_counts = [r["primes"] for r in results]
    min_primes = min(prime_counts)
    max_primes = max(prime_counts)
    median_primes = sorted(prime_counts)[len(prime_counts)//2]
    mean_primes = sum(prime_counts) / len(prime_counts)

    print(f"\n=== SUMMARY ===")
    print(f"  Min primes in orbit:    {min_primes}")
    print(f"  Median primes in orbit: {median_primes}")
    print(f"  Mean primes in orbit:   {mean_primes:.1f}")
    print(f"  Max primes in orbit:    {max_primes}")
    print(f"  Worst-case m: {sorted(results, key=lambda r: r['primes'])[0]['m']} with {min_primes} primes")

    if min_primes >= 10:
        verdict = "IRON_CLAD"
        msg = f"EVERY tested m (including worst cases from 10K sample) has >= 10 primes in orbit at L=40. NEG-203 empirically resolved at this scale for all tested m."
    elif min_primes >= 3:
        verdict = "STRONG"
        msg = f"All m have >= 3 primes in orbit. Strong evidence NEG-203 is empirically true."
    elif min_primes >= 1:
        verdict = "PARTIAL"
        msg = f"All m have >= 1 prime. Consistent with NEG-203 but not as decisive."
    else:
        verdict = "FAIL"
        msg = f"Some m have 0 primes at L=40. Need to push L higher."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r591_results.json"
    out.write_text(json.dumps({
        "L_TEST": L_TEST,
        "test_m_count": len(test_m),
        "results": results,
        "summary": {
            "min_primes": min_primes,
            "median_primes": median_primes,
            "mean_primes": mean_primes,
            "max_primes": max_primes,
            "verdict": verdict,
            "msg": msg,
        },
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
