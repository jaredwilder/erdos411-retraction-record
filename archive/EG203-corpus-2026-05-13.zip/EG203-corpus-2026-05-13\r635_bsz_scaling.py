"""R635 — Sarnak BSZ-scaling diagnostic on the (2,3)-orbit Möbius correlation.

Per Sarnak-emulated Phase-22 Borg recipe (4-hour quick gold):
Measure ⟨|M(m, L)|⟩ / Poisson(L) at multiple L values.
- M(m, L) := (1/N_φ) Σ_{(k,ℓ): 2^k 3^ℓ ≤ 2^L} μ(2^k 3^ℓ m + 1)
- Poisson floor = 1/√N_φ(L) for uniform random ±1 sums
- Question: does (1 - ⟨|M|⟩/Poisson) decay polynomially in N=2^L or logarithmically?

Polynomial decay → BSZ-grade signature of zero-entropy Möbius cancellation → empirical
Conjecture B''-weak (JNT-grade publication).
Logarithmic decay → MRT-grade → wall stays at full Furstenberg height.

Manuscript Th 6 reports at L=24: ⟨|M|⟩ = 0.068, 34% below Poisson floor 0.104.
This script extends to L ∈ {15, 18, 21, 24, 27} for scaling diagnostic.

For compute feasibility: use 14-m sample as in manuscript Th 6:
{1, 5, 7, 11, 13, 25, 49, 77, 175, 245, 1234, 12345, 78557, 99991}
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

# Manuscript Th 6 sample
SAMPLE_M = [1, 5, 7, 11, 13, 25, 49, 77, 175, 245, 1234, 12345, 78557, 99991]

# L values for scaling diagnostic
L_VALUES = [15, 18, 21, 24, 27]


def support_pairs(L):
    """All (k, ℓ) ∈ Z²_{≥0} with 2^k 3^ℓ ≤ 2^L."""
    pairs = []
    log2_3 = math.log2(3)
    max_k = L
    for k in range(max_k + 1):
        max_ell = int((L - k) / log2_3)
        for ell in range(max_ell + 1):
            pairs.append((k, ell))
    return pairs


def mobius(n):
    """Möbius function μ(n)."""
    if n == 1:
        return 1
    return sympy.mobius(n)


def compute_M(m, L):
    """M(m, L) = (1/N_φ) Σ_{(k,ℓ): 2^k 3^ℓ ≤ 2^L} μ(2^k 3^ℓ m + 1) with uniform φ."""
    pairs = support_pairs(L)
    N_phi = len(pairs)
    total = 0
    for (k, ell) in pairs:
        n = (1 << k) * (3 ** ell) * m + 1
        mu = mobius(n)
        total += mu
    return total / N_phi, N_phi


def main():
    print("R635 — Sarnak BSZ-scaling diagnostic on (2,3)-orbit Möbius")
    print("=" * 65)
    print(f"Sample m's: {SAMPLE_M}")
    print(f"L values: {L_VALUES}")
    print()

    results = {}

    for L in L_VALUES:
        pairs = support_pairs(L)
        N_phi = len(pairs)
        poisson_floor = 1 / math.sqrt(N_phi)
        print(f"\n=== L = {L} (N_φ = {N_phi}, Poisson floor = {poisson_floor:.4f}) ===")

        M_values = []
        absM_values = []
        t0 = time.time()
        for m in SAMPLE_M:
            M_val, _ = compute_M(m, L)
            M_values.append(M_val)
            absM_values.append(abs(M_val))
            print(f"  m={m:>6}: M(m, L) = {M_val:+.4f}, |M| = {abs(M_val):.4f}")
        elapsed = time.time() - t0

        mean_absM = sum(absM_values) / len(absM_values)
        ratio = mean_absM / poisson_floor
        deficit = 1 - ratio  # fraction below Poisson floor

        print(f"  Elapsed: {elapsed:.1f}s")
        print(f"  ⟨|M(m, L)|⟩ = {mean_absM:.4f}")
        print(f"  Poisson floor = {poisson_floor:.4f}")
        print(f"  Ratio = {ratio:.4f}")
        print(f"  Deficit (1 - ratio) = {deficit:.4f}  ({deficit*100:.1f}% below Poisson)")

        results[L] = {
            "N_phi": N_phi,
            "Poisson_floor": poisson_floor,
            "M_values": M_values,
            "absM_values": absM_values,
            "mean_absM": mean_absM,
            "ratio": ratio,
            "deficit": deficit,
            "elapsed_sec": elapsed,
        }

    # Scaling analysis
    print("\n" + "=" * 65)
    print("=== Scaling analysis (BSZ diagnostic) ===")
    print(f"\n{'L':>4} {'log N':>8} {'N_φ':>6} {'⟨|M|⟩':>9} {'Poisson':>9} {'ratio':>8} {'deficit':>9}")
    for L in L_VALUES:
        r = results[L]
        print(f"{L:>4} {L*math.log(2):>8.3f} {r['N_phi']:>6} {r['mean_absM']:>9.4f} "
              f"{r['Poisson_floor']:>9.4f} {r['ratio']:>8.4f} {r['deficit']:>9.4f}")

    # Fit: polynomial vs logarithmic
    print()
    print("=== Fit: deficit decay model ===")
    log_Ns = [L * math.log(2) for L in L_VALUES]
    Ns = [2**L for L in L_VALUES]
    deficits = [results[L]["deficit"] for L in L_VALUES]

    # Polynomial: deficit = C · N^{-δ}, fit log(deficit) vs log(N)
    log_deficits = [math.log(max(d, 1e-10)) for d in deficits]
    log_log_Ns = [math.log(N) for N in Ns]

    # Linear regression log(deficit) vs log(N)
    n = len(L_VALUES)
    mean_x = sum(log_log_Ns) / n
    mean_y = sum(log_deficits) / n
    num = sum((log_log_Ns[i] - mean_x) * (log_deficits[i] - mean_y) for i in range(n))
    den = sum((log_log_Ns[i] - mean_x) ** 2 for i in range(n))
    slope_poly = num / den if den != 0 else 0
    intercept_poly = mean_y - slope_poly * mean_x
    delta = -slope_poly  # deficit = exp(intercept) · N^{slope_poly} = C · N^{-delta}
    C_poly = math.exp(intercept_poly)
    # R² for polynomial fit
    y_pred = [intercept_poly + slope_poly * x for x in log_log_Ns]
    ss_res = sum((log_deficits[i] - y_pred[i]) ** 2 for i in range(n))
    ss_tot = sum((log_deficits[i] - mean_y) ** 2 for i in range(n))
    R2_poly = 1 - ss_res / ss_tot if ss_tot > 0 else 0

    print(f"Polynomial fit: deficit = {C_poly:.3f} · N^(-{delta:.4f})")
    print(f"  Polynomial decay rate δ = {delta:.4f}")
    print(f"  R² (polynomial) = {R2_poly:.4f}")

    # Logarithmic: deficit = C / (log N)^c, fit log(deficit) vs log(log N)
    log_log_log_Ns = [math.log(L * math.log(2)) for L in L_VALUES]
    mean_x_log = sum(log_log_log_Ns) / n
    num_log = sum((log_log_log_Ns[i] - mean_x_log) * (log_deficits[i] - mean_y) for i in range(n))
    den_log = sum((log_log_log_Ns[i] - mean_x_log) ** 2 for i in range(n))
    slope_log = num_log / den_log if den_log != 0 else 0
    intercept_log = mean_y - slope_log * mean_x_log
    c_log = -slope_log  # deficit = exp(intercept) / (log N)^c
    C_logfit = math.exp(intercept_log)
    y_pred_log = [intercept_log + slope_log * x for x in log_log_log_Ns]
    ss_res_log = sum((log_deficits[i] - y_pred_log[i]) ** 2 for i in range(n))
    R2_log = 1 - ss_res_log / ss_tot if ss_tot > 0 else 0

    print(f"\nLogarithmic fit: deficit = {C_logfit:.3f} / (log N)^{c_log:.4f}")
    print(f"  Logarithmic exponent c = {c_log:.4f}")
    print(f"  R² (logarithmic) = {R2_log:.4f}")

    # Verdict
    print()
    if R2_poly > R2_log + 0.05 and delta > 0.01:
        verdict = "POLYNOMIAL_DECAY_BSZ_GRADE"
        print(f"VERDICT: {verdict}")
        print(f"  Polynomial fit R² ({R2_poly:.3f}) significantly better than logarithmic ({R2_log:.3f})")
        print(f"  Decay rate δ ≈ {delta:.3f} — consistent with BSZ-grade Möbius cancellation")
        print(f"  → Empirical Conjecture B''-weak signature (JNT-grade publication potential)")
    elif R2_log > R2_poly + 0.05:
        verdict = "LOGARITHMIC_DECAY_MRT_GRADE"
        print(f"VERDICT: {verdict}")
        print(f"  Logarithmic fit R² ({R2_log:.3f}) significantly better than polynomial ({R2_poly:.3f})")
        print(f"  → MRT-grade (Matomäki-Radziwiłł-Tao), wall stays at full Furstenberg height")
    else:
        verdict = "INCONCLUSIVE_BOTH_FITS_COMPARABLE"
        print(f"VERDICT: {verdict}")
        print(f"  Polynomial R²={R2_poly:.3f}, Logarithmic R²={R2_log:.3f}")
        print(f"  Need more scales (e.g., L=30, 36) to distinguish; current data ambiguous")

    out = ROOT / "r635_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 22 R635 — Sarnak BSZ-scaling diagnostic",
        "sample_m": SAMPLE_M,
        "L_values": L_VALUES,
        "results": {str(L): results[L] for L in L_VALUES},
        "polynomial_fit": {"delta": delta, "C": C_poly, "R2": R2_poly},
        "logarithmic_fit": {"c": c_log, "C": C_logfit, "R2": R2_log},
        "verdict": verdict,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
