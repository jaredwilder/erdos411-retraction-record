"""R644 - rank-4 case: tau_4(m) = min{k+l+j+i : 2^k 3^l 5^j 7^i m + 1 prime}.

Theorem 10 reports tau_4 max = 4 across 416 m. R644 pushes to m <= 10^5 coprime to 210.
If max tau_4 stays <= 4 or 5, the rank-r >= 3 saturation hypothesis is empirically robust.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

M_MAX = 100_000
TAU_MAX = 6


def tau_4(m, tau_max=TAU_MAX):
    for total in range(0, tau_max + 1):
        for k in range(total + 1):
            for ell in range(total - k + 1):
                for j in range(total - k - ell + 1):
                    i = total - k - ell - j
                    n = (2**k) * (3**ell) * (5**j) * (7**i) * m + 1
                    if sympy.isprime(n):
                        return total
    return tau_max + 1


def main():
    print(f"R644 - rank-4 at M <= {M_MAX:,}")
    tau_counts = [0] * (TAU_MAX + 2)
    exceptional_m = []
    extreme_m = []
    n_tested = 0
    t0 = time.time()
    for m in range(1, M_MAX + 1):
        if math.gcd(m, 210) != 1:
            continue
        n_tested += 1
        tau = tau_4(m, TAU_MAX)
        tau_counts[tau] += 1
        if tau > 4:
            exceptional_m.append((m, tau))
        if tau > TAU_MAX:
            extreme_m.append(m)
        if n_tested % 2000 == 0:
            elapsed = time.time() - t0
            print(f"  n={n_tested:>6,} elapsed {elapsed:>4.0f}s "
                  f"max_tau {max(t for t in range(TAU_MAX+2) if tau_counts[t] > 0)} "
                  f"#exc {len(exceptional_m)}")

    elapsed = time.time() - t0
    max_tau = max(t for t in range(TAU_MAX + 2) if tau_counts[t] > 0)
    print(f"\nDone {elapsed:.0f}s. n_tested = {n_tested}")
    print(f"Max tau_4 = {max_tau}")
    for t in range(TAU_MAX + 2):
        if tau_counts[t] > 0:
            print(f"  tau={t}: {tau_counts[t]:>6,} ({tau_counts[t]/n_tested:.6f})")
    print(f"  exceptional (tau > 4): {len(exceptional_m)}")

    out = ROOT / "r644_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 25 R644 - rank-4 case",
        "M_MAX": M_MAX, "TAU_MAX": TAU_MAX, "n_tested": n_tested,
        "tau_counts": tau_counts, "max_tau": max_tau,
        "fraction_le_3": sum(tau_counts[0:4])/n_tested,
        "fraction_le_4": sum(tau_counts[0:5])/n_tested,
        "exceptional_count": len(exceptional_m),
        "exceptional_sample": exceptional_m[:50],
        "extreme_m": extreme_m,
        "elapsed_sec": elapsed,
    }, indent=2, default=str))
    print(f"Written {out}")


if __name__ == "__main__":
    main()
