"""R643 — Push rank-3 R637 anchor to production scale m <= 10^6.

R637 tested 26,666 m's coprime to 30 in [1, 10^5]: max tau_3 = 6, 99.91% tau_3 <= 5.
R643 pushes to m <= 10^6 (10x larger). If max tau_3 stays <= 6 across ~266K m's,
the empirical anchor for Theorem 19 (rank-3 unconditional bounded-gap) is production-grade.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

M_MAX = 1_000_000
TAU_MAX = 8


def tau_3(m, tau_max=TAU_MAX):
    for total in range(0, tau_max + 1):
        for k in range(total + 1):
            for ell in range(total - k + 1):
                j = total - k - ell
                n = (2**k) * (3**ell) * (5**j) * m + 1
                if sympy.isprime(n):
                    return total
    return tau_max + 1


def main():
    print(f"R643 - rank-3 production scale: M <= {M_MAX:,}")
    tau_counts = [0] * (TAU_MAX + 2)
    exceptional_m = []
    extreme_m = []

    n_tested = 0
    t0 = time.time()
    for m in range(1, M_MAX + 1):
        if math.gcd(m, 30) != 1:
            continue
        n_tested += 1
        tau = tau_3(m, TAU_MAX)
        tau_counts[tau] += 1
        if tau > 5:
            exceptional_m.append((m, tau))
        if tau > TAU_MAX:
            extreme_m.append(m)
        if n_tested % 10000 == 0:
            elapsed = time.time() - t0
            print(f"  n={n_tested:>7,} elapsed {elapsed:>5.0f}s rate {n_tested/elapsed:>6.0f}/s "
                  f"max_tau {max(t for t in range(TAU_MAX+2) if tau_counts[t] > 0)} "
                  f"#exc {len(exceptional_m)}")

    elapsed = time.time() - t0
    max_tau = max(t for t in range(TAU_MAX + 2) if tau_counts[t] > 0)
    print(f"\nDone {elapsed:.0f}s. n_tested = {n_tested}")
    print(f"Max tau_3 = {max_tau}")
    for t in range(TAU_MAX + 2):
        if tau_counts[t] > 0:
            print(f"  tau={t}: {tau_counts[t]:>7,} ({tau_counts[t]/n_tested:.6f})")
    print(f"  exceptional (tau > 5): {len(exceptional_m)}")
    print(f"  extreme (tau > {TAU_MAX}): {len(extreme_m)}")

    out = ROOT / "r643_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 25 R643 - rank-3 production scale",
        "M_MAX": M_MAX, "TAU_MAX": TAU_MAX, "n_tested": n_tested,
        "tau_counts": tau_counts, "max_tau": max_tau,
        "fraction_le_5": sum(tau_counts[0:6])/n_tested,
        "fraction_le_6": sum(tau_counts[0:7])/n_tested,
        "exceptional_count": len(exceptional_m),
        "exceptional_sample": exceptional_m[:100],
        "extreme_m": extreme_m,
        "elapsed_sec": elapsed,
    }, indent=2, default=str))
    print(f"Written {out}")


if __name__ == "__main__":
    main()
