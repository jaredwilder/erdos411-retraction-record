# PATCH FOR PAPER 1 — COMPLETE DISTRIBUTION LAW

Insert after the finite abelian subgroup obstruction lemma.

```latex
\section{Complete distribution law}

The variance identity is only the second-order shadow of a complete elementary distribution law.

\begin{theorem}[Scaled Bernoulli law]
Let \(G\) be a finite abelian group, \(\Gamma\le G\), and let \(c\) be uniformly distributed on \(G\). Define
\[
X_\Gamma(c)=\frac{\mathbf 1_\Gamma(c)}{|\Gamma|}.
\]
Then
\[
X_\Gamma=
\begin{cases}
|\Gamma|^{-1},&\text{with probability }|\Gamma|/|G|,\\
0,&\text{with probability }1-|\Gamma|/|G|.
\end{cases}
\]
Consequently, for every integer \(k\ge1\),
\[
\mathbb E X_\Gamma^k
=
\frac1{|G|\,|\Gamma|^{k-1}}.
\]
\end{theorem}

\begin{proof}
The random variable \(X_\Gamma\) equals \(|\Gamma|^{-1}\) exactly on the subgroup \(\Gamma\), which has probability \(|\Gamma|/|G|\), and equals \(0\) elsewhere.  The moment formula follows immediately.
\end{proof}

\begin{corollary}[Information-theoretic obstruction profile]
Let
\[
U_\Gamma(c)=\frac{\mathbf 1_\Gamma(c)}{|\Gamma|},
\qquad
U_G(c)=\frac1{|G|}.
\]
Then
\[
\|U_\Gamma-U_G\|_{\mathrm{TV}}
=
1-\frac{|\Gamma|}{|G|},
\]
\[
\chi^2(U_\Gamma\|U_G)
=
\frac{|G|}{|\Gamma|}-1,
\]
and
\[
D_{\mathrm{KL}}(U_\Gamma\|U_G)
=
\log\frac{|G|}{|\Gamma|}.
\]
\end{corollary}

\begin{proof}
For total variation,
\[
\frac12\sum_{c\in G}\left|U_\Gamma(c)-U_G(c)\right|
=
\frac12\left[
|\Gamma|\left(\frac1{|\Gamma|}-\frac1{|G|}\right)
+
(|G|-|\Gamma|)\frac1{|G|}
\right]
=
1-\frac{|\Gamma|}{|G|}.
\]
For chi-square divergence,
\[
\chi^2(U_\Gamma\|U_G)
=
\sum_{c\in G}\frac{(U_\Gamma(c)-U_G(c))^2}{U_G(c)}
=
|G|\left(\frac1{|\Gamma|}-\frac1{|G|}\right)
=
\frac{|G|}{|\Gamma|}-1.
\]
For KL divergence,
\[
D_{\mathrm{KL}}(U_\Gamma\|U_G)
=
\sum_{c\in\Gamma}\frac1{|\Gamma|}
\log\left(\frac{1/|\Gamma|}{1/|G|}\right)
=
\log\frac{|G|}{|\Gamma|}.
\]
\end{proof}
```
