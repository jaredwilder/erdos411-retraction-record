"""R619 — Test the structural-tracer prediction: do worst-case m's from L=40 remain worst-case at L=60?

Defense Specialist's prediction:
- If worst-case status is STRUCTURAL (driven by low singular series via small-prime obstruction):
  m=962653 and m=714739 (inH=23/23) PERSIST in worst-20 at L=60
- If random Poisson tail: worst-case set SHUFFLES, tracer particles regress to mean

Procedure:
1. Take 50 worst-case m's from R600 (L=40) data
2. Re-compute prime count at L=60 (heuristic ~80, vs ~50 at L=40)
3. Check whether 962653 and 714739 remain in worst-20
4. Check whether RANK CORRELATION between L=40 and L=60 rankings is high (structural) or low (random)
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

L_TEST = 60

# Top 50 worst-case from R600 at L=40
WORST_50_L40 = [
    647093, 789863, 968179, 398543, 567013, 962653, 577333, 613553, 725209, 725969,
    785663, 810527, 917207, 952447, 961411,  35941, 352679, 494483, 714739, 773671,
    899057, 937777, 253709, 297841, 303389, 345811, 391411, 406463, 421411, 473189,
    # Need 20 more — read from r600_results.json
]


def count_primes_in_orbit(m, L):
    cnt = 0
    n_pairs = 0
    for k in range(L + 1):
        pow2k = 1 << k
        pow3l = 1
        l = 0
        while True:
            val = pow2k * pow3l
            if val > (1 << L):
                break
            n = val * m + 1
            n_pairs += 1
            if sympy.isprime(n):
                cnt += 1
            pow3l *= 3
            l += 1
    return cnt, n_pairs


def main():
    print(f"R619 — Worst-case L=40 → L={L_TEST} persistence test\n")

    # Load full R600 worst list (top 100)
    r600 = json.loads((ROOT / "r600_results.json").read_text())
    worst_300 = r600["worst_300"]  # list of [m, count] pairs
    # Take first 50
    target_m = [entry[0] for entry in worst_300[:50]]
    l40_counts = {entry[0]: entry[1] for entry in worst_300[:50]}

    print(f"Testing {len(target_m)} worst-case m's from R600 at L={L_TEST}")
    print(f"Tracer particles: 962653, 714739 (predicted to persist)\n")

    t0 = time.time()
    results = []
    for i, m in enumerate(target_m):
        t1 = time.time()
        cnt60, n_pairs = count_primes_in_orbit(m, L_TEST)
        elapsed = time.time() - t1
        l40_cnt = l40_counts[m]
        results.append({"m": m, "count_L40": l40_cnt, "count_L60": cnt60, "support_L60": n_pairs})
        if (i+1) % 10 == 0:
            print(f"  [{i+1}/{len(target_m)}] m={m:>7}: L40={l40_cnt:>3} L60={cnt60:>4}  t={elapsed:.1f}s")

    elapsed_total = time.time() - t0
    print(f"\nTotal compute: {elapsed_total:.0f}s\n")

    # Sort by L60 count
    sorted_by_l60 = sorted(results, key=lambda r: r["count_L60"])

    # Check structural tracers
    tracer_results = {r["m"]: r for r in results if r["m"] in [962653, 714739]}
    print("=== STRUCTURAL TRACER STATUS ===")
    for m_tracer in [962653, 714739]:
        if m_tracer in tracer_results:
            r = tracer_results[m_tracer]
            # Where does this tracer rank in L60?
            l60_rank = next(i for i, x in enumerate(sorted_by_l60) if x["m"] == m_tracer) + 1
            print(f"  m={m_tracer}: L40={r['count_L40']}  L60={r['count_L60']}  L60 rank: {l60_rank}/{len(sorted_by_l60)}")

    # Compute rank correlation (Spearman) between L40 and L60
    l40_ranks = {r["m"]: i for i, r in enumerate(sorted(results, key=lambda x: x["count_L40"]))}
    l60_ranks = {r["m"]: i for i, r in enumerate(sorted(results, key=lambda x: x["count_L60"]))}
    n = len(results)
    sum_d2 = sum((l40_ranks[r["m"]] - l60_ranks[r["m"]])**2 for r in results)
    spearman = 1 - (6 * sum_d2) / (n * (n**2 - 1))
    print(f"\n=== RANK CORRELATION ===")
    print(f"Spearman ρ between L=40 and L={L_TEST} rankings: {spearman:.4f}")

    # Top 20 at L60
    print(f"\n=== TOP 20 WORST AT L={L_TEST} ===")
    for r in sorted_by_l60[:20]:
        print(f"  m={r['m']:>7}: L40={r['count_L40']:>3}  L60={r['count_L60']:>4}")

    # Verdict
    tracer_in_top20 = sum(1 for r in sorted_by_l60[:20] if r["m"] in [962653, 714739])
    if tracer_in_top20 == 2 and spearman > 0.5:
        verdict = "STRUCTURAL_TRACERS_PERSIST"
        msg = f"BOTH tracer particles in L=60 top-20 AND Spearman ρ={spearman:.3f} > 0.5 — worst-case status is STRUCTURAL, not random."
    elif spearman > 0.5:
        verdict = "STRUCTURAL_BUT_TRACERS_SHIFTED"
        msg = f"Spearman ρ={spearman:.3f} > 0.5 (structural correlation) but tracers shifted: only {tracer_in_top20}/2 in L=60 top-20."
    elif tracer_in_top20 >= 1:
        verdict = "PARTIAL"
        msg = f"At least one tracer persists but Spearman correlation weak (ρ={spearman:.3f})."
    else:
        verdict = "RANDOM_SHUFFLE"
        msg = f"Tracers shuffled out of top-20, Spearman ρ={spearman:.3f}. Worst-case status is Poisson noise, not structural."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r619_results.json"
    out.write_text(json.dumps({
        "L_TEST": L_TEST,
        "n_m": len(target_m),
        "spearman_rho": spearman,
        "tracers_in_top20": tracer_in_top20,
        "verdict": verdict,
        "msg": msg,
        "results": results,
        "top20_L60": sorted_by_l60[:20],
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
