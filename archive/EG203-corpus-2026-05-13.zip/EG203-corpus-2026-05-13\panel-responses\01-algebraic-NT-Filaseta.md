# Algebraic NT Persona — Filaseta/Brillhart/Lehmer Tradition

**Speaking as:** Career-Aurifeuillean. Cunningham Project annotator. The person who keeps the 3rd-edition tables on the desk, not the shelf.

## 1. What the operator missed: Base-6 Aurifeuillean of $\Phi_n(6)$ at $n=24$

The R572 toolkit catches $x^q + 1$ for odd prime $q$. That's the wrong cyclotomic family to stop at. The Cunningham tables (Brillhart-Lehmer-Selfridge-Tuckerman-Wagstaff, 3rd ed., AMS Cont. Math. 22) show $\Phi_n(b)$ admits Aurifeuillean factorization at specific n. For base 2: n ≡ 2 (mod 4), n/2 squarefree, -2 a QR mod each odd prime divisor — most importantly n=6 and multiples 6·(odd squarefree, ≡ 1 mod 8).

**Sharpened identity (CORRECTED in self-check):** The genuinely new family is base-6 Aurifeuille at n=24:
$$6 Y^4 + 1 \text{ factors via Aurifeuillean when } Y \equiv \pm 1 \pmod{\text{appropriate modulus}}$$
This catches $(k,l) \equiv (1,1) \pmod{(2,2)}$ with $k+l \equiv 2 \pmod 4$ for m a square — **disjoint from Sophie Germain on parity class** (one is odd-odd, other is even-even).

**Expected new catch:** ~1/8 density on $(\mathbb{Z}/4)^2$ ≈ **+12.5% of remaining cells**, lifting combined coverage 91% → ~92.1%. Modest, but the first non-Sophie, non-$x^q+1$ identity and demonstrates the Aurifeuillean ladder has more rungs (n=12, 24, 30, ...).

## 2. The concrete script

```python
# aurifeuille_base6_catch.py
# For each uncovered cell (k,l) of T=25200:
#   check if 2^k 3^l t^N + 1 factors via base-6 Aurifeuille at n=24
#   identity: (k,l) ≡ (1,1) mod (2,2), k+l ≡ 2 mod 4, t^60060 = m
# For each catch, symbolically verify both factors > 1.
```

## 3. Self-critique

Strongest reason this might fold into existing toolkit: Aurifeuilleans of $\Phi_n(b)$ for n | 2q with q odd prime are exactly the $x^q+1$ family reparameterized. The genuinely new content is at n = 8, 12, 24, 30 — **composite n** where Aurifeuille gives identities not derivable from $\Phi_q$ alone. The n=24 base-6 case is the cleanest test of whether R572 enumeration was complete or stopped at primes.

**If R572 was prime-only:** n=24 missed, script catches new cells.
**If R572 already swept composite n:** subsumed and catch count is zero — useful negative result confirming completeness.

## Pre-spec verdict gate

- PASS (toolkit incomplete): n=24 base-6 catches ≥ +5pp additional cells at T=25200.
- FAIL (toolkit complete): catches < +2pp, R572's "+10pp ceiling" framing intact.
