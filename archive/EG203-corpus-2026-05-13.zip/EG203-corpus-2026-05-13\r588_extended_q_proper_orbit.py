"""
R588 — Extended R586 to Q=10^6 with PROPER true-orbit enumeration (no cap bug).

R586 had a bug: orbit was enumerated by iterating (k, l) in [0, L]^2, capping orbit_size
at (L+1)^2 = 10201. For large primes with true orbit > 10201, the discrepancy was
computed against a wrong target.

R588 fix: compute true orbit via multiplicative BFS (orbit = {2^k 3^l mod p}, computed
to fixed point). Discrepancy then uses true |O_q|.

ALSO: scale L proportionally to sqrt(p) so orbit fits in support for each q.

Test: does the polynomial decay slope -0.10 hold at Q=10^6?
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import numpy as np
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

LOG2_3 = math.log2(3.0)
ETA_FIT = 0.65


def hann(x):
    if x < 0 or x > 1:
        return 0.0
    return math.cos(math.pi * x / 2.0) ** 2


def true_orbit_size(p):
    """Compute |<2, 3> mod p| via multiplicative BFS to fixed point."""
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return len(orbit)


def discrepancy_for_p_L(p, L, true_O):
    """Compute tilde_D using TRUE orbit size."""
    pow2 = [1] * (L + 1)
    for k in range(1, L + 1):
        pow2[k] = (pow2[k-1] * 2) % p
    pow3 = [1] * (L + 1)
    for l in range(1, L + 1):
        pow3[l] = (pow3[l-1] * 3) % p

    C_arr = np.zeros(p, dtype=np.float64)
    N_phi = 0.0
    for k in range(L + 1):
        wk = hann(k / L)
        if wk == 0:
            continue
        lmax = math.floor((L - k) / LOG2_3)
        for l in range(lmax + 1):
            wl = hann((l * LOG2_3) / L)
            w = wk * wl
            if w == 0:
                continue
            a = (pow2[k] * pow3[l]) % p
            C_arr[a] += w
            N_phi += w

    if N_phi == 0:
        return 0.0, N_phi

    # Discrepancy: max over ALL orbit elements of |C(a)/N - 1/|O||
    # Need to enumerate true orbit for "a" values
    target = 1.0 / true_O
    D = 0.0
    # First scan visited elements (those with C_arr[a] > 0):
    for a in range(p):
        if C_arr[a] > 0:
            diff = abs(C_arr[a] / N_phi - target)
            if diff > D:
                D = diff
    # Also: for orbit elements NOT visited (because support too small), their C(a) = 0.
    # The discrepancy at those is |0 - 1/|O|| = 1/|O|.
    # If we found < true_O hit elements, the max is at least 1/|O|.
    n_hit = int((C_arr > 0).sum())
    if n_hit < true_O:
        # Some orbit elements weren't visited
        D = max(D, target)

    return D, N_phi


def regress(xs, ys):
    xs_arr = np.array(xs, dtype=np.float64)
    ys_arr = np.array(ys, dtype=np.float64)
    if len(xs_arr) < 3:
        return 0.0, 0.0, 0.0
    xbar = xs_arr.mean()
    ybar = ys_arr.mean()
    Sxx = ((xs_arr - xbar) ** 2).sum()
    Sxy = ((xs_arr - xbar) * (ys_arr - ybar)).sum()
    Syy = ((ys_arr - ybar) ** 2).sum()
    if Sxx == 0:
        return 0.0, 0.0, 0.0
    b = Sxy / Sxx
    a = ybar - b * xbar
    r2 = (Sxy ** 2) / (Sxx * Syy) if Syy > 0 else 0.0
    return b, a, r2


def main():
    print("R588 — Extended R586, TRUE orbit, Q up to 1e6\n")
    Q_MAX = 1_000_000
    Q_BINS = [100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1_000_000]

    # Sample primes — for compute speed, sample logarithmically (don't use all 78498 primes <= 10^6)
    # Use all primes up to 50000, then sample 1/N for larger.
    primes_all = list(sympy.primerange(5, 50000 + 1))
    # For primes 50000 .. 1e6, sample every 5th prime
    primes_sample = []
    for p in sympy.primerange(50001, Q_MAX + 1):
        primes_sample.append(p)
    primes_sample = primes_sample[::10]  # every 10th
    primes = primes_all + primes_sample
    print(f"Total primes used: {len(primes)} (all primes ≤50000 = {len(primes_all)}, sampled {len(primes_sample)} primes in [50001, 1e6])")

    # For each prime, choose L such that L^2 / (2 log_2 3) >= 2 * true_orbit
    # That way orbit fits in support.
    # Default L=100 if small enough; bump up to L=400 for large primes.

    t0 = time.time()
    C_p = {}
    for i, p in enumerate(primes):
        true_O = true_orbit_size(p)
        # Pick L: aim for L^2 / (2 log_2 3) >= 4 * true_O (orbit fits w/ headroom)
        target_N = 4 * true_O
        L = max(50, int(math.sqrt(target_N * 2 * LOG2_3)) + 5)
        L = min(L, 600)  # cap for compute
        D, N_phi = discrepancy_for_p_L(p, L, true_O)
        C = D * (N_phi ** ETA_FIT) if D > 0 else 0.0
        C_p[p] = {"D": D, "orbit": true_O, "N_phi": N_phi, "L": L, "C": C}
        if (i+1) % 1000 == 0:
            elapsed = time.time() - t0
            print(f"  [{i+1}/{len(primes)}] p={p:>7}: D={D:.4e} O={true_O:>5} L={L:>4} N={N_phi:>10.1f} C={C:.4f}  t={elapsed:.1f}s")

    elapsed = time.time() - t0
    print(f"\nTotal compute: {elapsed:.1f}s for {len(primes)} primes.\n")

    # Compute \\bar{C}(Q) for each Q bin
    print("=== AVERAGED C OVER PRIME RANGE [3, Q] (TRUE orbit) ===\n")
    print(f"{'Q':>10} {'count':>6} {'mean C':>10} {'median C':>10} {'std C':>10}")
    bin_data = []
    for Q in Q_BINS:
        Cs = [C_p[p]["C"] for p in primes if p <= Q and C_p[p]["C"] > 0]
        if not Cs:
            continue
        mean_C = float(np.mean(Cs))
        median_C = float(np.median(Cs))
        std_C = float(np.std(Cs))
        bin_data.append({"Q": Q, "count": len(Cs), "mean": mean_C, "median": median_C, "std": std_C})
        print(f"{Q:>10} {len(Cs):>6} {mean_C:>10.4f} {median_C:>10.4f} {std_C:>10.4f}")

    xs = [math.log(b["Q"]) for b in bin_data]
    ys_mean = [math.log(b["mean"]) if b["mean"] > 0 else 0 for b in bin_data]
    ys_median = [math.log(b["median"]) if b["median"] > 0 else 0 for b in bin_data]
    slope_mean, _, r2_mean = regress(xs, ys_mean)
    slope_median, _, r2_median = regress(xs, ys_median)
    print(f"\nRegression log(mean_C) vs log Q:   slope = {slope_mean:+.4f}, R^2 = {r2_mean:.3f}")
    print(f"Regression log(median_C) vs log Q: slope = {slope_median:+.4f}, R^2 = {r2_median:.3f}")

    # Sub-range regression to check robustness
    print("\nSub-range regressions:")
    for q_min in [50, 500, 5000, 50000]:
        sub = [b for b in bin_data if b["Q"] >= q_min]
        if len(sub) < 3:
            continue
        xs_sub = [math.log(b["Q"]) for b in sub]
        ys_sub = [math.log(b["mean"]) for b in sub]
        s, _, r2 = regress(xs_sub, ys_sub)
        print(f"  Q in [{q_min}, {Q_MAX}]: slope = {s:+.4f}, R^2 = {r2:.3f}, n_bins = {len(sub)}")

    out = ROOT / "r588_results.json"
    out.write_text(json.dumps({
        "Q_MAX": Q_MAX,
        "Q_BINS": Q_BINS,
        "n_primes": len(primes),
        "bin_data": bin_data,
        "regression": {"slope_mean": slope_mean, "r2_mean": r2_mean,
                       "slope_median": slope_median, "r2_median": r2_median},
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
