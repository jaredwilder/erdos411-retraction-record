# EG203 Oracle Paper Draft Packet

**Date:** 2026-05-12  
**Author:** Jared Wilder  
**Purpose:** Draft all paper-shaped mathematical assets extracted from the Erdős–Graham #203 Oracle harvest.

## Honest status

This packet does **not** claim an unconditional solution of Erdős–Graham Problem #203.

It contains:

1. A fully elementary first paper draft.
2. A CRT/projective-slope algebra paper draft.
3. A density-zero Kummer obstruction theorem skeleton.
4. A conditional Kummer distribution criterion for #203.
5. A failed-routes / PHNC audit note.

The full #203 route remains blocked at the high-\(\ell\) PHNC seam.

## Files

### 01_SUBGROUP_OBSTRUCTION_CALCULUS.tex
First-ship MVP. Elementary finite abelian obstruction calculus, exact local density, character expansion, moment laws, CRT orthogonality, weighted variance.

### 02_CRT_SYNCHRONIZATION_PROJECTIVE_SLOPES.tex
Algebra paper on squarefree CRT synchronization, synchronization defect, pair determinant criterion, projective Kummer slopes, ratio fields, and star atom.

### 03_DENSITY_ZERO_KUMMER_OBSTRUCTION.tex
Safe #203-adjacent density-zero theorem skeleton. Needs final sieve normalization and exact Pappalardi citation before submission.

### 04_KUMMER_DISTRIBUTION_CRITERION_EG203.tex
Conditional criterion paper. Defines PHNC/Kummer-BV and the implication architecture to #203. Explicitly marks the high-\(\ell\) seam as open.

### 05_FAILED_ROUTES_PHNC_AUDIT.tex
Defensive/expository note explaining why BFI, Plünnecke-Ruzsa, fixed-field ineffective Chebotarev, multiplicative-order bounds, and generic Chebotarev-BT do not close PHNC as needed.

## Recommended submission order

1. `01_SUBGROUP_OBSTRUCTION_CALCULUS.tex`
2. `02_CRT_SYNCHRONIZATION_PROJECTIVE_SLOPES.tex`
3. `03_DENSITY_ZERO_KUMMER_OBSTRUCTION.tex`
4. `04_KUMMER_DISTRIBUTION_CRITERION_EG203.tex`
5. `05_FAILED_ROUTES_PHNC_AUDIT.tex`

## Immediate next work

- Add explicit computed examples to Paper 2.
- Replace Hypothesis/Pappalardi placeholder in Paper 3 with exact theorem and constants.
- Formalize the PHNC-to-KRWS bridge before upgrading Paper 4.
- Keep Paper 5 as an audit appendix or standalone expository note.

## Claim separation

- Papers 1 and 2: provable now.
- Paper 3: provable after formal sieve/Pappalardi writeup.
- Paper 4: conditional.
- Paper 5: audit/open-problem note.

## No-overclaim rule

Do not write “#203 solved” anywhere in submission-facing material unless the high-\(\ell\) PHNC theorem is actually proved.
