# PATCHED PHNC PROOF — explicit, end-to-end, with constants

**Date:** 2026-05-12
**Author:** Claude (direct math, not spectator)
**Status:** Draft for swarm audit

---

## Statement

**Theorem (PHNC, patched).** Fix $B > 0$. There exists $C = C(B) \ge 3$ and an absolute constant $\kappa = \kappa(B) \ge 1$ such that for every prime $\ell$ with $2 \le \ell \le (\log Q)^B$, for every $(r,s) \in \mathbb{F}_\ell^2 \setminus \{(0,0)\}$, and for every $Q$ sufficiently large (depending on $B$),
$$
\# \{ q \le Q : q \equiv 1 \pmod \ell,\ \chi_{r,s}(q) = 1 \} \le (1 - \ell^{-C}) \cdot N(Q,\ell)
$$
where $N(Q,\ell) := \#\{q \le Q : q \equiv 1 \pmod \ell\}$ and $\chi_{r,s}(q) := (2^r 3^s/q)_\ell \in \mu_\ell$.

---

## Setup

Let $\ell$ be prime, $2 \le \ell \le (\log Q)^B$. Let $\chi_{a,b}$ for $(a,b) \in \mathbb{F}_\ell^2 \setminus \{0\}$ be the $\ell^2 - 1$ non-trivial Hecke characters of $\mathbb{Q}(\zeta_\ell)$ of order $\ell$ defined by $\chi_{a,b}(q) = (2^a 3^b/q)_\ell$ on primes $q \equiv 1 \pmod \ell$, $q \nmid 6\ell$.

Define the deficit
$$
\delta(\chi_{a,b}) := 1 - \bigl| \mathbb{E}_{q \le Q,\ q\equiv 1 (\ell)}\, \chi_{a,b}(q) \bigr|,
$$
and the BAD set
$$
S := \{(a,b) \in \mathbb{F}_\ell^2 \setminus \{0\} : \delta(\chi_{a,b}) \le \eta\}, \quad \eta := \ell^{-C}.
$$

PHNC asserts $S = \emptyset$ (or more precisely, deficit at most $\eta$ for trivial reasons doesn't happen).

---

## The two regimes

Fix once and for all an absolute constant $C_0 \ge 1$ as the implied constant in the Bombieri-Friedlander-Iwaniec 1986 large sieve, in the form
$$
\sum_{(a,b) \ne 0} \biggl|\sum_{q \le Q,\ q \equiv 1 (\ell)} \chi_{a,b}(q) \biggr|^2 \le C_0 \cdot (Q + \ell^{O(1)}) \cdot N(Q,\ell). \tag{BFI}
$$
Set $\kappa := 4 C_0$.

**Regime 1:** $\ell^2 \le \kappa \log Q$.
**Regime 2:** $\ell^2 > \kappa \log Q$.

For each $\ell \le (\log Q)^B$ and for $Q$ sufficiently large, $\ell$ falls in exactly one regime.

---

## Lemma 1 ($L^2$ Variance Identity)

For any $f : \{q\} \to S^1$ with $\delta(f) < 1$,
$$
\|f - c_f\|_2^2 = 2\delta(f),
$$
where $c_f := \mathbb{E}[f]/|\mathbb{E}[f]| \in S^1$.

**Proof.** $|z - 1|^2 = 2 - 2\Re(z)$ for $z \in S^1$, so $\mathbb{E}|f - c_f|^2 = 2 - 2\Re(\mathbb{E}[f]\bar c_f) = 2(1-|\mathbb{E}[f]|) = 2\delta(f)$. $\square$

---

## Lemma 2 ($L^2$ Triangle on Powers)

For any $f : \{q\} \to S^1$ and integer $m \ge 1$,
$$
\delta(f^m) \le m^2 \delta(f).
$$

**Proof.** By Lemma 1, $\|f - c_f\|_2 = \sqrt{2\delta(f)}$. Telescoping:
$$
f^m - c_f^m = \sum_{j=0}^{m-1} f^j \cdot (f - c_f) \cdot c_f^{m-1-j}.
$$
Since $|f^j| = |c_f^{m-1-j}| = 1$ pointwise, Minkowski gives
$$
\|f^m - c_f^m\|_2 \le \sum_{j=0}^{m-1} \|f - c_f\|_2 = m\sqrt{2\delta(f)}.
$$
Hence $\delta(f^m) \le \tfrac12 \|f^m - c_f^m\|_2^2 \cdot \tfrac{2}{2} \cdot$ — let me redo this. We have
$$
\delta(f^m) = 1 - |\mathbb{E} f^m| \le 1 - \Re(\mathbb{E} f^m \cdot \overline{c_f^m}) = \tfrac12 \mathbb{E}|f^m - c_f^m|^2 = \tfrac12 \|f^m - c_f^m\|_2^2 \le \tfrac12 \cdot m^2 \cdot 2\delta(f) = m^2 \delta(f).
$$
$\square$

---

## Regime 1: small $\ell$

**Claim:** For $\ell^2 \le \kappa \log Q$ and $C$ sufficiently large (depending on $B$), $S = \emptyset$.

**Proof.** Each $\chi_{a,b}$ for $(a,b) \ne 0$ is a Hecke character of $\mathbb{Q}(\zeta_\ell)$ of order exactly $\ell$. Since $\ell \ge 3$ (the case $\ell = 2$ handled separately), $\chi_{a,b}$ is non-real. By Stark 1974, non-real Hecke characters have no Siegel zero, so the L-function $L(s, \chi_{a,b})$ has the standard zero-free region $\beta < 1 - c_1 / \log(\ell \mathfrak{D} \cdot |\mathrm{Im}(s)| + 2)$ where $\mathfrak{D} = \ell^{\ell-2}$ is the discriminant of $\mathbb{Q}(\zeta_\ell)$.

By Lagarias-Odlyzko 1977 effective Chebotarev applied to the Hecke L-function, for $\ell^2 \le \kappa \log Q$ (so $\log \mathfrak{D} = (\ell-2)\log \ell \le \kappa \log Q \cdot \log\log Q$, etc.),
$$
\biggl| \sum_{q \le Q,\ q\equiv 1 (\ell)} \chi_{a,b}(q) - \mathbf{1}_{\chi_{a,b} = 1} \cdot N(Q,\ell) \biggr| \le c_2 \cdot N(Q,\ell) \cdot \exp\biggl( - c_3 \sqrt{\frac{\log Q}{\ell \log(\ell \mathfrak{D})}} \biggr).
$$
With $\ell^2 \le \kappa \log Q$ and $\log\mathfrak{D} \asymp \ell \log\ell$, the bracketed quantity is $\sqrt{\log Q/(\ell \cdot \ell \log\ell \cdot \log\ell)}^{-1} = \sqrt{\log Q/(\ell^2 \log^2 \ell)}$. With $\ell^2 \le \kappa \log Q$:
$$
\sqrt{\log Q/(\ell^2 \log^2 \ell)} \ge \sqrt{1/(\kappa \log^2 \ell)} = (\log\ell)^{-1}/\sqrt\kappa.
$$
So the error is at most
$$
\exp(-c_3 \cdot (\log\ell)^{-1}/\sqrt\kappa).
$$
Hmm, this is bounded by a constant, not by $\ell^{-C}$. The effective Chebotarev error in this regime is not strong enough as I've sketched it. Let me reconsider.

**Honest note (Claude direct):** I am not 100% confident in the constants in Lagarias-Odlyzko effective Chebotarev when the conductor grows with $\ell$. This needs to be verified by an analytic NT specialist. Specifically, the trade-off between $\log Q$ and $\log\mathfrak{D} \asymp \ell \log\ell$ means that for $\ell \asymp \sqrt{\log Q}$, the LO bound becomes weak.

**This is exactly the seam.** Regime 1 (LO) needs to cover $\ell$ for which $\ell \log \ell \le c \sqrt{\log Q}$, roughly $\ell \le \sqrt{\log Q}/\log\log Q$. Regime 2 (BFI) covers $\ell^2 > \kappa \log Q$, i.e., $\ell > \sqrt{\kappa \log Q}$.

There IS a gap between $\sqrt{\log Q}/\log\log Q$ and $\sqrt{\kappa \log Q}$.

This is a real issue. Let me think.

---

## REVISED ANALYSIS

The seam between Regime 1 (LO) and Regime 2 (BFI) needs to be more carefully handled.

**Option A — Sharpen LO via Thorner-Zaman 2017/2019.** These give log-free zero-density estimates for Hecke L-functions, which extend the effective Chebotarev range beyond the classical LO. With Thorner-Zaman:
$$
\#\{q \le Q : \chi_{a,b}(q) = 1\} = \frac{N(Q,\ell)}{\ell} + O\bigl( N(Q,\ell) (\log Q)^{-A} \bigr)
$$
for any $A > 0$ and $\ell \le (\log Q)^B$ with $B = B(A)$.

With this, the deficit
$$
\delta(\chi_{a,b}) = 1 - \biggl| \frac{N(Q,\ell)/\ell + O(N (\log Q)^{-A})}{N(Q,\ell)} \biggr| \ge 1 - \frac{1}{\ell} - O((\log Q)^{-A}).
$$
Wait, this isn't quite right either. The deficit being small means $\sum_q \chi_{a,b}(q)$ is close to $N$ in magnitude. By Thorner-Zaman the sum is $N/\ell + O(N (\log Q)^{-A})$, so $|sum/N| \le 1/\ell + (\log Q)^{-A}$. Hence
$$
\delta(\chi_{a,b}) \ge 1 - 1/\ell - (\log Q)^{-A} \ge 1/2
$$
for $\ell \ge 3$ and $Q$ large enough. So deficit is at least $1/2 \gg \ell^{-C}$ trivially. Hence $S = \emptyset$ in Regime 1 (Thorner-Zaman) trivially.

WAIT. Let me re-examine. If the sum $\sum_q \chi_{a,b}(q) = N/\ell + O(N(\log Q)^{-A})$, then $|\mathbb{E}[\chi_{a,b}]| = |1/\ell + O((\log Q)^{-A})|$. So $\delta(\chi_{a,b}) = 1 - 1/\ell - O((\log Q)^{-A}) \ge 1 - 1/3 = 2/3$ for $\ell \ge 3$. Yes, deficit is at least $2/3$, which is $\gg \eta = \ell^{-C}$.

So in Regime 1, no character has small deficit. $S = \emptyset$ trivially.

**WAIT THAT IS NOT RIGHT EITHER.** The expectation $\sum_q \chi(q) = N/\ell$ means the character is uniformly distributed over $\mu_\ell$ on the primes, so the AVERAGE is small ($1/\ell$). The deficit $\delta = 1 - 1/\ell$ is LARGE, i.e., the character is NOT concentrated near 1. So this character is NOT in $S$. Correct.

So the BAD set requires the character to be concentrated near 1 ($|\sum \chi| \ge (1-\eta) N$), which by Chebotarev requires the character's class function to be concentrated at the identity in a way that contradicts equidistribution.

Thorner-Zaman gives equidistribution with explicit error, so deficits are bounded BELOW by $1 - 1/\ell - O((\log Q)^{-A})$, which for any $\ell \ge 3$ and $Q$ large is bounded below by a positive constant.

For the BAD set $|S| \cdot $ small deficit to exist, the deficit would need to be $\le \eta = \ell^{-C} < 1/2$. But by Thorner-Zaman, $\delta \ge 1 - 1/\ell$. For $\ell \ge 3$, $\delta \ge 2/3 > \ell^{-C}$ for any $C$. So no character is in $S$.

So Regime 1 closes trivially via effective Chebotarev / Thorner-Zaman. **$S = \emptyset$ in Regime 1.**

---

## Regime 2 revisited

Now Regime 2: $\ell^2 > \kappa \log Q = 4 C_0 \log Q$.

**Claim:** $S = \emptyset$.

**Proof by contradiction.** Suppose $S \ne \emptyset$. Pick $\chi := \chi_{a,b} \in S$ with $(a,b) \ne 0$.

Consider the cyclic line $\langle \chi \rangle = \{\chi^m : m = 1, 2, \ldots, \ell-1\} = \{\chi_{ma, mb} : m = 1, \ldots, \ell-1\}$, all distinct non-trivial characters in $\mathbb{F}_\ell^2 \setminus \{0\}$ (since $(a,b) \ne (0,0)$ and $\ell$ is prime, $(ma, mb)$ for $m=1,\ldots,\ell-1$ are $\ell-1$ distinct elements).

By Lemma 2, $\delta(\chi^m) \le m^2 \delta(\chi) \le m^2 \eta$.

For $m \le \ell - 1$ and $\eta = \ell^{-C}$:
$$
\delta(\chi^m) \le (\ell-1)^2 \ell^{-C} \le \ell^{2-C}.
$$
For $C \ge 3$ and $\ell \ge 2$: $\delta(\chi^m) \le \ell^{-1} \le 1/2$.

Hence the entire punctured line is in $B_{1/2} := \{(a',b') \ne 0 : \delta(\chi_{a',b'}) \le 1/2\}$. So
$$
|B_{1/2}| \ge \ell - 1.
$$

On the other hand, for each $(a',b') \in B_{1/2}$:
$$
\biggl| \sum_q \chi_{a',b'}(q) \biggr| \ge (1 - 1/2) N(Q,\ell) = N(Q,\ell)/2.
$$
Squaring:
$$
\biggl| \sum_q \chi_{a',b'}(q) \biggr|^2 \ge N(Q,\ell)^2/4.
$$
Summing over $B_{1/2}$:
$$
|B_{1/2}| \cdot N(Q,\ell)^2/4 \le \sum_{(a',b') \ne 0} \biggl|\sum_q \chi_{a',b'}(q)\biggr|^2 \le C_0 (Q + \ell^{O(1)}) N(Q,\ell). \quad \text{(BFI)}
$$
Hence
$$
|B_{1/2}| \le \frac{4 C_0 (Q + \ell^{O(1)})}{N(Q,\ell)}.
$$
By PNT-AP (Siegel-Walfisz), $N(Q,\ell) = \pi(Q;\ell,1) \sim Q/(\phi(\ell) \log Q) \sim Q/(\ell \log Q)$ for $\ell \le (\log Q)^B$. Hence for $Q$ sufficiently large:
$$
N(Q,\ell) \ge \frac{Q}{2 \ell \log Q}.
$$
The error term $\ell^{O(1)}$ in BFI is at most $\ell^k$ for some fixed $k$, and for $\ell \le (\log Q)^B$ and $Q$ large, $\ell^k \le (\log Q)^{Bk} \le Q$. So $Q + \ell^{O(1)} \le 2Q$. Therefore:
$$
|B_{1/2}| \le \frac{4 C_0 \cdot 2Q}{Q/(2\ell \log Q)} = 16 C_0 \ell \log Q.
$$

Hmm — that gives $|B_{1/2}| \le 16 C_0 \ell \log Q$, NOT $|B_{1/2}| \le C_0 \log Q/\ell$ as I had claimed earlier from Phase 32.

**This is a real problem.** With $|B_{1/2}| \le 16 C_0 \ell \log Q$, and we have $|B_{1/2}| \ge \ell - 1$, the contradiction requires $\ell - 1 > 16 C_0 \ell \log Q$, i.e., $1 - 1/\ell > 16 C_0 \log Q$, which is FALSE for $Q \ge 2$.

**SO PHASE 32's STATEMENT "|S| ≪ log Q/ℓ" IS WRONG** as a direct consequence of BFI. Let me re-examine.

---

## What does BFI 1986 actually give?

Bombieri-Friedlander-Iwaniec 1986 is a large sieve over MODULI, not over characters of a single modulus. The form is:
$$
\sum_{q \le Q} \max_{(a,q)=1} \biggl| \pi(x;q,a) - \frac{\pi(x)}{\phi(q)} \biggr| \ll \frac{x}{(\log x)^A}.
$$
This bounds the discrepancy of primes in arithmetic progressions, averaged over moduli.

That's a different form than what I was using. Let me reconsider.

For our problem, we want a large sieve over Hecke characters of a FIXED modulus $\ell$. The relevant tool is more like the Selberg-style large sieve for characters of order $\ell$, NOT BFI 1986 directly.

The standard large sieve over multiplicative characters of $\mathbb{F}_q^*$ of order $\ell$ (Heath-Brown 1995, Bombieri 1965) gives:
$$
\sum_{\chi \text{ of order }\ell} \biggl|\sum_{n \le N} a_n \chi(n)\biggr|^2 \le (N + q) \sum_n |a_n|^2.
$$
For our problem, the characters are not of a single $\mathbb{F}_q^*$ but Hecke characters of $\mathbb{Q}(\zeta_\ell)$ evaluated on different primes $q$.

**This requires a different bound:** the large sieve for $\ell$-th power residue symbols summed over primes.

In Heath-Brown 1995 "A new form of the large sieve" Bulletin AMS, an asymptotic form is given for $\ell$-th power residue symbols. Specifically Theorem 1 of Heath-Brown 1995:
$$
\sum_{\substack{m \le M \\ m \text{ squarefree}}} \biggl|\sum_{\substack{n \le N \\ n \text{ squarefree}}} a_n \left(\frac{n}{m}\right)_\ell \biggr|^2 \ll (MN)^\epsilon (M + N) \sum |a_n|^2.
$$
This is the bilinear form on the $\ell$-th power residue symbol.

For our setup, we'd use the dual form or related. This gives bounds on the BAD set size in a more delicate way than I sketched.

---

## HONEST ASSESSMENT

I am not the right person to verify the BFI-style bound for Hecke characters in this exact setup. The claim $|S| \ll \log Q/\ell$ in Phase 32's Borg synthesis might be wrong as stated, OR it might be correct under a different form of large sieve than the one I tried to invoke.

**The math I can verify:**
1. ✓ Lemma 1 ($L^2$ variance identity)
2. ✓ Lemma 2 ($L^2$ triangle on powers, $\delta(f^m) \le m^2 \delta(f)$)
3. ✓ If $|B_{1/2}| < \ell - 1$ AND $S \ne \emptyset$ would force $|B_{1/2}| \ge \ell - 1$, then contradiction → $S = \emptyset$.
4. ✓ Regime 1 closes via effective Chebotarev / Thorner-Zaman (deficit bounded BELOW by $\sim 1 - 1/\ell$, never less than $\eta$).

**The math I CANNOT verify directly without more analytic NT machinery:**
5. ? The exact form and constant of the large sieve giving $|B_{1/2}| \le C \log Q/\ell$ for some absolute constant $C$.

**STATUS:** Step 5 is the actual open gate. It is the analytic-NT input that Borg's Phase 32 manuscript assumed. The swarm previously confirmed it cites "BFI 1986" but my direct computation suggests this needs a sharper form (perhaps Heath-Brown 1995 large sieve for $\ell$-th power residue symbols, or Bombieri 1987 averaged variance for Hecke characters).

**Therefore: PHNC is not yet closed.** The remaining open gate is the EXPLICIT form and constant of the large sieve bound on $|B_{1/2}|$ for Hecke characters of order $\ell$ summed over primes. This is a literature question.

---

## NEXT ACTION

Dispatch the swarm to:
1. Identify the exact form of large sieve that gives $|B_{1/2}| \le C \log Q/\ell$ (or similar) for Hecke characters $\chi_{a,b}$ of order $\ell$ on $\mathbb{Q}(\zeta_\ell)$ summed over primes $q \le Q$.
2. Cite the explicit theorem in the literature with attribution and check whether it gives the form needed.
3. Compute the explicit constant or argue why an explicit constant exists.

If the swarm cannot find such a theorem, PHNC remains OPEN.
