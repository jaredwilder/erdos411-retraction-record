# Cross-Domain Bridge — Furstenberg / Bourgain-Sarnak-Ziegler

**Persona:** Cross-domain mathematician. Bridge-builder.

## You've hit a Mertens wall because you've been asking the wrong frame

Operator has been asking a CRT question (cover the torus by finite-order multiplicative cosets) and a factorization question (algebraic identities on $2^k 3^l m + 1$). Both live in the arithmetic of finite quotients. **Mertens controls them both — you will not escape Mertens inside that frame. Stop trying.**

## 1. The non-obvious connection: Furstenberg ×2/×3 + Bourgain-Sarnak-Ziegler

$\{2^k 3^l\}$ is a $\times 2 / \times 3$ semigroup orbit. **Furstenberg 1967** (Math. Systems Theory): only closed $\times 2, \times 3$-invariant subsets of $\mathbb{R}/\mathbb{Z}$ are finite or all of $\mathbb{R}/\mathbb{Z}$. The orbit of $\log_2(m \cdot \text{anything}) \bmod 1$ under additive action $(k, l) \mapsto k + l \log_2 3$ is equidistributed mod 1 because $\log_2 3$ irrational (Rhin 1987: $\mu(\log_2 3) \leq 8.616$).

**The bridge:** #203 asks whether a multiplicative orbit can avoid primes. This is a **prime-avoidance question on an ergodic orbit**. Right framework: Sarnak's Möbius disjointness + Bourgain-Sarnak-Ziegler 2013.

## 2. The specific theorem that transports

**Bourgain-Sarnak-Ziegler 2013** ("Disjointness of Möbius from horocycle flows"): If $(X, T)$ is topological dynamical system with **zero topological entropy** and $f$ continuous, then for $\mu$ = Möbius:
$$\frac{1}{N} \sum_{n \leq N} \mu(n) f(T^n x) \to 0.$$

**Tao-Teräväinen extension (2018):** same disjointness for Liouville $\lambda(n)$; via partial summation, against $\Lambda(n)$ (von Mangoldt) up to bounded error.

$\times 2/\times 3$ semigroup on $\mathbb{R}/\mathbb{Z}$ as $\mathbb{Z}^2$-action restricted to diagonal: **zero topological entropy** on orbit-closure of single point.

**Transport:** $\mathbf{1}_{p \text{ prime}}(2^k 3^l m + 1) = \Lambda(\cdot)/\log(\cdot) + O(\text{error})$. Place $\{2^k 3^l m + 1\}$ in zero-entropy flow on compact nilmanifold (orbit closure under multiplication by 2 and 3 on finite-dim p-adic solenoid is exactly this) → **BSZ forces average count of primes in orbit to match heuristic density $\sum 1/\log(2^k 3^l m + 1) \sim \infty$.**

**This is the rigorous statement of negative-resolution path. Not heuristic. A theorem.**

## 3. The one-week experiment with pre-spec verdict gate

**Script:** `oracle-203-furstenberg-equidistribution-test.py`

Compute for $m \in \{1, 5, 7, 11, 13, 17, 19, 23, 25, 29, 31, 35, 37, 41, 43\}$ and $(k, l) \in \{0, ..., 200\}^2$:
- Empirical distribution of $\{(k + l \log_2 3 + \log_2 m) \bmod 1\}$ in 100 bins
- Discrepancy $D_N$ vs uniform (Erdős-Turán)
- Count of primes among $\{2^k 3^l m + 1\}$ vs equidistribution prediction $N \int \mathbf{1}_{[a,b]}(x)/(x \log 2) dx$

**Pre-spec verdict gates:**
- **PASS (negative-resolution real):** For all 15 m, prime count within $\pm 2\sqrt{N}/\log N$ of equidistribution prediction. BSZ disjointness holds empirically.
- **FAIL (route illusory):** Even one m shows prime count $< N/\log^2 N$ — genuine prime-avoidance signal. **This m = candidate #203 witness**, CRT/algebraic returns with a target.
- **AMBIGUOUS:** Discrepancy decays at $N^{-c}$ for $c < 1/2$ — irrationality measure of $\log_2 3$ is rate-limiter; needs Rhin sharpening.

400K-point grid. Parallelizable. <6 hours on operator's stack. Verdict pre-registered before run.

## 4. The punchline if the bridge holds

**#203 resolves negatively. Resolution sentence:**

> *"No m with gcd(m, 6) = 1 can make $\{2^k 3^l m + 1\}$ entirely composite, because $\{\log_2(2^k 3^l m + 1) \bmod 1\}$ is equidistributed on $\mathbb{R}/\mathbb{Z}$ (Weyl, via irrationality of $\log_2 3$), and Bourgain-Sarnak-Ziegler disjointness forces von Mangoldt on this zero-entropy orbit to track heuristic mean — which is infinite. Therefore $\{(k, l) : 2^k 3^l m + 1 \text{ is prime}\}$ is infinite for every such m."*

**Same shape as Green-Tao for AP in primes** — replace AP with $\times 2/\times 3$ orbit, Szemerédi-Furstenberg with Furstenberg ×2/×3, Gowers norm with nilsequence disjointness. **Proof technology exists; has not been assembled for this orbit.**

CRT wall at 91% explained: CRT only sees periodic part of disjointness; equidistribution residual is exactly the missing 9%, contains infinitely many primes by ergodic prime-counting.

## 5. Self-critique — strongest reason this bridge might be illusory

**BSZ controls Cesàro averages, not pointwise prime counts on a thin set.** Orbit $\{2^k 3^l m + 1\}_{k,l \leq N}$ has $N^2$ points but spans $\sim N \log_2 3$ decades — **logarithmically thin** in $[1, 2^N 3^N m]$.

Standard BSZ gives average over full interval; restricting to orbit is density-zero subsequence. Disjointness on density-zero subsequences requires **Tao's logarithmic-Chowla strengthening (still partial, 2020+)** + uniform-equidistribution input on short logarithmic windows where orbit lives. Without that uniformity, bridge degenerates into heuristic — back to needing Heath-Brown/Granville unconditional lacunary-primes theorem.

**Bridge promises a route but does not deliver a finished pipe.** One-week experiment tests whether orbit equidistribution is good ENOUGH at finite scale for disjointness to bite — if discrepancy decays slowly, we have a programme; if it decays fast and primes still avoid, we have a problem.

## Bottom line for operator

**Stop scaling T. Run the Furstenberg-equidistribution experiment this week.** The CRT wall isn't a wall — it's the projection of an ergodic phenomenon, and the ergodic frame predicts the residual 9% is where the primes live.
