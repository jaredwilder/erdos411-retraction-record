# FINAL STATUS MAP

| Asset | Status | Action |
|---|---|---|
| Paper 1: Subgroup obstruction calculus | provable now | polish and submit |
| Paper 2: CRT/projective slopes | provable now | add diagrams, then submit |
| Paper 3: density-zero schema | dependency-gated | insert Pappalardi + sieve details |
| Paper 4: conditional criterion | conditional/open | formalize arrows |
| Paper 5: failed-routes audit | expository/audit | use as appendix or note |
| high-seam PHNC | open | expert outreach |
| full #203 | not solved | quarantine |
| finite examples | verified | keep script/report |
| Oracle methodology story | honest case study | use if needed |

## The exact open gate

\[
\#\{q\le Q:q\equiv1\bmod\ell,\ \chi_{r,s}(q)=1\}
\le
(1-\ell^{-C(B)})\pi(Q;\ell,1)
\]

uniformly for all

\[
\ell\le(\log Q)^B,\qquad (r,s)\ne0.
\]

This is the high-seam PHNC problem.
