
# Referee Checklist — Paper 1

A referee should be able to verify every substantive claim through elementary finite algebra.

## Main proof checks

1. Finite abelian subgroup obstruction lemma.
2. Character-annihilator expansion.
3. Scaled Bernoulli law.
4. All raw moment formula.
5. Total variation, chi-square, and KL divergence formulas.
6. Multiplication fiber theorem.
7. Exact local density formula.
8. Unit-inversion bijection over \(G_d\).
9. Exact centered moment law over \(m\).
10. CRT orthogonality.
11. Weighted prime-level variance.
12. Specialization to \(a=2,b=3\).
13. \(q=5\) and \(q=23\) examples.

## Claims not made

1. No unconditional solution of Erdős–Graham Problem #203.
2. No high-\(\ell\) PHNC theorem.
3. No prime-infinitude theorem.
4. No density-zero conclusion in this paper.

## Submission-readiness notes

Before journal submission:
- check TeX compile;
- decide journal target;
- add any preferred standard references;
- optionally add one more worked example.
