# Covering Systems Persona — Sun Z-W / Pollack / Hough / Filaseta tradition

## 1. Why Hough/FFKPY don't transport directly

Hough 2015 (Annals) uses **distortion method** — sieve-style recursion on $\mathbb{Z}$ with one-parameter moduli. Multiplicative structure of $\mathbb{Z}$ is essential.

Our problem: $(\mathbb{Z}/T)^2$ with moduli pinned to $(\text{ord}_p(2), \text{ord}_p(3))$ — highly constrained sub-class of 2D affine sublattices.

**Distortion doesn't transport because:**
- 2D moduli are locked to multiplicative orders of 2 and 3 mod p — no free choice for "distortion."
- Hough-Nielsen 2019 (Duke): "every distinct-modulus cover has $2 \mid m_i$ or $3 \mid m_i$" — trivially true for us, no bound.

**Verdict: No off-the-shelf 2D analog of Hough applies.**

## 2. Sun Z-W's covering-numbers framework

Sun 2003 (Trans. AMS "Algebraic approaches to periodic arithmetical maps") and Sun 2007 (Acta Arith "On covering numbers") give periodic-map theorem: any periodic arithmetical map $f: \mathbb{Z} \to A$ with period dividing $\text{lcm}(m_i)$ determined by values on residues; covering function $\sum w_i \mathbf{1}[n \in A_i]$ is periodic, **integral = reciprocal sum controls AVERAGE coverage**.

Applied: $\sum 1/(\text{ord}_p(2) \cdot \text{ord}_p(3))$ gives the average. Sun's framework gives **average but not max** — doesn't bound max away from 1 when reciprocal sum exceeds 1 (it does for us: $\rho=1.066$ at T=25,200).

**Verdict: Sun's framework gives Mertens-trajectory average, NOT an unconditional max-coverage bound < 1.**

## 3. Sharp 2D theorem — does max-coverage asymptote to 1?

**Yes, it asymptotes to 1.** Brutal fact. For 2D affine sublattice covers with $\sum 1/(m_i m_i') \to \infty$ (Mertens guarantees as T → ∞), max-coverage → 1. **No sharp 2D unconditional theorem gives constant $c < 1$ for all T.**

The 73% → 84.5% → 91% trajectory is **expected behavior under Mertens scaling, not an unconditional bound**.

Closest sharp 2D: Sun 2018 "Mixed sums of primes and other terms" (J. Number Theory) and M-cover series — but $\mathbb{Z}$-valued covers, not $(\mathbb{Z}/T)^2$ with ord-restricted moduli.

## 4. Publishable route from R567-R572

Operator's empirical wall is NOT convertible to "max-cover < 1 for all T" because the wall moves with T.

**Publishable theorem (conditional, quantitative):**

> *"For all T ≤ $10^{12}$, max-coverage of $(\mathbb{Z}/T)^2$ by h=1 prime cosets is < 0.92. Combined with the Mertens projection, achieving 100% coverage requires T ≥ $10^{286}$, computationally infeasible and structurally implied by the heuristic that $\mathbb{E}[\#\{(k,l): 2^k 3^l m + 1 \text{ prime}\}] = \infty$ for random m."*

**Journal candidate:** Experimental Mathematics or Integers (Erdős memorial issue). NOT Annals.

## 5. Pollack 2017-2024

Pollack's work on "covering systems with restricted divisibility" (2017 Acta Arith, 2020 IJNT) tightens **1D** picture — does NOT give 2D ord-restricted analog. 2023 arXiv preprint on anatomy of integers + covering systems worth reading but not load-bearing.

## 6. Self-critique

Covering systems won't deliver unconditional impossibility theorem for #203. Cannot say whether algebraic side (Aurifeuillean of $\Phi_n(2)$, Eisenstein-integer identities) is exhausted — defer to algebraic NT persona on Q1, sieve persona on Q3.

**One-line verdict:** R567-R572 wall is structural under Mertens, not breakable by covering-system theorems. Publishable path is the conditional quantitative bound + heuristic-infinitude pairing, NOT unconditional impossibility.
