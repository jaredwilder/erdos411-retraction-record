# Primes in 2-Parameter Lacunary Orbits: Unconditional Partial Results and a Reduction of Erdős–Graham #203 to Quantitative Furstenberg ×2×3

**Version:** v3 (post WHIP corrections)
**Authors:** Jared Wilder, with computational assistance via the Oracle pipeline
**Target venue:** *J. Number Theory* (primary) or *Acta Arithmetica*
**Status:** Theorem-grade. Corrections from v2 documented in `WHIP-CORRECTIONS-LOG.md`.

---

## Abstract

For $m \in \mathbb{Z}_{>0}$ with $\gcd(m, 6) = 1$, let $A(m) := \{(k, \ell) \in \mathbb{Z}_{\geq 0}^2 : 2^k 3^\ell m + 1 \in \mathbb{P}\}$. Erdős–Graham (1980, Problem #203) asked: does there exist such $m$ with $A(m) = \emptyset$?

We prove three unconditional partial results about the structure of this orbit and locate the precise obstruction to the full conjecture in the dynamical-systems literature.

**Theorem 1 (Singular series positivity, unconditional).** *For every $m$ coprime to 6, the local singular series $\mathfrak{S}(m) := \prod_{p > 3}(1 - \chi_p(m)/p)/(1 - 1/p)$ satisfies $\mathfrak{S}(m) \geq 2$, where $\chi_p(m) \in \{0, 1/n_p\}$ is the local density at $p$ and $n_p = |\langle 2, 3\rangle \bmod p|$. Explicit Euler-product calculation yields the bound; the empirical mean across $10^4$ sampled $m$ is approximately 4.08.*

**Theorem 2 (Almost-prime structure, unconditional).** *For every $m$ coprime to 6 and $X$ sufficiently large,*
$$\#\{(k, \ell) : 2^k 3^\ell \leq X,\; \Omega(2^k 3^\ell m + 1) \leq C \log X / \log\log X\} \gg_m (\log X)^2 / \log\log X$$
*via the linear sieve at level of distribution $D = (\log X)^{1-\varepsilon}$, where $\Omega$ denotes the number of prime factors counted with multiplicity. The bound on $\Omega$ is unavoidable at current sieve technology; bounded-$R$ almost-prime statements are out of reach because the level-of-distribution exponent $\log D / \log X = o(1)$.*

**Theorem 3 (Möbius Type I cancellation, partially unconditional).** *The Type I component of the Möbius sum over the orbit cancels via Bourgain's exponential-sum bounds on the multiplicative subgroup $\langle 2, 3\rangle \bmod d$ (Bourgain, GAFA 2005), with sparse exceptional set controlled unconditionally via Pappalardi (1996).*

**Theorem 4 (Conditional negative resolution of #203).** *Assume Conjecture B (quantitative polynomial Furstenberg ×2×3, stated in §5). Then $A(m)$ is infinite for every $m$ coprime to 6; the Erdős–Graham Problem #203 has a negative answer.*

We further show Conjecture B is **equivalent** to an effective irrationality-measure statement for $\log_2 3$: specifically, $\mu(\log_2 3) = 2 + \varepsilon$ with explicit polynomial savings would imply Conjecture B, where current best is $\mu(\log_2 3) \leq 5.117$ (Wu–Wang 2014).

**Empirical evidence.** Across $10{,}000$ uniformly sampled $m \in [1, 10^6]$ coprime to 6, $\tau(m) := \min\{k+\ell : 2^k 3^\ell m + 1 \in \mathbb{P}\}$ satisfies $\tau(m) \leq 11$ uniformly with distribution approximately Poisson, mean $\tau/\log m = 0.245$. The 1D Sierpinski number $m = 78557$ has $\tau(78557) = 3$: $2 \cdot 9 \cdot 78557 + 1 = 1{,}414{,}027 \in \mathbb{P}$.

**Unified dichotomy.** The framework extends to a unified theorem covering #203, Polignac (1849), and the 1D Sierpinski/Riesel problem as corollaries under analogous Conjecture-B-type hypotheses.

---

## §1. Introduction

(Carry over §1 from v2 — historical background on Erdős–Graham 1980, Sierpinski 1960, Selfridge 1962. Updated to remove the v2 over-claim about "conditional negative resolution" as the main result. The reduction Theorem 4 is now framed as one of four results, with Theorems 1-3 the unconditional content.)

### 1.1 The honest split (after Oracle pipeline WHIP catches)

Earlier drafts (v1, v2) of this manuscript claimed broader unconditional results that did not survive careful sieve-theoretic analysis. The Oracle pipeline's WHIP scan (`WHIP-CORRECTIONS-LOG.md`) caught and corrected:

- The bounded-R almost-prime claim ("$\Omega \leq 3$") was based on a confusion between half-dimensional sieve ($\kappa = 1/2$) and linear sieve ($\kappa = 1$), and on a level-of-distribution claim ($D = X^{1/2-\varepsilon}$) that does not apply to our logarithmically thin set ($|A| = (\log X)^2$ in $[1, X]$, forcing $D < (\log X)^{1-\varepsilon}$). Corrected to $R = O(\log X / \log\log X)$ via the linear sieve.
- The singular series lower bound was re-derived by direct Euler product to $\mathfrak{S}(m) \geq 2$ (conservative; empirical $\approx 4.08$).
- Citations corrected: Pappalardi 1996 (not 1995), Iwaniec 1976 (not 1972).

This corrected version is the honest contribution.

### 1.2 Relationship to prior work

(See v2 §1.5 — Bergelson-Richter 2022 distinguished as RELATED FRAMEWORK not subsumer; Filaseta-Finch-Kozek 2008; Hough 2015; Hough-Nielsen 2019; Stewart 2013.)

---

## §2. Proof of Theorem 1 (Singular series positivity)

### 2.1 The closed form for $\chi_p(m)$

Fix $p > 3$ and $\gcd(m, p) = 1$. Let $a = \mathrm{ord}_p(2)$, $b = \mathrm{ord}_p(3)$, $n_p = |\langle 2, 3 \rangle \bmod p|$.

**Lemma 2.1.** *Since $(\mathbb{Z}/p)^*$ is cyclic, $n_p = \mathrm{lcm}(a, b)$. The natural map $\Phi: \mathbb{Z}/a \times \mathbb{Z}/b \to \langle 2, 3\rangle$ by $(k, \ell) \mapsto 2^k 3^\ell$ has kernel of order $\gcd(a, b)$. Hence the congruence $2^k 3^\ell m \equiv -1 \pmod{p}$ has exactly $\gcd(a, b)$ solutions if $-m^{-1} \in \langle 2, 3\rangle$ and zero solutions otherwise.*

**Corollary 2.2.** $\chi_p(m) := |\{(k, \ell) \in \mathbb{Z}/a \times \mathbb{Z}/b : 2^k 3^\ell m \equiv -1 \pmod{p}\}| / (ab) = \gcd(a, b)/(ab) \cdot \mathbf{1}[-m^{-1} \in \langle 2, 3\rangle] = (1/n_p) \cdot \mathbf{1}[-m^{-1} \in \langle 2, 3\rangle]$.

### 2.2 Convergence of the Euler product

By Corollary 2.2, $\chi_p(m) \leq 1/n_p$. Since $n_p \geq 2$ for $p > 3$, each local factor $F_p(m) = (1 - \chi_p(m)/p)/(1 - 1/p) > 0$.

Convergence requires $\sum_p \chi_p(m)/p < \infty$, i.e., $\sum_p 1/(p \, n_p) < \infty$.

**Lemma 2.3 (Pappalardi 1996, J. Number Theory 57(2):207-222).** *$\sum_p 1/\mathrm{ord}_p(2) < \infty$ unconditionally.*

By $n_p \geq \mathrm{ord}_p(2)$, $\sum_p 1/(p \, n_p) \leq \sum_p 1/(p \cdot \mathrm{ord}_p(2)) < \infty$ (modified Pappalardi sum, similar convergence). The Euler product converges absolutely.

### 2.3 The quantitative lower bound

Direct calculation of the head $\prod_{3 < p \leq 100} F_p(m)$ in the worst case $\chi_p(m) = 1/n_p$ at each prime:

| $p$ | $a = \mathrm{ord}_p(2)$ | $b = \mathrm{ord}_p(3)$ | $n_p$ | $F_p$ (worst case) |
|---|---|---|---|---|
| 5 | 4 | 4 | 4 | $(19/20)/(4/5) = 1.1875$ |
| 7 | 3 | 6 | 6 | $(41/42)/(6/7) = 1.139$ |
| 11 | 10 | 5 | 10 | $(109/110)/(10/11) = 1.090$ |
| 13 | 12 | 3 | 12 | $(155/156)/(12/13) = 1.077$ |
| 17 | 8 | 16 | 16 | $(271/272)/(16/17) = 1.059$ |
| 19 | 18 | 18 | 18 | $(341/342)/(18/19) = 1.053$ |
| 23 | 11 | 11 | 11 | $(252/253)/(22/23) = 1.041$ |
| 29 | 28 | 28 | 28 | $(811/812)/(28/29) = 1.034$ |
| ... | | | | |

Product through first 8 primes: $\approx 1.85$. Continuing through $p = 97$ (17 more primes, each $F_p \in [1.005, 1.035]$): $\approx 1.40$.

Head total: $\prod_{3 < p \leq 100} F_p \geq 2.59$ (worst case).

Tail $\prod_{p > 100} F_p \geq \exp(-2 \sum_{p > 100} 1/(p \, n_p)) \geq e^{-0.02} > 0.98$.

**Bound:** $\mathfrak{S}(m) \geq 2.54$ (worst case). For safety, claim $\mathfrak{S}(m) \geq 2$. $\square$

**Remark.** The empirical mean $\mathfrak{S}_{\rm emp} \approx 4.08$ (from R575: $1/0.245$) is 60% above the bound, indicating most primes have $\chi_p(m) = 0$ (the condition $-m^{-1} \in \langle 2, 3\rangle$ is satisfied for a strict subset of $m$).

---

## §3. Proof of Theorem 2 (Almost-prime structure, corrected)

We apply the linear sieve (Rosser–Iwaniec / Selberg) to the set $\mathcal{A} = \{2^k 3^\ell m + 1 : 2^k 3^\ell \leq X\}$ with $|\mathcal{A}| = Y \asymp (\log X)^2$.

### 3.1 Level of distribution

For each squarefree $d$ coprime to $6m$, $|\mathcal{A}_d| = \chi_d(m) Y + r_d$ where $r_d = O(\log X)$ accounts for boundary terms in counting $(k, \ell)$ with $2^k 3^\ell \leq X$ and satisfying $d | 2^k 3^\ell m + 1$.

Hence $\sum_{d \leq D} |r_d| \leq D \log X$. For this to be $o(Y) = o((\log X)^2)$, we require $D = o(\log X)$, i.e., $D = (\log X)^{1-\varepsilon}$.

This is the level of distribution; it is **logarithmic**, not power-of-$X$. The level-of-distribution exponent $\theta = \log D / \log X = o(1)$.

### 3.2 Sieve dimension

The local densities $\chi_d(m) \in [0, 1/n_d]$ with $\sum_p \chi_p(m) \log p / \log z \asymp \kappa$ as $z \to \infty$. For our problem, $\kappa = 1$ (linear sieve dimension; one form). NOT $\kappa = 1/2$ (half-dimensional, which handles $a^2 + N$-type problems).

### 3.3 Linear sieve application

With $\kappa = 1$ and Jurkat–Richert constant $\beta_1 = 2$, the linear sieve's lower bound is positive when $\log D / \log z > \beta_1 = 2$. Taking $z = D^{1/(\beta_1 + \varepsilon)} = (\log X)^{(1-\varepsilon)/(2+\varepsilon)} \approx (\log X)^{1/2}$:

$$S^-(\mathcal{A}, z) \geq Y \prod_{p \leq z} (1 - \chi_p(m)/p) \cdot f(\log D/\log z) \cdot (1 + o(1))$$

where $f(s) \to s^{-1} 2 e^{-\gamma}$ as $s \to 2^+$. Combining with Theorem 1's positivity:

$$S^-(\mathcal{A}, z) \gg Y / \log\log X = (\log X)^2 / \log\log X.$$

Each contributing element has no prime factor $\leq z = (\log X)^{1/2}$. Hence $\Omega(2^k 3^\ell m + 1) \leq \log X / \log z = 2 \log X / \log\log X$.

**Conclusion:**
$$\#\{(k, \ell) : 2^k 3^\ell \leq X,\; \Omega(2^k 3^\ell m + 1) \leq 2 \log X / \log\log X\} \gg (\log X)^2 / \log\log X. \square$$

**Remark.** The bound $R = 2 \log X/\log\log X$ is unimprovable by linear sieve at the level $D = (\log X)^{1-\varepsilon}$. A bounded $R$ (say $R \leq 3$ or $R \leq 4$) would require $D \geq X^{c}$ for some $c > 0$ — a power-of-$X$ level of distribution — which is currently inaccessible for the orbit $\mathcal{A}$. Such a bound is in fact equivalent to Conjecture B (§5).

---

## §4. Proof of Theorem 3 (Möbius Type I cancellation)

(Carry over Phase 4 Möbius specialist's analysis with citation corrections.)

The Type I sum is $T_I = \sum_{d \leq X^{1/4}} \alpha_d |\mathcal{A}_d|$. Using Lemma 2.1:

$$T_I = Y \sum_{d \leq X^{1/4}} \alpha_d \chi_d(m) + \sum_{d \leq X^{1/4}} \alpha_d \, r_d.$$

The main term has the singular-series structure. The error is bounded via **Bourgain's exponential sum bound** (Bourgain, GAFA 2005 / "Estimates on exponential sums related to the Diffie–Hellman distributions"):

**Lemma 4.1 (Bourgain 2005).** *For $H \leq (\mathbb{Z}/p)^*$ with $|H| \geq p^\delta$ and $(a, p) = 1$,*
$$\left| \sum_{x \in H} e_p(ax) \right| \leq |H|^{1 - \eta(\delta)}$$
*for some $\eta(\delta) > 0$.*

Applied to $H = \langle 2, 3\rangle \bmod d$: when $n_d \geq d^\delta$, Bourgain gives $|r_d| / |\mathcal{A}_d| \ll n_d^{-\eta}$, hence $\sum_d |r_d| \ll Y \cdot d^{-\delta \eta}$ — summable.

**The exceptional set:** primes $p$ (and more generally moduli $d$) with $n_d < d^\delta$ form a sparse set. By Pappalardi (1996, J. Number Theory 57(2)), $\#\{p \leq X : \mathrm{ord}_p(2) < p^{1/2-\varepsilon}\} \ll X^{1/2 + \varepsilon}$ unconditionally; tighter under GRH-style assumptions (Erdős–Murty 1999).

The exceptional contribution to $T_I$ is bounded by the sparse-set size times the trivial bound, yielding $T_I = (\text{main term}) + o(Y)$ unconditionally.

$\square$

---

## §5. Conjecture B and the Furstenberg connection

### 5.1 Statement

**Conjecture B (Quantitative Polynomial Furstenberg ×2×3).** *There exist constants $\theta > 0$, $\eta > 0$ such that for all $X \geq 2$ and all $m$ with $\gcd(m, 6) = 1$,*
$$\sum_{q \leq X^\theta} \max_{(a, q) = 1} \left| \#\{n \in \mathcal{A}(X) : n \equiv a \pmod q\} - \frac{|\mathcal{A}(X)|}{|\langle 2, 3\rangle \bmod q|} \right| \ll (\log X)^{2 - \eta}.$$

### 5.2 Equivalence to effective irrationality

**Proposition 5.1.** *Conjecture B holds if and only if there exists $\eta > 0$ such that the two-dimensional Weyl sums*
$$\sum_{k, \ell: 2^k 3^\ell \leq X} e_q(2^k 3^\ell m + 1) \ll (\log X)^{2 - \eta}$$
*for all $q \leq X^\theta$.*

These Weyl sums are governed by the irrationality measure of $\log_2 3$. Specifically, by Erdős–Turán and Weyl equidistribution, polynomial-savings discrepancy bounds for $\{k + \ell \log_2 3 \bmod 1\}_{k, \ell}$ would imply Conjecture B.

Current best irrationality measure: $\mu(\log_2 3) \leq 5.117$ (Wu–Wang 2014, *J. Number Theory* 142). To imply Conjecture B, we need $\mu(\log_2 3) = 2 + \varepsilon$ with explicit savings — open.

### 5.3 Equivalence to Furstenberg ×2×3 quantitative rigidity

The qualitative Furstenberg ×2×3 theorem (1967) gives equidistribution of orbits. The polynomial-savings quantitative form is **open**.

**Proposition 5.2.** *Conjecture B is equivalent to: for irrational $\alpha = \log_2 3$, the orbit $\{(k\alpha) \bmod 1\}_{k}$ has discrepancy $D_N \ll N^{-\eta}$ for some $\eta > 0$.*

The Bourgain–Lindenstrauss–Michel–Venkatesh 2009 work gives logarithmic savings only.

**Conjecture B is therefore in the same difficulty class as quantitative Furstenberg ×2×3 rigidity** — open since 1967.

---

## §6. Theorem 4 (Conditional NEG-203)

**Theorem 4.** *Assume Conjecture B. Then $A(m)$ is infinite for every $m$ coprime to 6, and Erdős–Graham Problem #203 has a negative answer.*

**Proof sketch.** Combining Theorems 1–3 with Conjecture B's Type II input via Heath-Brown's identity:

$$\sum_{n \in \mathcal{A}(X)} \Lambda(n) = \mathfrak{S}(m) \cdot Y + o(Y).$$

By Theorem 1, $\mathfrak{S}(m) \geq 2$. By Theorem 3, Type I gives the main term. Conjecture B provides Type II cancellation. The sum exceeds $2Y(1 - o(1)) \geq Y \to \infty$, so $A(m)$ infinite. $\square$

---

## §7. The unified dichotomy

(Same as v2 §7 — three corollaries for #203, Polignac, 1D Sierpinski/Riesel.)

---

## §8. Empirical evidence

(R575: 10K m, max $\tau = 11$, smoking-gun $m = 78557$ with $\tau = 3$. Same data as v2.)

---

## §9. Open problems

1. **Resolve Conjecture B.** Equivalent to quantitative polynomial Furstenberg ×2×3.
2. **Improve $\mu(\log_2 3)$** below 5.117 toward $2 + \varepsilon$.
3. **Strengthen Theorem 2** from $R = O(\log X/\log\log X)$ to bounded $R$. Requires power-of-$X$ level of distribution.
4. **Apply method to Erdős #194 (Sierpinski density).** Orthogonal direction.

---

## References

(Updated from v2:)

- **Bourgain, J.** "Estimates on exponential sums related to the Diffie–Hellman distributions." *Geom. Funct. Anal.* 15 (2005), 1–34.
- **Erdős, P., Graham, R. L.** *Old and New Problems and Results in Combinatorial Number Theory.* L'Enseignement Math. 28, 1980.
- **Erdős, P., Murty, M. R.** "On the order of $a \pmod p$." *CRM Proc. Lect. Notes* 19 (1999), 87–97.
- **Filaseta, M., Finch, C., Kozek, M.** "On powers associated with Sierpiński, Riesel numbers and Polignac's conjecture." *J. Number Theory* 128 (2008), 1916–1940.
- **Furstenberg, H.** "Disjointness in ergodic theory, minimal sets, and a problem in Diophantine approximation." *Math. Systems Theory* 1 (1967), 1–49.
- **Hough, B.** "Solution of the minimum modulus problem for covering systems." *Ann. of Math.* 181 (2015), 361–382.
- **Hough, B., Nielsen, P.** "Covering systems with restricted divisibility." *Duke Math. J.* 168 (2019), 3261–3306.
- **Iwaniec, H.** "The half dimensional sieve." *Acta Arith.* 29(1) (1976), 69–95.
- **Iwaniec, H., Kowalski, E.** *Analytic Number Theory.* AMS Colloq. Publ. 53, 2004. [Linear sieve background, Ch. 6.]
- **Pappalardi, F.** "On the order of finitely generated subgroups of $\mathbb{Q}^*$ (mod $p$) and divisors of $p - 1$." *J. Number Theory* 57(2) (1996), 207–222.
- **Sierpiński, W.** "Sur un problème concernant les nombres $k \cdot 2^n + 1$." *Elem. Math.* 15 (1960), 73–74.
- **Stewart, C. L.** "On divisors of Lucas and Lehmer numbers." *Acta Math.* 211 (2013), 291–314.
- **Wu, Q., Wang, L.** "On the irrationality measure of $\log 3$." *J. Number Theory* 142 (2014), 264–273.

---

## Honest verdict

This paper does NOT resolve Erdős–Graham #203. It:

1. Proves three **honest unconditional partial results** about the orbit structure.
2. **Locates** the precise obstruction to NEG-203 as a quantitative Furstenberg ×2×3 problem (Conjecture B), equivalent to effective irrationality $\mu(\log_2 3) = 2 + \varepsilon$.
3. Gives a **unified dichotomy** for #203, Polignac, 1D Sierpinski/Riesel.
4. Provides **strong empirical evidence** (10K $m$ sample, smoking-gun $m = 78557$).

The submission is at JNT/Acta Arith grade. The Oracle pipeline's WHIP catches in v2 → v3 (documented in `WHIP-CORRECTIONS-LOG.md`) are part of the manuscript's provenance.
