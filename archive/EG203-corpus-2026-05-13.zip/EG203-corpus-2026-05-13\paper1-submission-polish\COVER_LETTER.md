
# Cover Letter

Dear Editor,

Please find attached the manuscript:

**A Subgroup Obstruction Calculus for Two-Generator Exponential Congruences**

The paper develops an elementary finite-group framework for local congruence obstructions in exponential problems of the form
\[
m a^k b^\ell+1.
\]
The main results are exact finite identities: a subgroup-obstruction lemma, a complete two-point distribution law for the local obstruction random variable, all raw moments, exact information-theoretic distances from uniformity, a multiplication-fiber theorem, exact local density formulas, character-annihilator expansions, exact moment laws, and CRT orthogonality/weighted-variance identities.

The Erdős–Graham Problem #203 sequence \(m2^k3^\ell+1\) is used only as a motivating example.  The manuscript does not claim a resolution of that problem.

The paper is elementary and self-contained apart from standard background on finite abelian groups, Dirichlet characters, and elementary number theory.

Sincerely,

Jared Wilder
