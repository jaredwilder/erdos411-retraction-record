"""R633 — Hooley a constant: extend to M=10⁹ via random sampling (fourth scale anchor).

R630 verified the SAME Hooley a ≈ 9.33 (fit from M=10⁶) predicts the empirical
Pr[m prime | inH=23, m ≤ M] at M=10⁶, 10⁷, 10⁸ within 3pp at each scale.

R633 pushes to M=10⁹ via random sampling (full sweep is 100× R630's compute):
1. Sample N = 10⁷ random m's uniformly from [1, M] coprime to 6
2. For each m: compute inH(m) (sum of f_p indicators across 23 primes)
3. Identify cohort-23 subset (~1.1% of sample, ~110K m's)
4. Primality test cohort-23 m's (sympy.isprime, deterministic for m ≤ 3.3×10¹⁴)
5. Compute empirical Pr[m prime | inH=23, m ≤ M] = (prime cohort-23) / (total cohort-23)
6. Hooley a = empirical * log M

Cross-validation: also sample at M=10⁸ and verify match to R630 full-sweep 47.91%.

If sample-based estimates match full-sweep within 1pp, the sampling is reliable.
Then trust the M=10⁹ estimate.

Output: r633_results.json with empirical a at M=10⁸ (cross-val), M=10⁹ (new),
and trend analysis 10⁶ → 10⁷ → 10⁸ → 10⁹.
"""
from __future__ import annotations
import json, math, sys, time, random
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

PRIMES_LIST = list(sympy.primerange(5, 101))
K_PRIMES = len(PRIMES_LIST)


def orbit_mod_p(p):
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def compute_inH(m, orbits):
    """Return inH count: # primes p in P with gcd(m,p)=1 AND -m^{-1} ∈ ⟨2,3⟩ mod p."""
    inH = 0
    for p in PRIMES_LIST:
        if m % p == 0:
            continue
        m_inv = pow(m, -1, p)
        if ((-m_inv) % p) in orbits[p]:
            inH += 1
    return inH


def sample_and_analyze(M, N_SAMPLE, orbits, seed=42, label=""):
    """Sample N random m's from [1, M] coprime to 6. Compute inH distribution.
    Primality-test cohort-23 m's. Return empirical Hooley a."""
    print(f"\n=== {label}: Sampling {N_SAMPLE:,} m's from [1, {M:,}] coprime to 6 ===")
    rng = random.Random(seed)

    # Sample m's coprime to 6 (sample more and reject; 1/3 acceptance rate)
    inH_dist = [0] * (K_PRIMES + 1)
    cohort_23_ms = []

    t0 = time.time()
    n_sampled = 0
    n_attempted = 0
    while n_sampled < N_SAMPLE:
        n_attempted += 1
        m = rng.randint(1, M)
        if math.gcd(m, 6) != 1:
            continue
        n_sampled += 1
        inH = compute_inH(m, orbits)
        inH_dist[inH] += 1
        if inH == 23:
            cohort_23_ms.append(m)

        if n_sampled % 100_000 == 0:
            elapsed = time.time() - t0
            rate = n_sampled / elapsed
            eta = (N_SAMPLE - n_sampled) / rate
            print(f"  n_sampled={n_sampled:>10,} elapsed {elapsed:>5.0f}s rate "
                  f"{rate:>8,.0f}/s ETA {eta:>4.0f}s cohort-23 so far: {len(cohort_23_ms):>6,}")

    elapsed_sample = time.time() - t0
    print(f"  Sampling complete: {elapsed_sample:.0f}s, attempt rate {n_attempted/elapsed_sample:.0f}/s, "
          f"cohort-23 = {len(cohort_23_ms):,} ({len(cohort_23_ms)/N_SAMPLE*100:.2f}%)")

    # Primality-test cohort-23 m's
    print(f"  Primality-testing {len(cohort_23_ms):,} cohort-23 m's...")
    t_prime = time.time()
    n_prime_in_cohort_23 = 0
    for m in cohort_23_ms:
        if sympy.isprime(m):
            n_prime_in_cohort_23 += 1
    print(f"  Primality testing: {time.time() - t_prime:.0f}s; n_prime_in_cohort_23 = "
          f"{n_prime_in_cohort_23:,}")

    if not cohort_23_ms:
        return {
            "M": M,
            "N_SAMPLE": N_SAMPLE,
            "n_sampled": n_sampled,
            "n_attempted": n_attempted,
            "elapsed_sample_sec": elapsed_sample,
            "cohort_23_count": 0,
            "n_prime_in_cohort_23": 0,
            "Pr_prime_inH23": None,
            "a": None,
            "se": None,
            "inH_dist": inH_dist,
        }

    Pr_prime_inH23 = n_prime_in_cohort_23 / len(cohort_23_ms)
    a = Pr_prime_inH23 * math.log(M)
    # Standard error
    se = math.sqrt(Pr_prime_inH23 * (1 - Pr_prime_inH23) / len(cohort_23_ms))

    print(f"  Pr[prime | inH=23, m ≤ {M:.0e}] = {Pr_prime_inH23:.4f} ± {se:.4f}")
    print(f"  Hooley a = {a:.3f} ± {se * math.log(M):.3f}")

    return {
        "M": M,
        "N_SAMPLE": N_SAMPLE,
        "n_sampled": n_sampled,
        "n_attempted": n_attempted,
        "elapsed_sample_sec": elapsed_sample,
        "cohort_23_count": len(cohort_23_ms),
        "n_prime_in_cohort_23": n_prime_in_cohort_23,
        "Pr_prime_inH23": Pr_prime_inH23,
        "a": a,
        "se_pr": se,
        "se_a": se * math.log(M),
        "inH_dist": inH_dist,
    }


def main():
    print("R633 — Hooley a extension to M=10⁹ via random sampling")
    print(f"Primes set P = {PRIMES_LIST}")
    print(f"|P| = {K_PRIMES}\n")

    # Precompute orbits
    orbits = {p: orbit_mod_p(p) for p in PRIMES_LIST}
    rho = {p: len(orbits[p]) / (p - 1) for p in PRIMES_LIST}
    print(f"rho_p product: {math.prod(rho[p] for p in PRIMES_LIST):.6f}")
    print(f"Mertens prod (1-1/p): {math.prod(1 - 1/p for p in PRIMES_LIST):.6f}\n")

    # Cross-validation: M=10⁸ sample. Known full-sweep value from R630: 47.91%
    results = {}
    N_SAMPLE = 10_000_000  # 10⁷ samples per scale

    # Cross-val at M=10⁸ (R630 known value: 47.91%)
    res_M8 = sample_and_analyze(10**8, N_SAMPLE, orbits, seed=42, label="Cross-val M=10⁸")
    results["M_1e8"] = res_M8

    # New: M=10⁹
    res_M9 = sample_and_analyze(10**9, N_SAMPLE, orbits, seed=43, label="NEW M=10⁹")
    results["M_1e9"] = res_M9

    # Compare to R630 full-sweep values
    r630_M6_pct = 67.5
    r630_M7_pct = 55.0
    r630_M8_pct = 47.91
    r630_a_value = 9.33  # fit from M=10⁶

    print("\n" + "=" * 70)
    print("=== Trend analysis: Hooley a across four scales ===")
    print("=" * 70)
    print(f"\n{'M':>10} {'Pr[prime|inH=23]':>20} {'a_emp':>10} {'a_emp - a_M6=9.33':>22} {'source':>20}")
    print(f"{10**6:>10.0e} {r630_M6_pct/100:>20.4f} {9.33:>10.3f} {0.0:>+22.3f} {'R630 full sweep':>20}")
    print(f"{10**7:>10.0e} {r630_M7_pct/100:>20.4f} {r630_M7_pct/100 * math.log(10**7):>10.3f} "
          f"{r630_M7_pct/100 * math.log(10**7) - 9.33:>+22.3f} {'R630 full sweep':>20}")
    print(f"{10**8:>10.0e} {r630_M8_pct/100:>20.4f} {r630_M8_pct/100 * math.log(10**8):>10.3f} "
          f"{r630_M8_pct/100 * math.log(10**8) - 9.33:>+22.3f} {'R630 full sweep':>20}")
    if res_M8['Pr_prime_inH23'] is not None:
        print(f"{10**8:>10.0e} {res_M8['Pr_prime_inH23']:>20.4f} {res_M8['a']:>10.3f} "
              f"{res_M8['a'] - 9.33:>+22.3f} {'R633 sample (cross-val)':>20}")
        cross_val_match = abs(res_M8['Pr_prime_inH23'] - r630_M8_pct/100) * 100
        cross_val_in_2pp = cross_val_match < 2.0
        print(f"\nCross-val: |R633_sample - R630_fullsweep| = {cross_val_match:.2f} pp "
              f"({'PASS' if cross_val_in_2pp else 'FAIL'} within 2pp)")
    if res_M9['Pr_prime_inH23'] is not None:
        print(f"{10**9:>10.0e} {res_M9['Pr_prime_inH23']:>20.4f} {res_M9['a']:>10.3f} "
              f"{res_M9['a'] - 9.33:>+22.3f} {'R633 sample (NEW)':>20}")

    # Trend across all four scales
    a_values = [
        (10**6, 9.33, "R630"),
        (10**7, r630_M7_pct/100 * math.log(10**7), "R630"),
        (10**8, r630_M8_pct/100 * math.log(10**8), "R630"),
        (10**9, res_M9['a'], "R633"),
    ]
    print("\n=== Hooley a trend ===")
    for M, a_val, src in a_values:
        if a_val is not None:
            print(f"  M={M:>10.0e} a = {a_val:>6.3f} ({src})")

    # If a is decreasing or increasing, what does it converge to?
    if res_M9['Pr_prime_inH23'] is not None:
        a_seq = [9.33, r630_M7_pct/100 * math.log(10**7),
                 r630_M8_pct/100 * math.log(10**8), res_M9['a']]
        diffs = [a_seq[i+1] - a_seq[i] for i in range(3)]
        print(f"\n  Δa across scales:")
        print(f"    10⁶→10⁷: {diffs[0]:+.3f}")
        print(f"    10⁷→10⁸: {diffs[1]:+.3f}")
        print(f"    10⁸→10⁹: {diffs[2]:+.3f}")
        print(f"  Trend: {'decreasing' if all(d < 0 for d in diffs) else 'mixed' if any(d > 0 for d in diffs) and any(d < 0 for d in diffs) else 'increasing'}")

        # Theoretical asymptotic from Mertens (assumes independence): a → 3 / mertens_factor
        mertens_factor = math.prod(1 - 1/p for p in PRIMES_LIST)
        asymptotic_a_indep = 3 / mertens_factor
        print(f"\n  Mertens-mechanism asymptotic a (independence): {asymptotic_a_indep:.3f}")
        print(f"  Current R633 M=10⁹ a value: {res_M9['a']:.3f}")
        print(f"  Gap from theoretical asymptotic: {asymptotic_a_indep - res_M9['a']:+.3f}")

    # Save
    out = ROOT / "r633_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 21 R633 — Hooley a M=10⁹ extension via sampling",
        "M_values_tested": [10**8, 10**9],
        "N_SAMPLE_per_scale": N_SAMPLE,
        "R630_full_sweep_reference": {
            "M_1e6_pct": r630_M6_pct,
            "M_1e7_pct": r630_M7_pct,
            "M_1e8_pct": r630_M8_pct,
            "a_M1e6": 9.33,
        },
        "M_1e8_results": res_M8,
        "M_1e9_results": res_M9,
        "rho_product": math.prod(rho[p] for p in PRIMES_LIST),
        "mertens_product": math.prod(1 - 1/p for p in PRIMES_LIST),
        "asymptotic_a_indep_mechanism": 3 / math.prod(1 - 1/p for p in PRIMES_LIST),
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
