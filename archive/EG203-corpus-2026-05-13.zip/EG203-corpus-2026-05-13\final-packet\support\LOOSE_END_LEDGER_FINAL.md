# LOOSE-END LEDGER — PASS 5 CONVERGENCE

This file ties up every known loose end in the packet.  “Resolved” does not always mean “proved”; it means the item has a correct status and an assigned next action.

## 1. Full Erdős–Graham #203

**Status:** Not proved.  
**Resolution:** Quarantined. No file claims an unconditional solution.  
**Next action:** Only revive if high-seam PHNC or an alternative full route is actually proved.

## 2. High-\(\ell\) PHNC

**Status:** Open analytic seam.  
**Resolution:** Extracted as `EXPERT_PACKET_HIGH_SEAM_PHNC.md`.  
**Next action:** Ask analytic number theorists whether a uniform theorem exists.

## 3. PHNC \(\Rightarrow\) KRWS

**Status:** Conditional bridge, not proved in the packet.  
**Resolution:** Explicitly labeled as dependency in Paper 4 and lemma checklist.  
**Next action:** Either prove finite Fourier/smoothing lemma or keep conditional.

## 4. Kummer-BV \(\Rightarrow\) NEG-203

**Status:** Conditional sieve bridge.  
**Resolution:** Explicitly labeled as dependency.  
**Next action:** Formalize separately before any full #203 claim.

## 5. Density-zero theorem

**Status:** Serious theorem schema, not submission-ready.  
**Resolution:** Paper 3 states exact requirements before submission.  
**Next action:** Insert exact Pappalardi theorem, weights, support, normalization, exceptional set.

## 6. Synchronization defect quotient

**Status:** Fixed.  
**Resolution:** Defined as
\[
\mathcal S_d(a,b)=\Pi_d(a,b)/\Gamma_d(a,b)
\]
with
\[
\Pi_d(a,b)=\prod_{q\mid d}\Gamma_q(a,b).
\]

## 7. Finite examples

**Status:** Verified.  
**Resolution:** Script `verify_finite_examples.py` and report `FINITE_EXAMPLE_VERIFICATION_PASS4.md` included.

## 8. First submission target

**Status:** Decided.  
**Resolution:** Submit/polish `01_SUBGROUP_OBSTRUCTION_CALCULUS_FINAL_DRAFT.tex` first.

## 9. Overclaim risk

**Status:** Controlled.  
**Resolution:** Readme, claim separation, loose-end ledger, and failed-routes audit all prevent “#203 solved” language.

## 10. What remains to do before first submission

1. Polish prose in Paper 1.
2. Add complete references.
3. Verify examples one more time locally.
4. Decide journal.
5. Compile PDF.
6. Send to one friendly mathematician or submit.

## Final convergence verdict

The bundle is converged as a research packet.  Remaining work is execution, not discovery harvesting.
