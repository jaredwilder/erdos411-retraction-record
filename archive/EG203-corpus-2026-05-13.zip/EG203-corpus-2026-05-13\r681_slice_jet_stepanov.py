"""R681 — Slice-jet Stepanov primitive auxiliary test (GPT R676-R680 CORRECTED).

GPT R676-R680 caught 6 mathematical errors in R660B-UNIFORM-PROOF.tex:
  1. Auxiliary class too small for claimed dimension count
  2. Order-2 vanishing on ALL V_q kills jet-primitivity (forces P ∈ I_q^2)
  3. Obstruction set mischaracterized (slice not full grid)
  4. Vandermonde proposition false as stated
  5. Bivariate zero count invalid
  6. δ extraction missing slice → distribution → Fourier bridge

CORRECTED framework (GPT R677-R678):
  - The bad set is the SLICE B_q(c) = {(x, y) ∈ V_q : xy = c} for c = -m^{-1}
  - Auxiliary P ∈ F_q[X, Y]_{≤D} vanishes on V_q (order 1) AND on B_q(c) to order m (jet)
  - Slice restriction R_c(X) = X^T · P(X, c · X^{-1}) reduces to one-variable
  - r · |B_q(c)| ≤ deg R_c ≤ 2D (valid Stepanov bound)

This script tests: for each prime q and each c ∈ F_q* with B_q(c) non-empty,
find smallest D where the slice-jet auxiliary exists (kernel > 0).

Then bound |B_q(c)| via deg R_c ≤ 2D and r = 2 (jet order on slice).
"""

import json
import math
from pathlib import Path
from sympy import isprime

OUT = Path(__file__).with_suffix('.json')


def order_mod(g, q):
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def build_orbit(q):
    a = order_mod(2, q)
    b = order_mod(3, q)
    twos = [pow(2, k, q) for k in range(a)]
    threes = [pow(3, l, q) for l in range(b)]
    pts = []
    seen = set()
    for x in twos:
        for y in threes:
            if (x, y) not in seen:
                seen.add((x, y))
                pts.append((x, y))
    return a, b, pts


def build_slice(q, c, V_q):
    """B_q(c) = {(x, y) ∈ V_q : xy ≡ c mod q}."""
    return [(x, y) for (x, y) in V_q if (x * y) % q == c % q]


def monomial_basis(D):
    return [(i, j) for i in range(D + 1) for j in range(D + 1 - i)]


def pow_mod(base, exp, q):
    if exp < 0:
        return 0
    return pow(base, exp, q) if base != 0 else (1 if exp == 0 else 0)


def falling(n, k):
    if k == 0:
        return 1
    r = 1
    for t in range(k):
        r *= (n - t)
    return r


def derivative_row(x, y, di, dj, basis, q):
    row = []
    for (i, j) in basis:
        if i < di or j < dj:
            row.append(0)
            continue
        coeff = falling(i, di) * falling(j, dj)
        val = (pow_mod(x, i - di, q) * pow_mod(y, j - dj, q)) % q
        row.append((coeff * val) % q)
    return row


def value_row(x, y, basis, q):
    """Row of P(x, y) evaluated on basis (order-0 jet)."""
    return [(pow_mod(x, i, q) * pow_mod(y, j, q)) % q for (i, j) in basis]


def gauss_rank(M, q):
    if not M:
        return 0
    M = [list(r) for r in M]
    nrow = len(M)
    ncol = len(M[0]) if M else 0
    r = 0
    for c in range(ncol):
        pivot = None
        for rr in range(r, nrow):
            if M[rr][c] % q != 0:
                pivot = rr
                break
        if pivot is None:
            continue
        if pivot != r:
            M[r], M[pivot] = M[pivot], M[r]
        inv = pow(M[r][c] % q, -1, q)
        for cc in range(c, ncol):
            M[r][cc] = (M[r][cc] * inv) % q
        for rr in range(nrow):
            if rr != r and M[rr][c] % q != 0:
                f = M[rr][c] % q
                for cc in range(c, ncol):
                    M[rr][cc] = (M[rr][cc] - f * M[r][cc]) % q
        r += 1
        if r == min(nrow, ncol):
            break
    return r


def slice_jet_test(q, D, m, V_q, B_slice):
    """Test slice-jet primitivity at degree D, jet order m on the slice.

    Constraints:
      - Value zero on V_q (full grid, order 1): |V_q| constraints
      - Order-m jet zero on B_slice (slice): |B_slice| · C(m+1, 2) constraints
    The slice constraints SUBSUME the value-zero on B_slice subset.

    Kernel > 0 ⟹ slice-jet auxiliary exists.
    """
    basis = monomial_basis(D)
    n_unknowns = len(basis)
    rows = []

    # Value zero on V_q \ B_slice (avoid duplicate constraints)
    slice_set = set(B_slice)
    for (x, y) in V_q:
        if (x, y) not in slice_set:
            rows.append(value_row(x, y, basis, q))

    # Full jet of order m on B_slice (value + derivatives up to order m-1)
    for (x, y) in B_slice:
        for di in range(m):
            for dj in range(m - di):
                rows.append(derivative_row(x, y, di, dj, basis, q))

    n_constraints = len(rows)
    rank = gauss_rank(rows, q) if rows else 0
    kernel = n_unknowns - rank
    return n_unknowns, n_constraints, rank, kernel


def find_typical_c(q, V_q):
    """Pick a non-trivial c ∈ F_q* such that B_q(c) is non-empty and not all of V_q."""
    seen_products = {}
    for (x, y) in V_q:
        prod = (x * y) % q
        seen_products.setdefault(prod, []).append((x, y))
    # Sort by slice size, pick median-size slice
    sized = sorted(seen_products.items(), key=lambda kv: len(kv[1]))
    if not sized:
        return None, []
    # Take a slice with non-trivial size (≥ 2)
    for c, slice_pts in sized:
        if len(slice_pts) >= 2:
            return c, slice_pts
    return sized[len(sized) // 2]


def bombieri_tight_D_slice(h_q, slice_size, log_q):
    """Bombieri-tight degree for slice-jet test.
    Constraints = h_q (value on V_q \ B_slice) + 3 · |B_slice| at m=2.
    Need binom(D+2, 2) > h_q + 3 · |B_slice|.
    """
    target = h_q - slice_size + 3 * slice_size  # = h_q + 2 · slice_size
    # binom(D+2, 2) ≈ D²/2, so D ≈ sqrt(2 · target)
    return int(math.ceil(math.sqrt(2 * (target + log_q * slice_size))))


def main():
    print("R681 — Slice-jet Stepanov primitive auxiliary test (GPT R676-R680 CORRECTED)")
    print("=" * 96)
    print("For each prime q: pick non-trivial slice B_q(c); find D where slice-jet kernel > 0")
    print()
    print(f"{'q':>4} {'h_q':>5} {'c':>4} {'|B|':>4} {'D':>4} {'unk':>5} {'cnst':>5} "
          f"{'rank':>5} {'ker':>5} {'cert':>5} {'StepBnd':>8}")
    print("-" * 96)

    results = []
    n_total = 0
    n_cert = 0

    for q in range(7, 100):
        if not isprime(q):
            continue
        a, b, V_q = build_orbit(q)
        if len(V_q) >= (q - 1) ** 2:
            continue  # full torus, trivial
        if len(V_q) > 1000:
            continue  # heavy
        c, B_slice = find_typical_c(q, V_q)
        if c is None or len(B_slice) < 2:
            continue

        h_q = len(V_q)
        log_q = math.log(q)
        D = bombieri_tight_D_slice(h_q, len(B_slice), log_q) + 2

        if D > 50:
            continue

        try:
            n_unknowns, n_constraints, rank, kernel = slice_jet_test(
                q, D, 2, V_q, B_slice
            )
        except Exception as e:
            print(f"{q:>4} ERROR: {e}")
            continue

        cert = "YES" if kernel > 0 else "NO"
        # Stepanov bound: r · |B| ≤ 2D ⟹ |B| ≤ D
        step_bound = D
        actual_B = len(B_slice)
        # Stepanov saving: bound on slice deviation from typical h_q/q
        print(f"{q:>4} {h_q:>5} {c:>4} {actual_B:>4} {D:>4} {n_unknowns:>5} "
              f"{n_constraints:>5} {rank:>5} {kernel:>5} {cert:>5} "
              f"{step_bound:>8}")
        n_total += 1
        if kernel > 0:
            n_cert += 1
            results.append({
                'q': q, 'a': a, 'b': b, 'h_q': h_q,
                'c': c, 'slice_size': actual_B,
                'D': D, 'n_unknowns': n_unknowns,
                'n_constraints': n_constraints, 'rank': rank,
                'kernel': kernel, 'stepanov_bound': step_bound,
                'jet_primitive_certified': True,
            })

    print()
    print("=" * 96)
    print(f"Total primes tested:    {n_total}")
    print(f"Slice-jet certified:    {n_cert}")
    print(f"Uniform certification:  {'YES' if n_cert == n_total and n_total >= 5 else 'NO'}")

    # Slope log(D) vs log(h_q) (Bombieri predicts ~ 0.5 + corrections)
    if n_cert >= 4:
        log_h = [math.log(r['h_q']) for r in results]
        log_D = [math.log(r['D']) for r in results]
        mean_h = sum(log_h) / len(log_h)
        mean_D = sum(log_D) / len(log_D)
        num = sum((lh - mean_h) * (ld - mean_D) for lh, ld in zip(log_h, log_D))
        den = sum((lh - mean_h) ** 2 for lh in log_h)
        slope = num / den if den > 0 else float('nan')
        print(f"Slope log(D) vs log(h_q): {slope:.4f}")
    else:
        slope = None

    out = {
        'phase': 'R681 — Slice-jet Stepanov primitive auxiliary (GPT R676-R680 CORRECTED)',
        'construction': 'P ∈ F_q[X,Y]_{≤D} vanishing on V_q (order 1) AND on B_q(c) (jet order 2)',
        'results': results,
        'n_total': n_total,
        'n_certified': n_cert,
        'slope': slope,
    }
    OUT.write_text(json.dumps(out, indent=2))
    print(f"\nWritten {OUT}")


if __name__ == '__main__':
    main()
