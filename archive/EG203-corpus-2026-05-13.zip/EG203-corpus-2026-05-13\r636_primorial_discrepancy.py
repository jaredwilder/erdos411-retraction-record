"""R636 — Erdős-emulated primorial-modulus discrepancy test.

PHASE-23 GOLD C: Compute $\tilde{D}_N^w(q)$ at primorial moduli $q = p_k\#/6$ for $p_k$
ranging from 5 to 19. Compare to prime-modulus discrepancy at similar magnitude.

If primorial $C(q)$ decays polynomially in $k$ but prime $C(q)$ doesn't, the wall
is at PRIME MODULI (not in the averaged statement) — implies Conjecture B'' weak
form is closer than R580 single-prime data suggests.

Test design:
- Primorials coprime to 6: q ∈ {5, 35, 385, 5005, 85085, 1616615}
- For each q: compute orbit ⟨2, 3⟩ mod q
- For each q: compute 2D weighted discrepancy of orbit residue distribution at L=50
- Compare C(q) = D · N^{0.65} (per R580 fit) across primorials
- Compare to prime moduli at similar magnitude (q = 5, 41, 379, 4099, ...)
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

L_TEST = 50  # support cap


def orbit_mod_q(q):
    """Compute orbit ⟨2, 3⟩ mod q. Returns set."""
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % q
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def support_pairs(L):
    """All (k, ℓ) ∈ Z²_{≥0} with 2^k 3^ℓ ≤ 2^L. With Hann window weight."""
    pairs = []
    log2_3 = math.log2(3)
    for k in range(L + 1):
        max_ell = int((L - k) / log2_3)
        for ell in range(max_ell + 1):
            pairs.append((k, ell))
    return pairs


def hann_weight(k, ell, L):
    """Hann window on the support triangle."""
    log2_3 = math.log2(3)
    s = (k + ell * log2_3) / L
    return 0.5 * (1 + math.cos(math.pi * s))


def compute_discrepancy(q, L, m=1, weighted=True):
    """Compute 2D weighted discrepancy on (2,3)-orbit residue distribution mod q.

    D = max_a |frac in class a - 1/|H_q||

    where the fraction is the Hann-weighted count of (k, ℓ) with 2^k 3^ℓ m ≡ a mod q.
    """
    pairs = support_pairs(L)
    N_phi = len(pairs)
    H_q = orbit_mod_q(q)
    H_size = len(H_q)

    # Histogram residues
    if weighted:
        weights = np.array([hann_weight(k, ell, L) for (k, ell) in pairs])
    else:
        weights = np.ones(N_phi)
    total_weight = weights.sum()

    residue_count = {}
    for i, (k, ell) in enumerate(pairs):
        val = (pow(2, k, q) * pow(3, ell, q) * m) % q
        residue_count[val] = residue_count.get(val, 0) + weights[i]

    # Compute discrepancy
    target_frac = 1 / H_size
    max_dev = 0
    for a in H_q:
        frac = residue_count.get(a, 0) / total_weight
        dev = abs(frac - target_frac)
        if dev > max_dev:
            max_dev = dev

    # Also: standard deviation of residue counts
    counts = np.array([residue_count.get(a, 0) / total_weight for a in H_q])
    std_dev = float(np.std(counts))

    return {
        "q": q,
        "L": L,
        "N_phi": N_phi,
        "H_size": H_size,
        "target_frac": target_frac,
        "max_dev": max_dev,
        "std_dev": std_dev,
        "C_q_at_065": max_dev * (N_phi ** 0.65),
    }


def main():
    print("R636 — Erdős primorial-modulus discrepancy test")
    print("=" * 65)

    # Primorials coprime to 6
    primorial_qs = [5, 35, 385, 5005, 85085, 1616615]
    print(f"\nPrimorial moduli (coprime to 6): {primorial_qs}")

    # Prime moduli at similar magnitude for comparison
    # 5 ↔ 5; 35 (≈3·11) ↔ 31 or 37; 385 (≈5²·15) ↔ 379 or 389; 5005 (≈5·1001) ↔ 4999;
    # 85085 ↔ 85091; 1616615 ↔ 1616627 (find a prime nearby)
    prime_qs = [5, 31, 379, 4999, 85091]
    # For 1616615 comparison: 1616627
    if sympy.isprime(1616627):
        prime_qs.append(1616627)
    else:
        # find a prime nearby
        for delta in range(1, 1000):
            if sympy.isprime(1616615 + delta):
                prime_qs.append(1616615 + delta)
                break
    print(f"Prime moduli (matched magnitudes): {prime_qs}")

    # Test on m = 1 (just orbit itself)
    print(f"\n=== Testing m = 1, L = {L_TEST} ===\n")
    print(f"{'q (mod type)':>22} {'|H_q|':>8} {'max_dev':>10} {'std_dev':>10} {'C(q)·N^0.65':>14}")

    results_primorial = []
    results_prime = []

    for q in primorial_qs:
        t0 = time.time()
        r = compute_discrepancy(q, L_TEST, m=1, weighted=True)
        elapsed = time.time() - t0
        results_primorial.append(r)
        print(f"{q:>10} (primor) {r['H_size']:>8} {r['max_dev']:>10.5f} {r['std_dev']:>10.5f} "
              f"{r['C_q_at_065']:>14.4f} (took {elapsed:.1f}s)")

    print()
    for q in prime_qs:
        t0 = time.time()
        r = compute_discrepancy(q, L_TEST, m=1, weighted=True)
        elapsed = time.time() - t0
        results_prime.append(r)
        print(f"{q:>10} (prime)  {r['H_size']:>8} {r['max_dev']:>10.5f} {r['std_dev']:>10.5f} "
              f"{r['C_q_at_065']:>14.4f} (took {elapsed:.1f}s)")

    # Scaling analysis
    print("\n" + "=" * 65)
    print("=== Scaling analysis ===\n")

    # For primorials: q = p_k\#/6 grows roughly geometrically
    # Check if C(q) decreases with q
    log_qs_p = [math.log(r['q']) for r in results_primorial]
    C_qs_p = [r['C_q_at_065'] for r in results_primorial]
    log_qs_prime = [math.log(r['q']) for r in results_prime]
    C_qs_prime = [r['C_q_at_065'] for r in results_prime]

    # Linear regression log(C) vs log(q) for primorials
    log_C_p = [math.log(c) for c in C_qs_p]
    n_p = len(log_qs_p)
    mx_p = sum(log_qs_p)/n_p
    my_p = sum(log_C_p)/n_p
    num_p = sum((log_qs_p[i]-mx_p)*(log_C_p[i]-my_p) for i in range(n_p))
    den_p = sum((log_qs_p[i]-mx_p)**2 for i in range(n_p))
    slope_p = num_p/den_p if den_p > 0 else 0
    print(f"Primorial: slope of log C(q) vs log q = {slope_p:.4f}")
    print(f"  → C(q) ~ q^({slope_p:.4f}) for primorial moduli")
    print(f"  → polynomial decay exponent δ_primorial = {-slope_p:.4f}")

    # Same for primes
    log_C_prime = [math.log(c) for c in C_qs_prime]
    n_pr = len(log_qs_prime)
    mx_pr = sum(log_qs_prime)/n_pr
    my_pr = sum(log_C_prime)/n_pr
    num_pr = sum((log_qs_prime[i]-mx_pr)*(log_C_prime[i]-my_pr) for i in range(n_pr))
    den_pr = sum((log_qs_prime[i]-mx_pr)**2 for i in range(n_pr))
    slope_pr = num_pr/den_pr if den_pr > 0 else 0
    print(f"Prime:     slope of log C(q) vs log q = {slope_pr:.4f}")
    print(f"  → C(q) ~ q^({slope_pr:.4f}) for prime moduli")
    print(f"  → polynomial decay exponent δ_prime = {-slope_pr:.4f}")

    print()
    if slope_p < slope_pr - 0.05:
        verdict = "PRIMORIAL_DECAY_FASTER"
        print(f"VERDICT: {verdict}")
        print("Primorial C(q) decays faster than prime C(q) by margin > 0.05.")
        print("→ Wall is at PRIME moduli, not in averaged statement.")
        print("→ Conjecture B'' WEAK form is closer than R580 prime-only data suggests.")
    elif slope_pr < slope_p - 0.05:
        verdict = "PRIME_DECAY_FASTER"
        print(f"VERDICT: {verdict}")
        print("Prime C(q) decays faster than primorial — unexpected, requires analysis.")
    else:
        verdict = "DECAYS_SIMILARLY"
        print(f"VERDICT: {verdict}")
        print("Primorial and prime C(q) decay at similar rates within data noise.")
        print("→ Wall structure is uniform across moduli; B''-weak not closer at primorial.")

    out = ROOT / "r636_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 23 R636 — Erdős primorial-modulus discrepancy test",
        "L": L_TEST,
        "m_tested": 1,
        "primorial_qs": primorial_qs,
        "prime_qs": prime_qs,
        "results_primorial": results_primorial,
        "results_prime": results_prime,
        "slope_log_C_vs_log_q_primorial": slope_p,
        "slope_log_C_vs_log_q_prime": slope_pr,
        "delta_primorial": -slope_p,
        "delta_prime": -slope_pr,
        "verdict": verdict,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
