# FINAL GOLD INVENTORY — 7-ROUND CONVERGED PACKET

## Honest headline

Erdős–Graham Problem #203 is **not** solved in this packet.

What this packet contains is the best defensible mathematical harvest from the attack:

\[
\boxed{\text{finite subgroup obstruction calculus}}
\]

\[
\boxed{\text{exact local densities and moments}}
\]

\[
\boxed{\text{CRT synchronization theory}}
\]

\[
\boxed{\text{projective Kummer slope machinery}}
\]

\[
\boxed{\text{density-zero obstruction theorem schema}}
\]

\[
\boxed{\text{conditional Kummer distribution criterion for #203}}
\]

\[
\boxed{\text{failed-routes audit and high-seam PHNC expert packet}}
\]

## The five core paper files

### 1. `papers/01_SUBGROUP_OBSTRUCTION_CALCULUS.tex`

**Status:** strongest first submission candidate.  
**Content:** finite abelian subgroup obstruction lemma, multiplication fiber theorem, exact local density, character expansion, exact moments, weighted variance, examples, multi-generator extension.  
**Dependency level:** elementary/provable now.  
**Next action:** polish references and submit.

### 2. `papers/02_CRT_SYNCHRONIZATION_PROJECTIVE_SLOPES.tex`

**Status:** algebra paper candidate.  
**Content:** squarefree lattice membership, synchronization defect quotient, local/global failure example \(d=95\), pair determinant criterion, projective Kummer slopes, star atom, Kummer ratio fields.  
**Dependency level:** elementary algebra plus finite examples.  
**Next action:** add diagrams and submit after Paper 1.

### 3. `papers/03_DENSITY_ZERO_KUMMER_OBSTRUCTION_SCHEMA.tex`

**Status:** serious theorem schema, not submission-ready.  
**Content:** Kummer obstruction energy, weighted second moment, Pappalardi/sieve route to density-zero exceptional set.  
**Dependency level:** needs exact Pappalardi theorem and sieve normalization.  
**Next action:** insert precise theorem and weights.

### 4. `papers/04_KUMMER_DISTRIBUTION_CRITERION_EG203.tex`

**Status:** conditional architecture paper.  
**Content:** PHNC, Kummer-BV, conditional route to #203, low-range discussion, high-seam open problem, expert-facing formulation.  
**Dependency level:** conditional/open.  
**Next action:** formalize arrows or keep as conditional criterion.

### 5. `papers/05_FAILED_ROUTES_PHNC_AUDIT.tex`

**Status:** defensive/expository note.  
**Content:** why BFI, Plünnecke–Ruzsa, fixed-field Chebotarev, order bounds, and generic Chebotarev-BT do not close the high-seam PHNC route as plug-ins.  
**Dependency level:** audit/expository.  
**Next action:** use as appendix or standalone note.

## Named mathematical objects preserved

| Object | Definition / role |
|---|---|
| Kummer obstruction energy | \(\mathcal E(d)=|\Gamma_d|^{-1}-\varphi(d)^{-1}\) |
| Energy defect factor | \(\kappa(d)=|G_d|/|\Gamma_d|\) |
| Synchronization defect quotient | \(\mathcal S_d(a,b)=\Pi_d(a,b)/\Gamma_d(a,b)\) |
| Kummer slope | \([\log_q2:\log_q3]\in\mathbb P^1(\mathbb F_\ell)\) |
| Star atom | \((\log_q2,\log_q3)=(0,0)\) |
| Kummer slope collision graph | graph on primes with equal projective Kummer slope |
| Collision excess statistic | variance-style diagnostic for slope clustering |
| Bad cyclic line | powers of a tiny-deficit order-\(\ell\) character |
| High-seam PHNC | PHNC for \((\log Q)^{1-\varepsilon}<\ell\le(\log Q)^B\) |

## Core certified lemmas

1. Finite abelian subgroup obstruction lemma.
2. Multiplication fiber theorem.
3. Unit-inversion bijection.
4. Character-annihilator expansion.
5. Exact moment law.
6. CRT orthogonality.
7. Weighted variance theorem.
8. Squarefree lattice membership.
9. Synchronization defect quotient size identity.
10. Pair determinant criterion.
11. Projective slope criterion.
12. Rational Kummer independence.
13. Kummer character order exactly \(\ell\).
14. Non-real odd Kummer character.
15. Power-stability of deficit.
16. Bad cyclic line consequence.

## Final public claim

The safe public claim is:

> We developed a finite subgroup obstruction calculus for two-generator exponential congruence problems, including exact local densities, character-annihilator expansions, exact moment laws, CRT synchronization, and projective Kummer slope criteria, with Erdős–Graham #203 as the motivating example.

## Final non-claim

Do **not** claim:

> Erdős–Graham #203 is solved.

Do **not** imply:

> Density-zero means full solution.

Do **not** present:

> PHNC is proved in the high-\(\ell\) seam.

## What makes this packet worth the work

The failed full proof did not vanish. It separated into:
- a provable elementary paper,
- a provable algebra paper,
- a serious density-zero route,
- a conditional full-route criterion,
- a precise open analytic seam,
- a defensive audit of failed shortcuts,
- reproducible finite examples,
- an expert outreach packet.

That is the Oracle repechage.
