"""R638 — Bombieri-emulated Deshouillers-Iwaniec + Jacobi sums diagnostic.

PHASE-23 GOLD D: Empirically test whether the orbit's Fourier transform admits
Kloosterman-style cancellation.

For prime q and a ∈ (Z/q)^*:
  S_q(a, L) = Σ_{(k,ℓ): 2^k 3^ℓ ≤ 2^L} e_q(a · 2^k · 3^ℓ)

Trivial bound: |S_q(a, L)| ≤ N_φ.
Kloosterman-type bound (DI 1982): on average, |S_q(a, L)| ≪ N_φ^{1-δ} for δ > 0.

The orbit Fourier transform factorizes:
  S_q(a, L) = Σ_{k,ℓ} e_q(a · 2^k · 3^ℓ)
            ≈ multiplicative-character-style sum on the rank-2 subgroup ⟨2, 3⟩ mod q.

For each Dirichlet character χ mod q:
  Σ_{k,ℓ} χ(2)^k χ(3)^ℓ = (geometric series in k) × (geometric series in ℓ)
                        (when both ≠ 1)

Test: compute max_a |S_q(a, L)| for various prime q and L, fit:
  max_a |S_q(a, L)| ~ N_φ^{1 - δ(q, L)}
If δ > 0 polynomially in N_φ (i.e., L), DI-grade savings present empirically.

This is genuinely the path Phase-22 5 specialists missed entirely.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent


def support_pairs(L):
    pairs = []
    log2_3 = math.log2(3)
    for k in range(L + 1):
        max_ell = int((L - k) / log2_3)
        for ell in range(max_ell + 1):
            pairs.append((k, ell))
    return pairs


def compute_S_qa(q, a, pairs):
    """S_q(a, L) = Σ e_q(a · 2^k · 3^ℓ) over pairs."""
    s = complex(0)
    for (k, ell) in pairs:
        n = (a * pow(2, k, q) * pow(3, ell, q)) % q
        s += complex(math.cos(2 * math.pi * n / q), math.sin(2 * math.pi * n / q))
    return s


def max_a_S_q(q, L, sample_a=None):
    """Max over a ∈ (Z/q)* of |S_q(a, L)|. If sample_a not None, sample only those a values."""
    pairs = support_pairs(L)
    N_phi = len(pairs)

    if sample_a is None:
        # Test all a ∈ (Z/q)*
        candidates = [a for a in range(1, q) if math.gcd(a, q) == 1]
    else:
        # Sample uniformly random a's coprime to q
        import random
        rng = random.Random(42)
        candidates = []
        attempts = 0
        while len(candidates) < sample_a and attempts < sample_a * 10:
            a = rng.randint(1, q - 1)
            if math.gcd(a, q) == 1:
                candidates.append(a)
            attempts += 1

    max_S = 0
    max_a_val = None
    for a in candidates:
        S = compute_S_qa(q, a, pairs)
        absS = abs(S)
        if absS > max_S:
            max_S = absS
            max_a_val = a

    return max_S, max_a_val, N_phi, len(candidates)


def main():
    print("R638 — Bombieri Deshouillers-Iwaniec + Jacobi sums diagnostic")
    print("=" * 65)
    print("\nQuestion: max_a |S_q(a, L)| = Σ e_q(a·2^k·3^ℓ) ~ N_phi^(1-δ)?")
    print("If δ > 0 empirically, Kloosterman-grade cancellation present.\n")

    test_primes = [5, 11, 31, 101, 503, 1009, 5003]
    test_Ls = [20, 30, 40]

    print(f"Test primes: {test_primes}")
    print(f"Test L values: {test_Ls}")
    print()

    results = {}

    for L in test_Ls:
        pairs = support_pairs(L)
        N_phi = len(pairs)
        print(f"\n=== L = {L} (N_φ = {N_phi}) ===")
        print(f"{'q':>6} {'max |S|':>10} {'|S|/N_φ':>10} {'log(N_φ)/log(|S|)':>20} {'δ_emp':>10}")

        L_results = []
        for q in test_primes:
            t0 = time.time()
            # For small q, test all a; for large q, sample
            if q <= 100:
                max_S, max_a, _, n_tested = max_a_S_q(q, L)
            else:
                max_S, max_a, _, n_tested = max_a_S_q(q, L, sample_a=200)
            elapsed = time.time() - t0

            ratio = max_S / N_phi if N_phi > 0 else 0
            # Fit |S| = N_phi^(1-δ): δ = 1 - log|S|/log N_phi
            if max_S > 1 and N_phi > 1:
                exponent = math.log(max_S) / math.log(N_phi)
                delta = 1 - exponent
            else:
                exponent = 0
                delta = 1

            print(f"{q:>6} {max_S:>10.3f} {ratio:>10.4f} {exponent:>20.4f} {delta:>10.4f}")
            L_results.append({
                "q": q,
                "max_S": float(max_S),
                "max_a": max_a,
                "ratio": float(ratio),
                "exponent": float(exponent),
                "delta_emp": float(delta),
                "n_tested": n_tested,
                "elapsed_sec": elapsed,
            })
        results[L] = L_results

    # Scaling analysis: does δ stay positive across L? Does δ depend on q?
    print("\n" + "=" * 65)
    print("=== Cross-L scaling for δ_emp(q, L) ===\n")
    print(f"{'q':>6}", end="")
    for L in test_Ls:
        print(f" {'δ@L='+str(L):>10}", end="")
    print()
    for q in test_primes:
        print(f"{q:>6}", end="")
        for L in test_Ls:
            r = next(x for x in results[L] if x["q"] == q)
            print(f" {r['delta_emp']:>10.4f}", end="")
        print()

    # Verdict
    print("\n=== Verdict ===\n")
    # Mean delta across all (q, L)
    all_deltas = [r["delta_emp"] for L in test_Ls for r in results[L]]
    mean_delta = np.mean(all_deltas)
    min_delta = min(all_deltas)
    max_delta = max(all_deltas)
    print(f"Mean δ_emp across all (q, L) tested: {mean_delta:.4f}")
    print(f"Range: [{min_delta:.4f}, {max_delta:.4f}]")

    if mean_delta > 0.1:
        verdict = "DI_KLOOSTERMAN_GRADE_CANCELLATION_PRESENT"
        print(f"VERDICT: {verdict}")
        print(f"  Mean δ ≈ {mean_delta:.3f} > 0.1 — empirical Kloosterman-grade cancellation present.")
        print(f"  → Deshouillers-Iwaniec 1982 framework applies to ⟨2,3⟩ mod q.")
        print(f"  → Genuine new attack vector for Conjecture B'' (Bombieri GOLD D).")
    elif mean_delta > 0.02:
        verdict = "PARTIAL_DI_CANCELLATION"
        print(f"VERDICT: {verdict}")
        print(f"  Mean δ ≈ {mean_delta:.3f} ∈ (0.02, 0.1) — partial cancellation present.")
        print(f"  → DI 1982 framework plausibly applies; needs theoretical confirmation.")
    else:
        verdict = "NO_KLOOSTERMAN_CANCELLATION"
        print(f"VERDICT: {verdict}")
        print(f"  Mean δ ≈ {mean_delta:.3f} ≤ 0.02 — no significant Kloosterman cancellation.")
        print(f"  → Bombieri's DI attack vector NOT empirically supported.")

    out = ROOT / "r638_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 23 R638 — Bombieri DI Kloosterman + Jacobi sums diagnostic",
        "test_primes": test_primes,
        "test_Ls": test_Ls,
        "results": {str(L): results[L] for L in test_Ls},
        "mean_delta": float(mean_delta),
        "min_delta": float(min_delta),
        "max_delta": float(max_delta),
        "verdict": verdict,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
