# Local Compile Verification — Paper 1

Date: 2026-05-13
Operator: Jared Wilder
Toolchain: TeX Live 2026 via `texlive/texlive:latest` Docker image
Host: Windows 11 (compile inside Linux container, mount of project dir)

## Result

- 3-pass `pdflatex` compile: exit 0 on every pass
- PDF: `01_SUBGROUP_OBSTRUCTION_CALCULUS_SUBMISSION_DRAFT.pdf` — 8 pages, 254,587 bytes
- Final pass: zero `undefined`/`warning`/`error`/`missing` matches in log
- All cross-references (`T:finite`, `L:fiber`, `L:crt`, `T:moments`) resolved
- Bibliography (3 standard references) typeset

## Diff vs prior Linux-side compile

- Patched 3 section headers with `\texorpdfstring{math}{plain}` to silence cosmetic
  `hyperref` Unicode warnings on PDF bookmark generation:
  - L315: `\section{Moments over m}`
  - L396: `\section{Specialization to a=2,b=3}`
  - L474: `\subsection{No obstruction when Γ_q = F_q*}`
- No content changes; bookmark labels now render cleanly in PDF viewers.

## Repro

```powershell
docker run --rm -v "${PWD}:/work" -w /work texlive/texlive:latest sh -c "
  pdflatex -interaction=nonstopmode -halt-on-error 01_SUBGROUP_OBSTRUCTION_CALCULUS_SUBMISSION_DRAFT.tex
  pdflatex -interaction=nonstopmode -halt-on-error 01_SUBGROUP_OBSTRUCTION_CALCULUS_SUBMISSION_DRAFT.tex
  pdflatex -interaction=nonstopmode -halt-on-error 01_SUBGROUP_OBSTRUCTION_CALCULUS_SUBMISSION_DRAFT.tex
"
```

## Status

Paper 1 is **journal-submission-ready** and **arXiv-upload-ready** (pending math.NT endorsement).
