"""R604 — Empirical Gowers U^3 / U^2 ratio for the (2,3)-orbit indicator.

Round-2 Gowers specialist prediction (50% confidence):
- Heisenberg pathway requires U^3 < c * U^2 with q-decay
- If U^3 ≈ U^2 within 5% with no q-decay → β refuted empirically

For prime q, let f(n) = 1[n ∈ <2,3> mod q] - |H_q|/q (mean-zero indicator).

Compute:
- ||f||_U^2^4 = (1/q^3) sum_{x, h_1, h_2} f(x) f(x+h_1) f(x+h_2) f(x+h_1+h_2)
- ||f||_U^3^8 = (1/q^4) sum_{x, h_1, h_2, h_3} prod_{ε ∈ {0,1}^3} f(x + ε·h)

For q up to ~30: U^3 doable in O(q^4) = ~10^6 ops. For q=50: 6.25e6. Fast.

If empirical U^3 ≈ U^2 → β refuted, attack vector (β) dies cleanly.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

Q_LIST = [17, 23, 29, 41, 53, 67, 79, 97]  # 8 primes from 17 to 97


def orbit_mod_p(p):
    """Compute <2, 3> mod p via BFS."""
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def gowers_u2(f, q):
    """Compute ||f||_U^2^4 = (1/q^3) sum_{x, h1, h2} f(x) f(x+h1) f(x+h2) f(x+h1+h2)."""
    # Use FFT identity: ||f||_U^2^4 = (1/q) sum_xi |\hat{f}(xi)|^4
    # where \hat{f}(xi) = sum_x f(x) e_q(-x xi) / sqrt(q)
    F = np.fft.fft(f) / math.sqrt(q)
    return float(np.sum(np.abs(F) ** 4) / q)


def gowers_u3(f, q):
    """Compute ||f||_U^3^8 by direct enumeration over (x, h_1, h_2, h_3)."""
    total = 0.0
    for h1 in range(q):
        for h2 in range(q):
            for h3 in range(q):
                # Product f(x) f(x+h1) f(x+h2) f(x+h3) f(x+h1+h2) f(x+h1+h3) f(x+h2+h3) f(x+h1+h2+h3) summed over x
                p1 = f[h1]  # f(0+h1)
                # Actually we need sum over x; do it vectorized
                pass
    # Use FFT for U^3 too: more complex formula
    # ||f||_U^3^8 = (1/q^2) sum_{xi_1, xi_2} |sum_xi \hat{f}(xi) \hat{f}(xi+xi_1) \hat{f}(xi+xi_2)|^2  (one form)
    # Simpler: direct enumeration
    f_arr = np.array(f, dtype=np.float64)
    total = 0.0
    # For each (h1, h2, h3), compute g(x) = f(x) f(x+h1) f(x+h2) f(x+h3) f(x+h1+h2) f(x+h1+h3) f(x+h2+h3) f(x+h1+h2+h3)
    # and sum over x. Then sum (1/q^4) sum_{h1, h2, h3, x} g.
    # Equivalent to (1/q^4) sum_{h1, h2, h3} [sum_x f(x) f(x+h1) f(x+h2) f(x+h3) f(x+h1+h2) f(x+h1+h3) f(x+h2+h3) f(x+h1+h2+h3)]
    # For each (h1, h2, h3), the inner sum is a convolution-like quantity.
    # Use vectorization: precompute shifts.
    for h1 in range(q):
        for h2 in range(q):
            for h3 in range(q):
                # Indices for x: 0..q-1
                # shift by h1, h2, h3, h1+h2, h1+h3, h2+h3, h1+h2+h3 (all mod q)
                v0 = f_arr  # x
                v1 = np.roll(f_arr, -h1)  # x + h1
                v2 = np.roll(f_arr, -h2)  # x + h2
                v3 = np.roll(f_arr, -h3)  # x + h3
                v12 = np.roll(f_arr, -((h1 + h2) % q))
                v13 = np.roll(f_arr, -((h1 + h3) % q))
                v23 = np.roll(f_arr, -((h2 + h3) % q))
                v123 = np.roll(f_arr, -((h1 + h2 + h3) % q))
                prod = v0 * v1 * v2 * v3 * v12 * v13 * v23 * v123
                total += prod.sum()
    return float(total / (q ** 4))


def main():
    print("R604 — Gowers U^3 / U^2 ratio for orbit indicator\n")
    print(f"Q_LIST = {Q_LIST}\n")

    results = {}
    t0 = time.time()
    for q in Q_LIST:
        t1 = time.time()
        # Build orbit indicator (mean-zero)
        orbit = orbit_mod_p(q)
        mean = len(orbit) / q
        f = np.array([1.0 - mean if i in orbit else -mean for i in range(q)])

        U2_4 = gowers_u2(f, q)  # U^2^4
        U3_8 = gowers_u3(f, q)  # U^3^8

        # Take 1/4 and 1/8 roots
        U2 = U2_4 ** (1/4) if U2_4 > 0 else 0
        U3 = U3_8 ** (1/8) if U3_8 > 0 else 0
        ratio = U3 / U2 if U2 > 0 else float('nan')

        elapsed = time.time() - t1
        results[q] = {"orbit_size": len(orbit), "U2": U2, "U3": U3, "ratio": ratio, "time": elapsed}
        print(f"  q={q:>3}: |O|={len(orbit):>3}  U^2={U2:.5f}  U^3={U3:.5f}  ratio U^3/U^2={ratio:.4f}  t={elapsed:.1f}s")

    print(f"\nTotal compute: {time.time() - t0:.1f}s\n")

    # Analyze
    ratios = [r["ratio"] for r in results.values() if not math.isnan(r["ratio"])]
    mean_ratio = float(np.mean(ratios))
    min_ratio = float(np.min(ratios))
    max_ratio = float(np.max(ratios))

    print("=== ANALYSIS ===")
    print(f"Mean U^3/U^2 ratio: {mean_ratio:.4f}")
    print(f"Min ratio:          {min_ratio:.4f}")
    print(f"Max ratio:          {max_ratio:.4f}")
    print(f"(Gowers specialist prediction: ratio ≈ 1.0 ± 5% → β-pathway REFUTED)")
    print()

    # q-decay regression
    log_q = np.log(np.array(Q_LIST, dtype=np.float64))
    log_U3 = np.array([math.log(results[q]["U3"]) if results[q]["U3"] > 0 else 0 for q in Q_LIST])
    log_U2 = np.array([math.log(results[q]["U2"]) if results[q]["U2"] > 0 else 0 for q in Q_LIST])

    slope_U3, _ = np.polyfit(log_q, log_U3, 1)
    slope_U2, _ = np.polyfit(log_q, log_U2, 1)
    slope_ratio = slope_U3 - slope_U2

    print(f"q-decay slope: U^2 ~ q^({slope_U2:+.3f}), U^3 ~ q^({slope_U3:+.3f})")
    print(f"Ratio decay: U^3/U^2 ~ q^({slope_ratio:+.3f})")
    print()

    # Verdict
    if abs(mean_ratio - 1.0) <= 0.05 and abs(slope_ratio) <= 0.01:
        verdict = "BETA_REFUTED_STRONGLY"
        msg = f"U^3/U^2 ≈ 1.0 ({mean_ratio:.3f}) with no q-decay. The Heisenberg/U^3 pathway is empirically a dead end."
    elif mean_ratio < 0.5 and slope_ratio < -0.05:
        verdict = "BETA_PARTIALLY_REVIVED"
        msg = f"U^3 is significantly smaller than U^2 with q-decay. The pathway may have legs."
    else:
        verdict = "AMBIGUOUS"
        msg = f"Ratio {mean_ratio:.3f}, slope {slope_ratio:.3f}. Partial signal."

    print(f"VERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r604_results.json"
    out.write_text(json.dumps({
        "Q_LIST": Q_LIST,
        "results": {str(q): r for q, r in results.items()},
        "mean_ratio": mean_ratio,
        "slope_ratio": slope_ratio,
        "verdict": verdict,
        "msg": msg,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
