# EXECUTION PLAN — FROM FINAL PACKET TO REAL OUTPUT

## Week 1: turn Paper 1 into submission form

1. Read `papers/01_SUBGROUP_OBSTRUCTION_CALCULUS.tex` line by line.
2. Verify all examples using `verification/verify_finite_examples.py`.
3. Add complete references:
   - finite abelian group character orthogonality;
   - elementary number theory text;
   - Iwaniec--Kowalski only as motivation if needed.
4. Decide journal:
   - Integers;
   - Journal of Number Theory;
   - Acta Arithmetica short note.
5. Compile and proofread PDF.
6. Send to one friendly mathematician or submit.

## Week 2: prepare Paper 2

1. Add diagrams:
   - CRT exponent lattice;
   - synchronization quotient;
   - projective slope collision.
2. Add one more local/global failure example.
3. Verify all discrete logs.
4. Decide whether to keep ratio-field material or split it.

## Parallel: expert outreach

Send `support/EXPERT_PACKET_HIGH_SEAM_PHNC.md`.

Classify responses:
- known theorem exists;
- impossible/false;
- stronger hypothesis needed;
- average-over-\(\ell\) theorem needed;
- novel/open;
- question misformulated.

## Month 1

- Submit Paper 1.
- Polish Paper 2.
- Use expert response to decide whether Paper 4 becomes stronger or remains conditional.

## Month 2+

- Density-zero paper only after exact Pappalardi/sieve functional is written.
- Conditional criterion only after arrows are formally stated.
