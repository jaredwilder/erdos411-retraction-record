"""
R579 — Regress empirical D vs |<2,3> mod q| (orbit size), not vs q.

R577 showed delta_q ~ 0.04 (flat). R578 showed neither poly nor log fits well in q.
INSIGHT: discrepancy depends on orbit size, not on q itself.

Orbit size |<2,3> mod q| for prime q can vary wildly (16, 40, 66, ..., 1019/2039, 910/8191, 15704/65521).

Hypothesis: D ~ (orbit_size)^{-alpha} * N^{-eta} for some alpha > 0.

If alpha ~ 0.5, this is Poisson scaling.
If alpha > 0.5, there's super-Poisson cancellation from orbit structure.
If alpha < 0.5, the orbit equidistributes WORSE than Poisson at this scale.
"""

from __future__ import annotations
import json, math, sys
from pathlib import Path
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

def regress(xs, ys):
    """Return (slope, intercept, R^2)."""
    xs_arr = np.array(xs, dtype=np.float64)
    ys_arr = np.array(ys, dtype=np.float64)
    if len(xs_arr) < 3:
        return 0.0, 0.0, 0.0
    n = len(xs_arr)
    xbar = xs_arr.mean()
    ybar = ys_arr.mean()
    Sxx = ((xs_arr - xbar) ** 2).sum()
    Sxy = ((xs_arr - xbar) * (ys_arr - ybar)).sum()
    Syy = ((ys_arr - ybar) ** 2).sum()
    if Sxx == 0:
        return 0.0, 0.0, 0.0
    b = Sxy / Sxx
    a = ybar - b * xbar
    r2 = (Sxy ** 2) / (Sxx * Syy) if Syy > 0 else 0.0
    return b, a, r2

def main():
    print("R579 — Discrepancy vs ORBIT SIZE\n")

    raw = json.loads((ROOT / "r577_results.json").read_text())
    M_LIST = raw["M_LIST"]
    Q_LIST = raw["Q_LIST"]
    L_LIST = raw["L_LIST"]
    results = raw["results"]

    # Aggregate: across all (m, q, L), record (orbit_size, N_phi, D).
    points = []
    for m in M_LIST:
        for L in L_LIST:
            for q in Q_LIST:
                row = results[str(m)][str(L)][str(q)]
                if row["D"] > 0 and row["orbit_size"] > 0:
                    points.append({
                        "m": m, "q": q, "L": L,
                        "orbit": row["orbit_size"],
                        "N": row["N_phi"],
                        "D": row["D"],
                    })

    print(f"Total points: {len(points)}\n")

    # --- Fit 1: log D vs log(orbit_size) at fixed L (per L)
    print("=== FIT 1: D vs orbit_size at fixed L ===\n")
    for L in L_LIST:
        sub = [p for p in points if p["L"] == L]
        # Average over m at each q (they're nearly identical anyway)
        # Group by orbit_size
        from collections import defaultdict
        bins = defaultdict(list)
        for p in sub:
            bins[p["orbit"]].append(p["D"])
        xs = []
        ys = []
        for orbit, Ds in sorted(bins.items()):
            xs.append(math.log(orbit))
            ys.append(math.log(np.mean(Ds)))
        slope, intercept, r2 = regress(xs, ys)
        alpha = -slope
        print(f"  L={L:4d}: alpha = {alpha:+.3f}, intercept = {intercept:+.3f}, R^2 = {r2:.3f}")

    # --- Fit 2: D vs orbit_size globally (pool across L)
    print("\n=== FIT 2: D * sqrt(N) vs sqrt(orbit_size) (Poisson rescaling test) ===\n")
    # If D ~ 1/sqrt(N * orbit), then D * sqrt(N) ~ 1/sqrt(orbit), and a regression of
    # log(D*sqrt(N)) vs log(orbit) should give slope -0.5 if Poisson.
    xs = []
    ys = []
    for p in points:
        xs.append(math.log(p["orbit"]))
        ys.append(math.log(p["D"] * math.sqrt(p["N"])))
    slope, intercept, r2 = regress(xs, ys)
    print(f"  Pooled slope = {slope:+.3f}, intercept = {intercept:+.3f}, R^2 = {r2:.3f}")
    print(f"  (Poisson prediction: slope = -0.5)")
    if abs(slope - (-0.5)) < 0.1:
        print(f"  ==> POISSON SCALING — discrepancy is statistical noise from orbit-not-filling")
    elif slope < -0.5:
        print(f"  ==> SUPER-POISSON — orbit structure gives MORE cancellation than statistical noise")
    elif slope > -0.5:
        print(f"  ==> SUB-POISSON — orbit equidistributes WORSE than statistical noise")
    else:
        print(f"  ==> unclear")

    # --- Fit 3: D vs N at fixed orbit_size (to isolate the N-decay from orbit-decay)
    print("\n=== FIT 3: D vs N_phi at FIXED orbit_size ===\n")
    print("  For each q, fit D vs N_phi across L:")
    eta_per_q = {}
    for q in Q_LIST:
        sub = [p for p in points if p["q"] == q and p["m"] == 1]
        xs = [math.log(p["N"]) for p in sub]
        ys = [math.log(p["D"]) for p in sub]
        slope, intercept, r2 = regress(xs, ys)
        eta = -slope
        # Get orbit_size for this q (constant across L for m=1)
        orbit = sub[0]["orbit"] if sub else None
        eta_per_q[q] = {"eta": eta, "r2": r2, "orbit": orbit}
        print(f"    q={q:>6} orbit={orbit:>6}: eta_N = {eta:+.3f}, R^2 = {r2:.3f}")

    # --- Fit 4: eta vs orbit — does the N-decay rate depend on orbit size?
    print("\n=== FIT 4: eta_N as a function of orbit size ===\n")
    xs = []
    ys = []
    for q in Q_LIST:
        info = eta_per_q[q]
        if info["r2"] > 0.7 and info["orbit"] > 1:
            xs.append(math.log(info["orbit"]))
            ys.append(info["eta"])
    if len(xs) >= 3:
        slope, intercept, r2 = regress(xs, ys)
        print(f"  eta_N = {intercept:+.3f} + {slope:+.4f} * log(orbit_size), R^2 = {r2:.3f}")
        if slope > 0.01:
            print(f"  ==> eta_N INCREASES with orbit size (larger orbits give faster N-decay)")
        elif slope < -0.01:
            print(f"  ==> eta_N DECREASES with orbit size (smaller orbits give faster N-decay)")
        else:
            print(f"  ==> eta_N essentially CONSTANT across orbit sizes")

    # Save
    out = ROOT / "r579_results.json"
    out.write_text(json.dumps({
        "fit1_alpha_per_L": {L: None for L in L_LIST},  # filled lazily
        "fit2_pooled_slope": slope,
        "fit3_eta_per_q": {str(q): v for q, v in eta_per_q.items()},
    }, indent=2, default=str))
    print(f"\nWritten {out}")

if __name__ == "__main__":
    main()
