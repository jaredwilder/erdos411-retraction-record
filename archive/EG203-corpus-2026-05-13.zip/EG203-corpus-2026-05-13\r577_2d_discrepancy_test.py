"""
R577 — Pre-registered ZENITH falsification test for Manuscript v4 §5.4 redirect.

Computes the 2D weighted discrepancy
    D_tilde_N^w(q, m) := max_a |C(a)/N_phi - 1/|m*O_q||
where:
    C(a) = sum over (k, l) with 2^k 3^l <= 2^L of phi(k, l) * 1[(2^k 3^l m) mod q == a]
    phi(k, l) = rho(k/L) * rho(l*log2(3)/L), rho = Hann window
    m*O_q = m * <2, 3> mod q
    N_phi = sum phi

For each m in M_LIST, q in Q_LIST, L in L_LIST, output D_tilde.
Then fit decay rates delta_q (q direction) and eta_N (N direction).

Pre-registered verdict gates in R577-PRE-REGISTRATION.md.

Runtime estimate: <30 min on a laptop.
"""

from __future__ import annotations
import json, math, sys, time
from pathlib import Path
from typing import Dict, List, Tuple
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

# ============================================================
# CONFIG (LOCKED per pre-registration)
# ============================================================
M_LIST = [1, 5, 7, 11, 13, 25, 49, 77, 175, 78557]
# Primes near powers of 2 from 16 to 65536, all coprime to 6.
# (Original draft used q=2^j which collapses the orbit since 2^k=0 mod 2^j for k>=j.)
Q_LIST = [17, 41, 67, 127, 257, 509, 1021, 2039, 4093, 8191, 16381, 32749, 65521]
L_LIST = [50, 100, 200, 400]  # support cap 2^L

LOG2_3 = math.log2(3.0)

# ============================================================
# HELPERS
# ============================================================
def hann(x: float) -> float:
    """Hann window on [0, 1]: rho(x) = cos^2(pi x/2). Vanishes at x=1, peak at x=0."""
    if x < 0 or x > 1:
        return 0.0
    return math.cos(math.pi * x / 2.0) ** 2

def enumerate_support(L: int) -> List[Tuple[int, int]]:
    """Return all (k, l) with k + l*log2(3) <= L, k >= 0, l >= 0."""
    pts = []
    for k in range(L + 1):
        lmax = math.floor((L - k) / LOG2_3)
        for l in range(lmax + 1):
            pts.append((k, l))
    return pts

def discrepancy_for_m_q_L(m: int, q: int, L: int) -> Tuple[float, int, float]:
    """
    Compute D_tilde_N^w(q, m) at scale L.
    Returns (D_tilde, orbit_size, N_phi).
    """
    pts = enumerate_support(L)

    # Compute b(k, l) = 2^k 3^l m mod q using running multiplication (avoid bignums on hot path)
    # First compute b for all (k, l) via a 1D array of 2^k mod q, then walk l
    # 2^k mod q: precompute up to k_max = L
    pow2 = [1] * (L + 1)
    for k in range(1, L + 1):
        pow2[k] = (pow2[k-1] * 2) % q
    # 3^l mod q: precompute up to l_max = ceil(L/log2(3)) = L
    pow3 = [1] * (L + 1)
    for l in range(1, L + 1):
        pow3[l] = (pow3[l-1] * 3) % q
    m_mod = m % q

    # Bin sum of weights by residue a in [0, q)
    C = np.zeros(q, dtype=np.float64)
    N_phi = 0.0
    for (k, l) in pts:
        # Weight
        w = hann(k / L) * hann((l * LOG2_3) / L)
        if w == 0.0:
            continue
        # Residue
        a = (pow2[k] * pow3[l] * m_mod) % q
        C[a] += w
        N_phi += w

    if N_phi == 0.0:
        return 0.0, 0, 0.0

    # Compute orbit m*O_q (orbit of m under <2,3>): set of (2^k 3^l m) mod q
    orbit = set()
    for k in range(L + 1):
        for l in range(L + 1):
            orbit.add((pow2[k] * pow3[l] * m_mod) % q)
            if len(orbit) >= q:
                break
        if len(orbit) >= q:
            break
    orbit_size = len(orbit)

    # Discrepancy: max_a in orbit of |C(a)/N_phi - 1/orbit_size|
    target = 1.0 / orbit_size
    D = 0.0
    for a in orbit:
        D_a = abs(C[a] / N_phi - target)
        if D_a > D:
            D = D_a

    return D, orbit_size, N_phi

def regress_loglog(xs: List[float], ys: List[float]) -> Tuple[float, float, float]:
    """Fit log(y) = a + b*log(x). Return (slope=-b is the 'decay rate'), R^2."""
    # Filter zeros
    xs2, ys2 = [], []
    for x, y in zip(xs, ys):
        if x > 0 and y > 0:
            xs2.append(math.log(x))
            ys2.append(math.log(y))
    if len(xs2) < 3:
        return 0.0, 0.0, 0.0
    xs_arr = np.array(xs2)
    ys_arr = np.array(ys2)
    n = len(xs_arr)
    xbar = xs_arr.mean()
    ybar = ys_arr.mean()
    Sxx = ((xs_arr - xbar) ** 2).sum()
    Sxy = ((xs_arr - xbar) * (ys_arr - ybar)).sum()
    Syy = ((ys_arr - ybar) ** 2).sum()
    if Sxx == 0:
        return 0.0, 0.0, 0.0
    b = Sxy / Sxx
    a = ybar - b * xbar
    r2 = (Sxy ** 2) / (Sxx * Syy) if Syy > 0 else 0.0
    # We want decay rate = -b (so positive means decay).
    return -b, a, r2

# ============================================================
# MAIN
# ============================================================
def main():
    print("R577 — 2D weighted discrepancy empirical test")
    print(f"M_LIST = {M_LIST}")
    print(f"Q_LIST = {Q_LIST[0]} .. {Q_LIST[-1]} ({len(Q_LIST)} values)")
    print(f"L_LIST = {L_LIST}")
    print()

    results: Dict = {}
    t0 = time.time()

    for m in M_LIST:
        print(f"--- m = {m} ---")
        results[m] = {}
        for L in L_LIST:
            t1 = time.time()
            row = {}
            for q in Q_LIST:
                D, orbit_size, N_phi = discrepancy_for_m_q_L(m, q, L)
                row[q] = {"D": D, "orbit_size": orbit_size, "N_phi": N_phi}
            results[m][L] = row
            elapsed = time.time() - t1
            # Print summary row
            D_vals = [row[q]["D"] for q in Q_LIST]
            print(f"  L={L:4d} t={elapsed:5.1f}s  D range: {min(D_vals):.4e} .. {max(D_vals):.4e}")

    print(f"\nTotal compute: {time.time() - t0:.1f}s")

    # ============================================================
    # FIT DECAY RATES
    # ============================================================
    print("\n=== DECAY RATE FITS ===\n")
    fits: Dict = {}
    for m in M_LIST:
        fits[m] = {}
        print(f"m = {m}:")

        # Per-L: regress D vs q
        delta_qs = []
        r2_qs = []
        for L in L_LIST:
            Ds = [results[m][L][q]["D"] for q in Q_LIST]
            slope, intercept, r2 = regress_loglog(Q_LIST, Ds)
            fits[m][f"delta_q_L{L}"] = {"slope": slope, "r2": r2}
            delta_qs.append(slope)
            r2_qs.append(r2)
            print(f"  L={L:4d}: delta_q = {slope:+.3f}, R^2 = {r2:.3f}")

        # Per-q: regress D vs N_phi
        eta_Ns = []
        r2_Ns = []
        for q in Q_LIST:
            Ds = [results[m][L][q]["D"] for L in L_LIST]
            Ns = [results[m][L][q]["N_phi"] for L in L_LIST]
            slope, intercept, r2 = regress_loglog(Ns, Ds)
            fits[m][f"eta_N_q{q}"] = {"slope": slope, "r2": r2}
            eta_Ns.append(slope)
            r2_Ns.append(r2)

        # Summary per m
        delta_q_mean = float(np.mean(delta_qs))
        eta_N_mean = float(np.mean(eta_Ns))
        delta_q_r2_mean = float(np.mean(r2_qs))
        eta_N_r2_mean = float(np.mean(r2_Ns))
        fits[m]["summary"] = {
            "delta_q_mean": delta_q_mean,
            "eta_N_mean": eta_N_mean,
            "delta_q_r2_mean": delta_q_r2_mean,
            "eta_N_r2_mean": eta_N_r2_mean,
        }
        print(f"  AVG delta_q = {delta_q_mean:+.3f} (R^2 avg {delta_q_r2_mean:.3f}), AVG eta_N = {eta_N_mean:+.3f} (R^2 avg {eta_N_r2_mean:.3f})")
        print()

    # ============================================================
    # PRE-REGISTERED VERDICT
    # ============================================================
    print("\n=== PRE-REGISTERED VERDICT GATE APPLICATION ===\n")

    pass_count = 0
    fail_count = 0
    detail = []
    delta_q_means = []
    eta_N_means = []
    for m in M_LIST:
        s = fits[m]["summary"]
        delta_q_means.append(s["delta_q_mean"])
        eta_N_means.append(s["eta_N_mean"])
        # PASS criteria: delta_q in [0.1, 1.0], eta_N in [0.1, 1.0], BOTH R^2 >= 0.85
        passed = (
            0.1 <= s["delta_q_mean"] <= 1.0 and
            0.1 <= s["eta_N_mean"] <= 1.0 and
            s["delta_q_r2_mean"] >= 0.85 and
            s["eta_N_r2_mean"] >= 0.85
        )
        # FAIL criteria: flat (both rates near zero)
        failed = (
            abs(s["delta_q_mean"]) < 0.05 and
            abs(s["eta_N_mean"]) < 0.05
        )
        if passed:
            pass_count += 1
            detail.append(f"  m={m}: PASS")
        elif failed:
            fail_count += 1
            detail.append(f"  m={m}: FAIL (flat)")
        else:
            detail.append(f"  m={m}: AMBIGUOUS")

    bar_delta_q = float(np.mean(delta_q_means))
    bar_eta_N = float(np.mean(eta_N_means))

    print(f"Per-m verdicts:")
    for line in detail:
        print(line)
    print()
    print(f"AVG bar_delta_q = {bar_delta_q:+.3f}")
    print(f"AVG bar_eta_N   = {bar_eta_N:+.3f}")
    print(f"PASS count: {pass_count}/10")
    print(f"FAIL count: {fail_count}/10")
    print()

    # Apply locked gates
    if pass_count >= 7 and bar_delta_q > 0.2 and bar_eta_N > 0.2:
        verdict = "PASS"
    elif fail_count >= 4 or (bar_delta_q < 0.05 and bar_eta_N < 0.05):
        verdict = "FAIL"
    else:
        verdict = "AMBIGUOUS"
    print(f"OVERALL VERDICT: {verdict}")

    # ============================================================
    # WRITE OUTPUT
    # ============================================================
    out = ROOT / "r577_results.json"
    payload = {
        "M_LIST": M_LIST,
        "Q_LIST": Q_LIST,
        "L_LIST": L_LIST,
        "results": {
            str(m): {str(L): {str(q): v for q, v in results[m][L].items()}
                     for L in L_LIST}
            for m in M_LIST
        },
        "fits": {str(m): fits[m] for m in M_LIST},
        "summary": {
            "pass_count": pass_count,
            "fail_count": fail_count,
            "bar_delta_q": bar_delta_q,
            "bar_eta_N": bar_eta_N,
            "verdict": verdict,
        }
    }
    out.write_text(json.dumps(payload, indent=2, default=str))
    print(f"\nWritten {out}")

if __name__ == "__main__":
    main()
