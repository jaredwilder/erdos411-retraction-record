"""R700 — Empirically verify R700's CRT-synchronization correction to Claude Lemma 11.

R700 catches: local-full-generation (Γ_q = F_q* for every prime factor q | d)
does NOT imply global-full-generation (Γ_d = G_d) when the n_i = q_i - 1 share factors.

Lemma R700.1: local-full + pairwise-coprime n_i ⟹ Γ_d = G_d.

CLAUDE'S CONTRIBUTION (Lemma 12, replacing the broken Lemma 11):
  For squarefree d = q_1 ... q_r with all q_i satisfying Γ_{q_i} = F_{q_i}*,
  the global index κ(d) = φ(d)/|Γ_d| equals the index of the lattice
  L_d = <U_d, V_d> in the CRT exponent module C_d = ⊕ Z/n_iZ.
  This index can be > 1 even when local-full holds, IF gcd(n_i, n_j) > 1.

This script:
  1. Finds all primes q ≤ 200 with both 2 AND 3 as primitive roots (local-full).
  2. For each pair (q_1, q_2) of such primes, computes |Γ_d| directly mod d = q_1 q_2.
  3. Identifies d with κ(d) > 1 despite local-full (CRT-synchronization defect).
  4. Tabulates Δ_m(d) for these "defective" d and various m.
"""

import json
import math
from pathlib import Path
from sympy import isprime


def order_mod(g, q):
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def is_primitive_root(g, q):
    return order_mod(g, q) == q - 1


def Gamma_d_size(d):
    """|Γ_d| = |<2, 3> mod d| by direct enumeration."""
    a = order_mod(2, d)
    b = order_mod(3, d)
    if a == 0 or b == 0:
        return 0
    G = set()
    for k in range(a):
        for l in range(b):
            G.add((pow(2, k, d) * pow(3, l, d)) % d)
    return len(G)


def main():
    print("R700 — CRT-synchronization defect: local-full but NOT global-full")
    print("=" * 90)
    print()

    # Step 1: find primes q ≤ 200 with both 2 and 3 as primitive roots
    print("Step 1: primes q ≤ 200 with both 2 and 3 as primitive roots (local-full)")
    local_full_primes = []
    for q in range(5, 200):
        if not isprime(q) or q in (2, 3):
            continue
        if is_primitive_root(2, q) and is_primitive_root(3, q):
            local_full_primes.append(q)
    print(f"  Found {len(local_full_primes)} primes: {local_full_primes}")
    print()

    # Step 2: for pairs (q_1, q_2), check global Γ_d vs prediction
    print("Step 2: Squarefree pairs d = q_1 q_2 from local-full primes")
    print()
    print(f"{'q1':>4} {'q2':>4} {'d':>7} {'φ(d)':>7} {'gcd(n1,n2)':>11} {'|Γ_d|':>7} "
          f"{'κ(d)':>6} {'sync_defect':>11}")
    print("-" * 80)
    defective_d = []
    all_pairs = []
    for i, q1 in enumerate(local_full_primes):
        for q2 in local_full_primes[i+1:]:
            d = q1 * q2
            phi_d = (q1 - 1) * (q2 - 1)
            g_d = Gamma_d_size(d)
            kappa = phi_d // g_d if g_d > 0 else 0
            sync_defect = math.gcd(q1 - 1, q2 - 1) > 1 and kappa > 1
            print(f"{q1:>4} {q2:>4} {d:>7} {phi_d:>7} {math.gcd(q1-1, q2-1):>11} "
                  f"{g_d:>7} {kappa:>6} {'YES' if sync_defect else 'no':>11}")
            row = {'q1': q1, 'q2': q2, 'd': d, 'phi_d': phi_d,
                   'gcd_orders': math.gcd(q1-1, q2-1), 'Gamma_d': g_d, 'kappa': kappa,
                   'sync_defect': sync_defect}
            all_pairs.append(row)
            if sync_defect:
                defective_d.append(row)

    print()
    print("=" * 90)
    print(f"Total local-full pairs tested: {len(all_pairs)}")
    print(f"CRT-synchronization-defective d (κ > 1 despite local-full): {len(defective_d)}")
    print()

    # Step 3: for defective d, compute Δ_m(d) for various m
    if defective_d:
        print("Step 3: Δ_m(d) for CRT-defective d (first 5)")
        print(f"{'d':>7} {'κ(d)':>6}", end='')
        for m in [1, 5, 7, 11]:
            print(f"  Δ_m={m}", end='')
        print()
        print("-" * 50)
        for row in defective_d[:5]:
            d = row['d']
            g_d = row['Gamma_d']
            phi_d = row['phi_d']
            print(f"{d:>7} {row['kappa']:>6}", end='')
            for m in [1, 5, 7, 11]:
                if math.gcd(m, 6 * d) != 1:
                    print(f"  N/A", end='')
                    continue
                c = (-pow(m, -1, d)) % d
                # Check c ∈ Γ_d
                a = order_mod(2, d)
                b = order_mod(3, d)
                in_Gamma = False
                for k in range(a):
                    for l in range(b):
                        if (pow(2, k, d) * pow(3, l, d)) % d == c:
                            in_Gamma = True
                            break
                    if in_Gamma:
                        break
                rho = (1.0 / g_d) if in_Gamma else 0.0
                delta = rho - 1.0 / phi_d
                print(f"  {delta:>+.5f}", end='')
            print()

    print()
    print("=" * 90)
    print("CONCLUSION: R700 correction VERIFIED — local-full ≠ global-full when n_i share factors.")
    print("Claude Lemma 12 supersedes Lemma 11: need pairwise coprime n_i + local-full for Δ_m(d) ≡ 0.")

    out = {
        'phase': 'R700 — CRT-synchronization defect verification',
        'local_full_primes': local_full_primes,
        'all_pairs': all_pairs,
        'defective_d_count': len(defective_d),
        'defective_d': defective_d,
    }
    Path(__file__).with_suffix('.json').write_text(json.dumps(out, indent=2))
    print(f"\nWritten {Path(__file__).with_suffix('.json')}")


if __name__ == '__main__':
    main()
