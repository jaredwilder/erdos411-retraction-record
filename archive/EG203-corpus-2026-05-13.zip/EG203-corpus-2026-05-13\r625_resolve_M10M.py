"""R625 — Resolve Iwaniec vs Pomerance asymptotic disagreement at M = 10⁷.

Iwaniec (Hooley scaling): Pr[m prime | inH=23, m ≤ 10⁷] ≈ 57.8% (a/log M with a≈9.3)
Pomerance (persistent): Pr ≈ 65-75% (asymptotic c > 0.235, plausibly ~0.8)

Empirical sweep across m ≤ 10⁷ coprime to 6 (3.33M m's). For each, compute inH count.
Tally primality fraction per inH cohort. Compare to Iwaniec/Pomerance predictions.

VERDICT:
- 55-60% at inH=23: Iwaniec wins (Hooley scaling)
- 65-75% at inH=23: Pomerance wins (persistent enrichment)
- Other: super-Hooley or new mechanism
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

PRIMES_LIST = list(sympy.primerange(5, 101))  # 23 primes


def orbit_mod_p(p):
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def main():
    print("R625 — Iwaniec vs Pomerance falsifier at M = 10⁷\n")
    print(f"Iwaniec prediction at inH=23: 57.8% (Hooley 9.3/log 10⁷)")
    print(f"Pomerance prediction at inH=23: 65-75% (persistent)\n")

    M_MAX = 10_000_000
    orbits = {p: orbit_mod_p(p) for p in PRIMES_LIST}

    # Group by inH and check primality
    print(f"Sweeping m ≤ {M_MAX} coprime to 6 + checking primality...")
    cohorts_size = {k: 0 for k in range(24)}
    cohorts_prime = {k: 0 for k in range(24)}

    t0 = time.time()
    n_processed = 0
    for m in range(1, M_MAX + 1):
        if math.gcd(m, 6) != 1:
            continue
        n_processed += 1
        cnt = 0
        for p in PRIMES_LIST:
            if math.gcd(m, p) == 1:
                m_inv = pow(m, -1, p)
                neg_m_inv = (-m_inv) % p
                if neg_m_inv in orbits[p]:
                    cnt += 1
        cohorts_size[cnt] += 1
        if sympy.isprime(m):
            cohorts_prime[cnt] += 1
        if n_processed % 500000 == 0:
            elapsed = time.time() - t0
            print(f"  [{n_processed}/3,333,333] m={m:>8} elapsed {elapsed:.0f}s")

    elapsed_total = time.time() - t0
    print(f"\nTotal compute: {elapsed_total:.0f}s\n")

    # Aggregate
    print("=== inH COHORTS at M = 10⁷ ===")
    print(f"{'inH':>4} {'size':>10} {'primes':>10} {'prime%':>10} {'enrichment':>12}")
    baseline = sum(cohorts_prime.values()) / sum(cohorts_size.values()) if sum(cohorts_size.values()) > 0 else 0
    print(f"  baseline (all m coprime to 6, prime fraction): {baseline*100:.2f}%")
    print()

    results = {}
    for k in range(24):
        sz = cohorts_size[k]
        pr = cohorts_prime[k]
        frac = pr / sz if sz > 0 else 0
        enrich = frac / baseline if baseline > 0 else 0
        if sz > 0:
            print(f"{k:>4} {sz:>10} {pr:>10} {frac*100:>9.2f}% {enrich:>11.2f}x")
            results[k] = {"size": sz, "primes": pr, "frac": frac, "enrichment": enrich}

    # FALSIFIER VERDICT
    if 23 in results:
        frac23 = results[23]["frac"]
        print(f"\n=== FALSIFIER VERDICT ===")
        print(f"Empirical Pr[prime | inH=23, m ≤ 10⁷] = {frac23*100:.2f}%")
        print(f"Iwaniec prediction (Hooley): 57.8%")
        print(f"Pomerance prediction (persistent): 65-75%")
        if 0.55 <= frac23 <= 0.60:
            verdict = "IWANIEC_WINS_HOOLEY"
            msg = f"Empirical {frac23*100:.1f}% matches Iwaniec Hooley a/log M prediction. Asymptotic decays as 1/log M."
        elif 0.65 <= frac23 <= 0.75:
            verdict = "POMERANCE_WINS_PERSISTENT"
            msg = f"Empirical {frac23*100:.1f}% matches Pomerance persistence prediction. Asymptotic enrichment persists with c > 0.235."
        elif frac23 < 0.50:
            verdict = "SUPER_HOOLEY"
            msg = f"Empirical {frac23*100:.1f}% below Iwaniec — faster than 1/log M decay."
        elif frac23 > 0.75:
            verdict = "SUPER_PERSISTENT"
            msg = f"Empirical {frac23*100:.1f}% above Pomerance — even stronger persistence."
        else:
            verdict = "BETWEEN_PREDICTIONS"
            msg = f"Empirical {frac23*100:.1f}% between Iwaniec (57.8%) and Pomerance (65-75%) — partial agreement."
        print(f"\nVERDICT: {verdict}")
        print(f"INTERPRETATION: {msg}")

    out = ROOT / "r625_results.json"
    out.write_text(json.dumps({
        "M_MAX": M_MAX,
        "baseline": baseline,
        "cohorts": {str(k): v for k, v in results.items()},
        "verdict": verdict if 23 in results else "no_inH_23_data",
        "msg": msg if 23 in results else "",
        "frac23": results[23]["frac"] if 23 in results else None,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
