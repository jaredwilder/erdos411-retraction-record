"""R651-JET — Jet-primitive Stepanov auxiliary certificate.

Operator's Oracle-reversal lesson: R651 ordinary kernel NEGATIVE identifies the correct
auxiliary class P = A·(X^a - 1) + B·(Y^b - 1) with (A, B) ≢ (0, 0) mod I_q.

For such P:
- P ≡ 0 mod I_q (so P vanishes ordinarily on V_q)
- D_X P ≡ a·A mod I_q (NONZERO in first jet quotient if A ≢ 0)
- D_Y P ≡ b·B mod I_q (NONZERO in first jet quotient if B ≢ 0)

The "jet-primitive" auxiliary IS the Stepanov auxiliary — component-divisible at the base
but nonzero in the jet quotient.

For each prime q:
  1. Compute a = ord_q(2), b = ord_q(3)
  2. Choose degree budgets for A, B (each in F_q[X, Y])
  3. Express constraints: jet vanishing of order r on bad subset B_q(m) (placeholder: V_q itself)
  4. Solve linear system over F_q
  5. Test if (A, B) ≢ (0, 0) mod I_q ⟺ at least one reduced monomial of A or B is nonzero
  6. If yes → jet-primitive certified

This is the empirical anchor for the corrected Gate 1: not "component-divisible = vacuous"
but "component-divisible + jet-primitive = correct auxiliary class."
"""
from __future__ import annotations
import json, math, sys
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent


def orbit_points(q):
    seen_x = []
    x = 1
    while True:
        seen_x.append(x)
        x = (x * 2) % q
        if x == 1:
            break
    seen_y = []
    y = 1
    while True:
        seen_y.append(y)
        y = (y * 3) % q
        if y == 1:
            break
    V_q = {(xv, yv) for xv in seen_x for yv in seen_y}
    return V_q, len(seen_x), len(seen_y)


def reduce_modulo_Iq(coefs_AB, monomials_A, monomials_B, a, b, q):
    """Reduce A and B modulo I_q = (X^a - 1, Y^b - 1).

    Reduction: X^i Y^j → X^{i mod a} Y^{j mod b}.
    Aggregate coefficients of monomials with same reduced exponents.

    Returns:
      reduced_A: dict (i_mod_a, j_mod_b) → coef
      reduced_B: dict (i_mod_a, j_mod_b) → coef
    """
    n_A = len(monomials_A)
    coefs_A = coefs_AB[:n_A]
    coefs_B = coefs_AB[n_A:]

    reduced_A = {}
    for k, (i, j) in enumerate(monomials_A):
        key = (i % a, j % b)
        reduced_A[key] = (reduced_A.get(key, 0) + coefs_A[k]) % q

    reduced_B = {}
    for k, (i, j) in enumerate(monomials_B):
        key = (i % a, j % b)
        reduced_B[key] = (reduced_B.get(key, 0) + coefs_B[k]) % q

    return reduced_A, reduced_B


def jet_primitivity_test(reduced_A, reduced_B):
    """Test if A ≢ 0 mod I_q OR B ≢ 0 mod I_q after reduction.

    Returns: (A_nontrivial, B_nontrivial)."""
    A_nontrivial = any(v != 0 for v in reduced_A.values())
    B_nontrivial = any(v != 0 for v in reduced_B.values())
    return A_nontrivial, B_nontrivial


def construct_and_certify(q, D_A, D_B, r=1, m_target=None):
    """Construct A, B with deg A ≤ D_A, deg B ≤ D_B such that P = A(X^a-1) + B(Y^b-1)
    has jet vanishing of order r on V_q (or on a target subset).

    Test jet-primitivity of the resulting P.

    Returns dict with certificate result."""
    V_q, a, b = orbit_points(q)

    # Monomials for A and B (separately)
    mon_A = [(i, j) for i in range(D_A + 1) for j in range(D_A + 1) if i + j <= D_A]
    mon_B = [(i, j) for i in range(D_B + 1) for j in range(D_B + 1) if i + j <= D_B]
    n_A = len(mon_A)
    n_B = len(mon_B)
    n_total = n_A + n_B

    # Bad subset: for now, use V_q itself.
    # In a real Stepanov gate, this would be a residue-failure slice.
    target_set = V_q  # all orbit points; can restrict later

    # Constraints: derivative of order < r vanishing on target_set
    # P = A(X^a - 1) + B(Y^b - 1)
    # D_X^j D_Y^k P evaluated at (x, y):
    #   = (D_X^j D_Y^k A)(x, y) · (x^a - 1)
    #     + a contribution from products of derivatives times derivative of (X^a - 1)
    # Since x^a = 1 on V_q (because (x, y) ∈ V_q ⊆ {X^a = 1}), the term (x^a - 1) = 0
    # AT V_q points. So at (x, y) ∈ V_q, P(x, y) = 0 automatically (gives no constraint).
    # For 1st-order: D_X P = (D_X A)(X^a - 1) + A · D_X(X^a - 1) + (D_X B)(Y^b - 1)
    # At V_q: (X^a - 1)|_{V_q} = 0 and (Y^b - 1)|_{V_q} = 0
    # D_X(X^a - 1) = a · X^{a-1}, so D_X(X^a - 1)|_x = a · x^{a-1}
    # In log-derivative form: D_X^log (X^a - 1) = a · X^a, evaluated at X^a = 1: = a
    # So D_X P at V_q = A(x, y) · a · x^{a-1} + 0 + 0 = a · x^{a-1} · A(x, y)
    # For the constraint D_X P = 0 at (x, y): A(x, y) = 0 (since a, x^{a-1} are nonzero mod q)
    # Similarly D_Y P = 0 forces B(x, y) = 0

    # SO: the jet constraints reduce to:
    #   For each (x, y) ∈ target_set and each derivative order (j, k) with j+k < r:
    #     - if (j, k) = (0, 0): P(x, y) = 0 — auto-satisfied
    #     - if j > 0: A(x, y) (and derivatives) = 0
    #     - if k > 0: B(x, y) (and derivatives) = 0
    # For r = 1: only (0, 0), auto-satisfied → NO constraints, ANY A, B works
    # For r = 2: need D_X P = 0 (gives A(x, y) = 0) and D_Y P = 0 (gives B(x, y) = 0)
    #            AND D_X D_Y P = 0 (gives mixed constraint)

    # For r = 1 (ordinary vanishing only): no constraints, P is automatically zero on V_q
    # → trivially "jet-primitive" since A, B free

    # For r = 2: A must vanish on V_q, B must vanish on V_q
    # This is the meaningful constraint

    if r < 2:
        # No constraints — A, B free. Trivially jet-primitive if any of them nonzero.
        coefs_AB = [0] * n_total
        coefs_AB[0] = 1  # Take A = 1
        reduced_A, reduced_B = reduce_modulo_Iq(coefs_AB, mon_A, mon_B, a, b, q)
        A_nt, B_nt = jet_primitivity_test(reduced_A, reduced_B)
        return {
            "q": q, "a": a, "b": b, "V_q_size": len(V_q),
            "D_A": D_A, "D_B": D_B, "r": r,
            "n_constraints": 0,
            "found": True,
            "A_nontrivial": A_nt, "B_nontrivial": B_nt,
            "jet_primitive_certified": A_nt or B_nt,
        }

    # For r >= 2: build constraint matrix
    # Each constraint: A(x, y) = 0 for (x, y) ∈ V_q with one derivative order > 0
    # Plus similar for B
    # And higher derivative constraints

    rows = []
    for (xv, yv) in target_set:
        for total_order in range(1, r):  # j + k = 1, 2, ..., r-1
            for j in range(total_order + 1):
                k = total_order - j
                # D_X^j D_Y^k P = a · D_X^{j-1} (something)  — complicated, simplify
                # For first-order j=1, k=0: D_X P = a · A(x, y)
                # For first-order j=0, k=1: D_Y P = b · B(x, y)
                if j == 1 and k == 0:
                    # constraint: A(x, y) = 0
                    row = [0] * n_total
                    for idx, (mi, mj) in enumerate(mon_A):
                        row[idx] = (pow(xv, mi, q) * pow(yv, mj, q)) % q
                    rows.append(row)
                elif j == 0 and k == 1:
                    # constraint: B(x, y) = 0
                    row = [0] * n_total
                    for idx, (mi, mj) in enumerate(mon_B):
                        row[n_A + idx] = (pow(xv, mi, q) * pow(yv, mj, q)) % q
                    rows.append(row)
                # Higher orders: skip for now (would need more careful derivative analysis)

    n_rows = len(rows)
    if n_rows >= n_total:
        return {
            "q": q, "a": a, "b": b, "V_q_size": len(V_q),
            "D_A": D_A, "D_B": D_B, "r": r,
            "n_constraints": n_rows, "n_unknowns": n_total,
            "found": False, "reason": "too many constraints",
        }

    # Gaussian elimination
    rows = [row[:] for row in rows]
    pivot_row = [None] * n_total
    cur = 0
    for c in range(n_total):
        if cur >= n_rows:
            break
        pivot = None
        for s in range(cur, n_rows):
            if rows[s][c] % q != 0:
                pivot = s
                break
        if pivot is None:
            continue
        rows[cur], rows[pivot] = rows[pivot], rows[cur]
        inv = pow(rows[cur][c], -1, q)
        rows[cur] = [(v * inv) % q for v in rows[cur]]
        for s in range(n_rows):
            if s != cur and rows[s][c] % q != 0:
                f = rows[s][c]
                rows[s] = [(rows[s][k] - f * rows[cur][k]) % q for k in range(n_total)]
        pivot_row[c] = cur
        cur += 1

    free = [c for c in range(n_total) if pivot_row[c] is None]
    if not free:
        return {
            "q": q, "a": a, "b": b, "V_q_size": len(V_q),
            "D_A": D_A, "D_B": D_B, "r": r,
            "n_constraints": n_rows, "n_unknowns": n_total,
            "found": False, "reason": "no free variables",
        }

    coefs_AB = [0] * n_total
    coefs_AB[free[0]] = 1
    for c in range(n_total):
        if pivot_row[c] is not None:
            coefs_AB[c] = (-rows[pivot_row[c]][free[0]]) % q

    reduced_A, reduced_B = reduce_modulo_Iq(coefs_AB, mon_A, mon_B, a, b, q)
    A_nt, B_nt = jet_primitivity_test(reduced_A, reduced_B)

    return {
        "q": q, "a": a, "b": b, "V_q_size": len(V_q),
        "D_A": D_A, "D_B": D_B, "r": r,
        "n_constraints": n_rows, "n_unknowns": n_total,
        "found": True,
        "A_nontrivial": A_nt, "B_nontrivial": B_nt,
        "jet_primitive_certified": A_nt or B_nt,
        "reduced_A_size": len([v for v in reduced_A.values() if v != 0]),
        "reduced_B_size": len([v for v in reduced_B.values() if v != 0]),
    }


def main():
    print("R651-JET — Jet-primitive Stepanov auxiliary certificate")
    print("=" * 70)
    print("Construction: P = A(X^a - 1) + B(Y^b - 1)")
    print("Test: (A, B) ≢ (0, 0) mod I_q ⟺ D_X P or D_Y P nonzero in jet quotient\n")

    primes = [5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41]

    print(f"{'q':>4} {'a':>4} {'b':>4} {'|V_q|':>6} {'r':>3} {'D_A':>4} {'D_B':>4} "
          f"{'A?':>3} {'B?':>3} {'CERT':>5}")

    results = []
    for q in primes:
        # Try r = 2 (first nontrivial multiplicity)
        for D in [3, 5, 7]:
            r = construct_and_certify(q, D, D, r=2)
            if r.get("found"):
                cert = r.get("jet_primitive_certified", False)
                print(f"{q:>4} {r['a']:>4} {r['b']:>4} {r['V_q_size']:>6} {r['r']:>3} "
                      f"{r['D_A']:>4} {r['D_B']:>4} "
                      f"{'Y' if r.get('A_nontrivial') else 'N':>3} "
                      f"{'Y' if r.get('B_nontrivial') else 'N':>3} "
                      f"{'YES' if cert else 'NO':>5}")
                results.append(r)
                break
        else:
            print(f"{q:>4} {'?':>4} {'?':>4} {'?':>6} not found at D up to 7")

    print("\n=== Certification summary ===")
    n_cert = sum(1 for r in results if r.get("jet_primitive_certified"))
    print(f"Jet-primitive certified: {n_cert} / {len(results)} primes")

    if n_cert == len(results):
        verdict = "ALL_PRIMES_JET_PRIMITIVE_CERTIFIED"
        print(f"\nVERDICT: {verdict}")
        print("→ R651-JET confirms the corrected Gate 1: jet-primitive Stepanov auxiliaries EXIST")
        print("→ R651 ordinary-vanishing NEGATIVE was a false-kill; the auxiliary class is jet-primitive")
        print("→ Stepanov route alive at multiplicity quotient, not coordinate quotient")
    elif n_cert > 0:
        verdict = "PARTIAL_JET_PRIMITIVE"
        print(f"\nVERDICT: {verdict} ({n_cert}/{len(results)})")
    else:
        verdict = "JET_PRIMITIVE_FAILS"
        print(f"\nVERDICT: {verdict}")

    out = ROOT / "R651_JET_primitive_certificate.json"
    out.write_text(json.dumps({
        "phase": "Phase 30 R651-JET — jet-primitive auxiliary certificate (false-kill reversal response)",
        "construction": "P = A(X^a - 1) + B(Y^b - 1)",
        "test": "(A, B) ≢ (0, 0) mod I_q",
        "results": results,
        "n_certified": n_cert,
        "n_total": len(results),
        "verdict": verdict,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
