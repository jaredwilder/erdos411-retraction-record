# LEMMA CARD CHECKLIST — PASS 5

Dependency classes:

- **E** = elementary/provable now.
- **C** = classical cited theorem required.
- **S** = sieve formalization required.
- **COND** = conditional implication.
- **OPEN** = open problem.
- **COMP** = computational verification.

## E-class: certified elementary

| Lemma | Where |
|---|---|
| Finite abelian subgroup obstruction lemma | Paper 1 |
| Multiplication fiber theorem | Paper 1 |
| Unit-inversion bijection | Paper 1/3 |
| Character-annihilator expansion | Paper 1 |
| Exact moment law | Paper 1/3 |
| CRT orthogonality | Paper 1/3 |
| Weighted variance theorem | Paper 1 |
| Squarefree lattice membership | Paper 2 |
| Synchronization defect quotient size identity | Paper 2 |
| Pair determinant criterion | Paper 2 |
| Projective slope criterion | Paper 2 |
| Rational Kummer independence | Paper 2/4/5 |
| Kummer character order exactly \(\ell\) | Paper 4/5 |
| Non-real odd Kummer character | Paper 4/5 |
| Power-stability of deficit | Paper 5 |
| Bad cyclic line consequence | Paper 5 |

## C-class: exact source needed

| Input | Needed for |
|---|---|
| Pappalardi subgroup-order theorem | density-zero paper |
| Effective Chebotarev / Thorner-Zaman low range | low-\(\ell\) PHNC |
| GRH Chebotarev | GRH conditional route |

## S-class: formalization required

| Step | Needed for |
|---|---|
| Integer averaging from residue classes | density-zero |
| Sieve threshold/normalization | density-zero |
| BVK sieve implication | conditional #203 |

## COND-class

| Conditional claim | Hypothesis |
|---|---|
| PHNC implies smoothing | finite-field Fourier/spectral lemma |
| Kummer-BV implies NEG-203 | rank-two sieve architecture |
| Kummer-GRH implies PHNC | uniform GRH Chebotarev |

## OPEN-class

| Problem | Comment |
|---|---|
| High-\(\ell\) PHNC | main analytic seam |
| Hyperplane non-concentration \(\Rightarrow\) Fourier gap | may need anti-atom hypothesis |
| Uniform fixed-radical Kummer large sieve | possible replacement route |

## COMP-class

| Computation | Paper |
|---|---|
| small local-to-global failure examples | Paper 2 |
| slope collision graphs | Paper 2/J |
| moment identity verification | Paper 1/J |


## PASS 5 additions

| Item | Class | Note |
|---|---|---|
| \(q=5\) no-obstruction example | COMP/E | finite verification |
| \(q=23\) proper-subgroup moment example | COMP/E | finite verification |
| \(d=95\) local/global failure example | COMP/E | parity contradiction |
| determinant-zero example \(7,37,\ell=3\) | COMP/E | finite verification |
| determinant-nonzero example \(7,13,\ell=3\) | COMP/E | finite verification |


## PASS 5 verification addition

All finite examples in Papers 1 and 2 are backed by `verify_finite_examples.py` and `FINITE_EXAMPLE_VERIFICATION_PASS4.md`.


## PASS 5 convergence labels

| Asset | Final status |
|---|---|
| Paper 1 lemmas | submission-candidate after polish |
| Paper 2 algebra | submission-candidate after diagrams/examples |
| Paper 3 density-zero | dependency-gated schema |
| Paper 4 conditional criterion | conditional architecture |
| Paper 5 failed-routes audit | defensive/expository |
| high-seam PHNC | expert packet/open problem |
