"""R632 — Pairwise correlation analysis for orbit-hit events.

Goal: identify the source of the 15-20% gap between Mertens-mechanism prediction
(a ≈ 7.5-7.9) and empirical Hooley constant (a ≈ 9.1) at M=10⁶.

The simple Mertens calc assumes independent f_p events conditional on primality.
If pairwise correlations are nonzero, predicted a shifts.

Strategy:
1. Single sweep m ≤ 10⁷ coprime to 6. For each m: compute bitmask = 23-bit pattern
   of f_p(m) values where f_p(m) = 1 iff gcd(m, p) = 1 AND -m^{-1} ∈ ⟨2,3⟩ mod p.
2. Track bitmask_counts split by primality (sparse dict).
3. Post-process with numpy: extract marginal Pr[f_p=1|·], joint Pr[f_p ∧ f_q|·],
   pairwise correlation matrix.
4. Compare predicted Hooley a (Mertens-independent vs corrected-correlation) to
   empirical a ≈ 8.87 at M=10⁷.

Output: r632_results.json with full statistics + verdict on whether correlations
explain the empirical-vs-predicted Hooley gap.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

PRIMES_LIST = list(sympy.primerange(5, 101))  # 23 primes
K_PRIMES = len(PRIMES_LIST)


def orbit_mod_p(p):
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def main():
    print("R632 — Pairwise correlation analysis for Theorem 16 mechanism")
    print(f"Primes set P = {PRIMES_LIST}")
    print(f"|P| = {K_PRIMES}\n")

    # Precompute orbits and densities
    orbits = {p: orbit_mod_p(p) for p in PRIMES_LIST}
    rho = {p: len(orbits[p]) / (p - 1) for p in PRIMES_LIST}
    print(f"rho_p (orbit density) per prime:")
    for p in PRIMES_LIST:
        print(f"  p={p:>3}: rho = {rho[p]:.4f}, |orbit| = {len(orbits[p])}")
    print()

    D2_simple = sum((1 - rho[p]) / p for p in PRIMES_LIST)
    print(f"Simplified D² = sum_p (1-rho_p)/p = {D2_simple:.4f}")
    print(f"e^(-D²) = {math.exp(-D2_simple):.4f}\n")

    M_CHECK = 10_000_000
    print(f"Sweep m ≤ {M_CHECK:,} coprime to 6 with bitmask tracking...")

    bitmask_counts_prime = {}
    bitmask_counts_comp = {}
    n_primes = 0
    n_comp = 0

    # Precompute orbit-membership as frozensets for fast lookup
    orbit_sets = {p: orbits[p] for p in PRIMES_LIST}

    t0 = time.time()
    progress_every = 500_000

    for m in range(1, M_CHECK + 1):
        if math.gcd(m, 6) != 1:
            continue
        is_prime = sympy.isprime(m)
        if is_prime:
            n_primes += 1
        else:
            n_comp += 1

        bitmask = 0
        for i, p in enumerate(PRIMES_LIST):
            if m % p == 0:
                continue  # gcd(m,p) > 1, f_p undefined (counted as 0)
            m_inv = pow(m, -1, p)
            if ((-m_inv) % p) in orbit_sets[p]:
                bitmask |= (1 << i)

        if is_prime:
            bitmask_counts_prime[bitmask] = bitmask_counts_prime.get(bitmask, 0) + 1
        else:
            bitmask_counts_comp[bitmask] = bitmask_counts_comp.get(bitmask, 0) + 1

        if m % progress_every == 0:
            elapsed = time.time() - t0
            rate = m / elapsed if elapsed > 0 else 0
            eta = (M_CHECK - m) / rate if rate > 0 else 0
            print(f"  m={m:>10,} elapsed {elapsed:>5.0f}s rate {rate:>9,.0f} m/s "
                  f"ETA {eta:>4.0f}s primes {n_primes:>7,} comp {n_comp:>8,}")

    elapsed_sweep = time.time() - t0
    print(f"\nSweep complete in {elapsed_sweep:.0f}s")
    print(f"n_primes={n_primes:,}, n_comp={n_comp:,}, prime_fraction={n_primes/(n_primes+n_comp):.4f}")
    print(f"distinct bitmasks: primes={len(bitmask_counts_prime):,}, comp={len(bitmask_counts_comp):,}\n")

    # ── Post-process with numpy ──
    print("Post-processing with numpy...")
    bm_arr_P = np.array(list(bitmask_counts_prime.keys()), dtype=np.uint32)
    ct_arr_P = np.array(list(bitmask_counts_prime.values()), dtype=np.int64)
    bm_arr_C = np.array(list(bitmask_counts_comp.keys()), dtype=np.uint32)
    ct_arr_C = np.array(list(bitmask_counts_comp.values()), dtype=np.int64)

    # inH distribution per primality state
    inH_dist_prime = np.zeros(K_PRIMES + 1, dtype=np.int64)
    inH_dist_comp = np.zeros(K_PRIMES + 1, dtype=np.int64)

    popcount_P = np.array([bin(int(bm)).count("1") for bm in bm_arr_P])
    popcount_C = np.array([bin(int(bm)).count("1") for bm in bm_arr_C])

    for k in range(K_PRIMES + 1):
        inH_dist_prime[k] = ct_arr_P[popcount_P == k].sum()
        inH_dist_comp[k] = ct_arr_C[popcount_C == k].sum()

    print(f"\n{'k':>3} {'cohort_size':>13} {'Pr[prime|k]':>13} {'Pr[k|prime]':>13} {'Pr[k|comp]':>13}")
    for k in range(K_PRIMES + 1):
        cohort = inH_dist_prime[k] + inH_dist_comp[k]
        if cohort == 0:
            continue
        pr_prime_k = inH_dist_prime[k] / cohort
        pr_k_prime = inH_dist_prime[k] / n_primes if n_primes else 0
        pr_k_comp = inH_dist_comp[k] / n_comp if n_comp else 0
        print(f"{k:>3} {cohort:>13,} {pr_prime_k:>13.4f} {pr_k_prime:>13.6f} {pr_k_comp:>13.6f}")

    # Marginal Pr[f_p = 1 | primality]
    print("\n=== Per-prime marginals ===")
    delta_prime = np.zeros(K_PRIMES)
    delta_comp = np.zeros(K_PRIMES)
    n_prime_coprime = np.zeros(K_PRIMES, dtype=np.int64)
    n_comp_coprime = np.zeros(K_PRIMES, dtype=np.int64)

    # For each p_i, count m's coprime to p_i (i.e., m mod p_i != 0)
    # For primes: m prime ⟹ m not divisible by p_i ⟹ all primes coprime to p_i (except m = p_i itself)
    # For composites: more careful
    # We can derive these from bitmask sweep counts: actually we lost m % p_i info
    # Workaround: assume primes are all coprime to p_i (off by 1 for the prime p_i itself if ≤ M)
    # For composites: approximate count of m coprime to 6 AND to p_i in [1, M] is M * (1/3) * (1 - 1/p_i)
    # Subtract prime count
    expected_total_coprime_to_pi = lambda p_i: M_CHECK * (1 - 1/p_i)
    # actually we need to track this separately if we want exact

    # Use bitmask-based: a bit is set only if gcd(m,p_i)=1 AND orbit-condition holds
    # So N(f_p_i = 1 | prime) = sum_bm: bit_i set in bm of ct
    # We need N(coprime to p_i | prime) — which is N(prime) - 1[p_i prime ≤ M]
    # since m prime, gcd(m, p_i) > 1 iff m = p_i
    for i, p_i in enumerate(PRIMES_LIST):
        n_marg_p = ct_arr_P[(bm_arr_P & (1 << i)) != 0].sum()
        n_marg_c = ct_arr_C[(bm_arr_C & (1 << i)) != 0].sum()
        # Coprime denominator for primes: n_primes minus 1 if p_i itself is in range
        n_prime_coprime[i] = n_primes - (1 if p_i <= M_CHECK else 0)
        # For composites: approximate via M * (1/3) * (1 - 1/p_i)
        # Better: count composites coprime to 6 not divisible by p_i = n_comp - (n composites divisible by p_i)
        # Composites divisible by p_i and coprime to 6: roughly M/(3 p_i) for p_i >= 5
        # But this is approximate. Use exact subtractive count.
        n_comp_div_pi = int(round(M_CHECK / (3 * p_i)))  # approximate; refine if needed
        # actually let's just normalize by n_comp (small denominator error for p_i >= 5)
        n_comp_coprime[i] = n_comp - n_comp_div_pi

        delta_prime[i] = n_marg_p / n_prime_coprime[i] if n_prime_coprime[i] > 0 else 0
        delta_comp[i] = n_marg_c / n_comp_coprime[i] if n_comp_coprime[i] > 0 else 0

    print(f"{'p':>4} {'rho_p':>8} {'delta_P':>10} {'delta_C':>10} {'P-C gap':>10}")
    for i, p_i in enumerate(PRIMES_LIST):
        rp = rho[p_i]
        gap = delta_prime[i] - delta_comp[i]
        print(f"{p_i:>4} {rp:>8.4f} {delta_prime[i]:>10.5f} {delta_comp[i]:>10.5f} {gap:>+10.6f}")

    # Pairwise joint counts via vectorized numpy
    print("\n=== Computing pairwise joint counts via numpy (vectorized) ===")
    t_pair = time.time()
    n_joint_prime = np.zeros((K_PRIMES, K_PRIMES), dtype=np.int64)
    n_joint_comp = np.zeros((K_PRIMES, K_PRIMES), dtype=np.int64)

    for i in range(K_PRIMES):
        mask_i = np.uint32(1 << i)
        has_i_P = (bm_arr_P & mask_i) != 0
        has_i_C = (bm_arr_C & mask_i) != 0
        for j in range(i + 1, K_PRIMES):
            mask_j = np.uint32(1 << j)
            both_P = has_i_P & ((bm_arr_P & mask_j) != 0)
            both_C = has_i_C & ((bm_arr_C & mask_j) != 0)
            n_joint_prime[i, j] = ct_arr_P[both_P].sum()
            n_joint_prime[j, i] = n_joint_prime[i, j]
            n_joint_comp[i, j] = ct_arr_C[both_C].sum()
            n_joint_comp[j, i] = n_joint_comp[i, j]
    print(f"Pairwise computation: {time.time() - t_pair:.1f}s\n")

    # Correlation matrix
    print("=== Pairwise correlations ===")
    corr_prime_matrix = np.zeros((K_PRIMES, K_PRIMES))
    corr_comp_matrix = np.zeros((K_PRIMES, K_PRIMES))
    corr_prime_list = []
    corr_comp_list = []

    for i in range(K_PRIMES):
        for j in range(i + 1, K_PRIMES):
            # Joint Pr[f_i=1 ∧ f_j=1 | primality]
            # Use denom = min(n_prime_coprime[i], n_prime_coprime[j]) — should both equal n_primes-2
            denom_P = n_primes - 2  # subtract for m = p_i and m = p_j
            denom_C = min(n_comp_coprime[i], n_comp_coprime[j])  # rough
            joint_P = n_joint_prime[i, j] / denom_P if denom_P > 0 else 0
            joint_C = n_joint_comp[i, j] / denom_C if denom_C > 0 else 0

            expected_P = delta_prime[i] * delta_prime[j]
            expected_C = delta_comp[i] * delta_comp[j]
            cov_P = joint_P - expected_P
            cov_C = joint_C - expected_C

            var_Pi = delta_prime[i] * (1 - delta_prime[i])
            var_Pj = delta_prime[j] * (1 - delta_prime[j])
            var_Ci = delta_comp[i] * (1 - delta_comp[i])
            var_Cj = delta_comp[j] * (1 - delta_comp[j])

            # Handle degenerate cases where var_i or var_j is 0 (deterministic f_p)
            # When f_p is deterministic (rho_p = 1 ⟹ always 1), correlation is undefined
            # but trivially 0 because the variable is constant
            prod_P = max(var_Pi * var_Pj, 0)
            prod_C = max(var_Ci * var_Cj, 0)
            denom_corr_P = math.sqrt(prod_P)
            denom_corr_C = math.sqrt(prod_C)
            corr_P = cov_P / denom_corr_P if denom_corr_P > 1e-12 else 0
            corr_C = cov_C / denom_corr_C if denom_corr_C > 1e-12 else 0

            corr_prime_matrix[i, j] = corr_P
            corr_prime_matrix[j, i] = corr_P
            corr_comp_matrix[i, j] = corr_C
            corr_comp_matrix[j, i] = corr_C
            corr_prime_list.append(corr_P)
            corr_comp_list.append(corr_C)

    mean_corr_prime = np.mean(corr_prime_list)
    mean_corr_comp = np.mean(corr_comp_list)
    print(f"Mean pairwise correlation (primes):     {mean_corr_prime:+.6f}")
    print(f"Mean pairwise correlation (composites): {mean_corr_comp:+.6f}")
    print(f"Max correlation (primes):               {max(corr_prime_list):+.6f}")
    print(f"Min correlation (primes):               {min(corr_prime_list):+.6f}")
    print(f"Max correlation (composites):           {max(corr_comp_list):+.6f}")
    print(f"Min correlation (composites):           {min(corr_comp_list):+.6f}")

    # Top 5 correlated pairs (prime side)
    pair_idx_sorted = sorted(range(len(corr_prime_list)), key=lambda x: abs(corr_prime_list[x]), reverse=True)
    pair_labels = [(PRIMES_LIST[i], PRIMES_LIST[j])
                   for i in range(K_PRIMES) for j in range(i+1, K_PRIMES)]
    print("\nTop 5 |correlations| (primes):")
    for idx in pair_idx_sorted[:5]:
        p_i, p_j = pair_labels[idx]
        print(f"  ({p_i},{p_j}): {corr_prime_list[idx]:+.6f}")

    # Predicted vs empirical Hooley a — Mertens-independent + correlation-corrected
    print("\n=== Hooley constant a: predicted vs empirical ===")
    pi_emp = n_primes / (n_primes + n_comp)

    # Empirical at M=10⁷
    cohort_23 = inH_dist_prime[23] + inH_dist_comp[23]
    if cohort_23 > 0:
        Pr_prime_inH23_emp = inH_dist_prime[23] / cohort_23
    else:
        Pr_prime_inH23_emp = 0
    a_M7_emp = Pr_prime_inH23_emp * math.log(M_CHECK)

    # Mertens-mechanism prediction (independent)
    prod_rho = np.prod([rho[p] for p in PRIMES_LIST])
    mertens_factor = np.prod([1 - 1/p for p in PRIMES_LIST])
    P1_23_predicted_indep = prod_rho
    P0_23_predicted_indep = mertens_factor * prod_rho

    Pr_inH23_predicted = P1_23_predicted_indep * pi_emp + P0_23_predicted_indep * (1 - pi_emp)
    Pr_prime_inH23_predicted = (P1_23_predicted_indep * pi_emp / Pr_inH23_predicted
                                if Pr_inH23_predicted > 0 else 0)
    a_M7_predicted = Pr_prime_inH23_predicted * math.log(M_CHECK)

    # Empirical Pr[inH=23 | prime] / predicted = clustering factor
    P1_23_emp = inH_dist_prime[23] / n_primes if n_primes else 0
    P0_23_emp = inH_dist_comp[23] / n_comp if n_comp else 0
    clustering_factor_prime = P1_23_emp / P1_23_predicted_indep if P1_23_predicted_indep > 0 else 0
    clustering_factor_comp = P0_23_emp / P0_23_predicted_indep if P0_23_predicted_indep > 0 else 0

    print(f"M = 10⁷, log M = {math.log(M_CHECK):.3f}")
    print(f"pi_emp (prime fraction coprime to 6) = {pi_emp:.4f}")
    print(f"")
    print(f"prod_rho_p (over 23 primes) = {prod_rho:.6f}")
    print(f"Mertens factor (sum (1-1/p)) = {mertens_factor:.6f}")
    print(f"")
    print(f"Empirical Pr[inH=23 | prime]:                {P1_23_emp:.5f}")
    print(f"Mertens-predicted Pr[inH=23 | prime, indep]: {P1_23_predicted_indep:.5f}")
    print(f"Clustering factor (prime side):              {clustering_factor_prime:.4f}")
    print(f"")
    print(f"Empirical Pr[inH=23 | composite]:                {P0_23_emp:.5f}")
    print(f"Mertens-predicted Pr[inH=23 | composite, indep]: {P0_23_predicted_indep:.5f}")
    print(f"Clustering factor (comp side):                   {clustering_factor_comp:.4f}")
    print(f"")
    print(f"Empirical Pr[prime | inH=23] at M=10⁷:      {Pr_prime_inH23_emp:.4f}")
    print(f"Mertens-predicted Pr[prime | inH=23], indep: {Pr_prime_inH23_predicted:.4f}")
    print(f"")
    print(f"Empirical Hooley a at M=10⁷:    {a_M7_emp:.3f}")
    print(f"Mertens-predicted a (indep):    {a_M7_predicted:.3f}")
    print(f"Discrepancy:                    {(a_M7_emp - a_M7_predicted) / a_M7_predicted * 100:+.1f}%")

    # Correlation-corrected prediction
    # If mean pairwise correlation is rho, the joint distribution shifts.
    # For sum of 23 indicators with correlation rho:
    #   Var[sum] = 23 * delta * (1-delta) * (1 + (K-1) * rho_avg)
    # And Pr[sum = 23 | prime] is enhanced relative to independent prediction by a clustering factor
    # The exact correction depends on the dependence structure but can be approximated via
    # the empirical clustering factor we just computed.
    print(f"\n=== Correlation-corrected mechanism ===")
    print(f"Empirical clustering factor on prime side: {clustering_factor_prime:.3f}")
    print(f"  ⟹ Pr[inH=23|prime] is {clustering_factor_prime:.2f}× the independent prediction")
    print(f"Empirical clustering factor on composite side: {clustering_factor_comp:.3f}")
    print(f"")
    # Use corrected P1, P0 directly from empirical:
    Pr_inH23_corrected = P1_23_emp * pi_emp + P0_23_emp * (1 - pi_emp)
    Pr_prime_inH23_corrected = (P1_23_emp * pi_emp / Pr_inH23_corrected
                                if Pr_inH23_corrected > 0 else 0)
    a_M7_corrected = Pr_prime_inH23_corrected * math.log(M_CHECK)
    print(f"Correlation-corrected a (using empirical P1, P0): {a_M7_corrected:.3f}")
    print(f"  This should match empirical a={a_M7_emp:.3f} by construction.")
    print(f"  Confirms internal-consistency of Bayes calculation.")

    # Save
    out = ROOT / "r632_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 21 R632 — pairwise correlation analysis",
        "M_CHECK": M_CHECK,
        "n_primes": int(n_primes),
        "n_comp": int(n_comp),
        "pi_emp": pi_emp,
        "rho": {str(p): rho[p] for p in PRIMES_LIST},
        "D_squared_simplified": D2_simple,
        "delta_prime": {str(PRIMES_LIST[i]): float(delta_prime[i]) for i in range(K_PRIMES)},
        "delta_comp": {str(PRIMES_LIST[i]): float(delta_comp[i]) for i in range(K_PRIMES)},
        "inH_dist_prime": [int(x) for x in inH_dist_prime.tolist()],
        "inH_dist_comp": [int(x) for x in inH_dist_comp.tolist()],
        "mean_pairwise_corr_prime": float(mean_corr_prime),
        "mean_pairwise_corr_comp": float(mean_corr_comp),
        "max_pairwise_corr_prime": float(max(corr_prime_list)),
        "min_pairwise_corr_prime": float(min(corr_prime_list)),
        "max_pairwise_corr_comp": float(max(corr_comp_list)),
        "min_pairwise_corr_comp": float(min(corr_comp_list)),
        "P1_23_empirical": float(P1_23_emp),
        "P1_23_predicted_indep": float(P1_23_predicted_indep),
        "clustering_factor_prime": float(clustering_factor_prime),
        "P0_23_empirical": float(P0_23_emp),
        "P0_23_predicted_indep": float(P0_23_predicted_indep),
        "clustering_factor_comp": float(clustering_factor_comp),
        "Pr_prime_inH23_empirical_M7": float(Pr_prime_inH23_emp),
        "Pr_prime_inH23_predicted_mertens_M7": float(Pr_prime_inH23_predicted),
        "a_M7_empirical": float(a_M7_emp),
        "a_M7_predicted_mertens_indep": float(a_M7_predicted),
        "a_M7_corrected_using_empirical_P1_P0": float(a_M7_corrected),
        "discrepancy_pct_indep": float((a_M7_emp - a_M7_predicted) / a_M7_predicted * 100),
        "elapsed_sweep_seconds": elapsed_sweep,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
