# Sieve Theorist Persona — Heath-Brown / Friedlander-Iwaniec / Granville lineage

## 1. The exact theorem we need (NEG-203)

For every $m \geq 1$ with $\gcd(m, 6) = 1$, define
$$A(m) = \{(k, \ell) \in \mathbb{N}_{\geq 0}^2 : 2^k 3^\ell m + 1 \text{ is prime}\}.$$
**Theorem (NEG-203, sieve form):** *For every such m, A(m) ≠ ∅.*

Realistic density-positive target:
$$\#\{(k,\ell) \leq (K, L) : 2^k 3^\ell m + 1 \text{ prime}\} \geq c(m)\frac{KL}{\log(2^K 3^L m)} \quad \text{for } K, L \geq K_0(m).$$

Local factors $\prod_p (1 - \chi_p/p)$ never vanish for $\gcd(m,6)=1$ — that's exactly the operator's R567-R572 wall: singular series positive, geometric density of certificates too thin.

## 2. Closest existing result + gap

**Closest:** Friedlander-Iwaniec, "Asymptotic sieve for primes," Annals 148 (1998), 1041-1065. Plus the sequel for $a^2+b^4$. Needs:
- (R) Bombieri-Vinogradov-type residue-class distribution
- (B) Type-II bilinear estimate with cancellation

**Our sequence** $a_{k,\ell} = 2^k 3^\ell m + 1$ is **multiplicatively lacunary of density $1/(\log 2 \log 3)$ in log-scale** — far thinner than $a^2+b^4$ (density ~ $x^{3/4}$).

Related but insufficient:
- Heath-Brown "Primes represented by $x^3+2y^3$" Acta 2001 — algebraic structure we lack
- Tenenbaum on $y$-smooth numbers — counts but not primes among shifts
- Mihailescu/Bilu-Bugeaud on S-unit equations — controls solutions, doesn't manufacture primes

**Gap:** No Type-II input. The "+1" destroys multiplicativity — same obstruction blocking Fermat primes.

## 3. Closeable or new machinery?

**New machinery required.** Closest live tool: **Maynard 2019 primes with missing digits** — adapts Fourier-on-digits trick to thin sets (density $x^{\log 9/\log 10}$). Treating $(k,\ell)$ as base-(2,3) digit data might work, but multiplicative coupling of 2,3 wrecks orthogonality.

**Estimate: 18 months focused work by Maynard-caliber theorist, 60/40 against success.**

What IS closeable in months: almost-prime statement ($2^k 3^\ell m + 1$ has ≤ C prime factors for some $(k,\ell)$), with linear sieve giving C=3 or 4. **Does not close #203.**

## 4. Single best computational experiment

For $m \in \{5, 7, 11, 13, ..., M\}$ with $M = 10^5$, $\gcd(m,6)=1$, compute
$$\tau(m) = \min\{k + \ell : 2^k 3^\ell m + 1 \text{ prime}\}, \quad (k, \ell) \leq (200, 200).$$

**Predictions:**
- NEG-203 holds: $\tau(m) = O(\log m)$ average, $\tau(m) \leq C \log^2 m$ for every m
- **Anomaly signature for #203 candidates:** $m$ with $\tau(m) > (\log m)^2$ and growing → empirical evidence #203 has positive answer
- Distributional check: plot $\tau(m)/\log m$ — heuristic predicts mean → constant, variance O(1). Heavy right tail = trouble.

~6 hours on operator's box.

## 5. Self-critique

Three hand-waves:
1. **Singular series positivity** depends on multiplicative orbits of (2,3) mod p being "generic" — but those are exactly the h=1 prime structure the operator pinned at saturation. Local densities might collapse faster.
2. **Every theorem I cited needs Type-II input I cannot produce** — saying "if a theorem like Maynard's worked here, we'd be done" is hopeful sieve-theorist talk for 80 years on Fermat primes.
3. **$\log 2, \log 3$ are Q-linearly independent** — the box $(k,\ell) \leq (K,L)$ is weird vs $n \leq N$, and equidistribution of $\{k\log 2 + \ell\log 3\} \mod 1$ is itself tied to Diophantine open problems on $\log_2 3$.

**Bottom line:** sieve theory does not currently solve #203 either direction. Negative-resolution path is the only one with a live research program (Maynard-style). The $\tau(m)$ experiment in §4 is the single highest-leverage cheap test.
