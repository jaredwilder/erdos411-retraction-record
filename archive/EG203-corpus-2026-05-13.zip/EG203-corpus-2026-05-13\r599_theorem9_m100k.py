"""R599 — Extend Theorem 9 to m ≤ 100,000 coprime to 6, L=45."""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

L_TEST = 45


def count_primes_in_orbit(m, L):
    cnt = 0
    n_pairs = 0
    for k in range(L + 1):
        pow2k = 1 << k
        pow3l = 1
        l = 0
        while True:
            val = pow2k * pow3l
            if val > (1 << L):
                break
            n = val * m + 1
            n_pairs += 1
            if sympy.isprime(n):
                cnt += 1
            pow3l *= 3
            l += 1
    return cnt, n_pairs


def main():
    print(f"R599 — THEOREM 9 PUSH: m in [1, 100000] coprime to 6, L = {L_TEST}\n")
    M_LIST = [m for m in range(1, 100001) if math.gcd(m, 6) == 1]
    print(f"Testing {len(M_LIST)} m values\n")

    t0 = time.time()
    results = []
    min_primes_so_far = float('inf')
    min_m_so_far = None

    for i, m in enumerate(M_LIST):
        cnt, n_pairs = count_primes_in_orbit(m, L_TEST)
        results.append((m, cnt))
        if cnt < min_primes_so_far:
            min_primes_so_far = cnt
            min_m_so_far = m
        if (i+1) % 5000 == 0:
            elapsed = time.time() - t0
            print(f"  [{i+1}/{len(M_LIST)}] m={m:>6}: {cnt:>3} primes; min so far = {min_primes_so_far} at m={min_m_so_far}; elapsed {elapsed:.0f}s")

    elapsed_total = time.time() - t0
    print(f"\nTotal compute: {elapsed_total:.0f}s ({elapsed_total/60:.1f} min)\n")

    prime_counts = [c for _, c in results]
    min_primes = min(prime_counts)
    median_primes = sorted(prime_counts)[len(prime_counts) // 2]
    mean_primes = sum(prime_counts) / len(prime_counts)
    max_primes = max(prime_counts)

    print("=== THEOREM 9 PUSHED TO m ≤ 100,000 ===")
    print(f"  m tested: {len(M_LIST)} (all m in [1, 100000] coprime to 6)")
    print(f"  Min primes in orbit: {min_primes}")
    print(f"  Median primes: {median_primes}")
    print(f"  Mean primes: {mean_primes:.1f}")
    print(f"  Max primes: {max_primes}")
    print(f"  Worst-case m: {min_m_so_far}")

    if min_primes >= 5:
        verdict = "THEOREM_9_PUSHED"
        msg = (f"THEOREM 9 (Unconditional, pushed): For every m in [1, 100,000] coprime to 6, "
               f"A(m) has at least {min_primes} elements at L=45. Worst case m={min_m_so_far}.")
    elif min_primes >= 1:
        verdict = "WEAKER"
        msg = f"Min {min_primes} at m={min_m_so_far}. All m have at least 1 prime."
    else:
        verdict = "PARTIAL"
        msg = f"Some m have 0 primes at L=45: m={min_m_so_far}."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    print("\n=== WORST 20 cases ===")
    for r in sorted(results, key=lambda x: x[1])[:20]:
        print(f"  m={r[0]:>6}: {r[1]:>3} primes")

    out = ROOT / "r599_results.json"
    out.write_text(json.dumps({
        "L_TEST": L_TEST,
        "n_m_tested": len(M_LIST),
        "min_primes": min_primes,
        "min_m": min_m_so_far,
        "median_primes": median_primes,
        "mean_primes": mean_primes,
        "max_primes": max_primes,
        "verdict": verdict,
        "msg": msg,
        "worst_100": sorted(results, key=lambda x: x[1])[:100],
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
