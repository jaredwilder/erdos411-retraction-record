# COVER LETTER — FIRST SUBMISSION CANDIDATE

Dear Editor,

Please find attached the manuscript:

**A Subgroup Obstruction Calculus for Two-Generator Exponential Congruences**

The paper develops an elementary finite-group framework for local congruence obstructions in exponential problems of the form
\[
m a^k b^\ell+1.
\]
The main results are exact finite identities: a subgroup-obstruction lemma, a multiplication-fiber theorem, exact local density formulas, character-annihilator expansions, exact moment laws, and CRT orthogonality/weighted-variance identities.

The paper deliberately makes no claim of solving Erdős–Graham Problem #203.  That problem is used as a motivating example, with \(a=2,b=3\), but the results are finite algebraic identities applicable more broadly to two-generator exponential congruence problems.

The manuscript includes small finite examples and a reproducibility script verifying those examples.

Sincerely,  
Jared Wilder
