"""R641 — Verify Selberg+Vinogradov+Linnik prediction that R638's δ_emp = 0.38 at L=40
saturates toward δ ≈ 0.43-0.50 as L grows (Weil-pointwise saturation).

R638 measured at L ∈ {20, 30, 40} for various q.
R641 pushes to L ∈ {40, 50, 60} at q ∈ {503, 1009, 5003} — 3 of R638's primes
extended to verify saturation prediction.

Selberg verdict: pointwise Weil ceiling δ → 1/2 as L grows.
Linnik prediction: δ_∞ = 0.43 ± 0.02.
Vinogradov interpretation: δ ≈ 1/2 - 1/sqrt(L) explicit Weil signature.

If δ_emp at L=60 > δ_emp at L=40, confirms saturation picture.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy
import numpy as np
import random

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent


def support_pairs(L):
    pairs = []
    log2_3 = math.log2(3)
    for k in range(L + 1):
        max_ell = int((L - k) / log2_3)
        for ell in range(max_ell + 1):
            pairs.append((k, ell))
    return pairs


def compute_max_S_q(q, L, sample_a=200, seed=42):
    """Compute max_a |S_q(a, L)| via sampling."""
    pairs = support_pairs(L)
    N_phi = len(pairs)

    rng = random.Random(seed)
    candidates = []
    attempts = 0
    while len(candidates) < sample_a and attempts < sample_a * 5:
        a = rng.randint(1, q - 1)
        if math.gcd(a, q) == 1:
            candidates.append(a)
        attempts += 1

    # Precompute 2^k 3^ℓ mod q
    pow2 = [pow(2, k, q) for k in range(L + 1)]
    pow3 = [pow(3, ell, q) for ell in range(L + 1)]

    max_S = 0
    for a in candidates:
        # Compute S = sum over pairs
        s_real = 0.0
        s_imag = 0.0
        for (k, ell) in pairs:
            n = (a * pow2[k] * pow3[ell]) % q
            angle = 2 * math.pi * n / q
            s_real += math.cos(angle)
            s_imag += math.sin(angle)
        absS = math.sqrt(s_real * s_real + s_imag * s_imag)
        if absS > max_S:
            max_S = absS

    return max_S, N_phi


def main():
    print("R641 — Weil-saturation verification for orbit Fourier transform")
    print("=" * 65)
    print("Hypothesis (Selberg+Vinogradov+Linnik): δ_emp at L=60 > δ_emp at L=40")
    print("Predicted δ_∞ ≈ 0.43-0.47 as L → ∞.")
    print()

    test_qs = [503, 1009, 5003]
    test_Ls = [40, 50, 60]

    print(f"Test primes: {test_qs}")
    print(f"Test L values: {test_Ls}")
    print()
    print(f"{'q':>6} {'L':>4} {'N_φ':>6} {'max|S|':>10} {'|S|/N_φ':>10} {'δ_emp':>10} {'elapsed':>10}")

    results = []
    for q in test_qs:
        for L in test_Ls:
            t0 = time.time()
            max_S, N_phi = compute_max_S_q(q, L, sample_a=300, seed=42)
            elapsed = time.time() - t0

            ratio = max_S / N_phi if N_phi > 0 else 0
            if max_S > 1 and N_phi > 1:
                exponent = math.log(max_S) / math.log(N_phi)
                delta = 1 - exponent
            else:
                delta = 1

            results.append({
                "q": q, "L": L, "N_phi": N_phi,
                "max_S": float(max_S), "ratio": float(ratio),
                "delta_emp": float(delta), "elapsed_sec": elapsed,
            })
            print(f"{q:>6} {L:>4} {N_phi:>6} {max_S:>10.3f} {ratio:>10.4f} {delta:>10.4f} {elapsed:>8.1f}s")

    # Scaling analysis: does δ INCREASE with L?
    print("\n" + "=" * 65)
    print("=== δ_emp vs L for each q ===\n")
    print(f"{'q':>6}", end="")
    for L in test_Ls:
        print(f" δ@L={L}".rjust(12), end="")
    print()

    for q in test_qs:
        print(f"{q:>6}", end="")
        for L in test_Ls:
            r = next(x for x in results if x["q"] == q and x["L"] == L)
            print(f"{r['delta_emp']:>12.4f}", end="")
        print()

    # Check saturation
    print("\n=== Saturation analysis ===")
    saturation_observed = []
    for q in test_qs:
        deltas = [next(x for x in results if x["q"] == q and x["L"] == L)["delta_emp"] for L in test_Ls]
        trend = "INCREASING" if all(deltas[i+1] >= deltas[i] - 0.01 for i in range(len(deltas)-1)) else "MIXED"
        max_delta = max(deltas)
        print(f"q = {q}: deltas = {[f'{d:.4f}' for d in deltas]}, trend = {trend}, max = {max_delta:.4f}")
        saturation_observed.append(trend == "INCREASING" and max_delta > 0.42)

    if any(saturation_observed):
        verdict = "WEIL_SATURATION_CONFIRMED"
        print(f"\nVERDICT: {verdict}")
        print("At least one prime shows δ > 0.42 with monotone increasing trend.")
        print("→ Confirms Selberg+Vinogradov+Linnik prediction.")
        print("→ Orbit Fourier IS at Weil-square-root height pointwise.")
    elif all(deltas := [next(x for x in results if x["q"] == q and x["L"] == 60)["delta_emp"] for q in test_qs]):
        max_d_at_60 = max(deltas)
        if max_d_at_60 > 0.40:
            verdict = "WEIL_SATURATION_APPROACHING"
            print(f"\nVERDICT: {verdict}")
            print(f"Max δ at L=60 = {max_d_at_60:.4f}; approaching predicted 0.43.")
        else:
            verdict = "SATURATION_NOT_OBSERVED"
            print(f"\nVERDICT: {verdict}")
    else:
        verdict = "INCONCLUSIVE"
        print(f"\nVERDICT: {verdict}")

    out = ROOT / "r641_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 24 R641 — Weil-saturation verification",
        "results": results,
        "verdict": verdict,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
