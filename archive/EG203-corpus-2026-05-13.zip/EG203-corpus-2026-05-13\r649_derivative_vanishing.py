"""R649 - Verify derivative vanishing order m_q = c_0 log h_q empirically for fibered
Stepanov polynomials from R648.

For each prime q in [5, 31], we previously found P_q vanishing on V_q with deg D ≈ √|V_q|.
R649 measures: what's the maximum derivative-order r such that ∂_X^j ∂_Y^k P_q(x, y) = 0
for all (x, y) ∈ V_q and all j + k ≤ r?

The Heath-Brown-Konyagin prediction: m_q = (1/4) log h_q + O(1).

For q=11, h_q=50, predicted m_q ≈ 0.98. For q=17, h_q=128, predicted m_q ≈ 1.21.
For q=23, h_q=121, predicted m_q ≈ 1.20.

This empirically anchors Section §4 of the Theorem 22 manuscript.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent


def orbit_points(q):
    points = set()
    seen_x = []
    x = 1
    while True:
        seen_x.append(x)
        x = (x * 2) % q
        if x == 1:
            break
    seen_y = []
    y = 1
    while True:
        seen_y.append(y)
        y = (y * 3) % q
        if y == 1:
            break
    for xv in seen_x:
        for yv in seen_y:
            points.add((xv, yv))
    return points


def monomial_basis(D):
    return [(i, j) for i in range(D + 1) for j in range(D + 1) if i + j <= D]


def poly_value(coefs, monomials, xv, yv, q):
    """Evaluate P(xv, yv) mod q."""
    s = 0
    for k, (i, j) in enumerate(monomials):
        s = (s + coefs[k] * pow(xv, i, q) * pow(yv, j, q)) % q
    return s


def derivative_value(coefs, monomials, xv, yv, q, dx, dy):
    """Evaluate (∂_X^dx ∂_Y^dy P)(xv, yv) mod q.
    For monomial X^i Y^j, derivative is i*(i-1)*...*(i-dx+1) * j*(j-1)*...*(j-dy+1) * X^{i-dx} Y^{j-dy}.
    """
    s = 0
    for k, (i, j) in enumerate(monomials):
        if i < dx or j < dy:
            continue
        # Falling factorial coefficients
        fx = 1
        for t in range(dx):
            fx = (fx * (i - t)) % q
        fy = 1
        for t in range(dy):
            fy = (fy * (j - t)) % q
        s = (s + coefs[k] * fx * fy * pow(xv, i - dx, q) * pow(yv, j - dy, q)) % q
    return s


def find_polynomial(q, V_q, D):
    """Find nontrivial P ∈ F_q[X,Y] of deg ≤ D vanishing on V_q. Return coefs+monomials."""
    monomials = monomial_basis(D)
    n_monomials = len(monomials)
    points_list = list(V_q)
    n_constraints = len(points_list)

    if n_monomials <= n_constraints:
        return None, monomials

    # Build matrix
    rows = []
    for (xv, yv) in points_list:
        row = []
        for (i, j) in monomials:
            row.append((pow(xv, i, q) * pow(yv, j, q)) % q)
        rows.append(row)

    # Gaussian elimination over F_q
    n_rows = len(rows)
    n_cols = n_monomials
    pivot_row = [None] * n_cols
    pivot_col = [None] * n_rows

    cur_row = 0
    for c in range(n_cols):
        if cur_row >= n_rows:
            break
        pivot = None
        for r in range(cur_row, n_rows):
            if rows[r][c] % q != 0:
                pivot = r
                break
        if pivot is None:
            continue
        rows[cur_row], rows[pivot] = rows[pivot], rows[cur_row]
        inv = pow(rows[cur_row][c], -1, q)
        rows[cur_row] = [(v * inv) % q for v in rows[cur_row]]
        for r in range(n_rows):
            if r != cur_row and rows[r][c] % q != 0:
                factor = rows[r][c]
                rows[r] = [(rows[r][k] - factor * rows[cur_row][k]) % q for k in range(n_cols)]
        pivot_row[c] = cur_row
        pivot_col[cur_row] = c
        cur_row += 1

    free_cols = [c for c in range(n_cols) if pivot_row[c] is None]
    if not free_cols:
        return None, monomials

    coefs = [0] * n_cols
    coefs[free_cols[0]] = 1
    for c in range(n_cols):
        if pivot_row[c] is not None:
            r = pivot_row[c]
            coefs[c] = (-rows[r][free_cols[0]]) % q

    return coefs, monomials


def measure_derivative_order(coefs, monomials, V_q, q):
    """Find max r such that ∂_X^j ∂_Y^k P vanishes on V_q for all j+k ≤ r."""
    for r in range(0, 20):
        # Check all (j, k) with j+k = r
        all_zero = True
        for j in range(r + 1):
            k = r - j
            for (xv, yv) in V_q:
                v = derivative_value(coefs, monomials, xv, yv, q, j, k)
                if v != 0:
                    all_zero = False
                    break
            if not all_zero:
                break
        if not all_zero:
            return r - 1  # last r where all derivatives vanished
    return 19


def main():
    print("R649 - Derivative-vanishing order for fibered Stepanov polynomials")
    print("=" * 75)

    primes = [5, 7, 11, 13, 17, 23, 31]
    print(f"Testing {len(primes)} primes\n")
    print(f"{'q':>4} {'|V_q|':>6} {'D':>3} {'r_meas':>7} {'r_pred':>7} {'r/log h':>9}")

    results = []
    for q in primes:
        V_q = orbit_points(q)
        h_q = len(V_q)
        # Use D from R648
        D_table = {5: 5, 7: 5, 11: 9, 13: 8, 17: 15, 23: 15, 31: 16}
        D = D_table[q]

        coefs, monomials = find_polynomial(q, V_q, D)
        if coefs is None:
            print(f"{q:>4} {h_q:>6} {D:>3} {'NA':>7}")
            continue

        # Verify P vanishes on V_q (sanity)
        ok = all(poly_value(coefs, monomials, x, y, q) == 0 for (x, y) in V_q)
        if not ok:
            print(f"{q:>4} {h_q:>6} {D:>3} {'FAIL':>7}")
            continue

        r_meas = measure_derivative_order(coefs, monomials, V_q, q)
        r_pred = math.log(h_q) / 4  # HB-Konyagin c_0 = 1/4 prediction
        ratio = r_meas / math.log(h_q) if h_q > 1 else 0

        print(f"{q:>4} {h_q:>6} {D:>3} {r_meas:>7} {r_pred:>7.2f} {ratio:>9.3f}")
        results.append({
            "q": q, "V_q_size": h_q, "D": D,
            "r_measured": r_meas, "r_predicted_HBK": r_pred,
            "r_over_log_h": ratio,
        })

    print("\n=== Heath-Brown-Konyagin c_0 verification ===")
    if results:
        c0_vals = [r["r_over_log_h"] for r in results]
        mean_c0 = sum(c0_vals) / len(c0_vals)
        print(f"Mean r/log(h_q) = {mean_c0:.4f}")
        print(f"HB-Konyagin prediction: c_0 = 0.25")
        print(f"Empirical/predicted ratio: {mean_c0/0.25:.2f}")

    out = ROOT / "r649_results.json"
    out.write_text(json.dumps({
        "phase": "Phase 27 R649 - derivative-vanishing order on fibered Stepanov polynomials",
        "results": results,
        "HB_Konyagin_c0_prediction": 0.25,
        "empirical_mean_c0": mean_c0 if results else None,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
