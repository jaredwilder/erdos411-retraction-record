# PASS 4 FINITE EXAMPLE VERIFICATION

- `q5_gamma`: `[1, 2, 3, 4]`
- `q23_gamma_size`: `11`
- `q23_order2`: `11`
- `q23_order3`: `11`
- `primroot_5`: `2`
- `primroot_19`: `2`
- `dlogs_5_base2`: `(1, 3)`
- `dlogs_19_base2`: `(1, 13)`
- `d95_num_solutions`: `0`
- `primroot_7`: `3`
- `primroot_37`: `2`
- `primroot_13`: `2`
- `dlogs_7_base3`: `(2, 1)`
- `dlogs_37_base2`: `(1, 26)`
- `dlogs_13_base2`: `(1, 4)`
- `det_7_37`: `51`
- `det_7_37_mod3`: `0`
- `det_7_13`: `7`
- `det_7_13_mod3`: `1`

All examples inserted in Pass 4 are finite arithmetic checks reproducible by `verify_finite_examples.py`.
