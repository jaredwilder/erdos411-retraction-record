"""R660B — Stepanov auxiliary at Bombieri degree, HIGHER primes q ∈ [100, 500].

Extends R660A to verify the slope log(D_min) vs log(|V_q|) at larger scale.
Uses the same dimension-test machinery but with smarter degree budget per prime.

For each q ∈ [100, 500] prime, q ∤ 6:
  - Compute a = ord_q(2), b = ord_q(3), |V_q| = a·b
  - Skip if V_q = F_q*^2 (both primitive roots)
  - Skip if |V_q| > 5000 (linear algebra too expensive)
  - Test at Bombieri degree D ≈ √|V_q| · log q, jet order m = 2 or 3
  - Record kernel dimension

Heavy primes (large |V_q|) are skipped to keep runtime tractable.
"""

import json
import math
from pathlib import Path
from sympy import isprime

OUT = Path(__file__).with_suffix('.json')


def order_mod(g, q):
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def build_orbit(q):
    a = order_mod(2, q)
    b = order_mod(3, q)
    twos = [pow(2, k, q) for k in range(a)]
    threes = [pow(3, l, q) for l in range(b)]
    pts = []
    seen = set()
    for x in twos:
        for y in threes:
            if (x, y) not in seen:
                seen.add((x, y))
                pts.append((x, y))
    return a, b, pts


def monomial_basis(D):
    return [(i, j) for i in range(D + 1) for j in range(D + 1 - i)]


def pow_mod(base, exp, q):
    if exp < 0:
        return 0
    return pow(base, exp, q) if base != 0 else (1 if exp == 0 else 0)


def falling(n, k):
    if k == 0:
        return 1
    r = 1
    for t in range(k):
        r *= (n - t)
    return r


def derivative_row(x, y, di, dj, basis, q):
    row = []
    for (i, j) in basis:
        if i < di or j < dj:
            row.append(0)
            continue
        coeff = falling(i, di) * falling(j, dj)
        val = (pow_mod(x, i - di, q) * pow_mod(y, j - dj, q)) % q
        row.append((coeff * val) % q)
    return row


def gauss_rank(M, q):
    if not M:
        return 0
    M = [list(r) for r in M]
    nrow = len(M)
    ncol = len(M[0]) if M else 0
    r = 0
    for c in range(ncol):
        pivot = None
        for rr in range(r, nrow):
            if M[rr][c] % q != 0:
                pivot = rr
                break
        if pivot is None:
            continue
        if pivot != r:
            M[r], M[pivot] = M[pivot], M[r]
        inv = pow(M[r][c] % q, -1, q)
        for cc in range(c, ncol):
            M[r][cc] = (M[r][cc] * inv) % q
        for rr in range(nrow):
            if rr != r and M[rr][c] % q != 0:
                f = M[rr][c] % q
                for cc in range(c, ncol):
                    M[rr][cc] = (M[rr][cc] - f * M[r][cc]) % q
        r += 1
        if r == min(nrow, ncol):
            break
    return r


def stepanov_dim_test(q, D, m, pts):
    basis = monomial_basis(D)
    n_unknowns = len(basis)
    rows = []
    for (x, y) in pts:
        for di in range(m):
            for dj in range(m - di):
                rows.append(derivative_row(x, y, di, dj, basis, q))
    n_constraints = len(rows)
    rank = gauss_rank(rows, q) if rows else 0
    return n_unknowns, n_constraints, rank, n_unknowns - rank


def main():
    print("R660B — Stepanov auxiliary at Bombieri degree, HIGHER primes q ∈ [100, 500]")
    print("=" * 90)
    print()
    print(f"{'q':>4} {'|V_q|':>6} {'D':>3} {'m':>3} {'unk':>6} {'cnst':>7} {'rank':>6} "
          f"{'ker':>5} {'cert':>5}")
    print("-" * 90)

    results = []
    for q in range(101, 500):
        if not isprime(q):
            continue
        a = order_mod(2, q)
        b = order_mod(3, q)
        V_size = a * b
        torus_size = (q - 1) ** 2
        if V_size >= torus_size:
            continue
        # Heavy primes: skip if |V_q| is too large for feasible Gaussian elimination
        if V_size > 2500:
            continue
        # Bombieri degree: D = ⌈√|V_q| · log q⌉, capped at 18 to bound runtime
        D = max(2, int(math.ceil(math.sqrt(V_size) * math.log(q))))
        if D > 18:
            D = 18
        m = 2  # Small jet order to keep constraints tractable

        a, b, pts = build_orbit(q)
        try:
            n_unknowns, n_constraints, rank, kernel = stepanov_dim_test(q, D, m, pts)
        except Exception as e:
            print(f"{q:>4} ERROR: {e}")
            continue

        cert = "YES" if kernel > 0 else "no"
        print(f"{q:>4} {V_size:>6} {D:>3} {m:>3} {n_unknowns:>6} {n_constraints:>7} "
              f"{rank:>6} {kernel:>5} {cert:>5}")

        results.append({
            'q': q,
            'a': a,
            'b': b,
            'V_size': V_size,
            'D': D,
            'm': m,
            'n_unknowns': n_unknowns,
            'n_constraints': n_constraints,
            'rank': rank,
            'kernel_dim': kernel,
            'auxiliary_exists': kernel > 0,
        })

    print()
    n_total = len(results)
    n_cert = sum(1 for r in results if r['auxiliary_exists'])
    print(f"=== Higher-prime certification summary ===")
    print(f"Stepanov auxiliary certified: {n_cert} / {n_total} primes")

    if n_cert >= 4:
        cert_pts = [(r['V_size'], r['D']) for r in results if r['auxiliary_exists']]
        log_V = [math.log(v) for v, d in cert_pts]
        log_D = [math.log(d) for v, d in cert_pts]
        mean_V = sum(log_V) / len(log_V)
        mean_D = sum(log_D) / len(log_D)
        num = sum((lv - mean_V) * (ld - mean_D) for lv, ld in zip(log_V, log_D))
        den = sum((lv - mean_V) ** 2 for lv in log_V)
        slope = num / den if den > 0 else float('nan')
        print(f"Slope log(D) vs log(|V_q|): {slope:.4f} (Bombieri predicts 0.5)")
    else:
        slope = None

    out = {
        'phase': 'R660B — Bombieri-grade Stepanov dimension test, q ∈ [100, 500]',
        'results': results,
        'n_certified': n_cert,
        'n_total': n_total,
        'slope_log_D_vs_log_V': slope,
        'bombieri_predicted_slope': 0.5,
    }
    OUT.write_text(json.dumps(out, indent=2))
    print(f"\nWritten {OUT}")


if __name__ == '__main__':
    main()
