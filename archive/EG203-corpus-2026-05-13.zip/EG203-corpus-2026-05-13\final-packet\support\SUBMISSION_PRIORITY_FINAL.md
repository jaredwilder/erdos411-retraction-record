# SUBMISSION PRIORITY — PASS 5

## First submission candidate

### 01_SUBGROUP_OBSTRUCTION_CALCULUS_PASS3.tex

This is still the first ship.

Why:
- elementary;
- now has examples;
- general beyond \(2,3\);
- no unproved analytic inputs;
- no #203 overclaim.

Remaining work:
1. polish prose;
2. add references;
3. verify examples independently using `verify_finite_examples.py`;
4. possibly shorten if journal format requires.

## Second submission candidate

### 02_CRT_SYNCHRONIZATION_PROJECTIVE_SLOPES_PASS3.tex

Now much stronger because it contains explicit examples.

Remaining work:
1. independently verify all discrete logs;
2. add one diagram of the exponent lattice;
3. decide whether to split projective slope material.

## Third

### 05_FAILED_ROUTES_PHNC_AUDIT_PASS3.tex

This can be an appendix to the conditional criterion or a standalone note.  Its value is defensive: it documents exactly where the full close failed without discarding the surviving structure.

## Hold

### 03_DENSITY_ZERO_KUMMER_OBSTRUCTION_PASS3.tex

Hold until Pappalardi theorem and sieve functional are inserted.

### 04_KUMMER_DISTRIBUTION_CRITERION_EG203_PASS3.tex

Hold until the PHNC-to-KRWS and Kummer-BV-to-NEG arrows are formalized or clearly labeled as hypotheses.


## Pass 4 editorial conclusion

The first submission candidate is now clearly:

\[
\boxed{\texttt{01\_SUBGROUP\_OBSTRUCTION\_CALCULUS\_PASS4.tex}}
\]

The second is:

\[
\boxed{\texttt{02\_CRT\_SYNCHRONIZATION\_PROJECTIVE\_SLOPES\_PASS4.tex}}
\]

The remaining files should be treated as program architecture until their dependencies are closed.


## PASS 5 final answer

No more default harvesting.

The next highest-value move is:

\[
\boxed{\text{polish Paper 1 into submission form}}
\]

The second highest-value move is:

\[
\boxed{\text{send the high-seam PHNC expert packet}}
\]

The third highest-value move is:

\[
\boxed{\text{add diagrams to Paper 2}}
\]
