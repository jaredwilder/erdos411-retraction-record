"""R691 — Empirically verify GPT's exact moment laws + Claude's CRT-independence.

GPT R691-R697 delivered:
  R691.1: Σ_{m∈F_q*} Δ_m(q) = 0                                (1st moment)
  R691.2: Σ_{m∈F_q*} |Δ_m(q)|² = 1/|Γ_q| - 1/(q-1)              (2nd moment exact)

Claude's contribution:
  Lemma 7: For distinct primes q_1 ≠ q_2, by CRT-independence,
           E_{m ∈ (Z/q_1q_2Z)*} [Δ_m(q_1) Δ_m(q_2)] = 0
  Lemma 8: Σ_{q ≤ Q} E_m |Δ_m(q)|² ≪ log Q unconditional via Pappalardi η=1/12

  By Fubini + Lemma 7:
    E_m |Σ_{q ≤ Q} Δ_m(q)|² = Σ_q E_m |Δ_m(q)|² ≪ log Q
  By Markov: density of m with |Σ_q Δ_m(q)| > T is ≪ log Q / T²
  ⟹ Cor 4.1' (density-zero exceptional set) unconditional via 2nd moment.

This script verifies:
  1. R691.2 second moment formula at primes q ≤ 200.
  2. CRT cross-moment vanishing for pairs (q_1, q_2) ≤ 50.
  3. Σ_q E_m |Δ_m(q)|² growth ~ log Q.
"""

import json
import math
from pathlib import Path
from sympy import isprime, gcd as sgcd

OUT = Path(__file__).with_suffix('.json')


def order_mod(g, q):
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def Gamma_q(q):
    a = order_mod(2, q)
    b = order_mod(3, q)
    G = set()
    for k in range(a):
        for l in range(b):
            G.add((pow(2, k, q) * pow(3, l, q)) % q)
    return G, a, b


def delta_m_q(m, q, Gamma):
    """Δ_m(q) = 1_{Γ_q}(-m^{-1})/|Γ_q| - 1/(q-1)."""
    if math.gcd(m, q) != 1:
        return None
    c = (-pow(m, -1, q)) % q
    g = len(Gamma)
    indicator = 1 if c in Gamma else 0
    return indicator / g - 1 / (q - 1)


def main():
    print("R691 — Empirical verification of EXACT moment laws + CRT-independence")
    print("=" * 88)
    print()

    # Step 1: Verify R691.2 second moment at primes q ≤ 200
    print("Step 1: R691.2 — second moment Σ_{m∈F_q*} |Δ_m(q)|²")
    print(f"{'q':>4} {'|Γ_q|':>6} {'predicted':>12} {'computed':>12} {'rel_err':>10} {'OK':>3}")
    print("-" * 60)
    R691_2_verified = []
    all_ok = True
    for q in range(5, 100):
        if not isprime(q) or q in (2, 3):
            continue
        Gamma, a, b = Gamma_q(q)
        g = len(Gamma)
        predicted = 1/g - 1/(q-1)
        computed = sum(delta_m_q(m, q, Gamma) ** 2 for m in range(1, q) if math.gcd(m, 6*q) == 1)
        # Need to add back the m values with gcd(m, 6) != 1 (but coprime to q)
        # Actually we want all m ∈ F_q*, regardless of gcd with 6
        # The formula Σ_{m∈F_q*} |Δ_m(q)|² is over all m ∈ {1,...,q-1}
        computed_full = sum(delta_m_q(m, q, Gamma) ** 2 for m in range(1, q))
        rel_err = abs(computed_full - predicted) / max(abs(predicted), 1e-15)
        ok = rel_err < 1e-10
        if not ok:
            all_ok = False
        print(f"{q:>4} {g:>6} {predicted:>12.8f} {computed_full:>12.8f} {rel_err:>10.2e} {'YES' if ok else 'NO':>3}")
        R691_2_verified.append({
            'q': q, 'Gamma_size': g, 'predicted': predicted,
            'computed': computed_full, 'rel_err': rel_err, 'ok': ok,
        })

    print(f"\nR691.2 second moment formula holds: {all_ok}")
    print()

    # Step 2: Verify CRT cross-moment vanishing
    print("Step 2: CRT cross-moment vanishing E_m [Δ_m(q_1)·Δ_m(q_2)] over m ∈ (Z/q_1q_2Z)*")
    print(f"{'q1':>3} {'q2':>3} {'q1q2':>5} {'cross_moment':>14} {'|cm|':>10}")
    print("-" * 50)
    crt_verified = []
    for q1 in [5, 7, 11]:
        for q2 in [13, 17, 19, 23, 29]:
            if q2 <= q1:
                continue
            G1, _, _ = Gamma_q(q1)
            G2, _, _ = Gamma_q(q2)
            N = q1 * q2
            total = 0.0
            count = 0
            for m in range(1, N):
                if math.gcd(m, N) != 1:
                    continue
                d1 = delta_m_q(m % q1, q1, G1)
                d2 = delta_m_q(m % q2, q2, G2)
                if d1 is None or d2 is None:
                    continue
                total += d1 * d2
                count += 1
            cross_moment = total / count if count > 0 else 0
            print(f"{q1:>3} {q2:>3} {N:>5} {cross_moment:>+14.10f} {abs(cross_moment):>10.2e}")
            crt_verified.append({'q1': q1, 'q2': q2, 'cross_moment': cross_moment})

    print()

    # Step 3: Σ_q E_m |Δ_m(q)|² growth
    print("Step 3: Σ_{q ≤ Q} E_m |Δ_m(q)|² growth")
    print(f"{'Q':>4} {'sum_var':>15} {'log_Q':>8} {'sum/log_Q':>12}")
    print("-" * 50)
    sum_var = 0.0
    growth_data = []
    for q in range(5, 200):
        if not isprime(q) or q in (2, 3):
            continue
        Gamma, a, b = Gamma_q(q)
        g = len(Gamma)
        E_var = (1/(q-1)) * (1/g - 1/(q-1))  # R691.2 normalized
        sum_var += E_var
        if q in (50, 100, 150, 200, 197):  # check at milestones
            log_Q = math.log(q)
            print(f"{q:>4} {sum_var:>15.8f} {log_Q:>8.3f} {sum_var/log_Q:>12.6f}")
            growth_data.append({'Q': q, 'sum_var': sum_var, 'log_Q': log_Q})

    out = {
        'phase': 'R691 — Moment-law empirical verification',
        'R691_2_verified_uniformly': all_ok,
        'R691_2_data': R691_2_verified,
        'crt_cross_moment_data': crt_verified,
        'sum_variance_growth': growth_data,
    }
    OUT.write_text(json.dumps(out, indent=2))
    print(f"\nWritten {OUT}")


if __name__ == '__main__':
    main()
