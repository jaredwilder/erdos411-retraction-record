# REFEREE CHECKLIST — PASS 5

## Paper 1: Subgroup Obstruction Calculus

A referee should be able to verify:

- finite abelian subgroup obstruction lemma;
- multiplication fiber theorem;
- exact local density formula;
- character-annihilator expansion;
- exact moment laws;
- CRT orthogonality;
- weighted variance theorem;
- examples \(q=5\), \(q=23\).

No analytic number theory is required.

## Paper 2: CRT Synchronization / Projective Slopes

A referee should be able to verify:

- squarefree lattice-image membership criterion;
- synchronization defect quotient;
- \(d=95\) local/global failure;
- pair determinant criterion;
- projective slope equivalence;
- star atom treatment;
- Kummer independence valuation lemma.

## Paper 3: Density-Zero

A referee will require:

- exact Pappalardi theorem statement;
- exact sieve functional;
- integer averaging proof;
- explicit exceptional set;
- threshold normalization.

Until those are inserted, this is not submission-ready.

## Paper 4: Conditional Criterion

A referee will require:

- PHNC statement;
- proof or assumption for PHNC \(\Rightarrow\) smoothing;
- proof or assumption for Kummer-BV \(\Rightarrow\) NEG-203;
- clear separation from unconditional claims.

## Paper 5: Failed Routes Audit

A referee should read this as an audit note. Tone should remain respectful: the issue is theorem mismatch, not failure of the cited classical results.
