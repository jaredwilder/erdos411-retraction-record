# L1-L4 Round 2 Specialist Borg — Brutal Self-Audit of Round 1's Attack Vectors

**Date:** 2026-05-12 Phase 13 (operator: *"ATTACK + USE THE ORACLE HARD + RECORD IT ALL... WE GET BETTER EVERYTIME"*)
**Stage:** L1-L4 Deepening Round 2 (post-Round-1 self-audit)
**Method:** 4 NEW specialist agents (Gowers/Tao + Adelic/Lindenstrauss + Maynard/Pintz + Sarnak/Möbius), each more technical than Round 1

---

## §0. Headline — Round 1 was over-promised; Round 2 corrects

**The Oracle just audited its own prior multi-AI Borg round and found MAJOR ERRORS:**

| Round 1 claim | Round 2 verdict |
|---|---|
| **(β) Heisenberg nilmanifold + $U^3$ inverse** — "Inventiones-grade, CHEAPER than Furstenberg ×2×3" | **CATEGORY ERROR.** $(\mathbb{Z}/q)^*$ is abelian → commutator $k\ell$ carries NO orbit information. Conjecture B'' lives at $U^2$, NOT $U^3$. LSS 2024 doesn't help. Demote to "negative-result direction" / JNT note. |
| **(γ) Bergelson-Richter adelic positive-entropy bypass** — "Inventiones-grade, bypasses Furstenberg's 60-year wall" | **WISHFUL THINKING.** EKL 2006 is a measure-rigidity theorem REQUIRING positive entropy as hypothesis, not producing it. Bergelson-Richter 2022 is QUALITATIVE only. Projection from adelic quotient to $\mathbb{Z}/q$ has $q^{O(1)}$ norm blow-up — SAME uniformity barrier. Best: density-one NEG-203 (no rate). |
| **(α) Linnik dispersion + large sieve** — JNT-grade follow-up | **CONFIRMED.** Maynard specialist confirms this is the only viable direction. Heath-Brown Type II on orbit is STRICTLY STRONGER than Conjecture B''. |

**Cumulative operator-coupling discipline fires: 44** (16 cardiac + 28 #203, F17-F44).

---

## §1. Gowers norms / Tao-school specialist — Heisenberg embedding is a category error (Fire 43)

### 1.1 The mathematical error in Round 1 Borg

The Round 1 cross-domain Borg said: "Embed orbit into $H_3(\mathbb{Z}/q)$ via $(k, \ell) \mapsto (k, \ell, k\ell)$. Discrepancy $C(q)$ becomes nilsequence correlation."

**Round 2 specialist refutation:**

The multiplicative orbit $\{2^k 3^\ell \bmod q\}$ lives in $(\mathbb{Z}/q)^*$. After passing to additive characters via Heath-Brown identity:
$$\mathbf{1}_{\rm prime}(2^k 3^\ell m + 1) \sim \sum_{k, \ell} \phi(k, \ell) \, e_q(a (\alpha k + \beta \ell + \text{lower})), \quad \alpha = \log_g 2, \beta = \log_g 3$$

**This is a 1-step (linear) nilsequence on $(\mathbb{Z}/q)^2$, not a genuine 2-step one.** The phase $\alpha k + \beta \ell$ is linear; no $k\ell$ term arises because **multiplication in $(\mathbb{Z}/q)^*$ is abelian** — the commutator vanishes.

**Conjecture B'' lives at $U^2$, NOT $U^3$.** For $U^2$ inverse, Green's 2005 unconditional polynomial inverse theorem already applies. The reason B'' is hard is the multiplicative-group-theoretic Bourgain bound, not $U^k$ inverse theorems.

### 1.2 The empirical falsification test (R604 revised)

Specialist's prediction (50% confidence): empirically, $\|f_q\|_{U^3}$ will match $\|f_q\|_{U^2}$ within 5% across q. **If yes → β is a dead end empirically.**

Concrete test: compute $\|f_q\|_{U^3}$ for $f_q(n) = \mathbf{1}[n \in \langle 2, 3\rangle \bmod q] - |H_q|/q$. Pre-registered verdict:
- $U^3 < 0.5 \cdot U^2$ with $q^{-\delta}$ decay ($\delta \geq 0.05$): β revived, Manners-Tao pathway works
- $U^3 \approx U^2$ within 5%: β refuted, demote to negative-result JNT note

### 1.3 LSS 2024 not strong enough even if right norm

Leng-Sah-Sawhney 2024 (arXiv:2402.17994, Annals accepted) gives **quasi-polynomial** complexity bound (over Manners 2021 doubly-exponential), but: (a) wrong norm ($U^2$ needed, not $U^3$); (b) even if right norm, translating to $q$-savings via Green-Tao 2012 gives only $(\log q)^{-c}$ savings — **logarithmic, not polynomial**. At best gives B''-weak ($o(1)$), not STRONG.

### 1.4 Honest verdict from Gowers specialist

> "Prior Borg over-promised. The Heisenberg framing is a category error. β as stated is a dead end. β with the *correct* nilsequence (joint equidistribution of $(\alpha k, \beta \ell)$ on $\mathbb{T}^2$) reduces to Baker / Rhin-Viola work on $\mu(\log_2 3)$, which the manuscript §5.4 already rules out as PNT-blocked below $\mu = 5$. **The Heisenberg pathway DOES NOT exist.**"

**Patch action:** Demote attack vector (β) in §9. Add to it: "Empirical test R604 will measure $\|f\|_{U^3}/\|f\|_{U^2}$ ratio; predicted to refute the pathway."

---

## §2. Adelic ergodic / Lindenstrauss specialist — positive-entropy bypass is wishful thinking (refines Fire 42)

### 2.1 The mathematical error in Round 1 Borg

Round 1 ergodic-theorist Borg said: "Embed orbit into $\mathbb{Q}_2 \times \mathbb{Q}_3 \times \mathbb{R}$. ×2×3 has POSITIVE entropy on adelic quotient via EKL 2006, bypassing Furstenberg wall."

### 2.2 Refutation in three parts

**(a)** EKL 2006 (Annals 164:513-560) is the **Littlewood paper**, Theorem 1.5: "If SOME one-parameter subgroup has positive entropy with respect to $\mu$, then $\mu$ is Haar on a closed orbit." This is **measure rigidity REQUIRING positive entropy**, NOT producing it from adelic embedding.

**(b)** Lind-Schmidt-Ward (Invent. Math. 1990) show entropy of $\times n$ on the full solenoid $S_{\{2,3\}}$ is $\log|n|$ — SAME as on $\mathbb{T}$. Adelic embedding gives invertibility, not new entropy.

**(c)** Even WITH a polynomial adelic discrepancy bound, projection to $\mathbb{Z}/q \times \mathbb{T}$ has Fourier modes scaling like $q$ in archimedean direction. **Norm blow-up $q^{O(1)}$ means the savings degrade to non-trivial only for $q \leq N^{\delta/C}$ — EXACTLY the BLMV 2009 uniformity barrier.** The adelic route RELOCATES the wall, doesn't bypass it.

### 2.3 What is ACTUALLY closable via adelic route

Specialist's honest concrete claim:

> "Replace Conjecture B'' strong with **Conjecture B''-qualitative**: $C(q) \to 0$ along a density-one sequence of $q$. The Bergelson-Richter / Frantzikinakis-Host framework on $S_{\{2,3\}}$ can plausibly deliver this in 12-18 months. **This gives density-one NEG-203 (exceptional set of density 0 in primes q) but NOT full NEG-203, and NOT polynomial rate.**"

Effective rate (Conjecture B'' STRONG) requires effective quantitative measure rigidity, flagged by Einsiedler-Lindenstrauss Clay 2010 and Einsiedler-Margulis-Venkatesh Invent. 2009 as the central open problem of the area.

**Patch action:** Right-size attack vector (γ) in §9. Reword from "Inventiones-grade if achieved" to "12-18 month path to qualitative density-one Conjecture B''-weak refinement (improves Cor 4.1 from natural-density to logarithmic-density exceptional set, no polynomial rate)."

---

## §3. Maynard specialist — bounded-gaps incompatible with multiplicatively-lacunary orbit (Fire 45)

### 3.1 Structural mismatch

Maynard 2015 (Annals, "Small gaps between primes") requires:
- 1-parameter linear family $n \mapsto n + h_i$ with **bounded** shifts $h_i = O(1)$
- $n$ ranges over $[N, 2N]$ with positive density

Our orbit:
- 2-parameter $(k, \ell)$ multiplicatively-lacunary structure
- Consecutive elements separated by $\geq m \cdot (3/2 - 1) \cdot 2^{k_1} 3^{\ell_1} \gg X^{1-o(1)}$
- **NEVER within $C \log X$ of each other** — bounded-gap is structurally impossible

### 3.2 Maynard 2019 (missing digits) density threshold

Maynard 2019 (Inventiones, "Primes with restricted digits") requires density $\geq X^{\log 4/\log 10} \approx X^{0.602}$. Our orbit has density $(\log X)^2 / X \approx X^{o(1) - 1}$ — **3+ orders of magnitude below threshold**. Maynard 2019 cannot apply.

### 3.3 Heath-Brown Type II on orbit is STRICTLY STRONGER than B''

Type II requires factoring $2^k 3^\ell m + 1 = uv$ with $X^\varepsilon \leq u \leq X^{1/2}$. The orbit has no known algebraic factorization theory. **Friedlander-Iwaniec barrier transposed to lacunary setting.**

Conjecture B'' is the **right intermediate target** — one-sided averaged discrepancy, weaker than full Type II.

**Fire 45 status:** Maynard direct application ruled out. The §9 attack vector "(α) Linnik dispersion + large sieve" remains the only sieve-theoretic path, now confirmed by 2nd-round Maynard specialist.

---

## §4. Sarnak / Möbius randomness specialist — Theorem 6 misframed (Fires 43, 44)

### 4.1 The actual Sarnak conjecture for our orbit

Sarnak's conjecture is for $\mathbb{Z}^1$-actions. Our (2,3)-orbit is $\mathbb{Z}^2$. **Bourgain 2013 Crelle proved Sarnak for rank-one systems unconditionally; rank-two not covered.** First wall.

### 4.2 Green-Tao 2012 rate is SUB-POLYNOMIAL not polynomial

Green-Tao 2012 (Annals 175, "The Möbius function is strongly orthogonal to nilsequences") gives, for $s$-step nilsequence of complexity $\leq Q$:
$$\sum_{n \leq N} \mu(n) F(g(n) \Gamma) \ll_s N (\log N)^{-A} \text{ for every } A > 0$$

**This is $(\log N)^{-A}$, NOT $N^{1-\delta}$.** Sub-polynomial. Manners-LSS quasi-poly is also sub-polynomial.

### 4.3 The gold-standard test

> "Polynomial Möbius cancellation for the orbit would need: $\sup_{|t| \leq N} |\sum_{n \leq N} \mu(n) e(t \log_2 3 \{n \log_2 3\})| \ll N^{1-\delta}$ — this is the **Sarnak-Ubis 2014 bilinear test** at $\log_2 3$. **Open problem in Sarnak's school, not a 50-hour fix.**"

**Sarnak-Ubis 2014 JMPA** ("The horocycle flow at prime times") gave polynomial savings for the horocycle flow; the $\log_2 3$ analog is open.

### 4.4 Honest verdict on what's achievable RIGHT NOW

| Path | Polynomial savings? |
|---|---|
| Tao-Teräväinen log-Chowla | No (log only) |
| Green-Tao 2012 + Manners-LSS | No (sub-polynomial) |
| Sarnak-Ubis bilinear at $\log_2 3$ | OPEN |
| Bergelson-Richter adelic | No (qualitative only) |

**Realistic Inventiones-grade target via Möbius route:** Use Green-Tao 2012 + Manners-LSS to upgrade Corollary 4.1 from natural-density-zero to **log-density-zero** exceptional set — UNCONDITIONALLY. This is a real Inventiones-grade improvement but uses sub-polynomial bounds.

**Polynomial savings remains Fields-Medal-class.**

---

## §5. Bibliography corrections (missing from v4 — Fires 43+44)

Specialists identified citations missing from manuscript v4.7:

| Reference | Why it matters |
|---|---|
| Sarnak 2009/2010 Möbius-nilsequence lectures (IAS, Newton) | The Sarnak conjecture context |
| Bourgain 2013 Crelle | Rank-one Sarnak (limits of current technology) |
| Sarnak-Ubis 2014 JMPA | The gold-standard bilinear test for polynomial Möbius |
| Frantzikinakis-Host 2017 JAMS | Joint structure of multiplicative functions |
| Manners 2021 GAFA | Quasi-poly $U^3$ inverse |
| Leng-Sah-Sawhney 2024 | Annals-accepted quasi-poly bounds |
| Einsiedler-Lindenstrauss Clay 2010 | "Effective rates is the central open problem" |
| Einsiedler-Margulis-Venkatesh 2009 Invent. | SL_2 effective rates (only effective case) |
| Lind-Schmidt-Ward 1990 Invent. | Solenoid entropy structure |
| EKL 2006 Annals (corrected citation) | Littlewood paper, measure rigidity not entropy production |

These will be added to v4.8 references.

---

## §6. Updated attack vector landscape — what's actually feasible

After Round 2 brutal audit, the 3 attack vectors are reranked:

### **(α) Linnik dispersion + large sieve** — CONFIRMED by Maynard specialist
- Status: Most realistic single path forward
- Heath-Brown Type II is strictly stronger than B''; Linnik dispersion lets us attack the WEAKER Conjecture B'' directly
- Expected: log-density-zero exceptional set (matches Sarnak specialist's Inventiones-grade target via different route)
- Timeline: 6-12 months, JNT-grade follow-up

### **(β) Heisenberg / $U^3$ pathway** — DEMOTED to negative-result direction
- Conjecture B'' is at $U^2$ NOT $U^3$ (commutator vanishes in abelian group)
- LSS 2024 doesn't help
- R604 will empirically confirm via $U^3/U^2$ ratio
- New status: "Empirical refutation candidate; JNT note documenting why this approach fails"

### **(γ) Adelic positive-entropy** — REFRAMED, weaker than promised
- Cannot give polynomial savings
- CAN give qualitative density-one Conjecture B''-weak via Bergelson-Richter / Frantzikinakis-Host
- New status: "12-18 month path to log-density-zero (NOT polynomial)"

### **(δ) NEW: Sarnak-Ubis bilinear bound at $\log_2 3$**
- Identified by Sarnak specialist as the gold standard
- Polynomial Möbius cancellation directly at $\log_2 3$
- Open problem in Sarnak's school
- Status: "Fields-Medal-class theoretical input; pre-register interest"

---

## §7. Manuscript v4.8 changes (post-Round-2)

1. **§9 Open problems**: Reorder attack vectors per Round 2 verdict
   - (α) Linnik dispersion — promoted to primary path
   - (β) Heisenberg / $U^3$ — demoted with empirical refutation queued
   - (γ) Adelic — reframed as qualitative not polynomial
   - (δ) Sarnak-Ubis bilinear — added as named open problem
2. **References**: add 10 missing citations (Sarnak 2009/2010, Bourgain 2013 Crelle, Sarnak-Ubis 2014, Frantzikinakis-Host 2017, Manners 2021, LSS 2024, Einsiedler-Lindenstrauss Clay 2010, EKL 2006 corrected, Lind-Schmidt-Ward 1990, EMV 2009)
3. **Theorem 6**: clarify rate as sub-polynomial (Green-Tao 2012 $(\log N)^{-A}$), not Sarnak-equivalent
4. **Conjecture C status**: confirm Sarnak specialist's framing — "log-density-zero exceptional set" is the achievable target via Green-Tao + Manners-LSS

---

## §8. The new wall sentence — post-Round-2

> *"After two rounds of multi-AI specialist Borg synthesis (8 specialists, 12 fires beyond W0-W4 scope), the honest landscape is: **Theorem 9 numerical verification stands at m ≤ 10⁵**; **Conjecture C (measure-theoretic NEG-203) is conjectural with concrete 50-hour-then-12-month proof path via Linnik dispersion or Green-Tao + LSS**; **B'' weak form achievable via Bergelson-Richter qualitative route in 12-18 months**; **B'' STRONG form (polynomial savings) remains Fields-Medal-class and equivalent to Sarnak-Ubis bilinear at $\log_2 3$, a named open problem in Sarnak's school**. The Heisenberg-$U^3$ pathway, queued as 'CHEAPER than Furstenberg' in Round 1, is a category error and dead end."*

This is what HARD multi-AI Borg discipline produces: **the methodology audits itself, demotes its own over-promises, and converges on the actual feasible directions**. The Oracle gets better every round.

---

## §9. Pre-registered Round 3 attack vectors (Phase 14)

Per PUSH-5 anti-convergence:

1. **R608 (Linnik dispersion variance test)**: empirically verify $\sum_m |T_{II}(m, X)|^2 \asymp$ predicted from Pappalardi bound on the orbit
2. **R609 (Sarnak-Ubis bilinear test)**: compute the bilinear $|\sum \mu(n) e(t \log_2 3 \{n \log_2 3\})|$ for sampled t, find decay rate
3. **R610 (Bergelson-Richter mean-convergence test)**: empirically check $\bar{T}^{\Omega(p-1)} x$ convergence along primes in our orbit
4. **R611 (Frantzikinakis-Host decomposition)**: explicit nilsequence + uniform decomposition of orbit Möbius correlation
5. **R612**: Apply L1-L4 Round 3 specialist Borg with even sharper specialists (named after this round's specifics: a Bourgain-school sum-product expert, a Heath-Brown decomposition expert, a Margulis-school adelic flow expert, a Goldston-Pintz-Yıldırım small-gaps expert)

---

**Round 2 ATTACK done. 44 cumulative fires. Manuscript v4.8 patches incoming. We get better every time.**
