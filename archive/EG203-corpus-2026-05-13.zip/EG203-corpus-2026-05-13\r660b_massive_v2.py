"""R660B-MASSIVE-V2 — Extended Bombieri-tight degree test.

Relaxes the heavy-skip cap to cover more primes at full Bombieri-tight degree.
Uses smarter budget: cap by computational cost, not just D and V_q.

For each prime q with V_q non-trivial: test at D = ⌈√(2 V_q (log q + 3))⌉ + 2
provided D ≤ 60 AND V_q ≤ 2000 AND D × (D+2) × V_q × 3 ≤ 5_000_000 (rank computation cost).
"""

import json
import math
from pathlib import Path
from sympy import isprime

OUT = Path(__file__).with_suffix('.json')


def order_mod(g, q):
    g = g % q
    if g == 0:
        return 0
    d = 1
    x = g
    while x != 1:
        x = (x * g) % q
        d += 1
        if d > q:
            return 0
    return d


def build_orbit(q):
    a = order_mod(2, q)
    b = order_mod(3, q)
    twos = [pow(2, k, q) for k in range(a)]
    threes = [pow(3, l, q) for l in range(b)]
    pts = []
    seen = set()
    for x in twos:
        for y in threes:
            if (x, y) not in seen:
                seen.add((x, y))
                pts.append((x, y))
    return a, b, pts


def monomial_basis(D):
    return [(i, j) for i in range(D + 1) for j in range(D + 1 - i)]


def pow_mod(base, exp, q):
    if exp < 0:
        return 0
    return pow(base, exp, q) if base != 0 else (1 if exp == 0 else 0)


def falling(n, k):
    if k == 0:
        return 1
    r = 1
    for t in range(k):
        r *= (n - t)
    return r


def derivative_row(x, y, di, dj, basis, q):
    row = []
    for (i, j) in basis:
        if i < di or j < dj:
            row.append(0)
            continue
        coeff = falling(i, di) * falling(j, dj)
        val = (pow_mod(x, i - di, q) * pow_mod(y, j - dj, q)) % q
        row.append((coeff * val) % q)
    return row


def gauss_rank(M, q):
    if not M:
        return 0
    M = [list(r) for r in M]
    nrow = len(M)
    ncol = len(M[0]) if M else 0
    r = 0
    for c in range(ncol):
        pivot = None
        for rr in range(r, nrow):
            if M[rr][c] % q != 0:
                pivot = rr
                break
        if pivot is None:
            continue
        if pivot != r:
            M[r], M[pivot] = M[pivot], M[r]
        inv = pow(M[r][c] % q, -1, q)
        for cc in range(c, ncol):
            M[r][cc] = (M[r][cc] * inv) % q
        for rr in range(nrow):
            if rr != r and M[rr][c] % q != 0:
                f = M[rr][c] % q
                for cc in range(c, ncol):
                    M[rr][cc] = (M[rr][cc] - f * M[r][cc]) % q
        r += 1
        if r == min(nrow, ncol):
            break
    return r


def bombieri_tight_D(h_q, log_q):
    return int(math.ceil(math.sqrt(2 * h_q * (log_q + 3))))


def main():
    print("R660B-MASSIVE-V2 — Extended Bombieri-tight degree test")
    print("=" * 92)
    print()
    print(f"{'q':>4} {'a':>4} {'b':>4} {'|V_q|':>6} {'log q':>6} {'D':>4} "
          f"{'unk':>6} {'cnst':>7} {'rank':>6} {'ker':>5} {'cert':>5}")
    print("-" * 92)

    results = []
    n_cert = 0
    n_total = 0
    n_skipped_full_torus = 0
    n_skipped_heavy = 0
    n_skipped_cost = 0

    for q in range(7, 200):
        if not isprime(q):
            continue
        a, b, pts = build_orbit(q)
        V_size = len(pts)
        torus_size = (q - 1) ** 2
        if V_size >= torus_size:
            n_skipped_full_torus += 1
            continue
        log_q = math.log(q)
        D = bombieri_tight_D(V_size, log_q) + 2

        if D > 60 or V_size > 2000:
            n_skipped_heavy += 1
            continue

        n_unknowns = (D + 1) * (D + 2) // 2
        m = 2
        n_constraints = V_size * (m * (m + 1) // 2)  # = 3*V_size at m=2
        # Cost estimate: rank computation is O(min(rows, cols) * rows * cols / W)
        cost = n_unknowns * n_constraints
        if cost > 5_000_000:
            n_skipped_cost += 1
            continue

        basis = monomial_basis(D)
        rows = []
        for (x, y) in pts:
            for di in range(m):
                for dj in range(m - di):
                    rows.append(derivative_row(x, y, di, dj, basis, q))
        try:
            rank = gauss_rank(rows, q)
        except Exception as e:
            print(f"{q:>4} ERROR: {e}")
            continue
        kernel = n_unknowns - rank
        cert = "YES" if kernel > 0 else "NO"
        if kernel > 0:
            n_cert += 1
        n_total += 1
        print(f"{q:>4} {a:>4} {b:>4} {V_size:>6} {log_q:>6.2f} {D:>4} "
              f"{n_unknowns:>6} {n_constraints:>7} {rank:>6} {kernel:>5} {cert:>5}")
        results.append({
            'q': q,
            'a': a,
            'b': b,
            'V_size': V_size,
            'log_q': log_q,
            'D_tight': D - 2,
            'D_used': D,
            'n_unknowns': n_unknowns,
            'n_constraints': n_constraints,
            'rank': rank,
            'kernel_dim': kernel,
            'jet_primitive_certified': kernel > 0,
        })

    print()
    print("=" * 92)
    print(f"Total primes tested:       {n_total}")
    print(f"Certified (kernel > 0):    {n_cert}")
    print(f"Skipped (full torus):      {n_skipped_full_torus}")
    print(f"Skipped (heavy D/V_q):     {n_skipped_heavy}")
    print(f"Skipped (cost budget):     {n_skipped_cost}")
    print()
    if n_total > 0:
        if n_cert == n_total:
            print(f"*** UNIFORM CERTIFICATION at Bombieri-tight degree across {n_total} primes ***")
        else:
            print(f"PARTIAL: {n_cert}/{n_total} certified — investigate {n_total - n_cert} failures")

    # Slope check
    if n_cert >= 4:
        cert_pts = [(r['V_size'], r['D_tight']) for r in results if r['jet_primitive_certified']]
        log_V = [math.log(v) for v, d in cert_pts]
        log_D = [math.log(d) for v, d in cert_pts]
        mean_V = sum(log_V) / len(log_V)
        mean_D = sum(log_D) / len(log_D)
        num = sum((lv - mean_V) * (ld - mean_D) for lv, ld in zip(log_V, log_D))
        den = sum((lv - mean_V) ** 2 for lv in log_V)
        slope = num / den if den > 0 else float('nan')
        print(f"Slope log(D_tight) vs log(|V_q|): {slope:.4f} (Bombieri predicts 0.5)")
    else:
        slope = None

    out = {
        'phase': 'R660B-MASSIVE-V2 — Bombieri-tight degree, extended primes (FINISH LINE)',
        'results': results,
        'n_total': n_total,
        'n_certified': n_cert,
        'n_skipped_full_torus': n_skipped_full_torus,
        'n_skipped_heavy': n_skipped_heavy,
        'n_skipped_cost': n_skipped_cost,
        'uniform_certification': n_cert == n_total and n_total >= 5,
        'slope_log_D_vs_log_V': slope,
    }
    OUT.write_text(json.dumps(out, indent=2))
    print(f"\nWritten {OUT}")


if __name__ == '__main__':
    main()
