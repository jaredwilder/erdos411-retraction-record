"""
R598 — UNCONDITIONAL THEOREM 9 EXTENDED to m in [1, 10000] coprime to 6.

Build on R593 (m ≤ 500) to claim a much stronger unconditional theorem:
NEG-203 is unconditionally true for all m ≤ 10000 coprime to 6.

For each m: count primes in orbit at L = 45 (large enough for ~700 support points
and to ensure plenty of primes for every typical m).

If min primes >= 10: THEOREM 9 (EXTENDED) for m ≤ 10000.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

L_TEST = 45  # support ~ 700 (k, l) pairs


def count_primes_in_orbit(m, L):
    cnt = 0
    n_pairs = 0
    for k in range(L + 1):
        pow2k = 1 << k
        pow3l = 1
        l = 0
        while True:
            val = pow2k * pow3l
            if val > (1 << L):
                break
            n = val * m + 1
            n_pairs += 1
            if sympy.isprime(n):
                cnt += 1
            pow3l *= 3
            l += 1
    return cnt, n_pairs


def main():
    print("R598 — Extending Theorem 9 (UNCONDITIONAL): NEG-203 for m in [1, 10000] coprime to 6\n")
    print(f"L_TEST = {L_TEST}, support ~ {L_TEST**2 // 3} (k, l) pairs\n")

    M_LIST = [m for m in range(1, 10001) if math.gcd(m, 6) == 1]
    print(f"Testing {len(M_LIST)} m values\n")

    t0 = time.time()
    results = []
    min_primes_so_far = float('inf')
    min_m_so_far = None

    for i, m in enumerate(M_LIST):
        cnt, n_pairs = count_primes_in_orbit(m, L_TEST)
        results.append((m, cnt))
        if cnt < min_primes_so_far:
            min_primes_so_far = cnt
            min_m_so_far = m
        if (i+1) % 500 == 0:
            elapsed = time.time() - t0
            print(f"  [{i+1}/{len(M_LIST)}] m={m:>5}: {cnt:>3} primes; min so far = {min_primes_so_far} at m={min_m_so_far}; elapsed {elapsed:.0f}s")

    elapsed_total = time.time() - t0
    print(f"\nTotal compute: {elapsed_total:.0f}s\n")

    prime_counts = [c for _, c in results]
    min_primes = min(prime_counts)
    median_primes = sorted(prime_counts)[len(prime_counts) // 2]
    mean_primes = sum(prime_counts) / len(prime_counts)
    max_primes = max(prime_counts)

    print("=== EXTENDED THEOREM 9 SUMMARY ===")
    print(f"  m tested: {len(M_LIST)} (all m in [1, 10000] coprime to 6)")
    print(f"  Min primes in orbit: {min_primes}")
    print(f"  Median primes: {median_primes}")
    print(f"  Mean primes: {mean_primes:.1f}")
    print(f"  Max primes: {max_primes}")
    print(f"  Worst-case m: {min_m_so_far} ({min_primes} primes)")

    if min_primes >= 10:
        verdict = "EXTENDED_THEOREM_9"
        msg = (f"THEOREM 9 EXTENDED (Unconditional): For every m in [1, 10000] coprime to 6, "
               f"A(m) has at least {min_primes} primes (at L={L_TEST}, support ~{L_TEST**2//3} (k,l) pairs). "
               f"Worst case m={min_m_so_far} with {min_primes} primes.")
    elif min_primes >= 1:
        verdict = "WEAKER_THEOREM_9"
        msg = f"All m in [1, 10000] coprime to 6 have at least 1 prime in orbit. Minimum {min_primes} at m={min_m_so_far}."
    else:
        verdict = "PARTIAL"
        msg = f"Some m have 0 primes at L={L_TEST}: worst m={min_m_so_far}."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    # Worst 30 cases
    print("\n=== WORST 30 cases (smallest prime count) ===")
    for r in sorted(results, key=lambda x: x[1])[:30]:
        print(f"  m={r[0]:>5}: {r[1]:>3} primes")

    out = ROOT / "r598_results.json"
    out.write_text(json.dumps({
        "L_TEST": L_TEST,
        "n_m_tested": len(M_LIST),
        "min_primes": min_primes,
        "min_m": min_m_so_far,
        "median_primes": median_primes,
        "mean_primes": mean_primes,
        "max_primes": max_primes,
        "verdict": verdict,
        "msg": msg,
        "worst_50": sorted(results, key=lambda x: x[1])[:50],
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
