"""R646 - Empirical dispersion variance for Wall B closure test.

Compute V(Q) = sum_{q ~ Q, q prime} sum_a^* |S_q(a, L)|^2 for various Q.
Linnik claimed V(Q) ~ Q^{1+1/15}. R646 tests this directly.

For each prime q in [Q/2, Q]:
  compute sum_a |S_q(a, L)|^2 across all a in (Z/q)^*
Sum across all such q.
Compare V(Q) to predicted Q^{1+1/15}.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent
L_TEST = 30


def support_pairs(L):
    pairs = []
    log2_3 = math.log2(3)
    for k in range(L + 1):
        max_ell = int((L - k) / log2_3)
        for ell in range(max_ell + 1):
            pairs.append((k, ell))
    return pairs


def compute_V_q(q, L):
    """Sum over a in (Z/q)* of |S_q(a, L)|^2."""
    pairs = support_pairs(L)
    pow2 = [pow(2, k, q) for k in range(L + 1)]
    pow3 = [pow(3, ell, q) for ell in range(L + 1)]
    V = 0.0
    for a in range(1, q):
        if math.gcd(a, q) != 1:
            continue
        sr, si = 0.0, 0.0
        for (k, ell) in pairs:
            n = (a * pow2[k] * pow3[ell]) % q
            ang = 2 * math.pi * n / q
            sr += math.cos(ang); si += math.sin(ang)
        V += sr*sr + si*si
    return V


def main():
    print("R646 - Empirical dispersion variance V(Q) for Wall B")
    print(f"L = {L_TEST}")
    Q_caps = [100, 300, 1000, 3000]
    print(f"Q caps tested: {Q_caps}")
    print()
    print(f"{'Q':>6} {'#primes':>8} {'V(Q)':>14} {'V/Q':>10} {'V/Q^{1+1/15}':>15}")

    results = []
    for Q in Q_caps:
        primes = [p for p in sympy.primerange(2, Q + 1) if p > 3]
        t0 = time.time()
        V_total = 0.0
        for q in primes:
            V_total += compute_V_q(q, L_TEST)
        elapsed = time.time() - t0
        n_primes = len(primes)
        V_per_Q = V_total / Q
        V_scaled = V_total / (Q ** (1 + 1/15))
        results.append({"Q": Q, "n_primes": n_primes, "V_total": V_total, "V_per_Q": V_per_Q, "V_scaled": V_scaled, "elapsed_sec": elapsed})
        print(f"{Q:>6} {n_primes:>8} {V_total:>14.2f} {V_per_Q:>10.3f} {V_scaled:>15.4f} (took {elapsed:.1f}s)")

    # Test if V_scaled is bounded (Linnik prediction)
    print()
    V_scaled_vals = [r["V_scaled"] for r in results]
    print(f"V/Q^(1+1/15) values: {[f'{v:.4f}' for v in V_scaled_vals]}")
    print(f"Ratio max/min: {max(V_scaled_vals)/min(V_scaled_vals):.4f}")
    if max(V_scaled_vals)/min(V_scaled_vals) < 1.5:
        verdict = "LINNIK_PREDICTION_SUPPORTED"
    elif max(V_scaled_vals)/min(V_scaled_vals) < 3:
        verdict = "PARTIAL_SUPPORT"
    else:
        verdict = "LINNIK_PREDICTION_DEVIATES"
    print(f"VERDICT: {verdict}")

    out = ROOT / "r646_results.json"
    out.write_text(json.dumps({"phase": "Phase 26 R646", "L": L_TEST, "results": results, "verdict": verdict}, indent=2, default=str))
    print(f"Written {out}")


if __name__ == "__main__":
    main()
