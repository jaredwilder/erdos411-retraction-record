#!/usr/bin/env python3
"""Verify finite examples used in the EG203 Oracle paper drafts."""

import math

def order_mod(a, q):
    a %= q
    x = 1
    for n in range(1, q):
        x = (x * a) % q
        if x == 1:
            return n
    raise ValueError("no order found")

def subgroup_generated(gens, q):
    S = {1}
    changed = True
    while changed:
        changed = False
        for s in list(S):
            for g in gens:
                t = (s * (g % q)) % q
                if t not in S:
                    S.add(t)
                    changed = True
    return S

def primitive_root(q):
    all_units = set(range(1, q))
    for g in range(2, q):
        if {pow(g, k, q) for k in range(1, q)} == all_units:
            return g
    raise ValueError("no primitive root found")

def dlog(base, a, q):
    x = 1
    for k in range(q - 1):
        if x == a % q:
            return k
        x = (x * base) % q
    raise ValueError("no log found")

def main():
    print("q=5 subgroup:", sorted(subgroup_generated([2,3], 5)))
    print("q=23 subgroup size:", len(subgroup_generated([2,3], 23)))
    print("ord_23(2), ord_23(3):", order_mod(2,23), order_mod(3,23))

    print("primitive root 2 mod 5?", primitive_root(5) == 2)
    print("primitive root 2 mod 19?", primitive_root(19) == 2)
    print("(u5,v5):", dlog(2,2,5), dlog(2,3,5))
    print("(u19,v19):", dlog(2,2,19), dlog(2,3,19))

    sols = []
    for k in range(math.lcm(4,18)):
        for l in range(math.lcm(4,18)):
            if (k + 3*l) % 4 == 0 and (k + 13*l) % 18 == 1:
                sols.append((k,l))
    print("solutions to d=95 sync system:", sols)

    print("primitive root 3 mod 7?", primitive_root(7) == 3)
    print("(u7,v7) base 3:", dlog(3,2,7), dlog(3,3,7))
    print("primitive root 2 mod 37?", primitive_root(37) == 2)
    print("(u37,v37) base 2:", dlog(2,2,37), dlog(2,3,37))
    det_7_37 = dlog(3,2,7) * dlog(2,3,37) - dlog(2,2,37) * dlog(3,3,7)
    print("det(7,37), mod 3:", det_7_37, det_7_37 % 3)

    print("primitive root 2 mod 13?", primitive_root(13) == 2)
    print("(u13,v13) base 2:", dlog(2,2,13), dlog(2,3,13))
    det_7_13 = dlog(3,2,7) * dlog(2,3,13) - dlog(2,2,13) * dlog(3,3,7)
    print("det(7,13), mod 3:", det_7_13, det_7_13 % 3)

if __name__ == "__main__":
    main()
