"""
R585 — Empirical correlation: C(q) vs lambda_1(Lambda_q) kernel lattice geometry.

KBK new coordinate: the kernel lattice Lambda_q = {(k, l) in Z^2 : 2^k 3^l ≡ 1 mod q}
has two successive minima (lambda_1, lambda_2) controlling orbit equidistribution.

Hypothesis: C(q) := mean_L tilde_D_N^w(q, L) * N^0.65 from R577 data
satisfies C(q) ∝ lambda_1(Lambda_q)^{-alpha} for some alpha > 0.

If yes: lattice geometry IS the right observable; BV-relevant quantity is sum of lattice
vectors, which is a thin (Pappalardi-style) set.
"""
from __future__ import annotations
import json, math, sys
from pathlib import Path
import numpy as np

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

P_LIST = [17, 41, 67, 127, 257, 509, 1021, 2039, 4093, 8191, 16381, 32749, 65521]


def mult_order(g, p):
    """Multiplicative order of g mod p."""
    g = g % p
    if g == 0:
        return 0
    o = 1
    cur = g
    while cur != 1:
        cur = (cur * g) % p
        o += 1
        if o > p:
            return -1  # error
    return o


def find_kernel_lattice_vectors(p, search_radius=None):
    """Enumerate small (k, l) in lattice {2^k 3^l ≡ 1 mod p}.
    Returns list of (k, l) vectors that lie in the kernel."""
    a = mult_order(2, p)
    b = mult_order(3, p)
    # Lattice contains (a, 0), (0, b). Also other relations.
    # Lattice index in Z^2 equals orbit size |<2,3> mod p|.
    # Smallest vector is at most O(sqrt(orbit size)).
    if search_radius is None:
        search_radius = min(int(math.sqrt(p - 1)) + 5, 300)

    # Precompute 2^k mod p and 3^l mod p with positive AND negative exponents using inverse.
    inv2 = pow(2, -1, p)
    inv3 = pow(3, -1, p)
    pow2 = {}
    cur = 1
    for k in range(0, search_radius + 1):
        pow2[k] = cur
        cur = (cur * 2) % p
    cur = inv2
    for k in range(1, search_radius + 1):
        pow2[-k] = cur
        cur = (cur * inv2) % p
    pow3 = {}
    cur = 1
    for l in range(0, search_radius + 1):
        pow3[l] = cur
        cur = (cur * 3) % p
    cur = inv3
    for l in range(1, search_radius + 1):
        pow3[-l] = cur
        cur = (cur * inv3) % p

    vecs = []
    for k in range(-search_radius, search_radius + 1):
        pk = pow2[k]
        for l in range(-search_radius, search_radius + 1):
            if k == 0 and l == 0:
                continue
            if (pk * pow3[l]) % p == 1:
                vecs.append((k, l))
    return vecs, a, b


def gauss_lagrange_2d(vectors):
    """Given a list of lattice vectors in Z^2, compute Gauss-reduced basis (v1, v2)
    such that |v1| <= |v2| and |<v1, v2>| <= |v1|^2 / 2.
    Returns (lambda_1, lambda_2) = (|v1|, |v2|).
    Uses the smallest two vectors among input as starting point."""
    if not vectors:
        return None, None
    # Sort by norm; pick two shortest independent
    vectors = sorted(set(map(tuple, vectors)), key=lambda v: v[0]*v[0] + v[1]*v[1])
    v1 = vectors[0]
    v2 = None
    # Find v2 not collinear with v1
    for v in vectors[1:]:
        # Check linear independence (det != 0)
        det = v1[0] * v[1] - v1[1] * v[0]
        if det != 0:
            v2 = v
            break
    if v2 is None:
        return math.sqrt(v1[0]**2 + v1[1]**2), float('inf')

    # Gauss-Lagrange reduction
    def norm_sq(v):
        return v[0]**2 + v[1]**2
    def dot(u, v):
        return u[0]*v[0] + u[1]*v[1]
    while True:
        # Ensure |v1| <= |v2|
        if norm_sq(v1) > norm_sq(v2):
            v1, v2 = v2, v1
        # Reduce: v2 -= round(<v1, v2>/|v1|^2) * v1
        d = dot(v1, v2)
        n1 = norm_sq(v1)
        if n1 == 0:
            return None, None
        mu = round(d / n1)
        if mu == 0:
            break
        v2 = (v2[0] - mu * v1[0], v2[1] - mu * v1[1])
        if norm_sq(v2) == 0:
            return math.sqrt(n1), float('inf')

    lam1 = math.sqrt(norm_sq(v1))
    lam2 = math.sqrt(norm_sq(v2))
    return lam1, lam2


def regress(xs, ys):
    xs_arr = np.array(xs, dtype=np.float64)
    ys_arr = np.array(ys, dtype=np.float64)
    if len(xs_arr) < 3:
        return 0.0, 0.0, 0.0
    xbar = xs_arr.mean()
    ybar = ys_arr.mean()
    Sxx = ((xs_arr - xbar) ** 2).sum()
    Sxy = ((xs_arr - xbar) * (ys_arr - ybar)).sum()
    Syy = ((ys_arr - ybar) ** 2).sum()
    if Sxx == 0:
        return 0.0, 0.0, 0.0
    b = Sxy / Sxx
    a = ybar - b * xbar
    r2 = (Sxy ** 2) / (Sxx * Syy) if Syy > 0 else 0.0
    return b, a, r2


def main():
    print("R585 — Lattice geometry vs C(q)\n")

    # Load R577 results to get C(q) values
    r577 = json.loads((ROOT / "r577_results.json").read_text())
    # For each q, compute C(q) := mean over L of D(q, L) * N_phi(q, L)^0.65 for m=1
    C_q = {}
    for p in P_LIST:
        Cs = []
        for L in r577["L_LIST"]:
            row = r577["results"]["1"][str(L)][str(p)]
            if row["D"] > 0:
                Cs.append(row["D"] * (row["N_phi"] ** 0.65))
        if Cs:
            C_q[p] = float(np.mean(Cs))

    print(f"{'p':>8} {'a=ord(2)':>10} {'b=ord(3)':>10} {'lattice_det':>12} {'lambda_1':>10} {'lambda_2':>10} {'C(q)':>10}")
    data = []
    for p in P_LIST:
        # Adaptive search radius: scale with sqrt(p)
        sr = min(int(2 * math.sqrt(p)) + 10, 500)
        vecs, a, b = find_kernel_lattice_vectors(p, search_radius=sr)
        if not vecs:
            print(f"  p={p}: NO lattice vectors found in radius {sr} — INCREASE search.")
            continue
        lam1, lam2 = gauss_lagrange_2d(vecs)
        if lam2 == float('inf') or lam1 == 0:
            print(f"  p={p}: degenerate lattice (lam1={lam1}, lam2={lam2}). Skipping.")
            continue
        # det of reduced basis ≈ orbit-size = (p-1)/gcd(...)
        # Compute via |lam1 * lam2 * sin(theta)| but since we have reduced basis, det = sqrt(|v1|^2 |v2|^2 - <v1,v2>^2)
        # Use lam1 * lam2 as approximation (for orthogonalish basis); not exact but ok for display
        det_approx = lam1 * lam2
        C = C_q.get(p, float('nan'))
        print(f"{p:>8} {a:>10} {b:>10} {det_approx:>12.2f} {lam1:>10.3f} {lam2:>10.3f} {C:>10.4f}")
        if not math.isnan(C) and lam1 > 0:
            data.append({"p": p, "a": a, "b": b, "lam1": lam1, "lam2": lam2, "det": det_approx, "C": C})

    print(f"\nTotal usable: {len(data)}")

    if len(data) < 3:
        print("Not enough data for regression.")
        return

    # Regression: log C vs log lambda_1
    xs = [math.log(d["lam1"]) for d in data]
    ys = [math.log(d["C"]) for d in data]
    slope, intercept, r2 = regress(xs, ys)
    alpha = -slope  # we expect C ~ lambda_1^{-alpha}, so slope = -alpha
    print(f"\nRegression log C vs log lambda_1:")
    print(f"  C(q) ~ lambda_1^({slope:+.3f}), intercept = {intercept:+.3f}, R^2 = {r2:.3f}")
    print(f"  => alpha = {alpha:+.3f}")

    # Apply pre-registered verdict
    if (-1.5 <= slope <= -0.2) and r2 >= 0.5:
        if (-1.2 <= slope <= -0.6) and r2 >= 0.7:
            verdict = "PASS-STRONG"
            msg = f"Strong match to theoretical C(q) ~ lambda_1^(-1) prediction. Lattice geometry IS the right observable."
        else:
            verdict = "PASS"
            msg = f"Lattice predicts C with measurable correlation. Slope = {slope:.3f}, R^2 = {r2:.3f}."
    elif abs(slope) < 0.1 or r2 < 0.2:
        verdict = "FAIL"
        msg = f"No lattice correlation. Slope = {slope:.3f}, R^2 = {r2:.3f}. ZENITH required."
    else:
        verdict = "AMBIGUOUS"
        msg = f"Partial correlation. Slope = {slope:.3f}, R^2 = {r2:.3f}."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    # Also check lam2 / lam_max
    xs2 = [math.log(d["lam2"]) for d in data]
    slope2, intercept2, r2_2 = regress(xs2, ys)
    print(f"\nSecondary: log C vs log lambda_2:")
    print(f"  C(q) ~ lambda_2^({slope2:+.3f}), intercept = {intercept2:+.3f}, R^2 = {r2_2:.3f}")

    # And lam1 * lam2 (= orbit index)
    xs3 = [math.log(d["lam1"] * d["lam2"]) for d in data]
    slope3, intercept3, r2_3 = regress(xs3, ys)
    print(f"\nTertiary: log C vs log(lambda_1 * lambda_2) [= log(orbit index)]:")
    print(f"  C(q) ~ (lam_1 lam_2)^({slope3:+.3f}), intercept = {intercept3:+.3f}, R^2 = {r2_3:.3f}")

    out = ROOT / "r585_results.json"
    out.write_text(json.dumps({
        "data": data,
        "regression_lam1": {"slope": slope, "intercept": intercept, "r2": r2, "verdict": verdict},
        "regression_lam2": {"slope": slope2, "intercept": intercept2, "r2": r2_2},
        "regression_product": {"slope": slope3, "intercept": intercept3, "r2": r2_3},
        "interpretation": msg,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
