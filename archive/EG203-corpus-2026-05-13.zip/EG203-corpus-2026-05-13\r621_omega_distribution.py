"""R621 — Empirical Ω-distribution on the orbit at L=60 for worst-case m + controls.

Theorem 15 prediction (Vinogradov specialist): for every m coprime to 6,
  #{(k, l) : 2^k 3^l <= X, Ω(2^k 3^l m + 1) <= C} >> (log X)^2/(log log X)^O(1)
with C ∈ [4, 6] UNCONDITIONAL.

Empirical test: for each m in worst-case-50 cohort from R600 + 50 random controls,
compute Ω(2^k 3^l m + 1) for all (k, l) with 2^k 3^l <= 2^60. Tally distribution.

VERDICT GATES (pre-registered):
- PASS_STRONG: For >= 70% of tested m, at least 30% of orbit elements have Ω <= 6.
- PASS_MODERATE: For >= 70% of m, at least 10% of orbit elements have Ω <= 6.
- AMBIGUOUS: 30-70% of m satisfy the >= 10% condition.
- FAIL: For < 30% of m, the >= 10% condition holds.

PASS_STRONG would be EMPIRICAL ANCHOR for Theorem 15.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

LOG2_3 = math.log2(3.0)
L_TEST = 60
OMEGA_THRESHOLD = 6  # Theorem 15 predicted C


def omega_count(n):
    """Count Ω(n) = total number of prime factors with multiplicity."""
    if n <= 1:
        return 0
    return sum(e for _, e in sympy.factorint(n).items())


def orbit_omega_distribution(m, L, max_pairs=None):
    """For each (k, l) with 2^k 3^l <= 2^L, compute Ω(2^k 3^l m + 1). Return distribution."""
    omega_counts = []
    for k in range(L + 1):
        pow2k = 1 << k
        pow3l = 1
        l = 0
        while True:
            val = pow2k * pow3l
            if val > (1 << L):
                break
            n = val * m + 1
            om = omega_count(n)
            omega_counts.append(om)
            if max_pairs is not None and len(omega_counts) >= max_pairs:
                return omega_counts
            pow3l *= 3
            l += 1
    return omega_counts


def main():
    print(f"R621 — Ω-distribution on orbit at L={L_TEST} (Theorem 15 empirical test)\n")
    print(f"Threshold: Ω <= {OMEGA_THRESHOLD} (Theorem 15 prediction)\n")

    # Load R600 worst-case 50
    r600 = json.loads((ROOT / "r600_results.json").read_text())
    worst_50 = [entry[0] for entry in r600["worst_300"][:50]]

    # Add 50 random controls
    import random
    rng = random.Random(42)
    controls_50 = []
    while len(controls_50) < 50:
        m = rng.randint(1, 1_000_000)
        if math.gcd(m, 6) == 1 and m not in controls_50 and m not in worst_50:
            controls_50.append(m)

    test_m = worst_50 + controls_50
    labels = ['worst'] * 50 + ['control'] * 50
    print(f"Testing {len(test_m)} m's: 50 worst-case from R600 + 50 random controls\n")

    t0 = time.time()
    results = []
    for i, (m, label) in enumerate(zip(test_m, labels)):
        t1 = time.time()
        # For L=60, support has ~1185 elements. Sample uniformly to keep compute reasonable.
        # Actually let's just do all of them — at L=60 it's 1185 isprime/factorint calls.
        omegas = orbit_omega_distribution(m, L_TEST, max_pairs=1500)
        n_total = len(omegas)
        n_low = sum(1 for o in omegas if o <= OMEGA_THRESHOLD)
        frac_low = n_low / n_total if n_total > 0 else 0.0
        # Also compute Ω = 1 (prime) count
        n_prime = sum(1 for o in omegas if o == 1)
        frac_prime = n_prime / n_total if n_total > 0 else 0.0

        elapsed = time.time() - t1
        results.append({
            "m": m, "label": label,
            "n_total": n_total,
            "n_low": n_low,
            "frac_low": frac_low,
            "n_prime": n_prime,
            "frac_prime": frac_prime,
            "min_omega": min(omegas) if omegas else None,
            "median_omega": sorted(omegas)[len(omegas)//2] if omegas else None,
        })
        if (i+1) % 10 == 0:
            total_elapsed = time.time() - t0
            print(f"  [{i+1}/{len(test_m)}] m={m:>7} ({label}): n_low={n_low}/{n_total} ({frac_low*100:.1f}%), n_prime={n_prime} ({frac_prime*100:.1f}%), t={elapsed:.1f}s, total={total_elapsed:.0f}s")

    total_elapsed = time.time() - t0
    print(f"\nTotal compute: {total_elapsed:.0f}s\n")

    # Stats by cohort
    for cohort_label in ['worst', 'control']:
        cohort = [r for r in results if r["label"] == cohort_label]
        fracs_low = [r["frac_low"] for r in cohort]
        fracs_prime = [r["frac_prime"] for r in cohort]
        import numpy as np
        print(f"=== {cohort_label.upper()} cohort (n={len(cohort)}) ===")
        print(f"  frac_low (Ω<=6) mean: {np.mean(fracs_low):.3f}, median: {np.median(fracs_low):.3f}, min: {min(fracs_low):.3f}")
        print(f"  frac_prime (Ω=1) mean: {np.mean(fracs_prime):.3f}, median: {np.median(fracs_prime):.3f}")

    # Pre-registered verdict
    all_fracs_low = [r["frac_low"] for r in results]
    n_passing_strong = sum(1 for f in all_fracs_low if f >= 0.30)
    n_passing_moderate = sum(1 for f in all_fracs_low if f >= 0.10)

    print(f"\n=== PRE-REGISTERED VERDICT ===")
    print(f"  n_m with frac_low >= 30% (PASS_STRONG threshold): {n_passing_strong}/100")
    print(f"  n_m with frac_low >= 10% (PASS_MODERATE threshold): {n_passing_moderate}/100")

    if n_passing_strong >= 70:
        verdict = "PASS_STRONG"
        msg = f"{n_passing_strong}/100 m have >= 30% orbit elements with Ω<=6. EMPIRICAL ANCHOR FOR THEOREM 15."
    elif n_passing_moderate >= 70:
        verdict = "PASS_MODERATE"
        msg = f"{n_passing_moderate}/100 m have >= 10% orbit elements with Ω<=6. Moderate empirical support."
    elif n_passing_moderate >= 30:
        verdict = "AMBIGUOUS"
        msg = f"{n_passing_moderate}/100 m have >= 10% — borderline."
    else:
        verdict = "FAIL"
        msg = f"Only {n_passing_moderate}/100 m have >= 10%. Theorem 15 prediction not empirically validated at L=60."

    print(f"\nVERDICT: {verdict}")
    print(f"INTERPRETATION: {msg}")

    out = ROOT / "r621_results.json"
    out.write_text(json.dumps({
        "L_TEST": L_TEST,
        "OMEGA_THRESHOLD": OMEGA_THRESHOLD,
        "n_m_tested": len(test_m),
        "verdict": verdict,
        "msg": msg,
        "results": results,
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
