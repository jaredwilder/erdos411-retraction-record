# BUILD NOTES — PASS 5

## To verify examples

Run:

```bash
python3 verify_finite_examples.py
```

Expected highlights:

- `q=5 subgroup: [1, 2, 3, 4]`
- `q=23 subgroup size: 11`
- `solutions to d=95 sync system: []`
- `det(7,37), mod 3: ... 0`
- `det(7,13), mod 3: ... 1`

## To compile TeX

Use a standard LaTeX installation:

```bash
pdflatex 01_SUBGROUP_OBSTRUCTION_CALCULUS_FINAL_DRAFT.tex
pdflatex 02_CRT_SYNCHRONIZATION_PROJECTIVE_SLOPES_FINAL_DRAFT.tex
pdflatex 03_DENSITY_ZERO_KUMMER_OBSTRUCTION_SCHEMA_FINAL_DRAFT.tex
pdflatex 04_KUMMER_DISTRIBUTION_CRITERION_EG203_FINAL_DRAFT.tex
pdflatex 05_FAILED_ROUTES_PHNC_AUDIT_FINAL_DRAFT.tex
```

Some references are placeholders and should be expanded before submission.
