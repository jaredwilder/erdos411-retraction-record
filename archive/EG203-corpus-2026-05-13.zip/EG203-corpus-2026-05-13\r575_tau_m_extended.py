"""
R575 — Extended tau(m) experiment per Tao's revision demand (10^4 floor, 10^6 reads).

Tao said: "10^4 is the floor. 10^6 is what makes me read the table."

This script samples 10,000 m values coprime to 6 in [1, 10^6] and computes
tau(m) := min{k+l : 2^k * 3^l * m + 1 is prime} with (k, l) <= (50, 50).

Output: r575_tau_m_extended_results.json
"""

from __future__ import annotations

import json
import math
import random
import sys
import time
from pathlib import Path

import sympy

sys.stdout.reconfigure(line_buffering=True)

ROOT = Path(__file__).parent

KL_MAX = 50  # max k+l per Tao recommendation
M_BOUND = 1_000_000  # m in [1, 10^6]
N_SAMPLES = 10_000  # 10^4 m values


def find_tau(m: int, kl_max: int) -> tuple[int, int, int] | None:
    for kl in range(0, kl_max + 1):
        for k in range(0, kl + 1):
            l = kl - k
            val = (1 << k) * (3 ** l) * m + 1
            if sympy.isprime(val):
                return (k, l, kl)
    return None


def main():
    rng = random.Random(203)  # seed for reproducibility
    # Sample 10^4 m values coprime to 6 in [1, 10^6]
    m_values = set()
    while len(m_values) < N_SAMPLES:
        m = rng.randint(1, M_BOUND)
        if math.gcd(m, 6) == 1:
            m_values.add(m)
    m_values = sorted(m_values)

    print(f"Testing {len(m_values)} m values coprime to 6 in [1, {M_BOUND}], k+l <= {KL_MAX}")

    t_start = time.time()
    results = []
    tau_counts = {}  # histogram of tau values
    no_prime_m = []

    for i, m in enumerate(m_values):
        t0 = time.time()
        res = find_tau(m, KL_MAX)
        if res is None:
            tau = None
            no_prime_m.append(m)
            status = "NO_PRIME"
        else:
            k, l, tau = res
            status = "OK"
        log_m = math.log(m) if m > 1 else 0
        ratio = tau / log_m if (tau is not None and log_m > 0) else None
        results.append({
            "m": m,
            "tau": tau,
            "k_l": [res[0], res[1]] if res else None,
            "log_m": log_m,
            "ratio": ratio,
            "status": status,
        })
        if tau is not None:
            tau_counts[tau] = tau_counts.get(tau, 0) + 1

        if (i + 1) % 500 == 0 or status == "NO_PRIME":
            elapsed = time.time() - t_start
            rate = (i + 1) / elapsed
            eta = (len(m_values) - i - 1) / rate
            print(f"  [{i+1}/{len(m_values)}] elapsed={elapsed:.0f}s, rate={rate:.1f}/s, ETA={eta:.0f}s, "
                  f"NO_PRIME so far={len(no_prime_m)}")

    t_total = time.time() - t_start
    print(f"\nTotal elapsed: {t_total:.1f}s")

    # Statistics
    taus_found = [r["tau"] for r in results if r["tau"] is not None]
    ratios = [r["ratio"] for r in results if r["ratio"] is not None and r["ratio"] > 0]

    print(f"\n=== STATISTICS ===")
    print(f"m values tested:            {len(results)}")
    print(f"tau found (within kl<={KL_MAX}):  {len(taus_found)}")
    print(f"NO prime found:             {len(no_prime_m)}")
    if no_prime_m:
        print(f"  candidate #203 witnesses: {no_prime_m[:20]}{'...' if len(no_prime_m) > 20 else ''}")
    print(f"\ntau distribution:")
    for tau_val in sorted(tau_counts.keys()):
        cnt = tau_counts[tau_val]
        pct = 100 * cnt / len(taus_found)
        print(f"  tau = {tau_val:>3}: {cnt:>5} m values ({pct:.2f}%)")
    print(f"\nmax tau = {max(taus_found) if taus_found else None}")
    print(f"tau/log(m) ratio:")
    print(f"  mean = {sum(ratios)/len(ratios):.4f}")
    print(f"  max  = {max(ratios):.4f}")
    largest = sorted(((r["ratio"], r["m"], r["tau"]) for r in results if r["ratio"]), reverse=True)[:10]
    print(f"\nTop 10 by tau/log(m):")
    for ratio, m, tau in largest:
        print(f"  m={m:>7d}: tau={tau}, log_m={math.log(m):.2f}, ratio={ratio:.4f}")

    # Heuristic prediction comparison
    # Bateman-Horn heuristic: E[tau] ~ (log m) / singular_series
    # For our (2,3) orbit, heuristic mean tau ~ log(m)/c with c ~ 1
    print(f"\n=== VERDICT (Tao's bar: 10^6 makes him read) ===")
    print(f"Sample size: {len(results)} m in [1, {M_BOUND}]")
    print(f"NO #203 candidates (tau = infinity): {len(no_prime_m) == 0}")
    if no_prime_m:
        print(f"  ANOMALIES: {len(no_prime_m)} m showed no prime within kl <= {KL_MAX}")
        print(f"  These are the candidate #203 witnesses for deeper investigation.")
    else:
        print(f"  Heuristic strongly supports NEG-203: every m tested has small tau.")

    out_path = ROOT / "r575_tau_m_extended_results.json"
    # Don't save all 10K results in detail - just summary + anomalies
    out_path.write_text(json.dumps({
        "config": {
            "n_samples": N_SAMPLES,
            "m_bound": M_BOUND,
            "kl_max": KL_MAX,
            "seed": 203,
        },
        "n_tested": len(results),
        "tau_distribution": tau_counts,
        "max_tau": max(taus_found) if taus_found else None,
        "mean_ratio": sum(ratios) / len(ratios) if ratios else None,
        "max_ratio": max(ratios) if ratios else None,
        "n_no_prime": len(no_prime_m),
        "no_prime_m_values": no_prime_m,
        "top10_largest_ratio": [
            {"m": m, "tau": tau, "ratio": ratio} for ratio, m, tau in largest
        ],
    }, indent=2))
    print(f"\nWritten to {out_path}")


if __name__ == "__main__":
    main()
