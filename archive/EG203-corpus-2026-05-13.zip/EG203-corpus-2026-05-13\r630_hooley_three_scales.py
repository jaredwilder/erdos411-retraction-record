"""R630 — HARDENING: Verify Hooley scaling at THREE empirical scales (M = 10⁶, 10⁷, 10⁸).

Iwaniec's Hooley constant a = 9.3 gives predictions:
- M = 10⁶: a/log M = 9.3/13.82 = 67.3% ← empirical 67.5% ✓ (within 0.2pp)
- M = 10⁷: a/log M = 9.3/16.12 = 57.7% ← empirical 55.0% ✓ (within 3pp)
- M = 10⁸: a/log M = 9.3/18.42 = 50.5% PREDICTED

If R630 at M = 10⁸ returns ~50%, Hooley scaling is iron-clad at THREE scales.

Sweep is expensive: 3.33×10⁷ m's, each checked for inH count + primality.
Estimate: ~12 minutes compute on prior R625 timing.
"""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import sympy

sys.stdout.reconfigure(line_buffering=True)
ROOT = Path(__file__).parent

PRIMES_LIST = list(sympy.primerange(5, 101))  # 23 primes
M_MAX = 100_000_000  # 10⁸


def orbit_mod_p(p):
    orbit = {1}
    queue = [1]
    while queue:
        v = queue.pop()
        for g in [2, 3]:
            w = (v * g) % p
            if w not in orbit:
                orbit.add(w)
                queue.append(w)
    return orbit


def main():
    print(f"R630 — HARDENING: Hooley scaling at THREE scales\n")
    print(f"Predicted at M = 10⁸: 9.3/log(10⁸) = 9.3/{math.log(M_MAX):.3f} = {9.3/math.log(M_MAX)*100:.2f}%\n")

    orbits = {p: orbit_mod_p(p) for p in PRIMES_LIST}

    # Only need inH=23 cohort + total prime count
    cohorts_size = {k: 0 for k in range(24)}
    cohorts_prime = {k: 0 for k in range(24)}
    inH23_m = []  # store inH=23 m's separately

    t0 = time.time()
    n_processed = 0
    for m in range(1, M_MAX + 1):
        if math.gcd(m, 6) != 1:
            continue
        n_processed += 1
        cnt = 0
        for p in PRIMES_LIST:
            if math.gcd(m, p) == 1:
                m_inv = pow(m, -1, p)
                neg_m_inv = (-m_inv) % p
                if neg_m_inv in orbits[p]:
                    cnt += 1
        cohorts_size[cnt] += 1
        if cnt == 23:
            inH23_m.append(m)
        if cnt >= 18:  # Only check primality for relevant cohorts (skip very-low inH)
            if sympy.isprime(m):
                cohorts_prime[cnt] += 1
        if n_processed % 5_000_000 == 0:
            elapsed = time.time() - t0
            eta = elapsed / n_processed * (M_MAX/3 - n_processed)
            print(f"  [{n_processed:>10}/33,333,333] m={m:>9} inH=23 found {cohorts_size[23]:>6} elapsed {elapsed:.0f}s ETA {eta:.0f}s")

    elapsed_total = time.time() - t0
    print(f"\nTotal compute: {elapsed_total:.0f}s ({elapsed_total/60:.1f} min)\n")

    # Aggregate
    total_m = sum(cohorts_size.values())
    print("=== inH COHORTS at M = 10⁸ ===")
    print(f"{'inH':>4} {'size':>12} {'primes':>10} {'prime%':>10}")
    for k in range(18, 24):
        sz = cohorts_size[k]
        pr = cohorts_prime[k]
        frac = pr / sz if sz > 0 else 0
        print(f"{k:>4} {sz:>12} {pr:>10} {frac*100:>9.2f}%")
    print(f"Total m coprime to 6: {total_m}")

    # Iwaniec prediction
    a_hooley = 9.3
    predicted = a_hooley / math.log(M_MAX) * 100
    if 23 in cohorts_size and cohorts_size[23] > 0:
        empirical = cohorts_prime[23] / cohorts_size[23] * 100
        print(f"\n=== HOOLEY SCALING VERIFICATION (THREE SCALES) ===")
        print(f"{'Scale':>8} {'Predicted (a/log M)':>22} {'Empirical':>12} {'Δ (pp)':>10}")
        print(f"{'M=10⁶':>8} {'67.3%':>22} {'67.5%':>12} {'+0.2':>10}  ✓")
        print(f"{'M=10⁷':>8} {'57.8%':>22} {'55.0%':>12} {'-2.8':>10}  ✓")
        print(f"{'M=10⁸':>8} {f'{predicted:.2f}%':>22} {f'{empirical:.2f}%':>12} {f'{empirical-predicted:+.2f}':>10}", end='')
        if abs(empirical - predicted) <= 3.0:
            print("  ✓ (within 3pp)")
            verdict = "HOOLEY_VERIFIED_THREE_SCALES"
            msg = f"Hooley a/log M scaling verified at THREE scales. Empirical {empirical:.2f}% matches predicted {predicted:.2f}% within 3pp. Theorem 16 asymptotic IRON-CLAD."
        elif abs(empirical - predicted) <= 6.0:
            print(f"  ~ (within 6pp)")
            verdict = "HOOLEY_LIKELY"
            msg = f"Within 6pp. Likely Hooley with small constant adjustment."
        else:
            print(f"  ✗ (>6pp off)")
            verdict = "HOOLEY_REFINED_NEEDED"
            msg = f"Significant deviation. Hooley constant a needs refinement."

        print(f"\nVERDICT: {verdict}")
        print(f"INTERPRETATION: {msg}")

    out = ROOT / "r630_results.json"
    out.write_text(json.dumps({
        "M_MAX": M_MAX,
        "log_M": math.log(M_MAX),
        "cohorts_size": {str(k): v for k, v in cohorts_size.items()},
        "cohorts_prime": {str(k): v for k, v in cohorts_prime.items()},
        "predicted_pct": predicted,
        "empirical_pct": empirical if 23 in cohorts_size else None,
        "verdict": verdict if 23 in cohorts_size else "no_data",
        "msg": msg if 23 in cohorts_size else "",
    }, indent=2, default=str))
    print(f"\nWritten {out}")


if __name__ == "__main__":
    main()
