# PARI/Python Computational Spec — Rank-3 Kummer Slopes

## Target

Compute the rank-3 projective Kummer points for bases
\[
(2,3,5)
\]
and test row-rank / collision statistics.

## Input

- prime \(\ell\);
- bound \(Q\);
- bases \([2,3,5]\).

## For each prime \(q\le Q\), \(q\equiv1\pmod\ell\), \(q\nmid30\)

1. find primitive root \(g_q\);
2. compute discrete logs:
   \[
   2=g_q^{u_1},\quad 3=g_q^{u_2},\quad 5=g_q^{u_3};
   \]
3. reduce:
   \[
   x_\ell(q)=(u_1,u_2,u_3)\bmod\ell;
   \]
4. classify:
   - star atom if \(x_\ell(q)=0\);
   - projective point \([u_1:u_2:u_3]\in\mathbb P^2(\mathbb F_\ell)\) otherwise.

## Outputs

1. projective bucket sizes;
2. star atom count;
3. pair-collision count;
4. matrix rank distribution for random triples;
5. adjacency matrix of \(G_{\ell,3}(Q)\);
6. second eigenvalue / spectral gap if graph nontrivial.

## Minimal pure Python pseudocode

```python
for q in primes_up_to(Q):
    if q % ell != 1 or q in bad_primes:
        continue
    g = primitive_root(q)
    row = [discrete_log_mod_prime(a, g, q) % ell for a in [2,3,5]]
    if row == [0,0,0]:
        star.append(q)
    else:
        buckets[projectivize(row, ell)].append(q)
```

## Direct theorem link

A bucket collision is exactly pairwise rank defect in the first-level \(\ell\)-synchronization matrix.
