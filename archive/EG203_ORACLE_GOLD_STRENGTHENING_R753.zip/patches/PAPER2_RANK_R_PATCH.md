# Patch for Paper 2 — Rank-\(r\) Generalization

Insert the following as a new final section before the bibliography.

```latex
\section{Rank-\(r\) synchronization}

Let \(a_1,\ldots,a_r\) be units modulo a squarefree integer \(d=q_1\cdots q_s\).  Choose primitive roots \(g_i\bmod q_i\), and write
\[
a_j\equiv g_i^{u_{ij}}\pmod{q_i},\qquad c\equiv g_i^{w_i}\pmod{q_i}.
\]
Define
\[
\Phi_d:\mathbb Z^r\to\bigoplus_{i=1}^s\mathbb Z/(q_i-1)\mathbb Z,
\qquad
(n_1,\ldots,n_r)\mapsto
\left(\sum_{j=1}^r n_j u_{ij}\right)_i .
\]
Then
\[
c\in\langle a_1,\ldots,a_r\rangle\bmod d
\]
if and only if
\[
(w_i)_i\in\operatorname{im}\Phi_d.
\]

For \(q\equiv1\pmod\ell\), define the Kummer log row
\[
x_\ell(q)=(u_{q1},\ldots,u_{qr})\in\mathbb F_\ell^r.
\]
If \(x_\ell(q)\ne0\), define the projective Kummer point
\[
\sigma_\ell(q; a_1,\ldots,a_r)=[u_{q1}:\cdots:u_{qr}]\in\mathbb P^{r-1}(\mathbb F_\ell).
\]
For two primes \(p,q\equiv1\pmod\ell\), outside the star atom \(x_\ell(p)=0\) or \(x_\ell(q)=0\),
\[
\rank
\begin{pmatrix}
x_\ell(p)\\x_\ell(q)
\end{pmatrix}<2
\]
if and only if
\[
\sigma_\ell(p)=\sigma_\ell(q).
\]
Thus the two-generator determinant criterion is the \(r=2\) case of projective collision in \(\mathbb P^{r-1}(\mathbb F_\ell)\).
```
