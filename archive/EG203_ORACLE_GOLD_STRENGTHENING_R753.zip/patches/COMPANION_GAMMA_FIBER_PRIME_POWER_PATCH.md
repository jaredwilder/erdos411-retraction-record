# Patch for Companion Note — Prime-Power / Hensel Synchronization

Insert as a new section in the exact \(\Gamma\)-fiber local-density note.

```latex
\section{Prime-power lifting}

Let \(q\nmid a_1\cdots a_r\) be an odd prime.  For \(e\ge1\), put
\[
\Gamma_{q^e}(\mathbf a)=\langle a_1,\ldots,a_r\rangle\subset(\mathbb Z/q^e\mathbb Z)^*.
\]
Reduction modulo \(q^e\) gives an exact sequence
\[
1\to K_e\to \Gamma_{q^{e+1}}(\mathbf a)\to\Gamma_{q^e}(\mathbf a)\to1,
\]
where
\[
K_e=\Gamma_{q^{e+1}}(\mathbf a)\cap(1+q^e\mathbb Z/q^{e+1}\mathbb Z).
\]
Since
\[
1+q^e\mathbb Z/q^{e+1}\mathbb Z\simeq(\mathbb Z/q\mathbb Z,+)
\]
has prime order \(q\), one has
\[
|K_e|\in\{1,q\}.
\]
Therefore
\[
|\Gamma_{q^e}(\mathbf a)|=|\Gamma_q(\mathbf a)|q^{N_e}
\]
for some \(0\le N_e\le e-1\).  The missing exponent \(e-1-N_e\) is the vertical lifting defect.
```
