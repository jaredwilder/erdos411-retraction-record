# V18 Ferrari Race 5: Tight-Cell Targeting

## Verdict

No replayed depth-3 targeted branch destroyed any parent tight cell, and no replayed branch destroyed any original residual cell.

## Binary

Can tight cells with exactly one surviving lift be characterized algebraically, or can they be targeted to produce a depth-3 counterexample branch?

## Setup

Race 4 identified the vulnerable edge: final families with global fiber minimum = 1. Race 5 targeted exactly those parent families.

- Parent tight families tested: `2`
- Candidate q3 primes: primes <= `300`
- Area limit: `1500000` cells
- Total branches considered: `101`
- Replayed branches: `26`
- Skipped branches: `75`

## Results

```json
{
  "prime_bound": 300,
  "area_limit": 1500000,
  "total_branches_considered": 101,
  "replayed_branches": 26,
  "skipped_branches": 75,
  "branches_destroying_parent_tight_cells": 0,
  "branches_destroying_any_initial_cell": 0,
  "max_initial_destroyed_count": 0,
  "min_parent_tight_survival_ratio": 1.0,
  "replayed_by_parent": {
    "4": 9,
    "6": 17
  },
  "skipped_by_parent": {
    "4": 41,
    "6": 34
  }
}
```

## Parent Tight Cells

```json
[
  {
    "idx": 4,
    "tight_min": 1,
    "tight_count": 1,
    "tight_cells_sample": [
      [
        0,
        0
      ]
    ],
    "moduli": [
      5,
      7,
      11,
      13,
      17,
      31,
      41,
      61,
      97,
      241
    ]
  },
  {
    "idx": 6,
    "tight_min": 1,
    "tight_count": 3,
    "tight_cells_sample": [
      [
        0,
        0
      ],
      [
        20,
        20
      ],
      [
        40,
        40
      ]
    ],
    "moduli": [
      5,
      7,
      11,
      13,
      17,
      31,
      41,
      61,
      241
    ]
  }
]
```

## Earned Claim

Within the bounded Race-5 targeted search, the tight one-lift cells could not be killed by any replayed depth-3 branch. This turns the vulnerable edge from a suspected attack surface into additional bounded evidence for fiber survival.

## What This Does Not Claim

- It does not prove unbounded depth.
- It does not cover skipped branches above the area limit.
- It does not cover q3 primes above `300`.
- It does not prove global CRT-covering impossibility.

## Next KBK Binary

Do tight-cell families admit an explicit residue-class formula that explains why q3 danger closure cannot eliminate their last surviving lift?

## Artifact

- `v18_race5_tight_cell_targeting_certificate.json`
- `race5_branch_rows.csv`
