# V17 Extension Stability Sweep

Primes tested: 21

Accuracy: 1.000
MAE: 0.004371

Classification counts: `{'MODULUS_DEPENDENT_ARTIFACT': 3, 'PERSISTENT_OBSTRUCTION': 18}`

Ablation winner: MASK_OVERLAP_ONLY (CARRIES_SIGNAL)
