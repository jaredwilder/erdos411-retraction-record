# V17 Extension Stability Sweep

Primes tested: 49

Accuracy: 1.000
MAE: 0.001873

Classification counts: `{'MODULUS_DEPENDENT_ARTIFACT': 3, 'PERSISTENT_OBSTRUCTION': 46}`

Ablation winner: MASK_OVERLAP_ONLY (CARRIES_SIGNAL)
