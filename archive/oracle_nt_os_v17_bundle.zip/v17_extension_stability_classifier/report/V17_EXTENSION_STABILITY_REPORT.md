# V17 Extension-Stability Classifier Report

## Verdict
DISCOVERY_PROMOTED_THEOREM_PRESSURE

## One Binary
Can extension-prime stability be predicted from computable q-features with replayable overlap certificates and heldout validation?

## V16 Input
Base moduli: [5, 7, 11]  
Train extension primes: [13, 17, 19, 23, 29, 31]  
Holdout extension primes: [37, 41, 43, 47, 53, 59, 61, 67, 71, 73]

## Feature Ledger Summary
Rows: 16  
Base uncovered count: 2010

## Overlap Certificate Replay Results
Each q has an `EXTENSION_MASK_OVERLAP_CERTIFICATE` in `overlap_certificates/` with replay command and hash.

## Classifier
Rule: `IF extension q enlarges the base exponent-period lattice THEN PERSISTENT_OBSTRUCTION ELSE MODULUS_DEPENDENT_ARTIFACT`

Holdout accuracy: 1.000  
Holdout MAE: 0.003259  
Validation verdict: CLASSIFIER_PROMOTED_HELDOUT_PASS

| q | actual class | actual rho | predicted class | correct |
|---:|---|---:|---|---|
| 37 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 41 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 43 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 47 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 53 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 59 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 61 | MODULUS_DEPENDENT_ARTIFACT | 0.982587064677 | MODULUS_DEPENDENT_ARTIFACT | True |
| 67 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 71 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |
| 73 | PERSISTENT_OBSTRUCTION | 1.000000000000 | PERSISTENT_OBSTRUCTION | True |

## Feature Ablation
Winner: MASK_OVERLAP_ONLY (CARRIES_SIGNAL)

## Theorem Route
Status: THEOREM_ROUTE_PROMOTED  
Attack surface: LEMMA_FEATURE_TO_OVERLAP

Lemma targets:
- **LEMMA_OVERLAP_IDENTITY**: rho(q) equals one minus the normalized count of base-uncovered cells whose full q-period lift fiber is contained in the extension mask C_q. — COMPUTATION_CONFIRMED
- **LEMMA_PERSISTENCE_VANISHING**: If no base-uncovered q-lift fiber is contained in C_q, extension by q preserves all base uncovered cells. — TARGET_READY
- **LEMMA_FRAGILITY_POSITIVE_OVERLAP**: If at least one base-uncovered q-lift fiber is contained in C_q, the destruction ratio equals the normalized number of such fibers. — TARGET_READY
- **LEMMA_FEATURE_TO_OVERLAP**: For this base family, period-lattice enlargement predicts overlap vanishing on the tested/heldout domain; prove or refute a clean algebraic criterion linking period growth to lift-fiber escape from C_q. — OPEN_REFEREE_TARGET

## Failure Assets
[]

## Next KBK Binary
Can period-lattice enlargement be proven to force q-lift fiber escape from the extension mask C_q for this base family?

## GTH Claim
CLAIM: Finite CRT noncover obstructions in exponent-pair covering systems have measurable extension-stability types, and for the tested {5,7,11} base family the persistence/fragility split is predicted on holdout primes by period-lattice enlargement.

STAKE: V16 observed mixed behavior. V17 converts the observation into replayed overlap certificates, a predeclared interpretable q-feature rule, holdout validation, ablation, and theorem-route lemmas.

ATTACK SURFACE: The feature-to-overlap step. The overlap identity is finite and replayable; the hard theorem target is to prove when period-lattice enlargement forces q-lift fiber escape from the extension mask.

REFEREE TARGET: Prove or refute a clean algebraic criterion linking the relation/period lattice of <2,3> modulo q and overlap vanishing for the projected uncovered set U.
