# Formal Lemma Targets

- **LEMMA_OVERLAP_IDENTITY**: rho(q) equals one minus the normalized count of base-uncovered cells whose full q-period lift fiber is contained in the extension mask C_q. (COMPUTATION_CONFIRMED)
- **LEMMA_PERSISTENCE_VANISHING**: If no base-uncovered q-lift fiber is contained in C_q, extension by q preserves all base uncovered cells. (TARGET_READY)
- **LEMMA_FRAGILITY_POSITIVE_OVERLAP**: If at least one base-uncovered q-lift fiber is contained in C_q, the destruction ratio equals the normalized number of such fibers. (TARGET_READY)
- **LEMMA_FEATURE_TO_OVERLAP**: For this base family, period-lattice enlargement predicts overlap vanishing on the tested/heldout domain; prove or refute a clean algebraic criterion linking period growth to lift-fiber escape from C_q. (OPEN_REFEREE_TARGET)