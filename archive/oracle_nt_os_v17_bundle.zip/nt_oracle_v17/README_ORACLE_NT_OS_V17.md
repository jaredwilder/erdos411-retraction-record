# Oracle NT OS V17 - Extension Stability Classifier

V17 implements the V17 Ultimate Heat File contract: compress V16's mixed CRT extension behavior into a heldout-validated, interpretable q-feature classifier with replayable overlap certificates and theorem-route pressure.

## Core binary

Can extension-prime stability be predicted from computable q-features with replayable overlap certificates and heldout validation?

## Commands

```bash
python oracle_nt_os_v17.py selftest --out v17_selftest
```

```bash
python oracle_nt_os_v17.py extension-stability-classifier \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --base-moduli 5 7 11 \
  --train-extension-primes 13 17 19 23 29 31 \
  --holdout-extension-primes 37 41 43 47 53 59 61 67 71 73 \
  --relation-bound 64 \
  --out v17_extension_stability_classifier
```

```bash
python oracle_nt_os_v17.py extension-stability-sweep \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --base-moduli 5 7 11 \
  --prime-min 13 \
  --prime-max 251 \
  --relation-bound 128 \
  --out v17_extension_stability_sweep
```

```bash
python oracle_nt_os_v17.py replay-overlap-certificate \
  --certificate v17_extension_stability_classifier/overlap_certificates/q_13.json
```

## Artifacts emitted

- `extension_prime_feature_ledger.json`
- `overlap_certificates/q_*.json`
- `classifier/predeclared_rules.json`
- `classifier/trained_classifier.json`
- `classifier/holdout_predictions.json`
- `classifier/ablation_ledger.json`
- `theorem_route/theorem_route_packet.json`
- `theorem_route/lemma_targets.md`
- `theorem_route/lean_stub_overlap_identity.lean`
- `kbk/next_binary_packet.json`
- `discovery_frontier_delta_packet.json`
- `report/V17_EXTENSION_STABILITY_REPORT.md`

## Status discipline

V17 does not claim theorem proved. It emits `DISCOVERY_PROMOTED_THEOREM_PRESSURE` only when:

- overlap certificates replay,
- heldout classification accuracy >= 0.80,
- heldout persistence MAE <= 0.10,
- ablation identifies a signal-carrying feature family,
- theorem route includes formal lemma targets.

