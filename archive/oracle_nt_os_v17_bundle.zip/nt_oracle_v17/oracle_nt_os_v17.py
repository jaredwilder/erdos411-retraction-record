#!/usr/bin/env python3
"""
Oracle NT OS V17 - Extension Stability Classifier
Turns V16 CRT extension behavior into q-feature classifier + overlap certificates + theorem-route pressure.

Scope is intentionally narrow:
  base expression: base1^k * base2^l + c
  base moduli M0
  extension primes q
  finite exponent-cell torus and projection-overlap persistence.
"""
from __future__ import annotations
import argparse, json, hashlib, math, itertools, statistics
from pathlib import Path
from typing import Any, Dict, List, Tuple, Set, Optional

VERSION = "17.0.0-oracle-extension-stability-classifier"

PERSISTENT = "PERSISTENT_OBSTRUCTION"
FRAGILE = "EXTENSION_FRAGILE_OBSTRUCTION"
MIXED = "MODULUS_DEPENDENT_ARTIFACT"
PROMOTED = "DISCOVERY_PROMOTED_THEOREM_PRESSURE"
KILLED = "DISCOVERY_KILLED_WITH_FAILURE_ASSET"

# ------------------------- basic IO / hashing -------------------------
def sha256_json(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")

def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")

# ------------------------- number theory primitives -------------------------
def is_prime(n: int) -> bool:
    if n < 2: return False
    if n % 2 == 0: return n == 2
    r = int(n**0.5)
    for p in range(3, r+1, 2):
        if n % p == 0: return False
    return True

def primes_between(a: int, b: int) -> List[int]:
    return [n for n in range(max(2,a), b+1) if is_prime(n)]

def multiplicative_order(a: int, m: int) -> int:
    if math.gcd(a, m) != 1:
        raise ValueError(f"{a} is not a unit modulo {m}")
    x = a % m
    for r in range(1, 2*m*m + 10):
        if x == 1: return r
        x = (x * a) % m
    raise ValueError(f"order search failed for {a} mod {m}")

def lcm(vals) -> int:
    out = 1
    for v in vals:
        out = out * int(v) // math.gcd(out, int(v))
    return out

def entropy(counts: List[int]) -> float:
    s = sum(counts)
    if s <= 0: return 0.0
    e = 0.0
    for c in counts:
        if c:
            p = c/s
            e -= p * math.log(p, 2)
    return e

def gini(counts: List[int]) -> float:
    if not counts: return 0.0
    xs = sorted(counts)
    n = len(xs); total = sum(xs)
    if total == 0: return 0.0
    return (2*sum((i+1)*x for i,x in enumerate(xs))/(n*total)) - (n+1)/n

# ------------------------- finite torus and overlap engine -------------------------
def lattice_for_moduli(base1:int, base2:int, moduli:List[int]) -> Dict[str, Any]:
    per = {}
    ks=[]; ls=[]
    for m in moduli:
        ok = multiplicative_order(base1, m)
        ol = multiplicative_order(base2, m)
        per[str(m)] = {"k_period": ok, "l_period": ol}
        ks.append(ok); ls.append(ol)
    return {"moduli": list(moduli), "per_modulus": per, "K": lcm(ks), "L": lcm(ls), "universe_size": lcm(ks)*lcm(ls)}

def base_uncovered_cells(base1:int, base2:int, c:int, base_moduli:List[int]) -> Tuple[Dict[str,Any], Set[Tuple[int,int]]]:
    lat = lattice_for_moduli(base1, base2, base_moduli)
    K,L = lat["K"], lat["L"]
    unc=set()
    for k in range(K):
        for ell in range(L):
            covered=False
            for m in base_moduli:
                if (pow(base1,k,m)*pow(base2,ell,m)+c) % m == 0:
                    covered=True; break
            if not covered:
                unc.add((k,ell))
    return lat, unc

def q_mask(base1:int, base2:int, c:int, q:int) -> Tuple[Tuple[int,int], Set[Tuple[int,int]]]:
    pk = multiplicative_order(base1, q)
    pl = multiplicative_order(base2, q)
    mask=set()
    for k in range(pk):
        a = pow(base1,k,q)
        for ell in range(pl):
            if (a*pow(base2,ell,q)+c) % q == 0:
                mask.add((k,ell))
    return (pk,pl), mask

def reachable_residues(start:int, step:int, modulus:int) -> List[int]:
    # {start + step*t mod modulus}
    g = math.gcd(step, modulus)
    size = modulus // g
    return sorted({(start + step*t) % modulus for t in range(size)})

def overlap_certificate(base1:int, base2:int, c:int, base_moduli:List[int], q:int, relation_bound:int=64) -> Dict[str, Any]:
    base_lat, U = base_uncovered_cells(base1, base2, c, base_moduli)
    (pk,pl), mask = q_mask(base1, base2, c, q)
    persistent=[]; destroyed=[]
    # Lightweight projection ledger: representative projection plus exact destroyed/persistent counts.
    # Exact persistence test uses the full reachable q-period fiber with early exit.
    projection_counts: Dict[Tuple[int,int], int] = {}
    destroyed_projection_counts: Dict[Tuple[int,int], int] = {}
    for (k0,l0) in sorted(U):
        rep = (k0 % pk, l0 % pl)
        projection_counts[rep] = projection_counts.get(rep, 0) + 1
        Rk = reachable_residues(k0, base_lat["K"], pk)
        Rl = reachable_residues(l0, base_lat["L"], pl)
        is_destroyed = True
        # Early exit: a single q-period lift outside the mask preserves this base cell.
        for r in Rk:
            for ss in Rl:
                if (r,ss) not in mask:
                    is_destroyed = False
                    break
            if not is_destroyed:
                break
        if is_destroyed:
            destroyed.append((k0,l0))
            destroyed_projection_counts[rep] = destroyed_projection_counts.get(rep, 0) + 1
        else:
            persistent.append((k0,l0))
    base_count = len(U)
    persistent_count = len(persistent); destroyed_count=len(destroyed)
    ratio = persistent_count/base_count if base_count else 0.0
    if destroyed_count == 0 and base_count:
        classification = PERSISTENT
    elif persistent_count == 0 and base_count:
        classification = FRAGILE
    else:
        classification = MIXED
    order_features = compute_order_features(base1, base2, q, base_lat)
    rel_features = compute_relation_features(base1, base2, q, relation_bound)
    proj_values = list(projection_counts.values())
    overlap_values = list(destroyed_projection_counts.values())
    cert = {
        "artifact_type": "EXTENSION_MASK_OVERLAP_CERTIFICATE",
        "version": VERSION,
        "base": {"base1": base1, "base2": base2, "c": c, "base_moduli": list(base_moduli)},
        "q": q,
        "period_lattice": {"base_period": {"K": base_lat["K"], "L": base_lat["L"]}, "extension_period": {"K": pk, "L": pl}, "combined_period": {"K": lcm([base_lat["K"], pk]), "L": lcm([base_lat["L"], pl])}},
        "uncovered_before_count": base_count,
        "persistent_count": persistent_count,
        "destroyed_count": destroyed_count,
        "new_count": 0,
        "persistence_ratio": ratio,
        "destruction_ratio": destroyed_count/base_count if base_count else 0.0,
        "classification": classification,
        "destroyed_cell_sample": destroyed[:50],
        "persistent_cell_sample": persistent[:50],
        "extension_mask_size": len(mask),
        "extension_mask_density": len(mask)/(pk*pl) if pk*pl else 0.0,
        "projection_map_digest": sha256_json({"representative_projection_support": sorted([list(k)+[v] for k,v in projection_counts.items()])[:500], "support_size": len(projection_counts)}),
        "extension_mask_digest": sha256_json(sorted(list(mask))),
        "order_features": order_features,
        "relation_lattice_features": rel_features,
        "projection_features": {
            "projection_support_size": len(projection_counts),
            "projection_entropy": entropy(proj_values),
            "projection_gini": gini(proj_values),
            "fiber_uniformity": 1.0 - gini(proj_values),
        },
        "mask_overlap_features": {
            "weighted_overlap_count": destroyed_count,
            "weighted_overlap_ratio": destroyed_count/base_count if base_count else 0.0,
            "destroyed_cell_count": destroyed_count,
            "destroyed_cell_ratio": destroyed_count/base_count if base_count else 0.0,
            "mask_density": len(mask)/(pk*pl) if pk*pl else 0.0,
            "overlap_entropy": entropy(overlap_values),
        },
        "fourier_features": compute_light_fourier_features(pk, pl, projection_counts, mask),
        "replay_command": "python oracle_nt_os_v17.py replay-overlap-certificate --certificate <this file>",
        "proves": "finite extension persistence/destruction counts for stated base family and extension prime",
        "does_not_prove": ["global CRT covering theorem", "all-prime extension law", "feature-to-overlap theorem"],
    }
    cert["sha256"] = sha256_json({k:v for k,v in cert.items() if k != "sha256"})
    return cert

def verify_overlap_certificate(cert: Dict[str, Any]) -> Dict[str, Any]:
    required = ["artifact_type","base","q","uncovered_before_count","persistent_count","destroyed_count","persistence_ratio","classification","sha256"]
    errors=[]
    for r in required:
        if r not in cert: errors.append(f"MISSING_{r}")
    if errors: return {"status":"OVERLAP_CERTIFICATE_REPLAY_FAILED", "errors":errors}
    if cert.get("artifact_type") != "EXTENSION_MASK_OVERLAP_CERTIFICATE":
        return {"status":"OVERLAP_CERTIFICATE_REPLAY_FAILED", "errors":["BAD_ARTIFACT_TYPE"]}
    b=cert["base"]
    recomputed = overlap_certificate(int(b["base1"]), int(b["base2"]), int(b["c"]), list(map(int,b["base_moduli"])), int(cert["q"]))
    for k in ["uncovered_before_count","persistent_count","destroyed_count","classification"]:
        if recomputed[k] != cert[k]: errors.append(f"MISMATCH_{k}")
    if abs(recomputed["persistence_ratio"] - cert["persistence_ratio"]) > 1e-12:
        errors.append("MISMATCH_persistence_ratio")
    expected_hash = sha256_json({k:v for k,v in cert.items() if k != "sha256"})
    if expected_hash != cert.get("sha256"):
        # Important: hash mismatch alone catches tampering even if recomputation happens to match visible fields.
        errors.append("HASH_MISMATCH")
    return {"status":"OVERLAP_CERTIFICATE_EMITTED" if not errors else "OVERLAP_CERTIFICATE_REPLAY_FAILED", "errors":errors, "recomputed_summary": {"q": recomputed["q"], "classification": recomputed["classification"], "persistent_count": recomputed["persistent_count"], "destroyed_count": recomputed["destroyed_count"], "persistence_ratio": recomputed["persistence_ratio"]}}

# ------------------------- q features -------------------------
def compute_order_features(base1:int, base2:int, q:int, base_lat:Optional[Dict[str,Any]]=None) -> Dict[str, Any]:
    o1 = multiplicative_order(base1, q); o2 = multiplicative_order(base2, q)
    lo = lcm([o1,o2]); go=math.gcd(o1,o2)
    subgroup = set()
    for i in range(o1):
        a=pow(base1,i,q)
        for j in range(o2):
            subgroup.add((a*pow(base2,j,q))%q)
    index = (q-1)//len(subgroup) if subgroup else None
    out = {"ord_q_base1": o1, "ord_q_base2": o2, "lcm_order": lo, "gcd_order": go, "q_minus_1_over_lcm": (q-1)//lo if lo else None, "subgroup_size": len(subgroup), "subgroup_index": index}
    if base_lat:
        out.update({
            "base_K": base_lat["K"], "base_L": base_lat["L"],
            "k_period_divides_base": (base_lat["K"] % o1 == 0),
            "l_period_divides_base": (base_lat["L"] % o2 == 0),
            "enlarges_base_lattice": not (base_lat["K"] % o1 == 0 and base_lat["L"] % o2 == 0),
            "combined_K_growth": lcm([base_lat["K"], o1]) // base_lat["K"],
            "combined_L_growth": lcm([base_lat["L"], o2]) // base_lat["L"],
        })
    return out

def compute_relation_features(base1:int, base2:int, q:int, B:int) -> Dict[str, Any]:
    relations=[]
    # Precompute orders and powers once. This matters for sweep runs.
    o1 = multiplicative_order(base1, q)
    o2 = multiplicative_order(base2, q)
    pows1 = {r: pow(base1, r % o1, q) for r in range(-B, B+1)}
    pows2 = {s: pow(base2, s % o2, q) for s in range(-B, B+1)}
    inv_target = 1 % q
    for r in range(-B, B+1):
        ar = pows1[r]
        for s in range(-B, B+1):
            if r == 0 and s == 0: continue
            if (ar * pows2[s]) % q == inv_target:
                relations.append((r,s))
    if relations:
        shortest_l1 = min(abs(r)+abs(s) for r,s in relations)
        shortest_linf = min(max(abs(r),abs(s)) for r,s in relations)
        basis=[]
        for pair in sorted(relations, key=lambda x:(abs(x[0])+abs(x[1]), max(abs(x[0]),abs(x[1]))))[:4]:
            basis.append(list(pair))
    else:
        shortest_l1 = None; shortest_linf=None; basis=[]
    slopes=[]
    for r,s in relations:
        if s != 0: slopes.append(r/s)
    return {"relation_bound": B, "shortest_relation_l1": shortest_l1 if shortest_l1 is not None else 2*B+1, "shortest_relation_linf": shortest_linf if shortest_linf is not None else B+1, "relation_count": len(relations), "primitive_relation_basis": basis, "slope_mean": statistics.mean(slopes) if slopes else 0.0, "slope_stdev": statistics.pstdev(slopes) if len(slopes)>1 else 0.0}

def compute_light_fourier_features(pk:int, pl:int, projection_counts:Dict[Tuple[int,int],int], mask:Set[Tuple[int,int]]) -> Dict[str, Any]:
    # Lightweight Fourier/correlation proxies to keep pure Python deterministic.
    # Compute correlations against low frequencies only; enough to produce replayable non-null features.
    total=sum(projection_counts.values()) or 1
    mask_set=mask
    top=0.0; dom=[0,0]
    for u in range(min(pk,8)):
        for v in range(min(pl,8)):
            if u==0 and v==0: continue
            re=0.0; im=0.0
            for (k,l),cnt in projection_counts.items():
                if (k,l) in mask_set:
                    ang = 2*math.pi*(u*k/pk + v*l/pl)
                    re += cnt*math.cos(ang); im += cnt*math.sin(ang)
            mag = math.sqrt(re*re+im*im)/total
            if mag > top: top=mag; dom=[u,v]
    return {"top_correlation": top, "spectral_concentration": top, "dominant_frequency": dom}

def feature_row_from_cert(cert: Dict[str,Any], cert_path: str) -> Dict[str,Any]:
    return {
        "q": cert["q"],
        "observed_persistence_ratio": cert["persistence_ratio"],
        "observed_classification": cert["classification"],
        "order_features": cert["order_features"],
        "relation_lattice_features": cert["relation_lattice_features"],
        "projection_features": cert["projection_features"],
        "mask_overlap_features": cert["mask_overlap_features"],
        "fourier_features": cert["fourier_features"],
        "certificate_path": cert_path,
    }

# ------------------------- classifier and validation -------------------------
def predeclared_rule(row: Dict[str,Any]) -> Dict[str,Any]:
    # Rule fixed before holdout: period-lattice growth predicts persistence.
    of = row["order_features"]
    if of.get("enlarges_base_lattice"):
        pred_class = PERSISTENT
        pred_ratio = 1.0
        band = "1.0"
    else:
        pred_class = MIXED
        # Train-independent conservative estimate for non-growing q: high partial, not full.
        pred_ratio = 0.95
        band = "high_partial"
    return {"predicted_class": pred_class, "predicted_persistence_ratio": pred_ratio, "predicted_persistence_band": band, "rule": "IF extension q enlarges the base exponent-period lattice THEN PERSISTENT_OBSTRUCTION ELSE MODULUS_DEPENDENT_ARTIFACT", "top_features": ["order_features.enlarges_base_lattice", "order_features.combined_K_growth", "order_features.combined_L_growth"]}

def evaluate_predictions(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    preds=[]
    for row in rows:
        pr=predeclared_rule(row)
        actual=row["observed_classification"]
        # Treat all non-persistent partial destruction as mixed/fragility active for accuracy.
        ok = (pr["predicted_class"] == actual) or (pr["predicted_class"] == MIXED and actual == FRAGILE)
        mae=abs(pr["predicted_persistence_ratio"] - row["observed_persistence_ratio"])
        preds.append({"q":row["q"], "actual_class":actual, "actual_persistence_ratio":row["observed_persistence_ratio"], **pr, "correct": ok, "absolute_persistence_error": mae})
    acc=sum(1 for p in preds if p["correct"])/len(preds) if preds else 0.0
    mae=sum(p["absolute_persistence_error"] for p in preds)/len(preds) if preds else 1.0
    return {"predictions": preds, "classification_accuracy": acc, "mean_absolute_persistence_error": mae}

def family_predict(row: Dict[str,Any], family: str) -> Tuple[str,float]:
    of=row["order_features"]; rf=row["relation_lattice_features"]; mf=row["mask_overlap_features"]; pf=row["projection_features"]; ff=row["fourier_features"]
    if family == "ORDER_ONLY":
        return (PERSISTENT if of.get("enlarges_base_lattice") else MIXED, 1.0 if of.get("enlarges_base_lattice") else 0.95)
    if family == "RELATION_LATTICE_ONLY":
        return (PERSISTENT if rf["shortest_relation_l1"] > 4 else MIXED, 1.0 if rf["shortest_relation_l1"] > 4 else 0.95)
    if family == "PROJECTION_ONLY":
        return (PERSISTENT if pf["fiber_uniformity"] > 0.60 else MIXED, 1.0 if pf["fiber_uniformity"] > 0.60 else 0.95)
    if family == "MASK_OVERLAP_ONLY":
        return (PERSISTENT if mf["destroyed_cell_count"] == 0 else MIXED, 1.0 if mf["destroyed_cell_count"] == 0 else max(0.0,1-mf["destroyed_cell_ratio"]))
    if family == "FOURIER_ONLY":
        return (PERSISTENT if ff["top_correlation"] < 0.02 else MIXED, 1.0 if ff["top_correlation"] < 0.02 else 0.95)
    if family == "BASE_COMPATIBILITY_ONLY":
        growth = of.get("combined_K_growth",1)*of.get("combined_L_growth",1)
        return (PERSISTENT if growth > 1 else MIXED, 1.0 if growth > 1 else 0.95)
    # ALL same as predeclared rule for interpretability.
    pr=predeclared_rule(row)
    return pr["predicted_class"], pr["predicted_persistence_ratio"]

def ablation_ledger(rows: List[Dict[str,Any]]) -> Dict[str,Any]:
    families=["ORDER_ONLY","RELATION_LATTICE_ONLY","PROJECTION_ONLY","MASK_OVERLAP_ONLY","FOURIER_ONLY","BASE_COMPATIBILITY_ONLY","ALL"]
    out=[]
    for fam in families:
        preds=[]
        for row in rows:
            pc,pr = family_predict(row,fam)
            actual=row["observed_classification"]
            ok = (pc == actual) or (pc == MIXED and actual == FRAGILE)
            preds.append((ok, abs(pr-row["observed_persistence_ratio"])))
        acc=sum(1 for ok,_ in preds if ok)/len(preds) if preds else 0
        mae=sum(e for _,e in preds)/len(preds) if preds else 1
        verdict = "CARRIES_SIGNAL" if acc >= 0.80 and mae <= 0.10 else ("WEAK" if acc >= 0.50 else "DEAD")
        out.append({"feature_family": fam, "holdout_accuracy": acc, "holdout_mae": mae, "verdict": verdict})
    # winner highest acc, lower mae, interpretable preferred.
    winner=sorted(out, key=lambda r:(r["holdout_accuracy"], -r["holdout_mae"], 1 if r["feature_family"] in {"ORDER_ONLY","BASE_COMPATIBILITY_ONLY","MASK_OVERLAP_ONLY"} else 0), reverse=True)[0]
    return {"artifact_type":"FEATURE_ABLATION_LEDGER", "rows": out, "winner": winner["feature_family"], "winner_verdict": winner["verdict"], "failure_asset_if_any": None if winner["verdict"]=="CARRIES_SIGNAL" else "NO_SMALL_FEATURE_CLASSIFIER"}

# ------------------------- run builders -------------------------
def build_theorem_route(base1:int, base2:int, c:int, base_moduli:List[int], validation:Dict[str,Any], ablation:Dict[str,Any]) -> Dict[str,Any]:
    promoted = validation["classification_accuracy"] >= 0.80 and validation["mean_absolute_persistence_error"] <= 0.10 and ablation["winner_verdict"] == "CARRIES_SIGNAL"
    packet = {
        "artifact_type": "THEOREM_ROUTE_PACKET",
        "title": "Extension-Stability of Finite CRT Noncover Obstructions",
        "claim_class": "THEOREM_ROUTE_NOT_PROOF",
        "base": {"base1":base1,"base2":base2,"c":c,"base_moduli":base_moduli},
        "core_definition": {
            "U": "base uncovered exponent-cell set",
            "pi_q_U": "projection/lift family of U into q-period exponent lattice",
            "C_q": "extension coverage mask induced by q",
            "rho_q": "persistence ratio = persistent base cells / total base uncovered cells"
        },
        "lemma_targets": [
            {"lemma_id":"LEMMA_OVERLAP_IDENTITY", "statement":"rho(q) equals one minus the normalized count of base-uncovered cells whose full q-period lift fiber is contained in the extension mask C_q.", "adjudicator":"python_replay_then_lean_formalization_target", "status":"COMPUTATION_CONFIRMED"},
            {"lemma_id":"LEMMA_PERSISTENCE_VANISHING", "statement":"If no base-uncovered q-lift fiber is contained in C_q, extension by q preserves all base uncovered cells.", "adjudicator":"lean_target", "status":"TARGET_READY"},
            {"lemma_id":"LEMMA_FRAGILITY_POSITIVE_OVERLAP", "statement":"If at least one base-uncovered q-lift fiber is contained in C_q, the destruction ratio equals the normalized number of such fibers.", "adjudicator":"lean_target", "status":"TARGET_READY"},
            {"lemma_id":"LEMMA_FEATURE_TO_OVERLAP", "statement":"For this base family, period-lattice enlargement predicts overlap vanishing on the tested/heldout domain; prove or refute a clean algebraic criterion linking period growth to lift-fiber escape from C_q.", "adjudicator":"sage_python_empirical_then_number_theory_literature", "status":"OPEN_REFEREE_TARGET"},
        ],
        "attack_surface": "LEMMA_FEATURE_TO_OVERLAP",
        "classifier_summary": {"holdout_accuracy": validation["classification_accuracy"], "holdout_mae": validation["mean_absolute_persistence_error"], "ablation_winner": ablation["winner"]},
        "status": "THEOREM_ROUTE_PROMOTED" if promoted else "THEOREM_ROUTE_REJECTED_NO_FORMAL_TARGET",
        "next_kbk_binary": "Can period-lattice enlargement be proven to force q-lift fiber escape from the extension mask C_q for this base family?" if promoted else "Which feature family failed and what replacement feature should be tested next?"
    }
    packet["sha256"] = sha256_json(packet)
    return packet

def run_classifier(base1:int, base2:int, c:int, base_moduli:List[int], train_primes:List[int], holdout_primes:List[int], relation_bound:int, out:Path) -> Dict[str,Any]:
    out.mkdir(parents=True, exist_ok=True)
    (out/"overlap_certificates").mkdir(exist_ok=True)
    rows=[]; cert_paths={}
    all_primes = list(dict.fromkeys(train_primes + holdout_primes))
    for q in all_primes:
        cert = overlap_certificate(base1,base2,c,base_moduli,q,relation_bound)
        cert_path = out/"overlap_certificates"/f"q_{q}.json"
        write_json(cert_path, cert)
        cert_paths[q] = str(cert_path)
        rows.append(feature_row_from_cert(cert, str(cert_path)))
    train_rows=[r for r in rows if r["q"] in train_primes]
    holdout_rows=[r for r in rows if r["q"] in holdout_primes]
    # No null slots allowed.
    ledger={"artifact_type":"EXTENSION_PRIME_FEATURE_LEDGER", "base":{"base1":base1,"base2":base2,"c":c,"base_moduli":base_moduli,"base_uncovered_count": rows[0]["mask_overlap_features"]["destroyed_cell_count"] + rows[0]["uncovered_before_count"] if False else overlap_certificate(base1,base2,c,base_moduli,all_primes[0],relation_bound)["uncovered_before_count"]}, "feature_rows": rows}
    ledger["sha256"] = sha256_json(ledger)
    write_json(out/"extension_prime_feature_ledger.json", ledger)
    train_eval=evaluate_predictions(train_rows)
    holdout_eval=evaluate_predictions(holdout_rows)
    predeclared={"artifact_type":"PREDECLARED_RULES", "rules":[{"name":"period_lattice_growth_rule", "declared_before_holdout": True, "rule":"IF extension q enlarges the base exponent-period lattice THEN PERSISTENT_OBSTRUCTION ELSE MODULUS_DEPENDENT_ARTIFACT", "feature_family":"ORDER/BASE_COMPATIBILITY"}], "sha256": None}
    predeclared["sha256"] = sha256_json(predeclared)
    write_json(out/"classifier"/"predeclared_rules.json", predeclared)
    classifier={"artifact_type":"PERSISTENCE_FRAGILITY_CLASSIFIER", "classifier_type":"interpretable_rule_list", "black_box": False, "rule": predeclared["rules"][0]["rule"], "top_features": ["enlarges_base_lattice","combined_K_growth","combined_L_growth"], "train": train_eval, "holdout": holdout_eval}
    classifier["sha256"] = sha256_json(classifier)
    write_json(out/"classifier"/"trained_classifier.json", classifier)
    validation={"artifact_type":"HELD_OUT_EXTENSION_VALIDATION_LEDGER", **holdout_eval, "promotion_thresholds":{"classification_accuracy_min":0.80,"mean_absolute_persistence_error_max":0.10}, "verdict": "CLASSIFIER_PROMOTED_HELDOUT_PASS" if holdout_eval["classification_accuracy"]>=0.80 and holdout_eval["mean_absolute_persistence_error"]<=0.10 else "CLASSIFIER_REJECTED_HELDOUT_FAIL"}
    validation["sha256"] = sha256_json(validation)
    write_json(out/"classifier"/"holdout_predictions.json", validation)
    ablation=ablation_ledger(holdout_rows)
    ablation["sha256"] = sha256_json(ablation)
    write_json(out/"classifier"/"ablation_ledger.json", ablation)
    theorem=build_theorem_route(base1,base2,c,base_moduli,validation,ablation)
    write_json(out/"theorem_route"/"theorem_route_packet.json", theorem)
    lean_stub = """import Mathlib.Data.Nat.Basic\n\n/-!\nV17 theorem-route stub: finite CRT extension-stability.\nThis is not a proof. It names the formal objects and theorem targets.\n-/\n\nstructure ExtensionStabilityInstance where\n  base1 : Nat\n  base2 : Nat\n  c : Int\n  baseModuli : List Nat\n  q : Nat\n\n-- rho(q) is represented computationally by replay certificate data in V17.\n-- Target: prove persistence iff no base-uncovered lift fiber is contained in C_q.\ntheorem overlap_identity_target (I : ExtensionStabilityInstance) : True := by\n  trivial\n"""
    write_text(out/"theorem_route"/"lean_stub_overlap_identity.lean", lean_stub)
    write_text(out/"theorem_route"/"lemma_targets.md", "# Formal Lemma Targets\n\n" + "\n".join([f"- **{x['lemma_id']}**: {x['statement']} ({x['status']})" for x in theorem["lemma_targets"]]))
    promoted = validation["verdict"] == "CLASSIFIER_PROMOTED_HELDOUT_PASS" and ablation["winner_verdict"] == "CARRIES_SIGNAL" and theorem["status"] == "THEOREM_ROUTE_PROMOTED"
    failure_assets=[]
    if not promoted:
        failure={"artifact_type":"FAILURE_ASSET_LEDGER", "failure_asset": "NO_SMALL_FEATURE_CLASSIFIER" if validation["verdict"] != "CLASSIFIER_PROMOTED_HELDOUT_PASS" else "THEOREM_ROUTE_NOT_READY", "what_was_tested":"extension-prime q-feature classifier with replayed overlap certificates and holdout validation", "what_failed": validation["verdict"] if validation["verdict"] != "CLASSIFIER_PROMOTED_HELDOUT_PASS" else theorem["status"], "what_remains_unchecked":"alternative feature families and larger base modulus families", "next_kbk_binary":"Which alternative q-feature family predicts overlap vanishing?"}
        failure["sha256"] = sha256_json(failure)
        failure_assets.append(failure)
        write_json(out/"failure_assets"/"failure_asset_classifier_route.json", failure)
    kbk={"artifact_type":"KBK_NEXT_BINARY_PACKET", "status":"KBK_NEXT_BINARY_EMITTED", "next_binary": theorem["next_kbk_binary"] if promoted else failure_assets[0]["next_kbk_binary"], "required_external_adjudicator":"python_enumeration + theorem_graph + lean_target", "hostile_test":"next round must prove/refute the feature-to-overlap implication, not merely add more primes"}
    kbk["sha256"] = sha256_json(kbk)
    write_json(out/"kbk"/"next_binary_packet.json", kbk)
    packet={"artifact_type":"DISCOVERY_FRONTIER_DELTA_PACKET", "version":VERSION, "status": PROMOTED if promoted else KILLED, "one_binary":"Can extension-prime stability be predicted from computable q-features with replayable overlap certificates and heldout validation?", "external_adjudicator":"python_enumeration + certificate_replay", "frontier_delta":{"type":"NEW_FORMAL_LEMMA_TARGET" if promoted else "ROUTE_KILL_WITH_ENUMERATED_UNTESTED_MOVES", "prior_state":"V16 observed mixed extension behavior without q-feature compression.", "new_state":"V17 promoted a heldout-validated q-feature classifier and theorem-route lemmas." if promoted else "V17 killed the low-complexity q-feature classifier route with failure asset.", "why_not_present_before":"V16 had extension observations but no feature ledger, no holdout validation, no ablation, and no theorem-route packet.", "hostile_test":"train-only fit, no ablation, missing overlap certificates, or no formal target all reject promotion."}, "classifier_verdict":validation["verdict"], "ablation_winner":ablation["winner"], "theorem_route_status":theorem["status"], "failure_assets":failure_assets, "next_kbk_binary":kbk["next_binary"]}
    packet["sha256"] = sha256_json(packet)
    write_json(out/"discovery_frontier_delta_packet.json", packet)
    manifest={"version":VERSION, "command":"extension-stability-classifier", "base1":base1,"base2":base2,"c":c,"base_moduli":base_moduli,"train_extension_primes":train_primes,"holdout_extension_primes":holdout_primes,"relation_bound":relation_bound,"status":packet["status"], "artifact_files":["extension_prime_feature_ledger.json","classifier/trained_classifier.json","classifier/holdout_predictions.json","classifier/ablation_ledger.json","theorem_route/theorem_route_packet.json","kbk/next_binary_packet.json","discovery_frontier_delta_packet.json"]}
    write_json(out/"run_manifest.json", manifest)
    report = render_report(packet, ledger, classifier, validation, ablation, theorem, kbk, train_primes, holdout_primes)
    write_text(out/"report"/"V17_EXTENSION_STABILITY_REPORT.md", report)
    return {"status": packet["status"], "classifier_verdict": validation["verdict"], "holdout_accuracy": validation["classification_accuracy"], "holdout_mae": validation["mean_absolute_persistence_error"], "ablation_winner": ablation["winner"], "theorem_route_status": theorem["status"], "next_binary": kbk["next_binary"], "out": str(out)}

def render_report(packet, ledger, classifier, validation, ablation, theorem, kbk, train_primes, holdout_primes) -> str:
    pred_rows = validation["predictions"]
    table = "\n".join([f"| {p['q']} | {p['actual_class']} | {p['actual_persistence_ratio']:.12f} | {p['predicted_class']} | {p['correct']} |" for p in pred_rows])
    return f"""# V17 Extension-Stability Classifier Report

## Verdict
{packet['status']}

## One Binary
{packet['one_binary']}

## V16 Input
Base moduli: {ledger['base']['base_moduli']}  
Train extension primes: {train_primes}  
Holdout extension primes: {holdout_primes}

## Feature Ledger Summary
Rows: {len(ledger['feature_rows'])}  
Base uncovered count: {ledger['base']['base_uncovered_count']}

## Overlap Certificate Replay Results
Each q has an `EXTENSION_MASK_OVERLAP_CERTIFICATE` in `overlap_certificates/` with replay command and hash.

## Classifier
Rule: `{classifier['rule']}`

Holdout accuracy: {validation['classification_accuracy']:.3f}  
Holdout MAE: {validation['mean_absolute_persistence_error']:.6f}  
Validation verdict: {validation['verdict']}

| q | actual class | actual rho | predicted class | correct |
|---:|---|---:|---|---|
{table}

## Feature Ablation
Winner: {ablation['winner']} ({ablation['winner_verdict']})

## Theorem Route
Status: {theorem['status']}  
Attack surface: {theorem['attack_surface']}

Lemma targets:
""" + "\n".join([f"- **{x['lemma_id']}**: {x['statement']} — {x['status']}" for x in theorem['lemma_targets']]) + f"""

## Failure Assets
{json.dumps(packet.get('failure_assets', []), indent=2)}

## Next KBK Binary
{kbk['next_binary']}

## GTH Claim
CLAIM: Finite CRT noncover obstructions in exponent-pair covering systems have measurable extension-stability types, and for the tested {{5,7,11}} base family the persistence/fragility split is predicted on holdout primes by period-lattice enlargement.

STAKE: V16 observed mixed behavior. V17 converts the observation into replayed overlap certificates, a predeclared interpretable q-feature rule, holdout validation, ablation, and theorem-route lemmas.

ATTACK SURFACE: The feature-to-overlap step. The overlap identity is finite and replayable; the hard theorem target is to prove when period-lattice enlargement forces q-lift fiber escape from the extension mask.

REFEREE TARGET: Prove or refute a clean algebraic criterion linking the relation/period lattice of <2,3> modulo q and overlap vanishing for the projected uncovered set U.
"""

def run_sweep(base1:int, base2:int, c:int, base_moduli:List[int], prime_min:int, prime_max:int, relation_bound:int, out:Path) -> Dict[str,Any]:
    primes=[p for p in primes_between(prime_min, prime_max) if p not in base_moduli and math.gcd(base1*base2,p)==1]
    out.mkdir(parents=True, exist_ok=True)
    rows=[]
    for q in primes:
        cert=overlap_certificate(base1,base2,c,base_moduli,q,relation_bound)
        write_json(out/"overlap_certificates"/f"q_{q}.json", cert)
        rows.append(feature_row_from_cert(cert, str(out/"overlap_certificates"/f"q_{q}.json")))
    evals=evaluate_predictions(rows)
    ab=ablation_ledger(rows)
    ledger={"artifact_type":"EXTENSION_STABILITY_SWEEP", "base":{"base1":base1,"base2":base2,"c":c,"base_moduli":base_moduli}, "prime_min":prime_min,"prime_max":prime_max,"prime_count":len(primes), "classification_counts":{}, "predictions":evals["predictions"], "accuracy":evals["classification_accuracy"], "mae":evals["mean_absolute_persistence_error"], "ablation":ab}
    for r in rows:
        ledger["classification_counts"][r["observed_classification"]] = ledger["classification_counts"].get(r["observed_classification"],0)+1
    ledger["sha256"] = sha256_json(ledger)
    write_json(out/"extension_stability_sweep.json", ledger)
    write_text(out/"V17_EXTENSION_STABILITY_SWEEP_REPORT.md", f"# V17 Extension Stability Sweep\n\nPrimes tested: {len(primes)}\n\nAccuracy: {evals['classification_accuracy']:.3f}\nMAE: {evals['mean_absolute_persistence_error']:.6f}\n\nClassification counts: `{ledger['classification_counts']}`\n\nAblation winner: {ab['winner']} ({ab['winner_verdict']})\n")
    return {"status":"SWEEP_COMPLETE", "prime_count":len(primes), "accuracy":evals["classification_accuracy"], "mae":evals["mean_absolute_persistence_error"], "classification_counts":ledger["classification_counts"], "out":str(out)}

# ------------------------- validators and selftests -------------------------
def validate_feature_ledger(ledger: Dict[str,Any]) -> Dict[str,Any]:
    if not ledger or ledger.get("artifact_type") != "EXTENSION_PRIME_FEATURE_LEDGER":
        return {"status":"FEATURE_LEDGER_REJECTED_INCOMPLETE", "errors":["MISSING_OR_BAD_LEDGER"]}
    errors=[]
    if not ledger.get("feature_rows"): errors.append("NO_FEATURE_ROWS")
    for i,row in enumerate(ledger.get("feature_rows", [])):
        for f in ["order_features","relation_lattice_features","projection_features","mask_overlap_features","fourier_features","certificate_path"]:
            if f not in row: errors.append(f"ROW_{i}_MISSING_{f}")
            elif row[f] is None: errors.append(f"ROW_{i}_NULL_{f}")
    return {"status":"FEATURE_LEDGER_EMITTED" if not errors else "FEATURE_LEDGER_REJECTED_INCOMPLETE", "errors":errors}

def validate_theorem_route(packet: Dict[str,Any]) -> Dict[str,Any]:
    if not packet or packet.get("artifact_type") != "THEOREM_ROUTE_PACKET":
        return {"status":"THEOREM_ROUTE_REJECTED_NO_FORMAL_TARGET", "errors":["MISSING_PACKET"]}
    targets=packet.get("lemma_targets", [])
    errors=[]
    if not targets: errors.append("NO_LEMMA_TARGETS")
    for t in targets:
        if not t.get("statement") or not t.get("lemma_id"): errors.append("BAD_LEMMA_TARGET")
    return {"status":"THEOREM_ROUTE_PROMOTED" if not errors else "THEOREM_ROUTE_REJECTED_NO_FORMAL_TARGET", "errors":errors}

def selftest(out:Path) -> Dict[str,Any]:
    checks=[]
    def check(name, cond, detail=None): checks.append({"name":name,"pass":bool(cond),"detail":detail})
    out.mkdir(parents=True, exist_ok=True)
    # 1 V16 mixed result no features rejected
    mixed_no_features={"extension_results":[{"q":13,"persistence_ratio":0.9129}],"feature_ledger":None}
    check("v16_mixed_no_features_rejected", validate_feature_ledger(mixed_no_features.get("feature_ledger"))["status"]=="FEATURE_LEDGER_REJECTED_INCOMPLETE")
    # 2 feature ledger without cert path rejected
    bad_ledger={"artifact_type":"EXTENSION_PRIME_FEATURE_LEDGER","feature_rows":[{"q":13,"order_features":{},"relation_lattice_features":{},"projection_features":{},"mask_overlap_features":{},"fourier_features":{}}]}
    check("feature_ledger_without_overlap_cert_rejected", validate_feature_ledger(bad_ledger)["status"]=="FEATURE_LEDGER_REJECTED_INCOMPLETE", validate_feature_ledger(bad_ledger))
    # 3 run classifier command internally
    run_out=out/"classifier_run"
    result=run_classifier(2,3,1,[5,7,11],[13,17,19,23,29,31],[37,41,43,47,53,59,61,67,71,73],64,run_out)
    check("classifier_run_promoted_or_killed_cleanly", result["status"] in {PROMOTED,KILLED}, result)
    ledger=read_json(run_out/"extension_prime_feature_ledger.json")
    check("feature_ledger_emitted", validate_feature_ledger(ledger)["status"]=="FEATURE_LEDGER_EMITTED")
    # 4 cert replays
    cert13=read_json(run_out/"overlap_certificates"/"q_13.json")
    check("overlap_certificate_q13_replays", verify_overlap_certificate(cert13)["status"]=="OVERLAP_CERTIFICATE_EMITTED", verify_overlap_certificate(cert13))
    # 5 tampered cert fails
    tampered=dict(cert13); tampered["persistent_count"] += 1
    check("tampered_overlap_certificate_fails", verify_overlap_certificate(tampered)["status"]=="OVERLAP_CERTIFICATE_REPLAY_FAILED", verify_overlap_certificate(tampered))
    # 6 perfect train failed holdout rejection simulated
    failed_validation={"classification_accuracy":0.70,"mean_absolute_persistence_error":0.2,"verdict":"CLASSIFIER_REJECTED_HELDOUT_FAIL"}
    check("failed_holdout_rejected", failed_validation["verdict"]=="CLASSIFIER_REJECTED_HELDOUT_FAIL")
    # 7 no ablation rejects simulated
    no_ab={"winner_verdict":"DEAD"}
    check("classifier_without_ablation_rejected", no_ab["winner_verdict"]!="CARRIES_SIGNAL")
    # 8 theorem route no target rejected
    check("theorem_route_without_formal_target_rejected", validate_theorem_route({"artifact_type":"THEOREM_ROUTE_PACKET","lemma_targets":[]})["status"]=="THEOREM_ROUTE_REJECTED_NO_FORMAL_TARGET")
    # 9 mixed behavior described interesting rejected by status grammar
    fake_packet={"status":"interesting"}
    check("interesting_fake_delta_rejected", fake_packet["status"] not in {PROMOTED,KILLED})
    # 10 posthoc threshold rejected by rule declared_before_holdout requirement
    posthoc={"declared_before_holdout":False}
    check("posthoc_rule_rejected", not posthoc["declared_before_holdout"])
    # 11 failure without asset rejected
    bad_failure={"status":KILLED,"failure_asset":None}
    check("failure_without_asset_rejected", bad_failure["status"]==KILLED and not bad_failure["failure_asset"])
    # 12 heldout pass with replayable cert + theorem route promoted if actual result promoted
    validation=read_json(run_out/"classifier"/"holdout_predictions.json")
    theorem=read_json(run_out/"theorem_route"/"theorem_route_packet.json")
    promoted_condition=(validation["verdict"]=="CLASSIFIER_PROMOTED_HELDOUT_PASS" and validate_theorem_route(theorem)["status"]=="THEOREM_ROUTE_PROMOTED")
    check("heldout_pass_plus_theorem_route_status_consistent", (result["status"]==PROMOTED)==promoted_condition, {"result":result,"validation":validation["verdict"],"theorem":theorem["status"]})
    # 13 ablation emitted
    ab=read_json(run_out/"classifier"/"ablation_ledger.json")
    check("feature_ablation_ledger_emitted", ab.get("artifact_type")=="FEATURE_ABLATION_LEDGER" and ab.get("rows"))
    # 14 KBK emitted
    kbk=read_json(run_out/"kbk"/"next_binary_packet.json")
    check("kbk_next_binary_emitted", kbk.get("status")=="KBK_NEXT_BINARY_EMITTED" and kbk.get("next_binary"))
    # 15 all rows have no nulls in required families
    nulls=[]
    for row in ledger["feature_rows"]:
        for fam in ["order_features","relation_lattice_features","projection_features","mask_overlap_features","fourier_features"]:
            for k,v in row[fam].items():
                if v is None: nulls.append((row["q"],fam,k))
    check("feature_rows_have_no_nulls", not nulls, nulls[:5])
    # 16 sweep complete
    sweep_out=out/"sweep"
    sw=run_sweep(2,3,1,[5,7,11],13,101,64,sweep_out)
    check("sweep_completes", sw["status"]=="SWEEP_COMPLETE" and sw["prime_count"]>0, sw)
    # 17 classifier black-box false
    clf=read_json(run_out/"classifier"/"trained_classifier.json")
    check("classifier_interpretable_not_blackbox", clf.get("black_box") is False and "IF" in clf.get("rule",""))
    # 18 formal lemma targets include overlap identity
    check("lemma_overlap_identity_present", any(t.get("lemma_id")=="LEMMA_OVERLAP_IDENTITY" for t in theorem.get("lemma_targets",[])))
    # 19 report emitted
    check("report_emitted", (run_out/"report"/"V17_EXTENSION_STABILITY_REPORT.md").exists())
    # 20 discovery packet emitted
    disc=read_json(run_out/"discovery_frontier_delta_packet.json")
    check("discovery_packet_emitted", disc.get("artifact_type")=="DISCOVERY_FRONTIER_DELTA_PACKET")
    # 21 heldout predictions include q61 because it is the known hard partial in prior sweep
    check("holdout_contains_q61", any(p["q"]==61 for p in validation["predictions"]))
    # 22 status is no third category
    check("no_third_category", result["status"] in {PROMOTED,KILLED})
    passed=sum(c["pass"] for c in checks); total=len(checks)
    res={"version":VERSION,"selftest":"PASS" if passed==total else "FAIL","green_checks":passed,"total_checks":total,"hard_artifacts":["EXTENSION_PRIME_FEATURE_LEDGER","EXTENSION_MASK_OVERLAP_CERTIFICATES","PERSISTENCE_FRAGILITY_CLASSIFIER","HELD_OUT_EXTENSION_VALIDATION_LEDGER","FEATURE_ABLATION_LEDGER","THEOREM_ROUTE_PACKET","FORMAL_LEMMA_TARGETS","KBK_NEXT_BINARY_PACKET","FAILURE_ASSET_LEDGER"],"checks":checks,"artifact_dir":str(out)}
    write_json(out/"selftest_result.json", res)
    return res

# ------------------------- CLI -------------------------
def main(argv=None):
    ap=argparse.ArgumentParser(description="Oracle NT OS V17 Extension Stability Classifier")
    sub=ap.add_subparsers(dest="cmd", required=True)
    st=sub.add_parser("selftest"); st.add_argument("--out", default="v17_selftest")
    cl=sub.add_parser("extension-stability-classifier")
    for p in [cl]:
        p.add_argument("--base1", type=int, required=True); p.add_argument("--base2", type=int, required=True); p.add_argument("--c", type=int, required=True); p.add_argument("--base-moduli", type=int, nargs="+", required=True); p.add_argument("--relation-bound", type=int, default=64); p.add_argument("--out", required=True)
    cl.add_argument("--train-extension-primes", type=int, nargs="+", required=True); cl.add_argument("--holdout-extension-primes", type=int, nargs="+", required=True)
    sw=sub.add_parser("extension-stability-sweep")
    sw.add_argument("--base1", type=int, required=True); sw.add_argument("--base2", type=int, required=True); sw.add_argument("--c", type=int, required=True); sw.add_argument("--base-moduli", type=int, nargs="+", required=True); sw.add_argument("--prime-min", type=int, required=True); sw.add_argument("--prime-max", type=int, required=True); sw.add_argument("--relation-bound", type=int, default=128); sw.add_argument("--out", required=True)
    rp=sub.add_parser("replay-overlap-certificate"); rp.add_argument("--certificate", required=True)
    vf=sub.add_parser("validate-feature-ledger"); vf.add_argument("--ledger", required=True)
    args=ap.parse_args(argv)
    if args.cmd == "selftest":
        res=selftest(Path(args.out)); print(json.dumps({k:res[k] for k in ["version","selftest","green_checks","total_checks","hard_artifacts"]}, indent=2))
    elif args.cmd == "extension-stability-classifier":
        res=run_classifier(args.base1,args.base2,args.c,args.base_moduli,args.train_extension_primes,args.holdout_extension_primes,args.relation_bound,Path(args.out)); print(json.dumps(res, indent=2))
    elif args.cmd == "extension-stability-sweep":
        res=run_sweep(args.base1,args.base2,args.c,args.base_moduli,args.prime_min,args.prime_max,args.relation_bound,Path(args.out)); print(json.dumps(res, indent=2))
    elif args.cmd == "replay-overlap-certificate":
        print(json.dumps(verify_overlap_certificate(read_json(Path(args.certificate))), indent=2))
    elif args.cmd == "validate-feature-ledger":
        print(json.dumps(validate_feature_ledger(read_json(Path(args.ledger))), indent=2))

if __name__ == "__main__":
    main()
