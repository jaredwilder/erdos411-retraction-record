# Oracle Number Theory OS V7 — Nuclear War Build

V7 is a failure-elimination release against the V6 hostile review.

The rule is simple: the old 20 failure points must produce 20 green checks.

## What V7 changes

- Schema-first formal object intake. Raw prefixes stay finite-prefix only.
- Thin formal flags are rejected. Theorem-grade routes require actual object schemas.
- Route-specific theorem gates. An open or killed strong-divisibility route no longer blocks a separate recurrence theorem route.
- Hardened corruption audit. Clean Fibonacci is not falsely accused; poisoned simple laws are detected before weak invariant opportunism.
- KBK state machine. A second run refuses the wrong next action unless explicitly overridden.
- Literature collision engine. Local OEIS cache plus optional live OEIS querying and transform collision reporting.
- Strict novelty discipline. Novelty is blocked unless collision search clears the tested transforms.
- Binding tribunal policy. Missing Sage/PARI/Lean is recorded as a route blocker/demotion, not silent background noise.
- Proof-search artifacts. Recurrence generating functions, companion matrices, Newton/binomial certificates, and Lean proof-debt skeletons are emitted.
- Object-native engines. CRT war lab and Diophantine local obstruction engine are first-class commands, not sequence side notes.
- Measured scoring components. Scores expose compression, proof debt, route readiness, literature collision, known-family status, and corruption state.

## Selftest

```bash
python oracle_nt_os_v7.py selftest --out v7_selftest_out
```

Expected:

```json
{
  "version": "7.0.0-oracle-nt-os-nuclear",
  "selftest": "PASS",
  "green_checks": 20,
  "total_checks": 20
}
```

## Analyze raw finite prefix

```bash
python oracle_nt_os_v7.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_prefix \
  --out out_v7
```

This cannot emit an infinite theorem claim. It remains finite-prefix/classification unless given a formal definition or verified literature source.

## Analyze formal recurrence object

```bash
python oracle_nt_os_v7.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_formal \
  --formal-recurrence "1,1" \
  --initial-terms "1,1" \
  --out out_v7
```

## Analyze full schema object

```bash
python oracle_nt_os_v7.py analyze-object --object-json object.json --out out_v7
```

Example `object.json`:

```json
{
  "object_type": "recurrence_sequence",
  "label": "fib_schema",
  "scope": "FORMAL_DEFINITION",
  "terms": [1,1,2,3,5,8,13,21,34,55,89,144],
  "index_start": 0,
  "definition": {
    "initial_terms": [1,1],
    "recurrence": {
      "coefficients": [1,1],
      "valid_for": "n >= 2"
    },
    "domain": "integers"
  }
}
```

## CRT war lab

```bash
python oracle_nt_os_v7.py crt-war --base1 2 --base2 3 --c 1 --max-modulus 120 --out crt_out
```

## Diophantine local obstruction

```bash
python oracle_nt_os_v7.py diophantine-local --A 1 --B 1 --C 3 --bound 97 --out dio_out
```

## Important honesty

V7 does not claim to solve mathematics by itself. It closes the exact V6 failure classes and forces debt into either a certificate, blocker, or executable next action.

The next victory condition is not another pretty report. It is a hard-target kill event: a certificate, a killed route, a proof hinge, or a nontrivial object-native result.
