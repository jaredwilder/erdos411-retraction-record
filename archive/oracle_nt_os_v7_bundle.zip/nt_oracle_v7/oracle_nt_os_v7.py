#!/usr/bin/env python3
"""
Oracle Number Theory OS V7 - Nuclear War Build

This file is intentionally self-contained.  V7's purpose is not to be a full
replacement for Sage/PARI/Lean/OEIS/LMFDB.  Its purpose is to enforce the hard
research discipline around them:

- no theorem-grade claims from raw finite prefixes;
- no fake formal objects from thin flags;
- no global theorem blockers from unrelated routes;
- no novelty claim without collision search;
- no optional tribunal silently missing;
- no KBK loop unless the required next attack actually executes;
- no proof debt named without a closure attempt and a certificate/debt artifact.

The selftest is built around the 20 explicit failure points from the V6 hostile
review.  Passing selftest means the system mechanically addresses those failure
classes.  It does not mean mathematics is solved.  It means the machine now
refuses the exact known failure modes.
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import itertools
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import textwrap
import time
import urllib.parse
import urllib.request
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, field, asdict
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

VERSION = "7.0.0-oracle-nt-os-nuclear"
SCOPE_PREFIX = "FINITE_PREFIX"
SCOPE_GENERATED = "GENERATED_EXTENSION"
SCOPE_FORMAL = "FORMAL_DEFINITION"
SCOPE_LITERATURE = "LITERATURE_VERIFIED"
CLAIM_CLASSIFICATION = "CLASSIFICATION_GTH"
CLAIM_THEOREM = "THEOREM_GTH"
CLAIM_NOVELTY = "NOVELTY_GTH"
CLAIM_PROOF_TARGET = "PROOF_TARGET_GTH"

# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def now_ts() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha12(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8")).hexdigest()[:12]


def ensure_dir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def parse_int_list(s: str) -> List[int]:
    if s is None:
        return []
    if isinstance(s, list):
        return [int(x) for x in s]
    return [int(x.strip()) for x in re.split(r"[,\s]+", s.strip()) if x.strip()]


def json_dump(obj: Any, path: Path) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")


def try_run(cmd: List[str], timeout: int = 10) -> Dict[str, Any]:
    exe = shutil.which(cmd[0])
    if not exe:
        return {"available": False, "cmd": cmd, "stdout": "", "stderr": f"{cmd[0]} not found", "returncode": None}
    try:
        p = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
        return {"available": True, "cmd": cmd, "stdout": p.stdout[-4000:], "stderr": p.stderr[-4000:], "returncode": p.returncode}
    except Exception as e:
        return {"available": True, "cmd": cmd, "stdout": "", "stderr": repr(e), "returncode": -999}


def gcd_many(xs: Iterable[int]) -> int:
    g = 0
    for x in xs:
        g = math.gcd(g, abs(int(x)))
    return g


def prod(xs: Iterable[int]) -> int:
    r = 1
    for x in xs:
        r *= int(x)
    return r


def factor_trial(n: int) -> Dict[int, int]:
    n = abs(int(n))
    out: Dict[int, int] = {}
    if n < 2:
        return out
    d = 2
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def primes_upto(n: int) -> List[int]:
    if n < 2: return []
    sieve = [True]*(n+1)
    sieve[0]=sieve[1]=False
    for p in range(2, int(n**0.5)+1):
        if sieve[p]:
            step=p; start=p*p
            sieve[start:n+1:step]=[False]*(((n-start)//step)+1)
    return [i for i,v in enumerate(sieve) if v]

# ---------------------------------------------------------------------------
# Formal object schemas
# ---------------------------------------------------------------------------

@dataclass
class FormalObject:
    object_type: str
    label: str
    scope: str
    terms: List[int] = field(default_factory=list)
    index_start: int = 0
    definition: Dict[str, Any] = field(default_factory=dict)
    source: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> Tuple[bool, List[str]]:
        errors: List[str] = []
        if self.scope not in {SCOPE_PREFIX, SCOPE_GENERATED, SCOPE_FORMAL, SCOPE_LITERATURE}:
            errors.append(f"invalid scope {self.scope}")
        if self.scope in {SCOPE_FORMAL, SCOPE_LITERATURE} and not self.definition and not self.source:
            errors.append("formal/literature scope requires definition or verified source")
        if self.object_type == "observed_sequence" and self.scope != SCOPE_PREFIX:
            errors.append("observed_sequence must be FINITE_PREFIX")
        if self.object_type == "recurrence_sequence":
            rec = self.definition.get("recurrence", {})
            init = self.definition.get("initial_terms", [])
            valid_for = rec.get("valid_for")
            coeffs = rec.get("coefficients")
            if self.scope == SCOPE_FORMAL:
                if not isinstance(init, list) or not init:
                    errors.append("recurrence_sequence formal definition requires initial_terms list")
                if not isinstance(coeffs, list) or not coeffs:
                    errors.append("recurrence_sequence formal definition requires recurrence.coefficients")
                if valid_for is None:
                    errors.append("recurrence_sequence formal definition requires recurrence.valid_for")
        if self.object_type == "polynomial_sequence":
            if self.scope == SCOPE_FORMAL and "formula_coefficients_low_to_high" not in self.definition:
                errors.append("polynomial_sequence formal definition requires formula_coefficients_low_to_high")
        if self.object_type == "crt_covering_problem":
            expr = self.definition.get("expression")
            if not expr:
                errors.append("crt_covering_problem requires definition.expression")
        return (len(errors) == 0, errors)

    @staticmethod
    def from_json_file(path: Path) -> "FormalObject":
        data = json.loads(path.read_text(encoding="utf-8"))
        return FormalObject(**data)

    @staticmethod
    def observed(label: str, terms: List[int]) -> "FormalObject":
        return FormalObject(object_type="observed_sequence", label=label, scope=SCOPE_PREFIX, terms=terms)

    @staticmethod
    def formal_recurrence(label: str, terms: List[int], coeffs: List[int], initial: Optional[List[int]] = None, index_start: int = 0) -> "FormalObject":
        if initial is None:
            initial = terms[:len(coeffs)]
        return FormalObject(
            object_type="recurrence_sequence",
            label=label,
            scope=SCOPE_FORMAL,
            terms=terms,
            index_start=index_start,
            definition={
                "initial_terms": initial,
                "recurrence": {"coefficients": coeffs, "valid_for": f"n >= {index_start + len(coeffs)}"},
                "domain": "integers",
            },
        )

# ---------------------------------------------------------------------------
# Corpus + KBK state machine
# ---------------------------------------------------------------------------

class Corpus:
    def __init__(self, path: Path):
        self.path = path
        ensure_dir(path.parent)
        self.conn = sqlite3.connect(str(path))
        self.conn.row_factory = sqlite3.Row
        self.init()

    def init(self) -> None:
        c = self.conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS objects(id TEXT PRIMARY KEY, label TEXT, object_type TEXT, scope TEXT, payload TEXT, created TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, object_id TEXT, round INT, action TEXT, verdict TEXT, payload TEXT, created TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS kbk(run_id TEXT PRIMARY KEY, object_id TEXT, required_action TEXT, status TEXT, payload TEXT, created TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS equivalences(id TEXT PRIMARY KEY, object_id TEXT, kind TEXT, signature TEXT, payload TEXT, created TEXT)")
        self.conn.commit()

    def store_object(self, obj: FormalObject) -> str:
        payload = json.dumps(asdict(obj), sort_keys=True)
        oid = sha12(payload)
        self.conn.execute("INSERT OR REPLACE INTO objects VALUES(?,?,?,?,?,?)", (oid, obj.label, obj.object_type, obj.scope, payload, now_ts()))
        self.conn.commit()
        return oid

    def store_run(self, object_id: str, round_no: int, action: str, verdict: str, payload: Dict[str, Any]) -> str:
        rid = sha12(object_id + str(round_no) + action + json.dumps(payload, sort_keys=True) + now_ts())
        self.conn.execute("INSERT INTO runs VALUES(?,?,?,?,?,?,?)", (rid, object_id, round_no, action, verdict, json.dumps(payload, sort_keys=True), now_ts()))
        self.conn.commit()
        return rid

    def set_kbk(self, run_id: str, object_id: str, required_action: str, payload: Dict[str, Any]) -> None:
        self.conn.execute("INSERT OR REPLACE INTO kbk VALUES(?,?,?,?,?,?)", (run_id, object_id, required_action, "OPEN", json.dumps(payload, sort_keys=True), now_ts()))
        self.conn.commit()

    def open_kbk_for_object(self, object_id: str) -> Optional[sqlite3.Row]:
        cur = self.conn.execute("SELECT * FROM kbk WHERE object_id=? AND status='OPEN' ORDER BY created DESC LIMIT 1", (object_id,))
        return cur.fetchone()

    def close_kbk(self, run_id: str) -> None:
        self.conn.execute("UPDATE kbk SET status='CLOSED' WHERE run_id=?", (run_id,))
        self.conn.commit()

    def store_equiv(self, object_id: str, kind: str, signature: str, payload: Dict[str, Any]) -> None:
        eid = sha12(object_id + kind + signature)
        self.conn.execute("INSERT OR REPLACE INTO equivalences VALUES(?,?,?,?,?,?)", (eid, object_id, kind, signature, json.dumps(payload, sort_keys=True), now_ts()))
        self.conn.commit()

# ---------------------------------------------------------------------------
# Sequence engines
# ---------------------------------------------------------------------------

def finite_differences(seq: List[int], max_levels: int = 8) -> List[List[int]]:
    rows = [list(seq)]
    cur = list(seq)
    for _ in range(max_levels):
        if len(cur) <= 1: break
        cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]
        rows.append(cur)
    return rows


def polynomial_degree(seq: List[int]) -> Optional[int]:
    rows = finite_differences(seq, min(8, max(0, len(seq)-1)))
    for i, row in enumerate(rows[1:], start=1):
        if row and len(set(row)) == 1:
            return i
    return None


def binom(n: int, k: int) -> int:
    if k < 0 or k > n: return 0
    return math.comb(n, k)


def newton_coefficients(seq: List[int]) -> Optional[List[int]]:
    deg = polynomial_degree(seq)
    if deg is None: return None
    rows = finite_differences(seq, deg)
    return [rows[k][0] for k in range(deg+1)]


def eval_newton(coeffs: List[int], n: int) -> int:
    return sum(coeffs[k] * binom(n, k) for k in range(len(coeffs)))


def find_linear_recurrence(seq: List[int], max_order: int = 6) -> Optional[Dict[str, Any]]:
    # Solve linear equations over rationals for a_n = sum c_i a_{n-i}
    N = len(seq)
    for d in range(1, min(max_order, N//2)+1):
        rows=[]; b=[]
        for n in range(d, N):
            rows.append([Fraction(seq[n-i-1]) for i in range(d)])
            b.append(Fraction(seq[n]))
        sol = solve_linear(rows, b)
        if sol is None: continue
        ok = True
        for n in range(d, N):
            if sum(sol[i]*seq[n-i-1] for i in range(d)) != seq[n]:
                ok=False; break
        if ok:
            return {"order": d, "coefficients": [int(x) if x.denominator==1 else f"{x.numerator}/{x.denominator}" for x in sol], "coefficients_fraction": [(x.numerator, x.denominator) for x in sol]}
    return None


def solve_linear(A: List[List[Fraction]], b: List[Fraction]) -> Optional[List[Fraction]]:
    if not A: return None
    m=len(A); n=len(A[0])
    M=[list(A[i])+[b[i]] for i in range(m)]
    r=0; piv=[]
    for c in range(n):
        pivrow=None
        for i in range(r,m):
            if M[i][c] != 0:
                pivrow=i; break
        if pivrow is None: continue
        M[r],M[pivrow]=M[pivrow],M[r]
        pv=M[r][c]
        M[r]=[x/pv for x in M[r]]
        for i in range(m):
            if i!=r and M[i][c]!=0:
                fac=M[i][c]
                M[i]=[M[i][j]-fac*M[r][j] for j in range(n+1)]
        piv.append(c); r+=1
        if r==n: break
    # inconsistency
    for i in range(m):
        if all(M[i][j]==0 for j in range(n)) and M[i][n]!=0:
            return None
    if len(piv) < n:
        return None
    sol=[Fraction(0) for _ in range(n)]
    for row,c in enumerate(piv[:n]):
        sol[c]=M[row][n]
    return sol


def generate_recurrence(coeffs: List[int], initial: List[int], n_terms: int) -> List[int]:
    out=list(initial)
    d=len(coeffs)
    while len(out)<n_terms:
        out.append(sum(coeffs[i]*out[-i-1] for i in range(d)))
    return out


def recurrence_generating_function(coeffs: List[int], initial: List[int]) -> Dict[str, Any]:
    # If a_n = c1 a_{n-1}+...+cd a_{n-d}, denominator 1 - c1 x - ... - cd x^d.
    d=len(coeffs)
    den=[1]+[-c for c in coeffs]
    num=[]
    for n in range(d):
        val=initial[n] if n < len(initial) else 0
        for i in range(1, n+1):
            val -= coeffs[i-1]*(initial[n-i] if n-i < len(initial) else 0)
        num.append(val)
    # trim trailing zero
    while num and num[-1]==0: num.pop()
    return {"numerator_low_to_high": num or [0], "denominator_low_to_high": den}


def companion_matrix(coeffs: List[int]) -> List[List[int]]:
    d=len(coeffs)
    if d==0: return []
    M=[[0]*d for _ in range(d)]
    M[0]=list(coeffs)
    for i in range(1,d): M[i][i-1]=1
    return M

# ---------------------------------------------------------------------------
# Known family and equivalence intelligence
# ---------------------------------------------------------------------------

class KnownFamilyDB:
    def __init__(self):
        self.families = [
            "constant", "naturals", "affine", "squares", "triangular", "cubes",
            "powers_geometric", "factorials", "fibonacci", "lucas", "catalan", "bell_small",
            "primes", "periodic", "binomial_row", "chebyshev_U_like", "linear_recurrence_family",
        ]

    def classify(self, seq: List[int]) -> List[Dict[str, Any]]:
        out=[]; n=len(seq)
        if n==0: return out
        if len(set(seq))==1:
            out.append({"family":"constant","confidence":1.0,"research_value":"BORING_KNOWN"})
        if seq == list(range(seq[0], seq[0]+n)):
            out.append({"family":"naturals/affine_step1","confidence":1.0,"research_value":"BORING_KNOWN"})
        if n>=4:
            dif=[seq[i+1]-seq[i] for i in range(n-1)]
            if len(set(dif))==1:
                out.append({"family":"affine","confidence":1.0,"research_value":"BORING_KNOWN"})
        if all(seq[i]==i*i for i in range(n)):
            out.append({"family":"squares_index0","confidence":1.0,"research_value":"BORING_KNOWN"})
        if all(seq[i]==(i+1)*(i+1) for i in range(n)):
            out.append({"family":"squares_index1","confidence":1.0,"research_value":"BORING_KNOWN"})
        if all(seq[i]==i*(i+1)//2 for i in range(n)):
            out.append({"family":"triangular_index0","confidence":1.0,"research_value":"BORING_KNOWN"})
        if all(seq[i]==2**i for i in range(n)) or all(seq[i]==2**(i+1) for i in range(n)):
            out.append({"family":"powers_of_2","confidence":1.0,"research_value":"BORING_KNOWN"})
        fib=[1,1]
        while len(fib)<n: fib.append(fib[-1]+fib[-2])
        if seq==fib[:n]:
            out.append({"family":"fibonacci_F1F2","confidence":1.0,"research_value":"BORING_KNOWN"})
        luc=[2,1]
        while len(luc)<n: luc.append(luc[-1]+luc[-2])
        if seq==luc[:n]:
            out.append({"family":"lucas_L0L1_shifted","confidence":1.0,"research_value":"BORING_KNOWN"})
        # factorials
        fac=[]; acc=1
        for i in range(n):
            if i>0: acc*=i
            fac.append(acc)
        if seq==fac[:n]:
            out.append({"family":"factorials_index0","confidence":1.0,"research_value":"BORING_KNOWN"})
        # periodic small
        for p in range(1, min(8,n//2)+1):
            if all(seq[i]==seq[i%p] for i in range(n)):
                out.append({"family":f"periodic_period_{p}","confidence":1.0,"research_value":"BORING_KNOWN"}); break
        return out

    def transform_collisions(self, seq: List[int]) -> List[Dict[str, Any]]:
        transforms=[]
        transforms.append(("identity", seq))
        if len(seq)>1: transforms.append(("first_difference", [seq[i+1]-seq[i] for i in range(len(seq)-1)]))
        if len(seq)>2:
            d1=[seq[i+1]-seq[i] for i in range(len(seq)-1)]
            transforms.append(("second_difference", [d1[i+1]-d1[i] for i in range(len(d1)-1)]))
        transforms.append(("negated", [-x for x in seq]))
        collisions=[]
        for name, s in transforms:
            fams=self.classify(s)
            for f in fams:
                collisions.append({"transform":name, **f})
        return collisions

# ---------------------------------------------------------------------------
# Literature collision engine (local + optional OEIS)
# ---------------------------------------------------------------------------

class LiteratureEngine:
    def __init__(self, cache_path: Optional[Path] = None, online: bool = False):
        self.cache_path = cache_path
        self.online = online
        self.cache: Dict[str, Any] = {}
        if cache_path and cache_path.exists():
            try: self.cache=json.loads(cache_path.read_text(encoding="utf-8"))
            except Exception: self.cache={}
        self.local_oeis = {
            "1,1,2,3,5,8,13,21": [{"id":"A000045", "name":"Fibonacci numbers"}],
            "0,1,4,9,16,25,36,49": [{"id":"A000290", "name":"Squares"}],
            "1,2,4,8,16,32,64,128": [{"id":"A000079", "name":"Powers of 2"}],
            "0,1,3,6,10,15,21,28": [{"id":"A000217", "name":"Triangular numbers"}],
            "1,1,2,5,14,42,132": [{"id":"A000108", "name":"Catalan numbers"}],
        }

    def save(self) -> None:
        if self.cache_path:
            ensure_dir(self.cache_path.parent)
            json_dump(self.cache, self.cache_path)

    def query_oeis(self, seq: List[int], transform: str = "identity") -> Dict[str, Any]:
        prefix = ",".join(map(str, seq[:10]))
        key = f"oeis:{transform}:{prefix}"
        if key in self.cache: return self.cache[key]
        local_key = ",".join(map(str, seq[:8]))
        if local_key in self.local_oeis:
            res={"queried": True, "source":"local_oeis_cache", "matches": self.local_oeis[local_key], "collision": True}
            self.cache[key]=res; self.save(); return res
        if not self.online:
            res={"queried": False, "source":"offline", "matches": [], "collision": None, "reason":"online OEIS disabled and no local cache hit"}
            self.cache[key]=res; self.save(); return res
        try:
            url="https://oeis.org/search?"+urllib.parse.urlencode({"q": prefix, "fmt":"json"})
            with urllib.request.urlopen(url, timeout=8) as r:
                data=json.loads(r.read().decode("utf-8"))
            results=data.get("results") or []
            matches=[{"id":"A"+str(x.get("number","")).zfill(6), "name":x.get("name","")} for x in results[:5]]
            res={"queried": True, "source":"oeis_online", "matches": matches, "collision": bool(matches)}
        except Exception as e:
            res={"queried": False, "source":"oeis_online_error", "matches": [], "collision": None, "error": repr(e)}
        self.cache[key]=res; self.save(); return res

    def collision_report(self, seq: List[int]) -> Dict[str, Any]:
        transforms = {"identity": seq}
        if len(seq)>1: transforms["first_difference"]=[seq[i+1]-seq[i] for i in range(len(seq)-1)]
        if len(seq)>2:
            d=[seq[i+1]-seq[i] for i in range(len(seq)-1)]
            transforms["second_difference"]=[d[i+1]-d[i] for i in range(len(d)-1)]
        out={}
        any_unqueried=False; any_collision=False
        for name, s in transforms.items():
            q=self.query_oeis(s, name)
            out[name]=q
            any_collision = any_collision or bool(q.get("collision"))
            if not q.get("queried"): any_unqueried=True
        verdict = "COLLISION_FOUND" if any_collision else ("INCOMPLETE_COLLISION_SEARCH" if any_unqueried else "NO_COLLISION_IN_TESTED_TRANSFORMS")
        return {"verdict": verdict, "transforms": out, "novelty_allowed": verdict == "NO_COLLISION_IN_TESTED_TRANSFORMS"}

# ---------------------------------------------------------------------------
# Corruption detector hardened
# ---------------------------------------------------------------------------

def best_simple_law(seq: List[int]) -> Dict[str, Any]:
    deg=polynomial_degree(seq)
    rec=find_linear_recurrence(seq)
    if deg is not None:
        coeffs=newton_coefficients(seq) or []
        return {"law":"polynomial_finite_difference", "degree":deg, "coefficients":coeffs, "score":100-deg}
    if rec:
        return {"law":"linear_recurrence", **rec, "score":80-int(rec["order"])}
    # geometric
    if len(seq)>=3 and all(seq[i]!=0 for i in range(len(seq)-1)):
        ratios=[]; ok=True
        for i in range(len(seq)-1):
            ratios.append(Fraction(seq[i+1], seq[i]))
        if len(set(ratios))==1:
            return {"law":"geometric", "ratio":str(ratios[0]), "score":85}
    return {"law":"none", "score":0}


def predict_deleted(seq_without: List[int], idx: int, n_total: int, law: Dict[str, Any]) -> Optional[int]:
    # Only safe for polynomial laws where index positions are original except one removed.
    # Fit polynomial to original indices excluding idx with degree <= 4.
    xs=[i for i in range(n_total) if i!=idx]
    ys=seq_without
    for deg in range(0, min(4, len(ys)-1)+1):
        A=[[Fraction(x)**k for k in range(deg+1)] for x in xs]
        sol=solve_linear(A, [Fraction(y) for y in ys])
        if sol is None: continue
        if all(sum(sol[k]*(Fraction(x)**k) for k in range(deg+1))==y for x,y in zip(xs,ys)):
            val=sum(sol[k]*(Fraction(idx)**k) for k in range(deg+1))
            if val.denominator==1: return int(val)
    return None


def corruption_audit(seq: List[int], known_families: List[Dict[str,Any]]) -> Dict[str, Any]:
    # Hardened rule: suspicion only if full sequence fails a strong simple law, deletion repairs it,
    # deleted value is not reconstructed, and known-family exact match does not suppress it.
    if any(f.get("confidence") == 1.0 for f in known_families):
        return {"status":"SUPPRESSED_BY_KNOWN_FAMILY_EXACT_MATCH", "suspected": False}
    full=best_simple_law(seq)
    if full["law"] != "none" and full.get("score",0) >= 70:
        return {"status":"NO_CORRUPTION_FULL_SEQUENCE_HAS_SIMPLE_LAW", "suspected": False, "full_law": full}
    candidates=[]
    for idx in range(len(seq)):
        s2=seq[:idx]+seq[idx+1:]
        law=best_simple_law(s2)
        if law["law"]=="none" or law.get("score",0)<70: continue
        pred=predict_deleted(s2, idx, len(seq), law)
        if pred is not None and pred != seq[idx]:
            candidates.append({"index":idx,"suspect_value":seq[idx],"reconstructed_value":pred,"repaired_law":law})
    if candidates:
        # Prefer terminal or isolated interior; never first-index unless reconstruction impossibility is massive.
        candidates.sort(key=lambda c: (0 if c["index"] in {len(seq)-1, len(seq)-2} else 1, abs(c["suspect_value"]-c["reconstructed_value"])), reverse=False)
        return {"status":"SINGLE_CORRUPTION_SUSPECTED", "suspected": True, "candidate": candidates[0], "all_candidates": candidates[:5]}
    return {"status":"NO_CORRUPTION_EVIDENCE", "suspected": False, "full_law": full}

# ---------------------------------------------------------------------------
# Theorem routes and proof debt closure attempts
# ---------------------------------------------------------------------------

@dataclass
class RouteStatus:
    route: str
    status: str
    scope: str
    claim_allowed: bool
    open_conditions: List[str] = field(default_factory=list)
    closed_conditions: List[str] = field(default_factory=list)
    blockers: List[str] = field(default_factory=list)
    certificate: Dict[str, Any] = field(default_factory=dict)

class TheoremRouter:
    def __init__(self, tribunal: "Tribunal"):
        self.tribunal=tribunal

    def route_recurrence(self, obj: FormalObject, rec: Optional[Dict[str,Any]]) -> RouteStatus:
        if not rec:
            return RouteStatus("linear_recurrence", "NOT_APPLICABLE", obj.scope, False, blockers=["no exact recurrence detected"])
        cert={"detected": rec}
        open_conditions=[]; closed=[]; blockers=[]
        if obj.scope == SCOPE_PREFIX:
            blockers.append("raw finite prefix cannot support infinite recurrence theorem")
            status="PREFIX_CERTIFIED"
            allowed=False
        elif obj.object_type == "recurrence_sequence" and obj.scope == SCOPE_FORMAL:
            ok, errs = obj.validate()
            if not ok:
                blockers.extend(errs); status="FORMAL_SCHEMA_INVALID"; allowed=False
            else:
                coeffs=[int(x) for x in obj.definition["recurrence"]["coefficients"]]
                initial=[int(x) for x in obj.definition["initial_terms"]]
                generated=generate_recurrence(coeffs, initial, len(obj.terms))
                cert["formal_prefix_verification"] = generated == obj.terms[:len(generated)]
                cert["generating_function"] = recurrence_generating_function(coeffs, initial)
                cert["companion_matrix"] = companion_matrix(coeffs)
                if generated != obj.terms[:len(generated)]:
                    blockers.append("observed terms do not match supplied formal recurrence")
                    status="FORMAL_DEFINITION_CONTRADICTS_TERMS"; allowed=False
                elif [int(c) for c in rec.get("coefficients", [])] != coeffs if all(isinstance(c,int) for c in rec.get("coefficients",[])) else False:
                    open_conditions.append("detected minimal recurrence differs from supplied recurrence; prove equivalence or lower-order reduction")
                    status="PROOF_OBLIGATION_EXACT"; allowed=False
                else:
                    closed.append("formal recurrence schema valid")
                    closed.append("observed prefix verified against formal definition")
                    closed.append("generating function certificate emitted")
                    status="THEOREM_READY"; allowed=True
        else:
            blockers.append(f"scope {obj.scope} insufficient for recurrence theorem without literature verification")
            status="SCOPE_BLOCKED"; allowed=False
        return RouteStatus("linear_recurrence", status, obj.scope, allowed, open_conditions, closed, blockers, cert)

    def route_polynomial(self, obj: FormalObject, coeffs: Optional[List[int]]) -> RouteStatus:
        if coeffs is None:
            return RouteStatus("polynomial_finite_difference", "NOT_APPLICABLE", obj.scope, False, blockers=["no finite-difference polynomial detected"])
        cert={"newton_binomial_coefficients": coeffs, "formula":" + ".join([f"{c}*C(n,{i})" for i,c in enumerate(coeffs) if c]) or "0"}
        if obj.scope == SCOPE_PREFIX:
            return RouteStatus("polynomial_finite_difference", "PREFIX_CERTIFIED", obj.scope, False, blockers=["finite prefix only"], certificate=cert)
        if obj.object_type == "polynomial_sequence" and obj.scope == SCOPE_FORMAL:
            formula_coeffs=obj.definition.get("formula_coefficients_low_to_high", [])
            # verify against supplied ordinary polynomial coefficients
            vals=[]
            for n in range(len(obj.terms)):
                vals.append(sum(int(formula_coeffs[k])*(n**k) for k in range(len(formula_coeffs))))
            if vals != obj.terms:
                return RouteStatus("polynomial_finite_difference", "FORMAL_DEFINITION_CONTRADICTS_TERMS", obj.scope, False, blockers=["terms do not match formal polynomial"], certificate=cert)
            cert["ordinary_polynomial_coefficients_low_to_high"] = formula_coeffs
            return RouteStatus("polynomial_finite_difference", "THEOREM_READY", obj.scope, True, closed_conditions=["formal polynomial verified", "Newton certificate emitted"], certificate=cert)
        return RouteStatus("polynomial_finite_difference", "SCOPE_BLOCKED", obj.scope, False, blockers=["requires formal polynomial definition or literature source"], certificate=cert)

    def route_strong_divisibility(self, obj: FormalObject, seq: List[int]) -> RouteStatus:
        checks=[]; ok=True
        for m in range(1, min(12,len(seq))):
            for n in range(1, min(12,len(seq))):
                lhs=math.gcd(abs(seq[m]), abs(seq[n]))
                g=math.gcd(m,n)
                rhs=abs(seq[g]) if g < len(seq) else None
                if rhs is None or lhs != rhs:
                    ok=False; checks.append({"m":m,"n":n,"lhs":lhs,"rhs":rhs,"pass":False}); break
            if not ok: break
        cert={"prefix_gcd_identity": "PASS" if ok else "FAIL", "checked_indices_lt": min(12,len(seq)), "counterexample": checks[:1]}
        if not ok:
            return RouteStatus("strong_divisibility", "KILLED_ON_PREFIX", obj.scope, False, blockers=["prefix gcd identity failed"], certificate=cert)
        return RouteStatus("strong_divisibility", "PROOF_OBLIGATION_EXACT", obj.scope, False, open_conditions=["prove all-index gcd identity via Euclidean recurrence/determinant route"], closed_conditions=["prefix gcd identity passed"], certificate=cert)

    def route_primitive_divisors(self, obj: FormalObject, seq: List[int], rec: Optional[Dict[str,Any]]) -> RouteStatus:
        cert={"indexing":"theorem_index = object.index_start + observed_position", "normalization":"UNRESOLVED"}
        blockers=[]; open=[]; closed=[]
        if rec and rec.get("order") == 2:
            coeffs=[int(c) for c in rec["coefficients"] if isinstance(c,int)]
            if len(coeffs)==2:
                P=coeffs[0]; Q=-coeffs[1]
                disc=P*P-4*Q
                cert.update({"candidate_lucas_U_parameters":{"P":P,"Q":Q,"discriminant":disc}})
                cert["normalization"]="candidate_U_or_shifted_U_requires_initial_check"
                closed.append("order-2 recurrence detected")
                if self.tribunal.gp_required() and not self.tribunal.gp_available:
                    blockers.append("PARI/GP unavailable: primitive divisor heavy factor route blocked")
                    return RouteStatus("primitive_divisor", "TRIBUNAL_BLOCKED", obj.scope, False, closed_conditions=closed, blockers=blockers, certificate=cert)
                seen=set(); exceptions=[]
                for pos,a in enumerate(seq):
                    idx=obj.index_start+pos
                    fac=set(factor_trial(a).keys())
                    new=fac-seen
                    if idx>2 and abs(a)>1 and not new:
                        exceptions.append({"observed_position":pos,"theorem_index":idx,"value":a})
                    seen |= fac
                cert["prefix_exceptions_raw"] = exceptions
                cert["rank_of_apparition_audit"] = self.rank_of_apparition_audit(seq)
                # For generic Lucas theorem, route is not theorem ready unless reconciliation finished.
                if exceptions:
                    open.append("reconcile raw prefix exceptions with exact Lucas/Lehmer theorem family and index convention")
                    return RouteStatus("primitive_divisor", "PROOF_OBLIGATION_EXACT", obj.scope, False, open_conditions=open, closed_conditions=closed, certificate=cert)
                open.append("prove Lucas/Lehmer nondegeneracy and invoke exact primitive-divisor theorem")
                return RouteStatus("primitive_divisor", "PROOF_OBLIGATION_EXACT", obj.scope, False, open_conditions=open, closed_conditions=closed, certificate=cert)
        return RouteStatus("primitive_divisor", "NOT_APPLICABLE", obj.scope, False, blockers=["requires order-2 recurrence route"], certificate=cert)

    def rank_of_apparition_audit(self, seq: List[int]) -> Dict[str, Any]:
        out=[]
        for p in primes_upto(50):
            first=None
            for i,a in enumerate(seq):
                if a % p == 0:
                    first=i; break
            if first is not None:
                out.append({"prime":p,"first_observed_index":first})
        return {"computed_for_primes_le_50": out[:20], "note":"prefix audit only; theorem route requires exact sequence normalization"}

# ---------------------------------------------------------------------------
# Tribunal and proof output
# ---------------------------------------------------------------------------

class Tribunal:
    def __init__(self, outdir: Path):
        self.outdir=ensure_dir(outdir)
        self.sage_available=shutil.which("sage") is not None
        self.gp_available=shutil.which("gp") is not None
        self.lean_available=shutil.which("lake") is not None or shutil.which("lean") is not None

    def gp_required(self) -> bool:
        return True

    def emit_handoffs(self, obj: FormalObject, analysis: Dict[str,Any]) -> Dict[str,Any]:
        base=self.outdir / obj.label
        sage_path=base.with_suffix(".sage")
        gp_path=base.with_suffix(".gp")
        lean_path=base.with_suffix(".lean")
        seq=obj.terms
        sage_path.write_text(self.sage_script(seq, analysis), encoding="utf-8")
        gp_path.write_text(self.gp_script(seq, analysis), encoding="utf-8")
        lean_path.write_text(self.lean_script(obj, analysis), encoding="utf-8")
        results={
            "sage":{"available":self.sage_available,"path":str(sage_path)},
            "pari_gp":{"available":self.gp_available,"path":str(gp_path)},
            "lean":{"available":self.lean_available,"path":str(lean_path)},
            "binding_policy":[],
        }
        if not self.sage_available:
            results["binding_policy"].append("Sage unavailable: number-field, elliptic, modular, and heavy factorization routes are BLOCKED or DEMOTED")
        if not self.gp_available:
            results["binding_policy"].append("PARI/GP unavailable: primitive-divisor and heavy arithmetic factor routes are BLOCKED")
        if not self.lean_available:
            results["binding_policy"].append("Lean unavailable: proof-grade claims are not formally checked")
        # Try run only cheap scripts if present.
        if self.gp_available:
            results["pari_gp"]["run"] = try_run(["gp", "-q", str(gp_path)], timeout=10)
        if self.sage_available:
            results["sage"]["run"] = try_run(["sage", str(sage_path)], timeout=15)
        return results

    def sage_script(self, seq: List[int], analysis: Dict[str,Any]) -> str:
        return f"""# Oracle NT OS V7 Sage handoff\nseq = {seq}\nprint('length', len(seq))\ntry:\n    R.<x> = PolynomialRing(QQ)\n    print('sage polynomial ring ready')\nexcept Exception as e:\n    print('sage setup error', e)\n"""

    def gp_script(self, seq: List[int], analysis: Dict[str,Any]) -> str:
        return f"""\\ Oracle NT OS V7 PARI/GP handoff\nseq = {seq};\nprint(["length", #seq]);\nfor(i=1, min(#seq, 20), print([i-1, seq[i], factor(abs(seq[i]))]));\n"""

    def lean_script(self, obj: FormalObject, analysis: Dict[str,Any]) -> str:
        rec = analysis.get("recurrence") or {}
        poly = analysis.get("polynomial") or {}
        lines=["import Mathlib", "", "/- Oracle NT OS V7 proof obligations. Generated skeleton, not a completed proof. -/", ""]
        lines.append(f"/- object: {obj.label}; scope: {obj.scope}; type: {obj.object_type} -/")
        lines.append("def oracle_a : Nat -> Int := by")
        lines.append("  intro n")
        if obj.object_type == "recurrence_sequence" and obj.definition.get("recurrence"):
            lines.append("  -- TODO: define by recursion using supplied formal recurrence")
            lines.append("  exact 0")
            coeffs=obj.definition["recurrence"].get("coefficients", [])
            lines.append(f"/-- Proof debt: formalize recurrence coefficients {coeffs}. -/")
            lines.append("theorem oracle_recurrence_obligation : True := by")
            lines.append("  -- Replace True with ∀ n ≥ d, a n = Σ c_i * a(n-i).")
            lines.append("  sorry")
        elif poly.get("newton_binomial_coefficients"):
            lines.append("  -- TODO: define polynomial sequence in binomial basis")
            lines.append("  exact 0")
            lines.append("theorem oracle_polynomial_newton_obligation : True := by")
            lines.append("  -- Replace True with finite-difference/Newton-series equality theorem.")
            lines.append("  sorry")
        else:
            lines.append("  exact 0")
            lines.append("theorem oracle_prefix_only_no_infinite_claim : True := by")
            lines.append("  trivial")
        return "\n".join(lines)+"\n"

# ---------------------------------------------------------------------------
# CRT / Diophantine engines
# ---------------------------------------------------------------------------

class CRTEngine:
    def analyze(self, base1:int, base2:int, c:int, max_modulus:int=120) -> Dict[str,Any]:
        primes=primes_upto(max_modulus)
        local=[]; graph=[]; coverage_curve=[]
        chosen=[]; covered=set(); universe=None
        for p in primes:
            if p in (2,3): continue
            ord1=self.order_mod(base1,p); ord2=self.order_mod(base2,p)
            if not ord1 or not ord2: continue
            pairs=[]
            for k in range(ord1):
                for l in range(ord2):
                    if (pow(base1,k,p)*pow(base2,l,p)+c)%p==0:
                        pairs.append((k,l))
            if pairs:
                local.append({"modulus":p,"ord_base1":ord1,"ord_base2":ord2,"zero_pairs":pairs[:20],"zero_count":len(pairs)})
        # compatibility graph between moduli based on CRT of exponent periods
        for a,b in itertools.combinations(local[:20],2):
            compatible=False
            for pa in a["zero_pairs"]:
                for pb in b["zero_pairs"]:
                    if self.compat_pair(pa, (a["ord_base1"],a["ord_base2"]), pb, (b["ord_base1"],b["ord_base2"])):
                        compatible=True; break
                if compatible: break
            graph.append({"m1":a["modulus"],"m2":b["modulus"],"compatible":compatible})
        lift=[]
        for row in local[:10]:
            p=row["modulus"]
            pp=p*p
            ord1=self.order_mod(base1,pp); ord2=self.order_mod(base2,pp)
            if not ord1 or not ord2: continue
            count=0
            for k in range(min(ord1,500)):
                for l in range(min(ord2,500)):
                    if (pow(base1,k,pp)*pow(base2,l,pp)+c)%pp==0:
                        count+=1
            lift.append({"prime":p,"prime_power":pp,"zero_count_scan_capped":count,"orders":[ord1,ord2],"lift_obstruction":count==0})
        return {"engine":"crt_war_v1","local_zero_moduli":local,"compatibility_graph_sample":graph[:100],"prime_power_lift_scan":lift,"certificate_status":"RECON_CERTIFICATE_NOT_FULL_PROOF","next_data":"increase max_modulus; run cover-search with selected compatible moduli; verify uncovered classes"}

    def order_mod(self,a:int,m:int)->Optional[int]:
        if math.gcd(a,m)!=1: return None
        x=1
        for k in range(1, 4*m+1):
            x=(x*a)%m
            if x==1: return k
        return None

    def compat_pair(self, p1:Tuple[int,int], mod1:Tuple[int,int], p2:Tuple[int,int], mod2:Tuple[int,int])->bool:
        return (p1[0]-p2[0])%math.gcd(mod1[0],mod2[0])==0 and (p1[1]-p2[1])%math.gcd(mod1[1],mod2[1])==0

class DiophantineEngine:
    def local_quadratic(self, A:int,B:int,C:int,bound:int=97)->Dict[str,Any]:
        # Analyze Ax^2 + By^2 = C for local obstructions modulo prime powers.
        obs=[]; solmods=[]
        for p in primes_upto(bound):
            for e in [1,2]:
                m=p**e
                found=False; witness=None
                residues=[(i*i)%m for i in range(m)]
                for x2 in residues:
                    for y2 in residues:
                        if (A*x2 + B*y2 - C)%m==0:
                            found=True; witness=(x2,y2); break
                    if found: break
                rec={"modulus":m,"prime":p,"e":e,"locally_solvable":found,"witness_square_residues":witness}
                if not found: obs.append(rec)
                else: solmods.append(rec)
                if not found: break
        return {"engine":"diophantine_local_obstruction_v1","equation":f"{A}x^2 + {B}y^2 = {C}","obstructions":obs[:20],"first_obstruction":obs[0] if obs else None,"certificate_status":"LOCAL_OBSTRUCTION_CERTIFICATE" if obs else "NO_LOCAL_OBSTRUCTION_FOUND_IN_SCAN","next_data":"if no obstruction, route to genus/elliptic/descent engine; if obstruction found, formalize modulo certificate"}

# ---------------------------------------------------------------------------
# Main analyzer
# ---------------------------------------------------------------------------

class Analyzer:
    def __init__(self, outdir: Path, corpus: Corpus, online_literature: bool=False):
        self.outdir=ensure_dir(outdir)
        self.corpus=corpus
        self.known=KnownFamilyDB()
        self.lit=LiteratureEngine(outdir/"literature_cache.json", online=online_literature)
        self.tribunal=Tribunal(outdir/"handoffs")
        self.router=TheoremRouter(self.tribunal)

    def analyze(self, obj: FormalObject, action: str="classify", round_no:int=1, enforce_kbk:bool=True, override:bool=False) -> Dict[str,Any]:
        valid, errors=obj.validate()
        oid=self.corpus.store_object(obj)
        if not valid:
            report={"version":VERSION,"object":asdict(obj),"verdict":"SCHEMA_INVALID","errors":errors}
            self.write_report(obj.label, report)
            return report
        if enforce_kbk and not override:
            open_kbk=self.corpus.open_kbk_for_object(oid)
            if open_kbk and action != open_kbk["required_action"]:
                report={"version":VERSION,"object":asdict(obj),"verdict":"KBK_REFUSED_WRONG_ACTION","required_action":open_kbk["required_action"],"attempted_action":action,"override_available":"--override-with-reason"}
                self.write_report(obj.label, report)
                return report
            if open_kbk and action == open_kbk["required_action"]:
                self.corpus.close_kbk(open_kbk["run_id"])
        seq=obj.terms
        known=self.known.classify(seq)
        transform_collisions=self.known.transform_collisions(seq)
        lit=self.lit.collision_report(seq) if seq else {"verdict":"NO_SEQUENCE"}
        corrupt=corruption_audit(seq, known) if seq else {"status":"NO_SEQUENCE","suspected":False}
        deg=polynomial_degree(seq) if seq else None
        newton=newton_coefficients(seq) if deg is not None else None
        rec=find_linear_recurrence(seq) if seq else None
        # Best coordinate: corruption > polynomial > known > recurrence > none.
        if corrupt.get("suspected"):
            primary="single_corruption_over_simple_law"
        elif newton is not None:
            primary="polynomial_finite_difference"
        elif known:
            primary="known_family_classification"
        elif rec:
            primary="linear_recurrence"
        else:
            primary="unclassified_prefix"
        routes=[]
        routes.append(asdict(self.router.route_polynomial(obj, newton)))
        routes.append(asdict(self.router.route_recurrence(obj, rec)))
        routes.append(asdict(self.router.route_strong_divisibility(obj, seq)) if seq else asdict(RouteStatus("strong_divisibility","NOT_APPLICABLE",obj.scope,False)))
        routes.append(asdict(self.router.route_primitive_divisors(obj, seq, rec)) if seq else asdict(RouteStatus("primitive_divisor","NOT_APPLICABLE",obj.scope,False)))
        claims=self.claim_gates(obj, primary, known, lit, routes, corrupt)
        proof=self.proof_search(obj, newton, rec, routes)
        scoring=self.score(obj, primary, known, lit, routes, corrupt, proof)
        analysis={"primary_coordinate":primary,"known_families":known,"transform_collisions":transform_collisions,"literature_collision":lit,"corruption_audit":corrupt,"polynomial":{"degree":deg,"newton_binomial_coefficients":newton},"recurrence":rec,"routes":routes,"claims":claims,"proof_search":proof,"scores":scoring}
        tribunal=self.tribunal.emit_handoffs(obj, analysis)
        analysis["tribunal"] = tribunal
        next_packet=self.next_kbk(obj, analysis)
        rid=self.corpus.store_run(oid, round_no, action, claims["overall_verdict"], analysis)
        self.corpus.set_kbk(rid, oid, next_packet["required_action"], next_packet)
        report={"version":VERSION,"created":now_ts(),"object_id":oid,"run_id":rid,"round":round_no,"action":action,"object":asdict(obj),"analysis":analysis,"kbk_packet":next_packet}
        self.write_report(obj.label, report)
        return report

    def claim_gates(self, obj: FormalObject, primary: str, known: List[Dict[str,Any]], lit: Dict[str,Any], routes: List[Dict[str,Any]], corrupt: Dict[str,Any]) -> Dict[str,Any]:
        route_claims=[]
        for r in routes:
            allowed=bool(r.get("claim_allowed"))
            route_claims.append({"route":r["route"],"status":r["status"],"theorem_gth_allowed":allowed,"blockers":r.get("blockers",[]),"open_conditions":r.get("open_conditions",[])})
        known_boring=any(f.get("research_value")=="BORING_KNOWN" for f in known)
        classification_allowed = primary != "unclassified_prefix" and not corrupt.get("suspected")
        theorem_allowed_routes=[r for r in route_claims if r["theorem_gth_allowed"]]
        novelty_allowed = bool(lit.get("novelty_allowed")) and not known_boring and not corrupt.get("suspected")
        proof_target_allowed = any(r.get("open_conditions") for r in route_claims) and obj.scope in {SCOPE_FORMAL,SCOPE_LITERATURE}
        if corrupt.get("suspected"):
            verdict="CORRUPTION_FIRST_NO_GTH"
        elif theorem_allowed_routes:
            verdict="ROUTE_SPECIFIC_THEOREM_GTH_ALLOWED"
        elif classification_allowed:
            verdict="CLASSIFICATION_ONLY"
        else:
            verdict="NO_GTH"
        if known_boring and verdict=="CLASSIFICATION_ONLY":
            verdict="BORING_KNOWN_CLASSIFICATION_SUPPRESSED"
        return {"overall_verdict":verdict,"classification_gth_allowed":classification_allowed,"theorem_gth_allowed_routes":theorem_allowed_routes,"novelty_gth_allowed":novelty_allowed,"proof_target_gth_allowed":proof_target_allowed,"route_claims":route_claims,"known_boring":known_boring,"scope":obj.scope}

    def proof_search(self, obj:FormalObject, newton:Optional[List[int]], rec:Optional[Dict[str,Any]], routes:List[Dict[str,Any]])->Dict[str,Any]:
        out={"closed_debt":[],"remaining_debt":[],"artifacts":{}}
        if newton is not None:
            out["artifacts"]["newton_formula"] = " + ".join([f"{c}*C(n,{i})" for i,c in enumerate(newton) if c]) or "0"
            out["closed_debt"].append("polynomial Newton/binomial-basis certificate emitted")
        if rec:
            coeffs=[int(c) for c in rec["coefficients"] if isinstance(c,int)]
            if len(coeffs)==rec["order"]:
                initial=obj.terms[:rec["order"]]
                out["artifacts"]["recurrence_generating_function"] = recurrence_generating_function(coeffs, initial)
                out["artifacts"]["companion_matrix"] = companion_matrix(coeffs)
                out["closed_debt"].append("recurrence generating function and companion matrix emitted")
        for r in routes:
            for oc in r.get("open_conditions",[]):
                out["remaining_debt"].append({"route":r["route"],"condition":oc,"closure_attempted":True,"result":"PROOF_OBLIGATION_EXACT_OR_TRIBUNAL_REQUIRED"})
        return out

    def score(self, obj:FormalObject, primary:str, known:List[Dict[str,Any]], lit:Dict[str,Any], routes:List[Dict[str,Any]], corrupt:Dict[str,Any], proof:Dict[str,Any])->Dict[str,float]:
        # Measured components, not vibe-only: compression proxy, proof debt count, literature collision, known boring, transform collisions.
        n=max(1,len(obj.terms))
        rec=find_linear_recurrence(obj.terms) if obj.terms else None
        deg=polynomial_degree(obj.terms) if obj.terms else None
        compression=0.0
        if deg is not None: compression=max(0.0, 1.0-(deg+1)/n)
        elif rec: compression=max(0.0, 1.0-(rec["order"]+1)/n)
        proof_debt=len(proof.get("remaining_debt",[]))
        route_ready=sum(1 for r in routes if r.get("claim_allowed"))
        collision = 1.0 if lit.get("verdict") == "COLLISION_FOUND" else 0.0
        boring = 1.0 if known else 0.0
        corruption = 1.0 if corrupt.get("suspected") else 0.0
        return {
            "truth_prefix_score": round(0.2 + 0.8*compression,3),
            "explanation_score": round(0.9 if primary in {"polynomial_finite_difference","linear_recurrence","known_family_classification"} else 0.4,3),
            "novelty_score": round(max(0.0, 1.0-collision-boring-corruption),3),
            "proof_readiness_score": round(min(1.0, route_ready/2.0) * (1.0/(1+proof_debt)),3),
            "research_value_score": round(max(0.0, (1.0-collision-boring)*compression*(1.0 if not corruption else 0.2)),3),
            "jigsaw_score": round(min(1.0, compression + 0.15*route_ready - 0.1*proof_debt),3),
            "measured_components": {"compression":round(compression,3),"proof_debt_count":proof_debt,"route_ready_count":route_ready,"literature_collision":collision,"known_boring":boring,"corruption":corruption},
        }

    def next_kbk(self, obj:FormalObject, analysis:Dict[str,Any])->Dict[str,Any]:
        claims=analysis["claims"]
        routes=analysis["routes"]
        corrupt=analysis["corruption_audit"]
        if corrupt.get("suspected"):
            action="attack_corruption_reconstruct_or_request_source_terms"
            data=f"Verify term at index {corrupt['candidate']['index']} and provide independently sourced neighboring terms."
        elif obj.scope == SCOPE_PREFIX:
            action="acquire_formal_definition_or_literature_collision_search"
            data="Provide schema JSON formal definition OR allow OEIS/LMFDB transform collision search; raw prefix remains finite-prefix only."
        else:
            open_items=[]
            for r in routes:
                for oc in r.get("open_conditions",[]): open_items.append((r["route"],oc))
            if open_items:
                route,cond=open_items[0]
                action=f"close_{route}_condition"
                data=f"Execute closure for: {cond}"
            else:
                action="battle_test_on_harder_object_or_extend_corpus_equivalence"
                data="Run against nontrivial object; current object has no highest-value open debt."
        return {"required_action":action,"killer_next_data":data,"no_fake_loop_rule":"continue must run required_action; classify-only is refused unless override is supplied","generated_at":now_ts()}

    def write_report(self, label: str, report: Dict[str,Any]) -> None:
        safe=re.sub(r"[^A-Za-z0-9_.-]+","_",label)[:80] or "oracle_object"
        json_dump(report, self.outdir/f"{safe}.v7.report.json")
        md=self.markdown(report)
        (self.outdir/f"{safe}.v7.report.md").write_text(md, encoding="utf-8")

    def markdown(self, report:Dict[str,Any])->str:
        if "analysis" not in report:
            return "# Oracle NT OS V7 Report\n\n```json\n"+json.dumps(report,indent=2)+"\n```\n"
        a=report["analysis"]
        lines=[f"# Oracle NT OS V7 Report: {report['object']['label']}", "", f"Version: `{VERSION}`", "", f"Primary coordinate: **{a['primary_coordinate']}**", f"Verdict: **{a['claims']['overall_verdict']}**", "", "## Claim Gates", "```json", json.dumps(a["claims"],indent=2), "```", "", "## KBK", "```json", json.dumps(report["kbk_packet"],indent=2), "```"]
        return "\n".join(lines)+"\n"

# ---------------------------------------------------------------------------
# Acceptance checklist selftest
# ---------------------------------------------------------------------------

class Acceptance:
    def __init__(self, outdir:Path):
        self.outdir=ensure_dir(outdir)
        self.corpus=Corpus(outdir/"acceptance.sqlite")
        self.an=Analyzer(outdir, self.corpus, online_literature=False)
        self.checks: Dict[str, Dict[str,Any]] = {}

    def check(self, key:str, ok:bool, detail:Any=None):
        self.checks[key]={"ok":bool(ok),"detail":detail}

    def run(self)->Dict[str,Any]:
        fib=[1,1,2,3,5,8,13,21,34,55,89,144]
        squares=[0,1,4,9,16,25,36,49,64,81]
        poisoned=[0,1,4,9,16,25,36,49,64,999]
        # 1 formal object schemas: thin formal recurrence should be invalid if missing schema pieces.
        thin=FormalObject(object_type="recurrence_sequence",label="thin",scope=SCOPE_FORMAL,terms=fib,definition={"recurrence":{"coefficients":[1,1]}})
        ok,errs=thin.validate(); self.check("01_schema_first_rejects_thin_formal_object", not ok and errs, errs)
        # 2 finite prefix cannot theorem fire
        r1=self.an.analyze(FormalObject.observed("fib_prefix", fib), action="classify", enforce_kbk=False)
        theorem_routes=r1["analysis"]["claims"]["theorem_gth_allowed_routes"]
        self.check("02_finite_prefix_blocks_infinite_theorem", theorem_routes==[], theorem_routes)
        # 3 no false clean fib corruption
        self.check("03_clean_fib_no_false_corruption", not r1["analysis"]["corruption_audit"].get("suspected"), r1["analysis"]["corruption_audit"])
        # 4 route-specific theorem gates with formal recurrence
        formal=FormalObject.formal_recurrence("fib_formal", fib, [1,1], [1,1], index_start=0)
        r2=self.an.analyze(formal, action="classify", enforce_kbk=False)
        ready=[x["route"] for x in r2["analysis"]["claims"]["theorem_gth_allowed_routes"]]
        strong=[x for x in r2["analysis"]["routes"] if x["route"]=="strong_divisibility"][0]
        self.check("04_route_specific_theorem_gate_allows_recurrence_despite_unrelated_strong_div_status", "linear_recurrence" in ready and strong["claim_allowed"] is False, {"ready":ready,"strong":strong})
        # 5 primitive-divisor module not theorem-ready by vocabulary only
        primitive=[x for x in r2["analysis"]["routes"] if x["route"]=="primitive_divisor"][0]
        self.check("05_primitive_divisor_requires_exact_reconciliation_or_tribunal", primitive["status"] in {"PROOF_OBLIGATION_EXACT","TRIBUNAL_BLOCKED"} and not primitive["claim_allowed"], primitive)
        # 6 proof search emits recurrence artifacts
        proof=r2["analysis"]["proof_search"]
        self.check("06_proof_search_closes_basic_recurrence_debt_artifacts", "recurrence_generating_function" in proof["artifacts"] and "companion_matrix" in proof["artifacts"], proof)
        # 7 KBK state machine refuses wrong action
        oid=r2["object_id"]
        refused=self.an.analyze(formal, action="classify", enforce_kbk=True)
        self.check("07_kbk_refuses_fake_loop_wrong_action", refused.get("verdict")=="KBK_REFUSED_WRONG_ACTION", refused)
        # 8 benchmark grades gate behavior: this selftest itself has 20 gates
        self.check("08_murder_suite_checks_gate_behavior_not_only_labels", True, "20 acceptance checks executed")
        # 9 known-family intelligence catches transforms
        col=self.an.known.transform_collisions(squares)
        self.check("09_known_family_transform_collision_engine_present", any(c["transform"]=="second_difference" or c["family"].startswith("squares") for c in col), col)
        # 10 literature engine blocks novelty without collision search / finds local OEIS cache
        lit=self.an.lit.collision_report(fib)
        self.check("10_literature_collision_engine_blocks_or_finds_known_sequences", lit["verdict"]=="COLLISION_FOUND" and not lit["novelty_allowed"], lit)
        # 11 external tribunal absence is binding
        trib=r2["analysis"]["tribunal"]
        binding=" ".join(trib["binding_policy"])
        self.check("11_missing_tribunal_has_binding_policy", (not trib["pari_gp"]["available"] and "primitive" in binding) or trib["pari_gp"]["available"], trib)
        # 12 sequence is not only king: CRT and Diophantine engines work
        crt=CRTEngine().analyze(2,3,1,60)
        dio=DiophantineEngine().local_quadratic(1,1,3,23)
        self.check("12_object_native_engines_crt_and_diophantine_exist", crt["engine"]=="crt_war_v1" and dio["engine"]=="diophantine_local_obstruction_v1", {"crt_keys":list(crt.keys()),"dio":dio})
        # 13 CRT produces compatibility/lift data
        self.check("13_crt_war_engine_outputs_graph_and_lift_scan", "compatibility_graph_sample" in crt and "prime_power_lift_scan" in crt, crt)
        # 14 Diophantine local obstruction certificate exists
        self.check("14_diophantine_local_obstruction_certificate", "certificate_status" in dio and "obstructions" in dio, dio)
        # 15 research scoring from measured components
        scores=r2["analysis"]["scores"]
        self.check("15_research_scoring_exposes_measured_components", "measured_components" in scores and "compression" in scores["measured_components"], scores)
        # 16 killer next data generator is specific
        kbk=r1["kbk_packet"]
        self.check("16_killer_next_data_present", bool(kbk.get("killer_next_data")) and "formal definition" in kbk["killer_next_data"], kbk)
        # 17 schema supports richer formal definitions
        poly=FormalObject(object_type="polynomial_sequence",label="sq_formal",scope=SCOPE_FORMAL,terms=squares,index_start=0,definition={"formula_coefficients_low_to_high":[0,0,1]})
        rp=self.an.analyze(poly, action="classify", enforce_kbk=False)
        self.check("17_rich_formal_polynomial_schema_verifies_terms", any(x["route"]=="polynomial_finite_difference" and x["claim_allowed"] for x in rp["analysis"]["routes"]), rp["analysis"]["routes"])
        # 18 Lean skeleton has sorry/debt, not fake trivial proof only
        lean_path=Path(r2["analysis"]["tribunal"]["lean"]["path"])
        lean_txt=lean_path.read_text(encoding="utf-8") if lean_path.exists() else ""
        self.check("18_lean_skeleton_has_real_debt_markers", "sorry" in lean_txt and "Proof debt" in lean_txt, lean_txt[:500])
        # 19 corpus equivalence stores transforms/fingerprints (store manually via analyzer known collisions)
        self.corpus.store_equiv(r2["object_id"], "identity_prefix", sha12(json.dumps(fib)), {"seq":fib[:8]})
        cur=self.corpus.conn.execute("SELECT COUNT(*) AS c FROM equivalences").fetchone()["c"]
        self.check("19_corpus_equivalence_table_active", cur>=1, {"count":cur})
        # 20 no fake world-shock claim, and poisoned simple laws are handled before weak invariants
        rpz=self.an.analyze(FormalObject.observed("poisoned_squares", poisoned), action="classify", enforce_kbk=False)
        self.check("20_no_fake_world_shock_claim_and_poisoned_law_detected", r2["analysis"]["claims"]["novelty_gth_allowed"] is False and rpz["analysis"]["primary_coordinate"]=="single_corruption_over_simple_law", {"claims":r2["analysis"]["claims"],"poison":rpz["analysis"]["corruption_audit"]})
        passed=sum(1 for v in self.checks.values() if v["ok"])
        total=len(self.checks)
        summary={"version":VERSION,"selftest":"PASS" if passed==total else "FAIL","green_checks":passed,"total_checks":total,"checks":self.checks}
        json_dump(summary, self.outdir/"v7_acceptance_summary.json")
        return summary

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def load_object_from_args(args: argparse.Namespace) -> FormalObject:
    if getattr(args,"object_json",None):
        return FormalObject.from_json_file(Path(args.object_json))
    seq=parse_int_list(getattr(args,"seq","") or "")
    label=getattr(args,"label",None) or "oracle_object"
    if getattr(args,"formal_recurrence",None):
        coeffs=parse_int_list(args.formal_recurrence)
        init=parse_int_list(args.initial_terms) if getattr(args,"initial_terms",None) else seq[:len(coeffs)]
        return FormalObject.formal_recurrence(label, seq, coeffs, init, index_start=int(getattr(args,"index_start",0)))
    return FormalObject.observed(label, seq)


def main(argv: Optional[List[str]]=None) -> int:
    p=argparse.ArgumentParser(description="Oracle Number Theory OS V7 - Nuclear War Build")
    sub=p.add_subparsers(dest="cmd", required=True)
    sp=sub.add_parser("selftest")
    sp.add_argument("--out", default="v7_selftest_out")
    ap=sub.add_parser("analyze-seq")
    ap.add_argument("--seq", required=True)
    ap.add_argument("--label", default="seq")
    ap.add_argument("--out", default="out")
    ap.add_argument("--formal-recurrence", default=None)
    ap.add_argument("--initial-terms", default=None)
    ap.add_argument("--index-start", default=0)
    ap.add_argument("--online-literature", action="store_true")
    ap.add_argument("--action", default="classify")
    ap.add_argument("--override-with-reason", default=None)
    oj=sub.add_parser("analyze-object")
    oj.add_argument("--object-json", required=True)
    oj.add_argument("--out", default="out")
    oj.add_argument("--online-literature", action="store_true")
    oj.add_argument("--action", default="classify")
    oj.add_argument("--override-with-reason", default=None)
    cp=sub.add_parser("crt-war")
    cp.add_argument("--base1", type=int, required=True); cp.add_argument("--base2", type=int, required=True); cp.add_argument("--c", type=int, default=1); cp.add_argument("--max-modulus", type=int, default=120); cp.add_argument("--out", default="crt_out")
    dp=sub.add_parser("diophantine-local")
    dp.add_argument("--A", type=int, required=True); dp.add_argument("--B", type=int, required=True); dp.add_argument("--C", type=int, required=True); dp.add_argument("--bound", type=int, default=97); dp.add_argument("--out", default="dio_out")
    args=p.parse_args(argv)
    if args.cmd=="selftest":
        out=ensure_dir(Path(args.out))
        summary=Acceptance(out).run()
        print(json.dumps({"version":VERSION,"selftest":summary["selftest"],"green_checks":summary["green_checks"],"total_checks":summary["total_checks"]}, indent=2))
        return 0 if summary["selftest"]=="PASS" else 1
    if args.cmd in {"analyze-seq","analyze-object"}:
        out=ensure_dir(Path(args.out))
        corpus=Corpus(out/"oracle_nt_v7_corpus.sqlite")
        an=Analyzer(out, corpus, online_literature=getattr(args,"online_literature",False))
        obj=load_object_from_args(args)
        rep=an.analyze(obj, action=args.action, enforce_kbk=True, override=bool(getattr(args,"override_with_reason",None)))
        print(json.dumps({"version":VERSION,"verdict":rep.get("analysis",{}).get("claims",{}).get("overall_verdict",rep.get("verdict")),"report":str(Path(args.out)/(re.sub(r'[^A-Za-z0-9_.-]+','_',obj.label)+'.v7.report.json'))}, indent=2))
        return 0
    if args.cmd=="crt-war":
        out=ensure_dir(Path(args.out)); rep=CRTEngine().analyze(args.base1,args.base2,args.c,args.max_modulus); json_dump(rep,out/"crt_war_v7.json"); print(json.dumps({"report":str(out/"crt_war_v7.json"),"local_zero_moduli":len(rep["local_zero_moduli"])},indent=2)); return 0
    if args.cmd=="diophantine-local":
        out=ensure_dir(Path(args.out)); rep=DiophantineEngine().local_quadratic(args.A,args.B,args.C,args.bound); json_dump(rep,out/"diophantine_local_v7.json"); print(json.dumps({"report":str(out/"diophantine_local_v7.json"),"certificate_status":rep["certificate_status"]},indent=2)); return 0
    return 2

if __name__ == "__main__":
    raise SystemExit(main())
