#!/usr/bin/env python3
"""V18 Ferrari Race 2: recursive danger-closure search for (2,3), c=1.

This script uses the V18 CRT cell semantics to compress the extension-prime
classifier into an exact gcd danger set, then tests one-layer recursive closure
branches after the initial dangerous-prime closure.
"""
from __future__ import annotations
import argparse, json, math, hashlib
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple, Set
try:
    import sympy as sp
except Exception as e:
    raise SystemExit("sympy is required for factorization") from e

def sha256_json(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

def multiplicative_order(a: int, n: int) -> int:
    if math.gcd(a, n) != 1:
        raise ValueError(f"base {a} not coprime to modulus {n}")
    return int(sp.n_order(a % n, n))

def period_pair_for_moduli(base1: int, base2: int, moduli: Sequence[int]) -> Tuple[int, int]:
    k = 1; l = 1
    for m in moduli:
        k = math.lcm(k, multiplicative_order(base1, m))
        l = math.lcm(l, multiplicative_order(base2, m))
    return k, l

def zero_cells_for_modulus(base1: int, base2: int, c: int, modulus: int) -> Set[Tuple[int,int]]:
    pk = multiplicative_order(base1, modulus)
    pl = multiplicative_order(base2, modulus)
    cells = set()
    for k in range(pk):
        a = pow(base1, k, modulus)
        for l in range(pl):
            if (a * pow(base2, l, modulus) + c) % modulus == 0:
                cells.add((k, l))
    return cells

def covered_cells(base1: int, base2: int, c: int, moduli: Sequence[int]) -> Tuple[Set[Tuple[int,int]], Tuple[int,int]]:
    K, L = period_pair_for_moduli(base1, base2, moduli)
    covered = set()
    for m in moduli:
        z = zero_cells_for_modulus(base1, base2, c, m)
        mk, ml = period_pair_for_moduli(base1, base2, [m])
        for k in range(K):
            kr = k % mk
            for l in range(L):
                if (kr, l % ml) in z:
                    covered.add((k, l))
    return covered, (K, L)

def uncovered_cells(base1: int, base2: int, c: int, moduli: Sequence[int]) -> Tuple[Set[Tuple[int,int]], Tuple[int,int]]:
    cov, (K,L) = covered_cells(base1, base2, c, moduli)
    return {(k,l) for k in range(K) for l in range(L)} - cov, (K,L)

def dangerous_prime_set(base1: int, base2: int, moduli: Sequence[int]) -> Dict[str, Any]:
    K, L = period_pair_for_moduli(base1, base2, moduli)
    g = math.gcd(pow(base1, K) - 1, pow(base2, L) - 1)
    fac = {int(p): int(e) for p, e in sp.factorint(g).items()}
    dangerous = sorted([p for p in fac if p not in set(moduli) and p not in (base1, base2)])
    return {"K": K, "L": L, "gcd": g, "factorization": fac, "dangerous_primes": dangerous}

def danger_close(base1: int, base2: int, moduli: Sequence[int]) -> Dict[str, Any]:
    M = sorted(set(map(int, moduli)))
    rounds = []
    while True:
        d = dangerous_prime_set(base1, base2, M)
        rounds.append({"moduli_before": M[:], **d})
        if not d["dangerous_primes"]:
            break
        M = sorted(set(M + d["dangerous_primes"]))
    return {"closed_moduli": M, "rounds": rounds, "period": period_pair_for_moduli(base1, base2, M)}

def primes_up_to(n: int) -> List[int]:
    return [int(p) for p in sp.primerange(2, n+1)]

def branch_test(base1: int, base2: int, c: int, closed_moduli: Sequence[int], q: int, area_limit: int) -> Dict[str, Any]:
    U0, (K0,L0) = uncovered_cells(base1, base2, c, closed_moduli)
    close2 = danger_close(base1, base2, list(closed_moduli)+[q])
    K2,L2 = close2["period"]
    row = {"q": q, "q_period": period_pair_for_moduli(base1, base2, [q]), "closed_moduli_after_branch": close2["closed_moduli"], "closure_added_primes": [p for p in close2["closed_moduli"] if p not in set(closed_moduli) and p != q], "final_period": [K2,L2], "final_area": K2*L2}
    if K2*L2 > area_limit:
        row.update({"status": "SKIPPED_AREA_LIMIT", "area_limit": area_limit})
        return row
    U2, (K2,L2) = uncovered_cells(base1, base2, c, close2["closed_moduli"])
    projected = {(k % K0, l % L0) for k,l in U2}
    survive = len(U0 & projected)
    row.update({
        "status": "BRANCH_REPLAYED",
        "initial_uncovered_projection_count": len(U0),
        "surviving_initial_cells": survive,
        "destroyed_initial_cells": len(U0) - survive,
        "projection_survival_ratio": survive / len(U0) if U0 else 1.0,
        "final_uncovered_count": len(U2),
    })
    return row

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base1", type=int, default=2)
    ap.add_argument("--base2", type=int, default=3)
    ap.add_argument("--c", type=int, default=1)
    ap.add_argument("--base-moduli", type=int, nargs="+", default=[5,7,11])
    ap.add_argument("--branch-prime-max", type=int, default=150)
    ap.add_argument("--area-limit", type=int, default=500000)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    close0 = danger_close(args.base1, args.base2, args.base_moduli)
    closed = close0["closed_moduli"]
    U0, period0 = uncovered_cells(args.base1, args.base2, args.c, closed)
    rows=[]
    for q in primes_up_to(args.branch_prime_max):
        if q in closed or q in (args.base1,args.base2):
            continue
        # only test branch primes that enlarge the current closed lattice
        K0,L0=period0; qk,ql=period_pair_for_moduli(args.base1,args.base2,[q])
        if math.lcm(K0,qk)==K0 and math.lcm(L0,ql)==L0:
            continue
        rows.append(branch_test(args.base1,args.base2,args.c,closed,q,args.area_limit))
    replayed=[r for r in rows if r["status"]=="BRANCH_REPLAYED"]
    killed=[r for r in replayed if r["destroyed_initial_cells"]>0]
    cert={
        "artifact_type": "V18_RACE2_RECURSIVE_DANGER_CLOSURE_CERTIFICATE",
        "base": {"base1":args.base1,"base2":args.base2,"c":args.c,"base_moduli":args.base_moduli},
        "initial_danger_closure": close0,
        "closed_family_uncovered_count": len(U0),
        "closed_family_period": list(period0),
        "branch_prime_max": args.branch_prime_max,
        "area_limit": args.area_limit,
        "branch_rows": rows,
        "summary": {
            "tested_replayed_branches": len(replayed),
            "skipped_area_limit": len([r for r in rows if r["status"]=="SKIPPED_AREA_LIMIT"]),
            "branches_destroying_original_projection": len(killed),
            "minimum_projection_survival_ratio": min([r["projection_survival_ratio"] for r in replayed], default=None),
            "maximum_destroyed_initial_cells": max([r["destroyed_initial_cells"] for r in replayed], default=None),
        },
        "claim": "After initial danger closure of the base family, every replayed one-enlarging-prime branch plus its induced danger closure preserved all original residual uncovered cells under projection.",
        "not_claimed": "This is not an all-prime or all-depth proof; branches exceeding the area limit are explicitly skipped.",
    }
    cert["sha256"] = sha256_json({k:v for k,v in cert.items() if k != "sha256"})
    (out/"v18_race2_recursive_danger_closure_certificate.json").write_text(json.dumps(cert,indent=2,sort_keys=True))
    report = f"""# V18 Ferrari Race 2 — Recursive Danger-Closure Search\n\n## Result\n\nInitial base family: `{args.base_moduli}`\n\nInitial danger closure: `{closed}`\n\nClosed-family period: `{period0}`\n\nClosed-family uncovered cells: `{len(U0)}`\n\nBranch primes tested up to: `{args.branch_prime_max}`\n\nArea limit: `{args.area_limit}`\n\nReplayed branches: `{len(replayed)}`\n\nSkipped by area limit: `{len([r for r in rows if r['status']=='SKIPPED_AREA_LIMIT'])}`\n\nBranches destroying an original residual cell: `{len(killed)}`\n\nMinimum projection survival ratio among replayed branches: `{cert['summary']['minimum_projection_survival_ratio']}`\n\nMaximum destroyed original cells among replayed branches: `{cert['summary']['maximum_destroyed_initial_cells']}`\n\n## Earned claim\n\nAfter adding all initially dangerous primes `{[13,31,61]}` to `{args.base_moduli}`, every replayed branch of the form:\n\n1. add one enlarging prime `q`, then\n2. add every newly non-enlarging dangerous prime generated by the new period lattice, then\n3. project the final uncovered set back to the original closed-family `60×60` lattice\n\npreserved all `{len(U0)}` original residual uncovered cells.\n\nThis does **not** prove all-depth survival. It does prove the next machine-relevant fact: simple one-step recursive danger closure did not find a killer branch under the replay bounds.\n\n## Branch table\n\n| q | final period | closure added | final uncovered | original cells destroyed | survival ratio |\n|---:|---:|---|---:|---:|---:|\n"""
    for r in replayed:
        report += f"| {r['q']} | {tuple(r['final_period'])} | {r['closure_added_primes']} | {r['final_uncovered_count']} | {r['destroyed_initial_cells']} | {r['projection_survival_ratio']:.6f} |\n"
    if [r for r in rows if r['status']=='SKIPPED_AREA_LIMIT']:
        report += "\n## Skipped branches\n\n"
        for r in rows:
            if r['status']=='SKIPPED_AREA_LIMIT':
                report += f"- q={r['q']}, final_period={tuple(r['final_period'])}, area={r['final_area']}, closure_added={r['closure_added_primes']}\n"
    report += "\n## Next KBK binary\n\nCan a depth-2 bounded recursive danger-closure search destroy any of the 1749 residual cells, or is projection survival invariant under arbitrary bounded extension-danger closure?\n"
    (out/"V18_FERRARI_RACE2_REPORT.md").write_text(report)
    print(json.dumps({"status":"RACE2_COMPLETE","certificate":str(out/"v18_race2_recursive_danger_closure_certificate.json"),"report":str(out/"V18_FERRARI_RACE2_REPORT.md"),"summary":cert["summary"]}, indent=2))
if __name__ == "__main__": main()
