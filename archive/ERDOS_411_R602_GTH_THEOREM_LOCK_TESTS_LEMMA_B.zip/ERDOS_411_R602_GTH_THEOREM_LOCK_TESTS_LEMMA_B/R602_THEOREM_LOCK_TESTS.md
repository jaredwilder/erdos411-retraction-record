# R602 — GTH Theorem-Lock Tests for Lemma B

## Target

Lock Lemma B:

```text
odd(C2)/phi(odd(C2)) < 8/3
```

This is equivalent to:

```text
phi(C2)/C2 > 3/16
```

because `C2` is even.

## Chamber

```text
p <= 20,000,000
p ≡ 7 mod 8
prime tested: 317,668
strict underflows: 5,277
```

## Exact pass/fail

```text
odd-damage failures:       0
Lemma B gap failures:      0
```

## Forbidden-signature reduction

A failure requires odd prime divisors of `C2` whose product damage reaches:

```text
product(q/(q-1)) >= 8/3
```

Python enumerated minimal forbidden signatures among small odd primes.

```text
minimal forbidden signatures length <= 6: 10
forbidden signature hits in chamber:      0
```

## Worst observed odd damage

```text
p:                 13218407
odd damage:        2.516798782927305
target ceiling:    2.6666666666666665
odd primes:        (3, 5, 7, 11, 23, 2161, 275309)
factor C2:         {2: 2, 3: 1, 5: 1, 7: 1, 11: 2, 23: 1, 2161: 1, 275309: 1}
gapB:              124227860805180
```

## Weakest phi ratio

```text
p:                 13218407
phi(C2)/C2:        0.19866506746258308
target floor:      0.1875
odd damage:        2.516798782927305
odd primes:        (3, 5, 7, 11, 23, 2161, 275309)
factor C2:         {2: 2, 3: 1, 5: 1, 7: 1, 11: 2, 23: 1, 2161: 1, 275309: 1}
```

## Top observed near-misses

```json
[
  {
    "p": 13218407,
    "odd_damage": 2.516798782927305,
    "odd_primes": [
      3,
      5,
      7,
      11,
      23,
      2161,
      275309
    ]
  },
  {
    "p": 16831247,
    "odd_damage": 2.4087154297238116,
    "odd_primes": [
      3,
      5,
      7,
      11,
      977,
      249818951
    ]
  },
  {
    "p": 5476607,
    "odd_damage": 2.2373864066377895,
    "odd_primes": [
      3,
      5,
      11,
      13,
      743,
      18711031
    ]
  },
  {
    "p": 5233727,
    "odd_damage": 2.2133685657332225,
    "odd_primes": [
      3,
      5,
      11,
      19,
      61,
      4338427
    ]
  },
  {
    "p": 3928247,
    "odd_damage": 2.1914062504008567,
    "odd_primes": [
      3,
      5,
      11,
      17,
      5466810067
    ]
  },
  {
    "p": 10121687,
    "odd_damage": 2.088942307959475,
    "odd_primes": [
      3,
      5,
      11,
      79,
      7818853541
    ]
  },
  {
    "p": 13734527,
    "odd_damage": 2.063312652359418,
    "odd_primes": [
      3,
      5,
      11,
      2539,
      448031911
    ]
  },
  {
    "p": 7541087,
    "odd_damage": 2.062500000066185,
    "odd_primes": [
      3,
      5,
      11,
      31162741199
    ]
  },
  {
    "p": 6104927,
    "odd_damage": 2.0554763259684874,
    "odd_primes": [
      3,
      5,
      13,
      131,
      239,
      2033429
    ]
  },
  {
    "p": 7675727,
    "odd_damage": 2.019346604130977,
    "odd_primes": [
      3,
      5,
      37,
      41,
      61,
      181,
      234343
    ]
  }
]
```

## GTH

The theorem lock is now a finite forbidden-signature theorem:

```text
No minimal forbidden odd-prime damage signature divides odd(C2).
```

In the full shock chamber, Python found zero forbidden signatures and zero Lemma B failures.
