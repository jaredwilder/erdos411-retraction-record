# V18 Ferrari Race 7: Nonunit Tight-Cell Analysis After Unit Purge

## Verdict

```text
NONUNIT_TIGHT_CELLS_EXIST_AND_SURVIVE_ACTUAL_Q_DANGER_CLOSURE
```

## Active Binary

```text
After removing the universal unit cell (0,0), do any nonunit tight cells remain under Race-4/Race-5 replay families, and can they be destroyed by actual q-danger closure?
```

## Result

```json
{
  "race4_nonunit_tight_cells_found": 2,
  "race4_nonunit_tight_cells": [
    [
      20,
      20
    ],
    [
      40,
      40
    ]
  ],
  "nonunit_cells_follow_diagonal_20_multiple_pattern": true,
  "race5_nonunit_cell_branch_tests": 34,
  "race5_destroyed_nonunit_tests": 0,
  "min_surviving_lift_count_race5": 2,
  "max_surviving_lift_count_race5": 49,
  "surviving_counts_by_cell": {
    "(20, 20)": {
      "min": 2,
      "max": 49,
      "tests": 17
    },
    "(40, 40)": {
      "min": 2,
      "max": 49,
      "tests": 17
    }
  },
  "surviving_counts_by_q3": {
    "19": {
      "min": 9,
      "max": 9,
      "tests": 2
    },
    "29": {
      "min": 49,
      "max": 49,
      "tests": 2
    },
    "37": {
      "min": 9,
      "max": 9,
      "tests": 2
    },
    "43": {
      "min": 49,
      "max": 49,
      "tests": 2
    },
    "71": {
      "min": 49,
      "max": 49,
      "tests": 2
    },
    "73": {
      "min": 3,
      "max": 3,
      "tests": 2
    },
    "97": {
      "min": 2,
      "max": 2,
      "tests": 2
    },
    "101": {
      "min": 25,
      "max": 25,
      "tests": 2
    },
    "109": {
      "min": 27,
      "max": 27,
      "tests": 2
    },
    "113": {
      "min": 49,
      "max": 49,
      "tests": 2
    },
    "151": {
      "min": 5,
      "max": 5,
      "tests": 2
    },
    "181": {
      "min": 9,
      "max": 9,
      "tests": 2
    },
    "193": {
      "min": 4,
      "max": 4,
      "tests": 2
    },
    "211": {
      "min": 49,
      "max": 49,
      "tests": 2
    },
    "257": {
      "min": 30,
      "max": 30,
      "tests": 2
    },
    "271": {
      "min": 9,
      "max": 9,
      "tests": 2
    },
    "281": {
      "min": 49,
      "max": 49,
      "tests": 2
    }
  }
}
```

## Earned Statement

After removing the universal unit cell, Race4/Race5 still contain nonunit tight cells, specifically diagonal classes (20,20) and (40,40). Across replayed Race5 q-danger branches, none are destroyed; the minimum surviving lift count remains at least 1.

## Why This Matters

Race 6 correctly killed the unit-cell illusion. Race 7 checks whether anything remains after that kill.

Something remains: the nonunit diagonal cells `(20,20)` and `(40,40)` appear as Race4/Race5 tight cells, and actual replayed q-danger branches did not destroy them.

This is now the thing to care about. Not random branch counts. Not the unit cell. The live mathematical target is the diagonal nonunit tight-cell pair.

## Next KBK Binary

```text
Can diagonal nonunit tight cells (20,20) and (40,40) be explained by a mod-20/order-lattice symmetry, or can an adversarial q3 branch outside current bounds destroy them?
```

## Artifacts

- `race7_nonunit_tight_cell_analysis_certificate.json`
- `race7_referee_forge_packet.json`
- `race7_nonunit_branch_rows.csv`
