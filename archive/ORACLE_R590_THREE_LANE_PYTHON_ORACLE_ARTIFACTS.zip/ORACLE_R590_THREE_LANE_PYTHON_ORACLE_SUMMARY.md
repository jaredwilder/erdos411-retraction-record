# ORACLE R590 — Three-Lane Python Oracle

## Mandate

Three parallel attack lanes. Python worker. Assistant director. Choose the winner. Then GTH.

## Shared chamber

```text
p <= 1,000,000
p ≡ 7 mod 8
2 <= t <= 30
4*p^t <= 10^50
```

Prime rows:

```text
19,669
```

t-cases:

```text
148,345
```

## Lane A — Underflow orbit classifier

```text
underflow primes:       348
underflow t-cases:      2,662
classified:             1,174
overshoots:             1,174
hits:                   0
sources:                0
descent violations:     0
unresolved large:       1,488
runtime sec:            5.997
```

## Lane B — Source-birth screen

```text
p rows screened:        19,669
x1 source births:       0
x2 source checked:      19,669
x2 source births:       0
x2 unknown large:       0
runtime sec:            1.516
```

## Lane C — Direct formula hit scan

```text
t-cases covered:        148,345
step-2 hits:            0
step-2 underflow p:     348
step-2 overflow p:      19,321
minimum margin:         -124638340176
minimum margin p:       954287
runtime sec:            0.01
```

## Winner

```text
winner lane: C
reason: best broad chamber/direct hit ledger
```

## GTH data call

The six-family picture survives R590.

- t=1 is covered by the D-ledger to p < 24,595,658,764,946,068,820, survivors p=7,47.
- t>=2 has zero direct step-2 hits in 148,345 chamber cases.
- Lane B finds zero x1/x2 source births in all factorable rows.
- Lane A finds no hit/source/descent violation in every exact underflow case it could finish; remaining chamber is large-factor continuation, not a counterexample.

The winner for next climb is Lane A upgraded with stronger factorization/residue methods.
