from __future__ import annotations
import math, re
from fractions import Fraction
from typing import List, Optional, Dict, Any, Tuple

def parse_ints(s: str) -> List[int]:
    if not s: return []
    return [int(t.strip()) for t in re.split(r'[,\s]+', s.strip()) if t.strip()]

def primes_upto(n:int)->List[int]:
    if n<2: return []
    sieve=[True]*(n+1); sieve[0]=sieve[1]=False
    for p in range(2,int(n**0.5)+1):
        if sieve[p]:
            for q in range(p*p,n+1,p): sieve[q]=False
    return [i for i,v in enumerate(sieve) if v]

def factor(n:int)->Dict[int,int]:
    n=abs(n); out={}; d=2
    while d*d<=n:
        while n%d==0:
            out[d]=out.get(d,0)+1; n//=d
        d+=1 if d==2 else 2
    if n>1: out[n]=out.get(n,0)+1
    return out

def finite_differences(seq:List[int], levels:int=20)->List[List[int]]:
    rows=[seq[:]]; cur=seq[:]
    for _ in range(levels):
        if len(cur)<=1: break
        cur=[cur[i+1]-cur[i] for i in range(len(cur)-1)]
        rows.append(cur)
    return rows

def polynomial_profile(seq:List[int])->Dict[str,Any]:
    n=len(seq); rows=finite_differences(seq, max(0,n-1))
    for deg,row in enumerate(rows[1:], start=1):
        if row and len(set(row))==1:
            # high-degree interpolation is a fallback warning, not an invariant
            safe_degree=max(1,(n-4)//2)
            risk=(len(row)<3 or deg>safe_degree)
            return {"detected":True,"degree":deg,"constant_row_length":len(row),"terms":n,"interpolation_risk":risk,"verdict":"HIGH_DEGREE_POLYNOMIAL_INTERPOLATION_RISK" if risk else "LOW_RISK"}
    return {"detected":False,"interpolation_risk":False,"terms":n}

def eval_poly_low(coeffs:List[int], n:int)->int:
    return sum(int(c)*(n**i) for i,c in enumerate(coeffs))

def binom(n:int,k:int)->int:
    return math.comb(n,k) if 0<=k<=n else 0

def newton_coefficients(seq:List[int])->Optional[List[int]]:
    prof=polynomial_profile(seq)
    if not prof.get('detected') or prof.get('interpolation_risk'): return None
    rows=finite_differences(seq, prof['degree'])
    return [rows[i][0] for i in range(prof['degree']+1)]

def eval_newton(coeffs:List[int], n:int)->int:
    return sum(c*binom(n,i) for i,c in enumerate(coeffs))

def solve_linear(A:List[List[Fraction]], b:List[Fraction])->Optional[List[Fraction]]:
    if not A: return None
    m=len(A); n=len(A[0]); M=[row[:] + [b[i]] for i,row in enumerate(A)]
    r=0; piv=[]
    for c in range(n):
        pivrow=next((i for i in range(r,m) if M[i][c]!=0), None)
        if pivrow is None: continue
        M[r],M[pivrow]=M[pivrow],M[r]
        div=M[r][c]; M[r]=[x/div for x in M[r]]
        for i in range(m):
            if i!=r and M[i][c]!=0:
                f=M[i][c]; M[i]=[M[i][j]-f*M[r][j] for j in range(n+1)]
        piv.append(c); r+=1
        if r==m: break
    for row in M:
        if all(row[c]==0 for c in range(n)) and row[-1]!=0: return None
    if len(piv)<n: return None
    sol=[Fraction(0) for _ in range(n)]
    for i,c in enumerate(piv[:n]): sol[c]=M[i][-1]
    return sol

def find_recurrence(seq:List[int], max_order:int=8)->Optional[Dict[str,Any]]:
    N=len(seq)
    for d in range(1,min(max_order,N//2)+1):
        A=[]; b=[]
        for n in range(d,N):
            A.append([Fraction(seq[n-i-1]) for i in range(d)]); b.append(Fraction(seq[n]))
        sol=solve_linear(A,b)
        if sol is None: continue
        if all(sum(sol[i]*seq[n-i-1] for i in range(d))==seq[n] for n in range(d,N)):
            risk=(N<2*d+4 or d>=N//3)
            return {"order":d,"coefficients":[str(x) for x in sol],"integer_coefficients":all(x.denominator==1 for x in sol),"interpolation_risk":risk,"margin_terms":N-2*d}
    return None

def gen_recurrence(coeffs:List[int], initial:List[int], length:int)->List[int]:
    out=initial[:]; d=len(coeffs)
    while len(out)<length:
        out.append(sum(coeffs[i]*out[-i-1] for i in range(d)))
    return out[:length]

def parse_valid_for(s: str)->Optional[int]:
    if not isinstance(s,str): return None
    m=re.fullmatch(r'\s*n\s*>=\s*(-?\d+)\s*', s)
    return int(m.group(1)) if m else None

def recurrence_gf(coeffs:List[int], initial:List[int])->Dict[str,Any]:
    den=[1]+[-c for c in coeffs]
    d=len(coeffs); num=[]
    for n in range(d):
        val=initial[n] if n<len(initial) else 0
        for j in range(1,min(n,d)+1): val-=coeffs[j-1]*(initial[n-j] if n-j<len(initial) else 0)
        num.append(val)
    return {"numerator_coefficients":num,"denominator_coefficients":den,"claim":"ordinary generating function P(x)/Q(x) for this supplied recurrence definition"}

def companion_matrix(coeffs:List[int])->List[List[int]]:
    d=len(coeffs)
    return [coeffs[:]] + [[1 if j==i-1 else 0 for j in range(d)] for i in range(1,d)] if d else []
