from __future__ import annotations
from typing import List, Dict, Any, Optional
from math import gcd, lcm
from .mathutils import eval_poly_low, parse_valid_for, recurrence_gf, companion_matrix

def _hash_fields(cert:Dict[str,Any])->Dict[str,Any]:
    return {k:v for k,v in cert.items() if k not in {'replay_passed','failure','certificate_scope','checked_theorem_indices','checked_indices','coverage_summary'}}

def recurrence_certificate(coeffs:List[int], initial:List[int], index_start:int, valid_for:str, terms:List[int], object_hash:str|None=None, claim_hash:str|None=None)->Dict[str,Any]:
    cert={'type':'RECURRENCE_REPLAY_CERTIFICATE','claim_id':'recurrence_definition_conformance','claim_proves':'supplied terms conform to supplied recurrence over legal checked index range only','does_not_prove':['minimality','novelty','strong divisibility','primitive divisors','formal Lean proof','OEIS/literature identity'],'object_hash':object_hash,'claim_hash':claim_hash,'coefficients':coeffs,'initial_terms':initial,'index_start':index_start,'valid_for':valid_for,'terms':terms,'gf':recurrence_gf(coeffs,initial),'companion_matrix':companion_matrix(coeffs)}
    cert.update(verify_recurrence_certificate(cert)); return cert

def verify_recurrence_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    required={'type','coefficients','initial_terms','index_start','valid_for','terms'}
    if cert.get('type')!='RECURRENCE_REPLAY_CERTIFICATE': return {'replay_passed':False,'failure':'wrong_type'}
    if not required.issubset(cert): return {'replay_passed':False,'failure':'missing_fields'}
    vf=parse_valid_for(cert.get('valid_for'))
    if vf is None: return {'replay_passed':False,'failure':'invalid_valid_for'}
    coeffs=[int(x) for x in cert['coefficients']]; init=[int(x) for x in cert['initial_terms']]; terms=[int(x) for x in cert['terms']]; index_start=int(cert['index_start'])
    d=len(coeffs)
    if len(init)<d: return {'replay_passed':False,'failure':'insufficient_initial_terms'}
    for i,t in enumerate(terms[:len(init)]):
        if t!=init[i]: return {'replay_passed':False,'failure':'initial_terms_mismatch','position':i}
    checked=[]
    for pos in range(d,len(terms)):
        theorem_n=index_start+pos
        if theorem_n < vf: continue
        lhs=terms[pos]; rhs=sum(coeffs[i]*terms[pos-i-1] for i in range(d))
        if lhs!=rhs: return {'replay_passed':False,'failure':'recurrence_mismatch','position':pos,'theorem_n':theorem_n,'lhs':lhs,'rhs':rhs}
        checked.append(theorem_n)
    if not checked: return {'replay_passed':False,'failure':'no_terms_in_valid_for_range_checked','valid_for_min':vf,'max_observed_index':index_start+len(terms)-1}
    return {'replay_passed':True,'checked_theorem_indices':checked,'certificate_scope':'PREFIX_CONFORMANCE_CERTIFICATE'}

def polynomial_certificate(coeffs_low:List[int], index_start:int, terms:List[int], object_hash:str|None=None, claim_hash:str|None=None)->Dict[str,Any]:
    cert={'type':'POLYNOMIAL_REPLAY_CERTIFICATE','claim_id':'polynomial_definition_conformance','claim_proves':'supplied terms conform to supplied polynomial formula at stated index_start only','does_not_prove':['novelty','minimal formula','formal Lean proof','OEIS/literature identity'],'object_hash':object_hash,'claim_hash':claim_hash,'coefficients_low_to_high':coeffs_low,'index_start':index_start,'terms':terms}
    cert.update(verify_polynomial_certificate(cert)); return cert

def verify_polynomial_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    if cert.get('type')!='POLYNOMIAL_REPLAY_CERTIFICATE': return {'replay_passed':False,'failure':'wrong_type'}
    required={'type','coefficients_low_to_high','index_start','terms'}
    if not required.issubset(cert): return {'replay_passed':False,'failure':'missing_fields'}
    coeffs=[int(x) for x in cert['coefficients_low_to_high']]; idx=int(cert['index_start']); terms=[int(x) for x in cert['terms']]
    for pos,t in enumerate(terms):
        n=idx+pos; val=eval_poly_low(coeffs,n)
        if val!=t: return {'replay_passed':False,'failure':'polynomial_mismatch','position':pos,'n':n,'expected':val,'got':t}
    return {'replay_passed':True,'checked_indices':[idx+i for i in range(len(terms))],'certificate_scope':'PREFIX_CONFORMANCE_CERTIFICATE'}

def multiplicative_order(a:int,m:int,limit:int=10000)->Optional[int]:
    if gcd(a,m)!=1: return None
    x=1%m
    for k in range(1,limit+1):
        x=(x*a)%m
        if x==1: return k
    return None

def crt_torus_noncover_certificate(base1:int, base2:int, c:int, moduli:List[int], max_torus:int=5000)->Dict[str,Any]:
    usable=[]; periods=[]
    for m in moduli:
        if m<=1 or gcd(base1,m)!=1 or gcd(base2,m)!=1: continue
        o1=multiplicative_order(base1,m); o2=multiplicative_order(base2,m)
        if o1 and o2:
            usable.append(int(m)); periods.append((o1,o2))
    if not usable:
        return {'type':'CRT_FINITE_TORUS_NONCOVER_CERTIFICATE','replay_passed':False,'failure':'no_usable_coprime_moduli','base1':base1,'base2':base2,'c':c,'moduli':moduli}
    K=1; L=1
    for o1,o2 in periods:
        K=lcm(K,o1); L=lcm(L,o2)
        if K*L>max_torus:
            return {'type':'CRT_FINITE_TORUS_NONCOVER_CERTIFICATE','replay_passed':False,'failure':'torus_too_large','partial_K':K,'partial_L':L,'max_torus':max_torus,'moduli':usable}
    uncovered=[]; covered=0; witness={}
    for k in range(K):
        for l in range(L):
            hit=[]
            for m in usable:
                if (pow(base1,k,m)*pow(base2,l,m)+c)%m==0:
                    hit.append(m)
            if hit:
                covered+=1
            else:
                uncovered.append([k,l])
            if len(hit)>0 and len(witness)<20: witness[f'{k},{l}']=hit[:]
    cert={'type':'CRT_FINITE_TORUS_NONCOVER_CERTIFICATE','claim_id':'finite_torus_noncover','claim_proves':'for the finite exponent torus induced by the listed moduli, the local zero congruences do not cover every exponent cell','does_not_prove':['no infinite covering system','prime existence','nonexistence of a different modulus set cover'],'base1':base1,'base2':base2,'c':c,'moduli':usable,'periods':periods,'torus_dimensions':{'K':K,'L':L,'cells':K*L},'uncovered_cells':uncovered[:200],'uncovered_count':len(uncovered),'covered_count':covered,'sample_covered_witnesses':witness}
    cert.update(verify_crt_torus_certificate(cert)); return cert

def verify_crt_torus_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    if cert.get('type')!='CRT_FINITE_TORUS_NONCOVER_CERTIFICATE': return {'replay_passed':False,'failure':'wrong_type'}
    for key in ['base1','base2','c','moduli','torus_dimensions','uncovered_count','covered_count']:
        if key not in cert: return {'replay_passed':False,'failure':'missing_'+key}
    b1=int(cert['base1']); b2=int(cert['base2']); c=int(cert['c']); mods=[int(x) for x in cert['moduli']]
    K=int(cert['torus_dimensions']['K']); L=int(cert['torus_dimensions']['L'])
    if K<1 or L<1 or not mods: return {'replay_passed':False,'failure':'empty_torus_or_moduli'}
    uncovered=[]; covered=0
    for k in range(K):
        for l in range(L):
            if any((pow(b1,k,m)*pow(b2,l,m)+c)%m==0 for m in mods): covered+=1
            else: uncovered.append([k,l])
    if len(uncovered)!=int(cert['uncovered_count']) or covered!=int(cert['covered_count']):
        return {'replay_passed':False,'failure':'coverage_count_mismatch','expected_uncovered':len(uncovered),'got_uncovered':cert['uncovered_count'],'expected_covered':covered,'got_covered':cert['covered_count']}
    if int(cert['uncovered_count'])==0:
        return {'replay_passed':False,'failure':'not_a_noncover_certificate_full_coverage'}
    # Require listed sample uncovered cells to actually be uncovered.
    listed=cert.get('uncovered_cells',[])
    for cell in listed[:200]:
        k,l=int(cell[0]),int(cell[1])
        if any((pow(b1,k,m)*pow(b2,l,m)+c)%m==0 for m in mods): return {'replay_passed':False,'failure':'listed_uncovered_cell_is_covered','cell':[k,l]}
    return {'replay_passed':True,'certificate_scope':'FINITE_TORUS_NONCOVER_CERTIFICATE','verified_uncovered_count':len(uncovered),'verified_covered_count':covered}

# Backward compatible but intentionally weaker alias retired from V14 main path.
def crt_uncovered_certificate(base1:int, base2:int, c:int, moduli:List[int], search_bound:int=64)->Dict[str,Any]:
    return crt_torus_noncover_certificate(base1,base2,c,moduli,max_torus=max(1000,search_bound*search_bound))

def diophantine_local_certificate(A:int,B:int,C:int,modulus:int)->Dict[str,Any]:
    solutions=[]
    for x in range(modulus):
        for y in range(modulus):
            if (A*x*x+B*y*y-C)%modulus==0: solutions.append([x,y])
    cert={'type':'LOCAL_OBSTRUCTION_CERTIFICATE','claim_id':'quadratic_local_obstruction','claim_proves':'no residue pair solves A*x^2+B*y^2=C modulo m' if not solutions else 'local solutions exist modulo m','does_not_prove':['global solubility over integers','rational solubility','higher genus facts'],'A':A,'B':B,'C':C,'modulus':modulus,'solutions':solutions[:50],'solution_count':len(solutions)}
    cert.update(verify_diophantine_certificate(cert)); return cert

def verify_diophantine_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    if cert.get('type')!='LOCAL_OBSTRUCTION_CERTIFICATE': return {'replay_passed':False,'failure':'wrong_type'}
    for key in ['A','B','C','modulus','solution_count']:
        if key not in cert: return {'replay_passed':False,'failure':'missing_'+key}
    A=int(cert['A']); B=int(cert['B']); C=int(cert['C']); m=int(cert['modulus'])
    if m<2: return {'replay_passed':False,'failure':'bad_modulus'}
    count=0
    for x in range(m):
        for y in range(m):
            if (A*x*x+B*y*y-C)%m==0: count+=1
    if count!=int(cert['solution_count']): return {'replay_passed':False,'failure':'solution_count_mismatch','expected':count,'got':cert['solution_count']}
    return {'replay_passed':True,'certificate_scope':'QUADRATIC_LOCAL_ONLY','obstruction':count==0}

def verify_any_certificate(cert:Dict[str,Any], expected_type:Optional[str]=None, expected_object_hash:Optional[str]=None, expected_claim_hash:Optional[str]=None)->Dict[str,Any]:
    if expected_type and cert.get('type')!=expected_type: return {'replay_passed':False,'failure':'wrong_artifact_type','expected':expected_type,'got':cert.get('type')}
    if expected_object_hash and cert.get('object_hash')!=expected_object_hash: return {'replay_passed':False,'failure':'object_hash_mismatch','expected':expected_object_hash,'got':cert.get('object_hash')}
    if expected_claim_hash and cert.get('claim_hash')!=expected_claim_hash: return {'replay_passed':False,'failure':'claim_hash_mismatch','expected':expected_claim_hash,'got':cert.get('claim_hash')}
    t=cert.get('type')
    if t=='RECURRENCE_REPLAY_CERTIFICATE': return verify_recurrence_certificate(cert)
    if t=='POLYNOMIAL_REPLAY_CERTIFICATE': return verify_polynomial_certificate(cert)
    if t=='CRT_FINITE_TORUS_NONCOVER_CERTIFICATE': return verify_crt_torus_certificate(cert)
    if t=='CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE': return {'replay_passed':False,'failure':'retired_weak_certificate_type_not_accepted_in_v14'}
    if t=='LOCAL_OBSTRUCTION_CERTIFICATE': return verify_diophantine_certificate(cert)
    return {'replay_passed':False,'failure':'unknown_certificate_type'}
