VERSION='14.0.0-oracle-discovery-pressure-core'
