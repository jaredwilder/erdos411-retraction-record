from __future__ import annotations
from typing import List, Dict, Any
from .mathutils import factor

def strong_divisibility_plan(family:Dict[str,Any])->Dict[str,Any]:
    if family.get('family') not in {'Fibonacci','Lucas'}:
        return {'status':'NOT_CANONICAL_LUCAS_FAMILY','proof_object':None}
    proof={
        'type':'STRONG_DIVISIBILITY_STRUCTURED_PROOF_OBJECT',
        'family':family.get('family'),
        'canonical_index_start':family.get('canonical_index_start'),
        'claim_target':'gcd(U_m,U_n)=U_gcd(m,n) under canonical Lucas_U/Fibonacci hypotheses',
        'coordinate_warning':'observed indices are normalized to canonical family metadata before theorem routing',
        'lemmas':[
            {'id':'addition_formula','statement':'Lucas/Fibonacci addition identity expresses U_{a+b} from lower-index terms'},
            {'id':'euclidean_step','statement':'gcd(U_m,U_n)=gcd(U_n,U_{m mod n}) using addition formula and coprimality hypotheses'},
            {'id':'rank_of_apparition','statement':'p divides U_n iff rank r_p divides n for primitive primes outside exceptional cases'},
            {'id':'euclidean_descent','statement':'repeat euclidean_step to reduce gcd on terms to gcd on indices'}],
        'machine_check_status':'PROOF_OBJECT_STRUCTURED_NOT_LEAN_VERIFIED',
        'does_not_prove':['Lean-checked proof','general Lehmer cases without hypotheses']}
    return {'status':'STRUCTURED_PROOF_OBJECT_EMITTED_NOT_FORMALLY_VERIFIED','proof_object':proof}

def primitive_divisor_audit(seq:List[int], family:Dict[str,Any])->Dict[str,Any]:
    if family.get('family') not in {'Fibonacci','Lucas'}: return {'status':'NOT_CANONICAL_LUCAS_FAMILY'}
    prior=set(); exceptions=[]; audits=[]
    start=int(family.get('canonical_index_start',0)); known=set(family.get('known_exception_set',[1,2,6,12]))
    for pos,val in enumerate(seq):
        n=start+pos
        if val in (0,1,-1):
            prior |= set(factor(val).keys());
            audits.append({'theorem_index':n,'value':val,'unit_or_zero':True,'primitive_prime_factors':[],'allowed_exception':n in known})
            continue
        ps=set(factor(val).keys()); prim=sorted(ps-prior)
        audits.append({'theorem_index':n,'value':val,'prime_factors':sorted(ps),'primitive_prime_factors':prim,'allowed_exception':(not prim and n in known)})
        if not prim and n not in known: exceptions.append({'theorem_index':n,'value':val,'reason':'no primitive divisor outside known exception set'})
        prior |= ps
    return {'status':'CANONICAL_PREFIX_AUDIT_COMPLETE','theorem_family':family.get('primitive_divisor_family'),'known_exception_set':sorted(known),'unexpected_exceptions':exceptions,'audits':audits,'claim_proves':'prefix-level primitive divisor audit under canonical family indexing','does_not_prove':['BHV general theorem','all-index primitive divisor result without external proof']}
