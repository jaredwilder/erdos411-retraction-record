from __future__ import annotations
import json, urllib.request, urllib.parse
from pathlib import Path
from typing import List, Dict, Any
class KnownFamilies:
    def classify(self, seq:List[int])->List[Dict[str,Any]]:
        out=[]; n=len(seq)
        fib=[0,1]
        while len(fib)<max(n+10,40): fib.append(fib[-1]+fib[-2])
        for start in range(0,10):
            if seq==fib[start:start+n]: out.append({'family':'Fibonacci','oeis':'A000045','canonical_index_start':start,'canonical_terms':[0,1],'canonical_recurrence':[1,1],'strong_divisibility_known':True,'primitive_divisor_family':'Lucas_U','known_exception_set':[1,2,6,12]}); break
        luc=[2,1]
        while len(luc)<max(n+10,40): luc.append(luc[-1]+luc[-2])
        for start in range(0,10):
            if seq==luc[start:start+n]: out.append({'family':'Lucas','oeis':'A000032','canonical_index_start':start,'canonical_recurrence':[1,1],'primitive_divisor_family':'Lucas_V'}); break
        if seq==[i*i for i in range(n)]: out.append({'family':'Squares_n0','oeis':'A000290','canonical_index_start':0})
        if seq==[(i+1)**2 for i in range(n)]: out.append({'family':'Squares_n1','oeis':'A000290','canonical_index_start':1})
        if seq==[2**i for i in range(n)]: out.append({'family':'PowersOf2','oeis':'A000079','canonical_index_start':0,'canonical_recurrence':[2]})
        if n>=3 and len(set(seq))==1: out.append({'family':'Constant'})
        return out
class Literature:
    def __init__(self, cache:Path, online:bool=False):
        self.cache=cache; self.online=online; cache.parent.mkdir(parents=True,exist_ok=True)
        if not cache.exists():
            cache.write_text(json.dumps({
                'A000045':[0,1,1,2,3,5,8,13,21,34,55,89,144],
                'A000032':[2,1,3,4,7,11,18,29,47,76],
                'A000290':[0,1,4,9,16,25,36,49,64,81],
                'A000079':[1,2,4,8,16,32,64,128]
            },indent=2))
        self.db=json.loads(cache.read_text())
    def exact_prefix(self, seq:List[int])->Dict[str,Any]:
        matches=[]
        for oid,terms in self.db.items():
            for start in range(0,max(1,min(10,len(terms)-len(seq)+1))):
                if seq==terms[start:start+len(seq)]: matches.append({'oeis':oid,'start':start,'match_type':'LOCAL_EXACT_PREFIX'})
        return {'exact_collision':bool(matches),'matches':matches,'matched_oeis':matches[0]['oeis'] if matches else None,'search_complete':not self.online}
    def query_online_exact(self, seq:List[int])->Dict[str,Any]:
        if not self.online: return self.exact_prefix(seq)|{'online':'disabled'}
        q=','.join(map(str,seq[:12])); url='https://oeis.org/search?fmt=json&q='+urllib.parse.quote(q)
        try:
            data=json.loads(urllib.request.urlopen(url,timeout=8).read().decode())
            verified=[]; adjacent=[]
            for r in data.get('results',[])[:10]:
                raw=r.get('data','')
                try: terms=[int(x.strip()) for x in raw.split(',') if x.strip()][:max(len(seq),20)]
                except Exception: terms=[]
                ok=False
                for start in range(0,max(1,min(10,len(terms)-len(seq)+1))):
                    if seq==terms[start:start+len(seq)]: ok=True; break
                if ok: verified.append({'oeis':'A%06d'%int(r.get('number',0)),'name':r.get('name',''),'start':start,'match_type':'ONLINE_EXACT_TERMS_VERIFIED'})
                else: adjacent.append({'oeis':'A%06d'%int(r.get('number',0)),'name':r.get('name',''),'match_type':'ADJACENT_TEXT_MATCH_NOT_PREFIX_VERIFIED'})
            return {'exact_collision':bool(verified),'matches':verified,'adjacent':adjacent,'matched_oeis':verified[0]['oeis'] if verified else None,'search_complete':True,'online':'queried_terms_verified'}
        except Exception as e:
            base=self.exact_prefix(seq); base.update({'online':'error','error':str(e),'search_complete':False}); return base
