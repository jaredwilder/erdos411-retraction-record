from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Dict, Any, Tuple
import json
SCOPE_PREFIX='FINITE_PREFIX'; SCOPE_GENERATED='GENERATED_EXTENSION'; SCOPE_FORMAL='FORMAL_DEFINITION'; SCOPE_LITERATURE='LITERATURE_VERIFIED'
@dataclass
class FormalObject:
    object_type:str
    label:str
    scope:str=SCOPE_PREFIX
    terms:List[int]=field(default_factory=list)
    index_start:int=0
    definition:Dict[str,Any]=field(default_factory=dict)
    source:Dict[str,Any]=field(default_factory=dict)
    @staticmethod
    def observed(label:str, terms:List[int])->'FormalObject': return FormalObject('observed_sequence',label,SCOPE_PREFIX,terms)
    @staticmethod
    def from_json(path:Path)->'FormalObject':
        d=json.loads(path.read_text())
        return FormalObject(**d)
    def to_dict(self): return asdict(self)
    def payload_for_receipt(self)->Dict[str,Any]:
        d=asdict(self); d['source']={}; return d
    def validate_schema(self)->Tuple[bool,List[str]]:
        e=[]
        if self.scope not in {SCOPE_PREFIX,SCOPE_GENERATED,SCOPE_FORMAL,SCOPE_LITERATURE}: e.append('invalid scope')
        if self.object_type=='observed_sequence' and self.scope!=SCOPE_PREFIX: e.append('observed_sequence must be FINITE_PREFIX')
        if self.scope in {SCOPE_FORMAL,SCOPE_LITERATURE} and not self.definition: e.append('formal/literature scope requires definition')
        if self.object_type=='recurrence_sequence' and self.scope in {SCOPE_FORMAL,SCOPE_LITERATURE}:
            rec=self.definition.get('recurrence',{}); init=self.definition.get('initial_terms',[])
            if not isinstance(init,list) or not init: e.append('recurrence requires initial_terms')
            if not isinstance(rec.get('coefficients'),list) or not rec.get('coefficients'): e.append('recurrence requires coefficients')
            if rec.get('valid_for') is None: e.append('recurrence requires valid_for')
        if self.object_type=='polynomial_sequence' and self.scope in {SCOPE_FORMAL,SCOPE_LITERATURE}:
            if 'formula_coefficients_low_to_high' not in self.definition: e.append('polynomial requires formula_coefficients_low_to_high')
        return (not e,e)
