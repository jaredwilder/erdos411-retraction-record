from __future__ import annotations
from typing import Any, Dict, List, Tuple
from .certificates import verify_any_certificate, crt_torus_noncover_certificate

ALLOWED_DELTAS = {
    "NEW_OBSTRUCTION",
    "NEW_CONSTRUCTION",
    "NEW_INVARIANT",
    "NEW_DICHOTOMY",
    "NEW_COUNTEREXAMPLE",
    "NEW_FORMAL_LEMMA_TARGET",
    "NEW_SEARCH_SPACE_REDUCTION",
    "NEW_CERTIFICATE_SCHEMA",
    "NEW_COORDINATE_SYSTEM",
    "ROUTE_KILL_WITH_ENUMERATED_UNTESTED_MOVES",
}

ALLOWED_ADJUDICATORS = {
    "python_enumeration",
    "sage_pari_sympy",
    "lean",
    "certificate_replay",
    "literature_search",
    "known_theorem_graph",
    "counterexample_search",
    "randomized_stress_harness",
}

VERIFIER_ONLY_PHRASES = [
    "rejects fake",
    "prevents self-attested",
    "passes selftest",
    "selftest passed",
    "hardens certificate",
    "enforces valid_for",
    "blocks local-only theorem unlock",
    "replay_passed false",
    "green_checks",
    "green checks",
]

DISCOVERY_STATUSES = {
    "VERIFIED_BUT_NO_DISCOVERY",
    "DISCOVERY_CANDIDATE_UNADJUDICATED",
    "DISCOVERY_REFUSED_SELF_ATTESTED_NOVELTY",
    "DISCOVERY_REJECTED_RESTATEMENT",
    "DISCOVERY_REJECTED_NO_PROOF_PRESSURE",
    "DISCOVERY_PROMOTED_FRONTIER_DELTA",
    "DISCOVERY_KILLED_WITH_FAILURE_ASSET",
    "DISCOVERY_ROUTE_SHIFTED",
}


def _has_text(x: Any) -> bool:
    return isinstance(x, str) and bool(x.strip())


def verify_frontier_delta(packet: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    delta = packet.get("frontier_delta", {}) or {}
    if delta.get("type") not in ALLOWED_DELTAS:
        errors.append("NO_TYPED_FRONTIER_DELTA")
    for field in ["prior_state", "new_state", "why_not_present_before", "hostile_test"]:
        if not delta.get(field):
            errors.append(f"MISSING_FRONTIER_DELTA_{field.upper()}")
    return errors


def verify_one_binary(packet: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    selected = packet.get("selected_binary")
    if not selected:
        errors.append("NO_SELECTED_BINARY")
    if isinstance(selected, list):
        errors.append("MULTIPLE_BINARIES_SELECTED")
    if "rejected_binaries" not in packet:
        errors.append("MISSING_REJECTED_BINARY_LEDGER")
    return errors


def verify_external_adjudicator(packet: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    if packet.get("external_adjudicator") not in ALLOWED_ADJUDICATORS:
        errors.append("NO_EXTERNAL_ADJUDICATOR")
    result = packet.get("adjudicator_result")
    if not result:
        errors.append("NO_ADJUDICATOR_RESULT")
    return errors


def verify_novelty(packet: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    novelty = packet.get("novelty_against_corpus", {}) or {}
    if not novelty.get("nearest_prior_result"):
        errors.append("NO_NEAREST_PRIOR_RESULT")
    try:
        overlap = float(novelty.get("overlap_score", 1.0))
    except Exception:
        overlap = 1.0
    if overlap > 0.70:
        errors.append("TOO_CLOSE_TO_PRIOR")
    if not novelty.get("new_information"):
        errors.append("NO_NEW_INFORMATION")
    if novelty.get("self_attested") is True:
        errors.append("SELF_ATTESTED_NOVELTY")
    return errors


def verify_surprise(packet: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    surprise = packet.get("surprise_certificate", {}) or {}
    for field in ["expected_baseline_output", "actual_output", "difference", "why_difference_matters", "reviewer_value"]:
        if not surprise.get(field):
            errors.append(f"MISSING_SURPRISE_{field.upper()}")
    if surprise.get("reviewer_value") in (None, "", "none", "NONE"):
        errors.append("NO_REVIEWER_VALUE")
    return errors


def verify_proof_pressure(packet: Dict[str, Any]) -> List[str]:
    errors: List[str] = []
    proof = packet.get("proof_pressure", {}) or {}
    if not (proof.get("formal_lemma_target") or proof.get("finite_reduction") or proof.get("certificate_type")):
        errors.append("NO_PROOF_PRESSURE")
    if not proof.get("missing_ingredient"):
        errors.append("NO_MISSING_INGREDIENT")
    return errors


def verify_failure_asset(packet: Dict[str, Any]) -> List[str]:
    if packet.get("round_verdict") != "KILL":
        return []
    errors: List[str] = []
    failure = packet.get("failure_asset", {}) or {}
    if not failure.get("new_constraint_learned"):
        errors.append("KILL_LEARNED_NOTHING")
    if not failure.get("routes_eliminated"):
        errors.append("KILL_ELIMINATED_NOTHING")
    if not failure.get("new_attack_suggested"):
        errors.append("KILL_DID_NOT_ROUTE")
    return errors


def reject_verifier_only_progress(summary_text: str, packet: Dict[str, Any]) -> List[str]:
    text = (summary_text or "").lower()
    verifier_language = any(p in text for p in VERIFIER_ONLY_PHRASES)
    has_delta = (packet.get("frontier_delta", {}) or {}).get("type") in ALLOWED_DELTAS
    if verifier_language and not has_delta:
        return ["VERIFIER_ONLY_NOT_DISCOVERY"]
    return []


def verify_discovery_packet(packet: Dict[str, Any], summary_text: str = "") -> Dict[str, Any]:
    errors: List[str] = []
    errors += verify_one_binary(packet)
    errors += verify_external_adjudicator(packet)
    errors += verify_frontier_delta(packet)
    errors += verify_novelty(packet)
    errors += verify_surprise(packet)
    errors += verify_proof_pressure(packet)
    errors += verify_failure_asset(packet)
    errors += reject_verifier_only_progress(summary_text, packet)

    # Round verdict consistency.
    rv = packet.get("round_verdict")
    if rv not in DISCOVERY_STATUSES:
        errors.append("INVALID_DISCOVERY_STATUS")
    if rv == "DISCOVERY_PROMOTED_FRONTIER_DELTA" and errors:
        # Do not let a packet claim promotion while failing hard gates.
        errors.append("PROMOTION_STATUS_WITH_FAILED_GATES")

    if errors:
        if errors == ["VERIFIER_ONLY_NOT_DISCOVERY"] or "NO_TYPED_FRONTIER_DELTA" in errors:
            status = "VERIFIED_BUT_NO_DISCOVERY"
        elif "SELF_ATTESTED_NOVELTY" in errors or "TOO_CLOSE_TO_PRIOR" in errors or "NO_NEAREST_PRIOR_RESULT" in errors:
            status = "DISCOVERY_REFUSED_SELF_ATTESTED_NOVELTY"
        elif "NO_PROOF_PRESSURE" in errors or "NO_MISSING_INGREDIENT" in errors:
            status = "DISCOVERY_REJECTED_NO_PROOF_PRESSURE"
        elif "NO_EXTERNAL_ADJUDICATOR" in errors or "NO_ADJUDICATOR_RESULT" in errors:
            status = "DISCOVERY_CANDIDATE_UNADJUDICATED"
        else:
            status = "DISCOVERY_PACKET_REJECTED"
        return {"status": status, "errors": sorted(set(errors))}
    return {"status": packet.get("round_verdict", "DISCOVERY_PROMOTED_FRONTIER_DELTA"), "errors": []}


def perfect_verifier_report_to_packet(verifier_report: Dict[str, Any]) -> Dict[str, Any]:
    """Intentionally wraps a verifier-only report as a non-discovery packet."""
    return {
        "source": "verifier_report",
        "verifier_summary": verifier_report,
        "round_verdict": "VERIFIED_BUT_NO_DISCOVERY",
    }


def make_crt_lift_pressure_packet(base1: int, base2: int, c: int, moduli: List[int], max_torus: int = 5000) -> Dict[str, Any]:
    cert = crt_torus_noncover_certificate(base1, base2, c, moduli, max_torus=max_torus)
    verification = verify_any_certificate(cert)
    prior = "V13 verifier can replay finite-torus noncover certificates, but finite noncover is not global lift obstruction."
    if verification.get("replay_passed") and cert.get("uncovered_count", 0) > 0:
        delta_type = "NEW_FORMAL_LEMMA_TARGET"
        new_state = "Finite torus noncover converted into explicit lift-obstruction lemma target rather than mistaken for global theorem."
        round_verdict = "DISCOVERY_PROMOTED_FRONTIER_DELTA"
        new_information = "The certificate identifies uncovered exponent cells and forces the next proof hinge: characterize when finite-torus uncovered cells persist under modulus extension/lifting."
        actual_output = f"replayed noncover over torus {cert.get('torus_dimensions')} with {cert.get('uncovered_count')} uncovered cells"
        reviewer_value = "turns a replayable finite artifact into a precise lift-theory lemma target; prevents verifier-only praise"
    else:
        delta_type = "ROUTE_KILL_WITH_ENUMERATED_UNTESTED_MOVES"
        new_state = "Candidate finite certificate failed; route shifts to modulus selection or alternate local obstruction."
        round_verdict = "DISCOVERY_KILLED_WITH_FAILURE_ASSET"
        new_information = "Failed finite certificate constrains the modulus set and forces a new modulus-selection attack."
        actual_output = f"certificate failed: {verification}"
        reviewer_value = "failure eliminates one fake CRT route and routes to a sharper modulus selector"

    packet = {
        "version": "14.0.0-oracle-discovery-pressure-core",
        "selected_binary": "Does the strongest finite CRT noncover obstruction lift into a general obstruction against global covering constructions, or is it only a finite-window artifact?",
        "rejected_binaries": [
            {"binary": "Can we make the verifier report prettier?", "rejection": "verifier polish is not frontier displacement"},
            {"binary": "Can we add more local CRT moduli randomly?", "rejection": "scatter; does not ask lift question"},
            {"binary": "Can we claim global noncover from finite noncover?", "rejection": "overclaim; needs lift condition"},
        ],
        "attack_type": delta_type,
        "external_adjudicator": "certificate_replay",
        "adjudicator_result": {"certificate": cert, "verification": verification},
        "frontier_delta": {
            "type": delta_type,
            "prior_state": prior,
            "new_state": new_state,
            "why_not_present_before": "Earlier versions verified finite certificates but did not require a lift-condition lemma target or demote the artifact to bounded evidence.",
            "hostile_test": "If the packet cannot state the lift condition it must not count as discovery, even if the certificate replays.",
        },
        "novelty_against_corpus": {
            "nearest_prior_result": "V13 CRT_FINITE_TORUS_NONCOVER_CERTIFICATE",
            "overlap_score": 0.45,
            "new_information": new_information,
            "would_previous_version_have_passed": False,
        },
        "surprise_certificate": {
            "expected_baseline_output": "certificate replay only, with no frontier delta",
            "actual_output": actual_output,
            "difference": "adds explicit lift-obstruction lemma target and rejects treating finite noncover as global proof",
            "why_difference_matters": "it converts a bounded artifact into the next theorem hinge instead of rewarding verification cleanliness",
            "reviewer_value": reviewer_value,
        },
        "proof_pressure": {
            "formal_lemma_target": "For bases b1,b2 and modulus set M, characterize conditions under which an uncovered cell in the finite exponent torus persists under modulus extension or prime-power lifting.",
            "finite_reduction": "Replay finite torus coverage; compute uncovered cells; test persistence under enlarged modulus sets.",
            "certificate_type": "CRT_FINITE_TORUS_NONCOVER_CERTIFICATE",
            "known_tools": ["certificate_replay", "python_enumeration", "known_theorem_graph"],
            "missing_ingredient": "A lift-composability theorem or counterexample showing finite noncover is only bounded evidence.",
        },
        "failure_asset": None,
        "round_verdict": round_verdict,
        "next_binary": "Do uncovered cells persist after adding the next admissible prime-power modulus, or do they disappear as finite-window artifacts?",
        "kbk_packet": {
            "required_external_adjudicator": "python_enumeration",
            "required_artifact": "CRT_LIFT_PERSISTENCE_AUDIT",
            "hostile_test_that_would_break_fake_progress": "Adding moduli without measuring uncovered-cell persistence is scatter, not KBK.",
        },
    }
    if round_verdict == "DISCOVERY_KILLED_WITH_FAILURE_ASSET":
        packet["failure_asset"] = {
            "new_constraint_learned": "selected modulus set did not produce a replayable noncover certificate",
            "routes_eliminated": ["this exact modulus set as discovery artifact"],
            "new_attack_suggested": "run modulus selection search and replay strongest candidate",
        }
    return packet
