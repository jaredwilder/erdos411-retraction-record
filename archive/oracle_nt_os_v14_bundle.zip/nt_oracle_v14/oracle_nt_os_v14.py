#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys, zipfile, os, shutil
from pathlib import Path
from oracle_nt_v14.objects import FormalObject, SCOPE_FORMAL, SCOPE_GENERATED
from oracle_nt_v14.mathutils import parse_ints, primes_upto
from oracle_nt_v14.trust import TrustAuthority
from oracle_nt_v14.literature import Literature
from oracle_nt_v14.analysis import analyze
from oracle_nt_v14.certificates import (verify_any_certificate, crt_torus_noncover_certificate, diophantine_local_certificate, recurrence_certificate, polynomial_certificate)
from oracle_nt_v14.kbk import create_requirement, continue_with_artifact, status as kbk_status
from oracle_nt_v14.discovery import (verify_discovery_packet, perfect_verifier_report_to_packet, make_crt_lift_pressure_packet)
VERSION='14.0.0-oracle-discovery-pressure-core'

def write_report(report:dict,out:Path,label:str):
    out.mkdir(parents=True,exist_ok=True)
    p=out/f'{label}.v14.report.json'; p.write_text(json.dumps(report,indent=2,sort_keys=True))
    (out/f'{label}.v14.report.md').write_text('# Oracle NT OS V14 Report\n\n```json\n'+json.dumps({'verdict':report.get('overall_verdict'),'primary_coordinate':report.get('primary_coordinate'),'claim_trust':report.get('claims',{}).get('claim_trust_summary')},indent=2)+'\n```\n')
    return p

def cmd_analyze(args):
    out=Path(args.out); trust=TrustAuthority(Path(args.trust_registry or out/'trust_registry.json')); lit=Literature(out/'oeis_cache.json', online=args.online)
    if args.object_json:
        obj=FormalObject.from_json(Path(args.object_json))
    else:
        terms=parse_ints(args.seq)
        if args.formal_recurrence:
            coeffs=parse_ints(args.formal_recurrence); init=parse_ints(args.initial_terms) if args.initial_terms else terms[:len(coeffs)]
            obj=FormalObject('recurrence_sequence',args.label,SCOPE_GENERATED,terms,0,{'initial_terms':init,'recurrence':{'coefficients':coeffs,'valid_for':args.valid_for or f'n >= {len(coeffs)}'}},{'user_definition_source':args.definition_source or 'none','status':'USER_ASSERTED_UNVERIFIED'})
        else:
            obj=FormalObject.observed(args.label, terms)
    rep=analyze(obj,out,trust,lit); path=write_report(rep,out,obj.label)
    print(json.dumps({'report':str(path),'verdict':rep.get('overall_verdict'),'primary_coordinate':rep.get('primary_coordinate'),'claim_trust':rep.get('claims',{}).get('claim_trust_summary')},indent=2))

def cmd_seal(args):
    obj=FormalObject.from_json(Path(args.object_json)); trust=TrustAuthority(Path(args.trust_registry)); rec=trust.seal_local(obj); print(json.dumps({'local_receipt':rec,'external_verified':False,'warning':'local receipt is not external definition verification and does not unlock route-grade claims'},indent=2))

def cmd_verify_cert(args):
    cert=json.loads(Path(args.certificate).read_text())
    print(json.dumps(verify_any_certificate(cert, expected_type=args.expected_type, expected_object_hash=args.expected_object_hash, expected_claim_hash=args.expected_claim_hash),indent=2,sort_keys=True))

def cmd_crt(args):
    moduli=args.moduli or [p for p in primes_upto(args.max_modulus) if args.base1%p and args.base2%p]
    cert=crt_torus_noncover_certificate(args.base1,args.base2,args.c,moduli,args.max_torus)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); p=out/'crt_torus_noncover_certificate.v14.json'; p.write_text(json.dumps(cert,indent=2,sort_keys=True)); print(json.dumps({'certificate':str(p),'verification':verify_any_certificate(cert)},indent=2))

def cmd_dio(args):
    cert=None
    for m in range(2,args.bound+1):
        c=diophantine_local_certificate(args.A,args.B,args.C,m)
        if c.get('obstruction'):
            cert=c; break
    if cert is None: cert=diophantine_local_certificate(args.A,args.B,args.C,args.bound)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); p=out/'diophantine_certificate.v14.json'; p.write_text(json.dumps(cert,indent=2,sort_keys=True)); print(json.dumps({'certificate':str(p),'verification':verify_any_certificate(cert)},indent=2))


def cmd_discovery_verify(args):
    packet=json.loads(Path(args.packet).read_text())
    summary=Path(args.summary).read_text() if args.summary else args.summary_text or ''
    print(json.dumps(verify_discovery_packet(packet, summary), indent=2, sort_keys=True))

def cmd_discovery_from_verifier(args):
    report=json.loads(Path(args.report).read_text())
    packet=perfect_verifier_report_to_packet(report)
    out=verify_discovery_packet(packet, json.dumps(report))
    print(json.dumps({'packet':packet,'discovery_verification':out}, indent=2, sort_keys=True))

def cmd_discovery_crt_lift(args):
    packet=make_crt_lift_pressure_packet(args.base1,args.base2,args.c,args.moduli,args.max_torus)
    verification=verify_discovery_packet(packet, 'crt finite noncover certificate replay with lift pressure')
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    p=out/'discovery_crt_lift_packet.v14.json'; p.write_text(json.dumps(packet, indent=2, sort_keys=True))
    print(json.dumps({'packet':str(p),'discovery_verification':verification,'status':verification.get('status')}, indent=2, sort_keys=True))

def cmd_kbk_init(args):
    create_requirement(Path(args.corpus),args.run_id,args.required_type,args.required_action,args.expected_object_hash,args.expected_claim_hash)
    print(json.dumps({'created':args.run_id,'required_type':args.required_type,'required_action':args.required_action,'expected_object_hash':args.expected_object_hash,'expected_claim_hash':args.expected_claim_hash},indent=2))

def cmd_kbk_continue(args): print(json.dumps(continue_with_artifact(Path(args.corpus),args.run_id,Path(args.artifact)),indent=2,sort_keys=True))
def cmd_kbk_status(args): print(json.dumps(kbk_status(Path(args.corpus)),indent=2,sort_keys=True))

def cmd_selftest(args):
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); checks=[]
    def ck(name, ok, detail=None): checks.append({'name':name,'passed':bool(ok),'detail':detail})
    trust=TrustAuthority(out/'trust.json'); lit=Literature(out/'oeis.json')
    # 1 OEIS term match cannot launder recurrence definition trust
    oeis_obj=FormalObject('recurrence_sequence','fib_oeis_launder',SCOPE_FORMAL,[0,1,1,2,3,5,8,13],0,{'initial_terms':[0,1],'recurrence':{'coefficients':[1,1],'valid_for':'n >= 2'}},{'oeis_id':'A000045','status':'USER_ASSERTED_UNVERIFIED'})
    rep=analyze(oeis_obj,out,trust,lit)
    ck('oeis_term_match_does_not_verify_recurrence_definition', rep['source_trust']['claim_trust']['term_identity']['grade']=='EXTERNAL_VERIFIED' and rep['source_trust']['claim_trust']['recurrence_definition']['grade']=='LOCAL_ONLY' and 'RECURRENCE_DEFINITION_CONFORMANCE_ROUTE' not in rep['claims']['allowed_route_claims'], rep['claims'])
    # 2 fake verified JSON ignored
    fake=FormalObject('recurrence_sequence','fake',SCOPE_FORMAL,[1,1,2,3,5,8],0,{'initial_terms':[1,1],'recurrence':{'coefficients':[1,1],'valid_for':'n >= 2'}},{'status':'SIGNED_PROJECT_DEFINITION_VERIFIED'})
    repf=analyze(fake,out,trust,lit); ck('user_json_cannot_self_assign_definition_trust', repf['source_trust']['claim_trust']['recurrence_definition']['grade']!='EXTERNAL_VERIFIED' and not repf['claims']['allowed_route_claims'], repf['source_trust'])
    # 3 local seal not external
    trust.seal_local(fake); repseal=analyze(fake,out,trust,lit); ck('local_seal_still_not_external_definition_trust', repseal['source_trust']['claim_trust']['recurrence_definition']['grade']=='LOCAL_ONLY' and not repseal['claims']['allowed_route_claims'], repseal['source_trust'])
    # 4 valid_for enforced
    bad=recurrence_certificate([1,1],[1,1],0,'n >= 100',[1,1,2,3,5,8]); ck('recurrence_valid_for_enforced', not bad['replay_passed'] and bad['failure']=='no_terms_in_valid_for_range_checked', bad)
    bad2=recurrence_certificate([1,1],[1,1],0,'after two',[1,1,2,3]); ck('invalid_valid_for_fails', not bad2['replay_passed'] and bad2['failure']=='invalid_valid_for', bad2)
    # 5 KBK object/claim hash bound
    obj_hash=trust.object_hash(fake); claim_hash=trust.claim_hash(fake,'recurrence_definition')
    good=recurrence_certificate([1,1],[1,1],0,'n >= 2',[1,1,2,3,5,8],obj_hash,claim_hash); goodp=out/'good_rec.json'; goodp.write_text(json.dumps(good))
    wrong=recurrence_certificate([1,1],[1,1],0,'n >= 2',[1,1,2,3,5,8],'wronghash',claim_hash); wrongp=out/'wrong_rec.json'; wrongp.write_text(json.dumps(wrong))
    corpus=out/'kbk.sqlite'; create_requirement(corpus,'r1','RECURRENCE_REPLAY_CERTIFICATE','prove recurrence conformance for exact object',obj_hash,claim_hash)
    kres_bad=continue_with_artifact(corpus,'r1',wrongp); ck('kbk_rejects_valid_cert_for_wrong_object', not kres_bad['artifact_verified'] and kres_bad['verification']['failure']=='object_hash_mismatch', kres_bad)
    kres_good=continue_with_artifact(corpus,'r1',goodp); ck('kbk_accepts_exact_bound_cert', kres_good['artifact_verified'], kres_good)
    # 6 fake replay passed rejected
    fake_art=out/'fake_art.json'; fake_art.write_text(json.dumps({'type':'RECURRENCE_REPLAY_CERTIFICATE','replay_passed':True,'object_hash':obj_hash,'claim_hash':claim_hash}))
    create_requirement(corpus,'r2','RECURRENCE_REPLAY_CERTIFICATE','reject fake artifact',obj_hash,claim_hash); kres_fake=continue_with_artifact(corpus,'r2',fake_art); ck('kbk_rejects_self_reported_fake_cert_even_with_hashes', not kres_fake['artifact_verified'], kres_fake)
    # 7 CRT torus noncover real and meaningful
    crt=crt_torus_noncover_certificate(2,3,1,[5,7,11],5000); ver=verify_any_certificate(crt); ck('crt_finite_torus_noncover_certificate_replays', crt.get('type')=='CRT_FINITE_TORUS_NONCOVER_CERTIFICATE' and ver['replay_passed'] and crt.get('uncovered_count',0)>0, {'cert':crt,'ver':ver})
    # 8 old weak CRT rejected
    old={'type':'CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE','base1':2,'base2':3,'c':1,'moduli':[5],'uncovered_pair':{'k':0,'l':0},'checks':[{'modulus':5,'k':0,'l':0,'value_mod_m':2}]}; ck('retired_weak_crt_pair_cert_rejected', not verify_any_certificate(old)['replay_passed'], verify_any_certificate(old))
    # 9 empty torus cert fails
    empty={'type':'CRT_FINITE_TORUS_NONCOVER_CERTIFICATE','base1':2,'base2':3,'c':1,'moduli':[],'torus_dimensions':{'K':1,'L':1},'uncovered_count':1,'covered_count':0}; ck('empty_torus_certificate_fails', not verify_any_certificate(empty)['replay_passed'], verify_any_certificate(empty))
    # 10 Diophantine certificate replays
    dio=diophantine_local_certificate(1,1,3,4); ck('diophantine_local_obstruction_replays', dio.get('obstruction') and verify_any_certificate(dio)['replay_passed'], dio)
    # 11 polynomial cert index_start
    poly=polynomial_certificate([0,0,1],1,[1,4,9,16]); ck('polynomial_cert_respects_index_start', poly['replay_passed'], poly)
    # 12 known family has strong/primitive routes
    fib=FormalObject.observed('fib0',[0,1,1,2,3,5,8,13,21,34]); fibr=analyze(fib,out,trust,lit)
    ck('fib0_known_family_not_interpolation', fibr['primary_coordinate']=='known_family_classification' and fibr['scores']['novelty_score']==0.0, fibr)
    ck('strong_divisibility_structured_object_for_fib', fibr['routes']['strong_divisibility']['status']=='STRUCTURED_PROOF_OBJECT_EMITTED_NOT_FORMALLY_VERIFIED', fibr['routes']['strong_divisibility'])
    ck('primitive_divisor_prefix_audit_for_fib', fibr['routes']['primitive_divisor']['status']=='CANONICAL_PREFIX_AUDIT_COMPLETE', fibr['routes']['primitive_divisor'])
    # 13 junk blocked
    junk=FormalObject.observed('sixjunk',[3,8,5,13,21,7]); jr=analyze(junk,out,trust,lit); ck('six_junk_interpolation_risk_no_gth', jr['overall_verdict']=='NO_GTH_INTERPOLATION_RISK', jr)
    # 14 claim trust split present
    ck('claim_specific_trust_map_present', set(['term_identity','recurrence_definition','formal_proof']).issubset(rep['source_trust']['claim_trust'].keys()))
    # 15 no formal proof language without Lean
    ck('no_formal_verification_without_lean', not fibr['proof_status']['formal_proof_verified'] and not fibr['proof_status']['lean_compile_attempted'], fibr['proof_status'])
    # 16 fuzz fake external source statuses do not promote definition trust
    for i,status in enumerate(['OEIS_EXACT_VERIFIED','SIGNED_PROJECT_DEFINITION_VERIFIED','LITERATURE_RECURRENCE_VERIFIED','LEAN_FORMALLY_VERIFIED','REMOTE_REPRODUCIBLE_DEFINITION_VERIFIED']):
        o=FormalObject('recurrence_sequence',f'fuzz{i}',SCOPE_FORMAL,[1,1,2,3],0,{'initial_terms':[1,1],'recurrence':{'coefficients':[1,1],'valid_for':'n >= 2'}},{'status':status})
        rr=analyze(o,out,trust,lit); ck(f'fuzz_input_status_not_definition_trust_{i}', rr['source_trust']['claim_trust']['recurrence_definition']['grade']!='EXTERNAL_VERIFIED')
    # 17 Discovery Pressure Layer: perfect verifier report is not discovery.
    perfect_v12={'version':'12.0.0','selftest':'PASS','green_checks':30,'total_checks':30,'hard_artifacts':['RECURRENCE_REPLAY_CERTIFICATE']}
    non_discovery=verify_discovery_packet(perfect_verifier_report_to_packet(perfect_v12), json.dumps(perfect_v12))
    ck('perfect_verifier_report_without_frontier_delta_is_not_discovery', non_discovery['status']=='VERIFIED_BUT_NO_DISCOVERY', non_discovery)
    # 18 one binary enforced
    multi={'selected_binary':['A','B'],'rejected_binaries':[],'external_adjudicator':'certificate_replay','adjudicator_result':{'ok':True},'frontier_delta':{'type':'NEW_OBSTRUCTION','prior_state':'p','new_state':'n','why_not_present_before':'x','hostile_test':'h'},'novelty_against_corpus':{'nearest_prior_result':'prior','overlap_score':0.1,'new_information':'info'},'surprise_certificate':{'expected_baseline_output':'a','actual_output':'b','difference':'c','why_difference_matters':'d','reviewer_value':'valuable'},'proof_pressure':{'certificate_type':'CERT','missing_ingredient':'lemma'},'round_verdict':'DISCOVERY_PROMOTED_FRONTIER_DELTA'}
    mv=verify_discovery_packet(multi); ck('discovery_rejects_multiple_binaries', 'MULTIPLE_BINARIES_SELECTED' in mv['errors'], mv)
    # 19 external adjudicator required
    noadj=dict(multi); noadj['selected_binary']='A or B'; noadj['external_adjudicator']='prose'; av=verify_discovery_packet(noadj); ck('discovery_rejects_prose_only_adjudication', 'NO_EXTERNAL_ADJUDICATOR' in av['errors'], av)
    # 20 novelty ledger rejects restatement
    restate=dict(noadj); restate['external_adjudicator']='certificate_replay'; restate['novelty_against_corpus']={'nearest_prior_result':'same as previous','overlap_score':0.95,'new_information':''}; nv=verify_discovery_packet(restate); ck('discovery_rejects_restatement_as_novelty', 'TOO_CLOSE_TO_PRIOR' in nv['errors'] and 'NO_NEW_INFORMATION' in nv['errors'], nv)
    # 21 surprise certificate required
    nosurp=dict(multi); nosurp['selected_binary']='A or B'; nosurp['surprise_certificate']={}; sv=verify_discovery_packet(nosurp); ck('discovery_rejects_no_surprise_certificate', any(e.startswith('MISSING_SURPRISE') for e in sv['errors']), sv)
    # 22 proof pressure required
    nopress=dict(multi); nopress['selected_binary']='A or B'; nopress['proof_pressure']={}; pv=verify_discovery_packet(nopress); ck('discovery_rejects_no_proof_pressure', 'NO_PROOF_PRESSURE' in pv['errors'], pv)
    # 23 kill must pay rent
    kill=dict(multi); kill['selected_binary']='A or B'; kill['round_verdict']='KILL'; kill['failure_asset']={}; kv=verify_discovery_packet(kill); ck('discovery_rejects_kill_without_failure_asset', 'KILL_LEARNED_NOTHING' in kv['errors'], kv)
    # 24 valid CRT lift pressure packet passes discovery gates
    lift=make_crt_lift_pressure_packet(2,3,1,[5,7,11],5000); lv=verify_discovery_packet(lift); ck('crt_lift_pressure_packet_promotes_frontier_delta', lv['status']=='DISCOVERY_PROMOTED_FRONTIER_DELTA' and lift['frontier_delta']['type']=='NEW_FORMAL_LEMMA_TARGET', {'verify':lv,'packet_summary':{k:lift[k] for k in ['selected_binary','round_verdict','next_binary']}})
    # 25 verifier-only language with no delta fails
    vod=verify_discovery_packet({'round_verdict':'VERIFIED_BUT_NO_DISCOVERY'}, 'selftest passed 30 green checks and rejects fake artifacts')
    ck('verifier_only_language_without_delta_rejected', vod['status']=='VERIFIED_BUT_NO_DISCOVERY', vod)

    passed=sum(c['passed'] for c in checks); result={'version':VERSION,'selftest':'PASS' if passed==len(checks) else 'FAIL','green_checks':passed,'total_checks':len(checks),'checks':checks,'hard_artifacts':['CRT_FINITE_TORUS_NONCOVER_CERTIFICATE','LOCAL_OBSTRUCTION_CERTIFICATE','RECURRENCE_REPLAY_CERTIFICATE_BOUND_TO_OBJECT_AND_CLAIM','POLYNOMIAL_REPLAY_CERTIFICATE','STRONG_DIVISIBILITY_STRUCTURED_PROOF_OBJECT','PRIMITIVE_DIVISOR_CANONICAL_PREFIX_AUDIT']}
    (out/'selftest.v14.json').write_text(json.dumps(result,indent=2,sort_keys=True)); print(json.dumps({k:result[k] for k in ['version','selftest','green_checks','total_checks','hard_artifacts']},indent=2))
    if result['selftest']!='PASS': sys.exit(1)

def main():
    ap=argparse.ArgumentParser(description='Oracle NT OS V14 hard math core')
    sub=ap.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('analyze-seq'); a.add_argument('--seq'); a.add_argument('--label',default='seq'); a.add_argument('--out',default='out_v14'); a.add_argument('--trust-registry'); a.add_argument('--formal-recurrence'); a.add_argument('--initial-terms'); a.add_argument('--definition-source'); a.add_argument('--valid-for'); a.add_argument('--object-json'); a.add_argument('--online',action='store_true'); a.set_defaults(func=cmd_analyze)
    s=sub.add_parser('seal-object'); s.add_argument('--object-json',required=True); s.add_argument('--trust-registry',required=True); s.set_defaults(func=cmd_seal)
    v=sub.add_parser('verify-cert'); v.add_argument('--certificate',required=True); v.add_argument('--expected-type'); v.add_argument('--expected-object-hash'); v.add_argument('--expected-claim-hash'); v.set_defaults(func=cmd_verify_cert)
    c=sub.add_parser('crt-war'); c.add_argument('--base1',type=int,required=True); c.add_argument('--base2',type=int,required=True); c.add_argument('--c',type=int,required=True); c.add_argument('--max-modulus',type=int,default=30); c.add_argument('--moduli',nargs='*',type=int); c.add_argument('--max-torus',type=int,default=5000); c.add_argument('--out',default='crt_v14'); c.set_defaults(func=cmd_crt)
    d=sub.add_parser('diophantine-local'); d.add_argument('--A',type=int,required=True); d.add_argument('--B',type=int,required=True); d.add_argument('--C',type=int,required=True); d.add_argument('--bound',type=int,default=97); d.add_argument('--out',default='dio_v14'); d.set_defaults(func=cmd_dio)
    k=sub.add_parser('kbk-init'); k.add_argument('--corpus',required=True); k.add_argument('--run-id',required=True); k.add_argument('--required-type',required=True); k.add_argument('--required-action',required=True); k.add_argument('--expected-object-hash'); k.add_argument('--expected-claim-hash'); k.set_defaults(func=cmd_kbk_init)
    kc=sub.add_parser('kbk-continue'); kc.add_argument('--corpus',required=True); kc.add_argument('--run-id',required=True); kc.add_argument('--artifact',required=True); kc.set_defaults(func=cmd_kbk_continue)
    ks=sub.add_parser('kbk-status'); ks.add_argument('--corpus',required=True); ks.set_defaults(func=cmd_kbk_status)
    dv=sub.add_parser('discovery-verify'); dv.add_argument('--packet',required=True); dv.add_argument('--summary'); dv.add_argument('--summary-text'); dv.set_defaults(func=cmd_discovery_verify)
    df=sub.add_parser('discovery-from-verifier'); df.add_argument('--report',required=True); df.set_defaults(func=cmd_discovery_from_verifier)
    dl=sub.add_parser('discovery-crt-lift'); dl.add_argument('--base1',type=int,required=True); dl.add_argument('--base2',type=int,required=True); dl.add_argument('--c',type=int,required=True); dl.add_argument('--moduli',nargs='+',type=int,required=True); dl.add_argument('--max-torus',type=int,default=5000); dl.add_argument('--out',default='discovery_v14'); dl.set_defaults(func=cmd_discovery_crt_lift)
    st=sub.add_parser('selftest'); st.add_argument('--out',default='v14_selftest_out'); st.set_defaults(func=cmd_selftest)
    args=ap.parse_args(); args.func(args)
if __name__=='__main__': main()
