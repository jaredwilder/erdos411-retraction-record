# Oracle NT OS V13 — Hard Math Core

V13 focuses on the V12 avoided work:

- claim-specific trust instead of object-level trust laundering
- OEIS term identity does not verify recurrence definitions
- KBK artifacts are bound to object hash and claim hash
- CRT certificate upgraded to finite-torus noncover replay
- recurrence/polynomial certificates remain narrow and explicit
- strong divisibility emits a structured proof object, not fake proof
- primitive divisor emits canonical prefix audit, not all-index theorem closure

Run:

```bash
python oracle_nt_os_v13.py selftest --out v13_selftest_out
```

CRT finite torus noncover:

```bash
python oracle_nt_os_v13.py crt-war --base1 2 --base2 3 --c 1 --max-modulus 30 --out crt_v13
```

Diophantine local obstruction:

```bash
python oracle_nt_os_v13.py diophantine-local --A 1 --B 1 --C 3 --bound 97 --out dio_v13
```
