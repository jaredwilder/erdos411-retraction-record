# Oracle NT OS V14 — Discovery Pressure Core

V14 adds the Wallbreaker layer on top of the V13 verifier core.

The V13 verifier answered: **is the artifact fake?**

V14 adds the second gate: **did the frontier move?**

A run that only reports green checks, replayed certificates, or hardened trust is now rejected as:

```text
VERIFIED_BUT_NO_DISCOVERY
```

## Core rule

```text
NO FRONTIER DELTA = NO DISCOVERY
NO EXTERNAL ADJUDICATOR = NO MATHEMATICAL CLAIM
NO ONE BINARY = NO KBK
NO NOVELTY LEDGER = NO NOVELTY
NO PROOF PRESSURE = NO THEOREM ROUTE
NO FAILURE ASSET = NO KILL
```

## New commands

### Selftest

```bash
python oracle_nt_os_v14.py selftest --out v14_selftest_out
```

Expected:

```json
{
  "version": "14.0.0-oracle-discovery-pressure-core",
  "selftest": "PASS",
  "green_checks": 33,
  "total_checks": 33
}
```

### Reject verifier-only progress

```bash
python oracle_nt_os_v14.py discovery-from-verifier --report some_v13_or_v12_report.json
```

A perfect verifier report with no frontier delta is not discovery.

### Verify a discovery packet

```bash
python oracle_nt_os_v14.py discovery-verify --packet packet.json
```

### First Wallbreaker CRT lift-pressure run

```bash
python oracle_nt_os_v14.py discovery-crt-lift \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --moduli 5 7 11 \
  --out discovery_v14
```

This emits and verifies a discovery packet for the binary:

```text
Does the strongest finite CRT noncover obstruction lift into a general obstruction against global covering constructions, or is it only a finite-window artifact?
```

## What V14 rejects that V13/V12 could still praise

- verifier selftest reports with no frontier delta
- multiple binaries posing as KBK
- prose-only adjudication
- novelty without nearest-prior comparison
- surprise-free reports
- proof-pressure-free theorem routes
- KILL verdicts that do not pay rent
- verifier-only language masquerading as discovery

## What a valid V14 discovery packet requires

- selected binary
- rejected binary ledger
- external adjudicator
- adjudicator result
- typed frontier delta
- novelty ledger against corpus
- surprise certificate
- proof-pressure object
- failure asset on KILL
- next KBK binary

## Status

This does not claim to have shocked the world. It prevents the machine from confusing verification cleanliness with discovery.

V14 is the first build that mechanically rejects “perfect verifier, no frontier movement.”
