# Oracle Number Theory OS V4

V4 is a hardening release. Its purpose is not to make prettier reports. Its purpose is to stop the system from rewarding weak mathematical coordinates just because they predict.

## What V4 closes from the V3 audit

- **Invariant hierarchy engine**: polynomial finite-difference, geometric, recurrence, rational generating function, divisibility, p-adic, and modular coordinates are ranked by explanatory primacy, not only detection.
- **Squares regression fixed**: squares now top-rank as `polynomial_finite_difference`; generic recurrence is demoted as predictive but non-primary.
- **Binary-to-action compiler**: a five-round KBK run executes different attack types instead of rerunning the same analysis in costume.
- **Theorem eligibility checkers**: finite difference, recurrence, Lucas/Zsigmondy/BHV-style eligibility, LTE, and strong divisibility routes expose pass/fail/open conditions.
- **Binding tribunal**: internal adjudication from factorization and coordinate dominance mutates hypothesis scores.
- **External tribunal handoffs**: Sage, PARI/GP, and Lean files are emitted every run; Sage/PARI/Lean are executed if installed.
- **Real Lean skeleton direction**: emitted files contain theorem-shaped proof debts, not `True := trivial` as the main claim.
- **Adversarial falsifier**: prefix stability, holdout prediction, constructed trap resistance, transform stability, and extension counterexample pressure.
- **Persistent corpus**: SQLite stores objects, invariants, killed routes, KBK packets, theorem registry, and equivalence fingerprints.
- **Object registry**: supports `sequence`, `crt_cover`, `diophantine_square`, and raw objects.
- **CRT lab V4**: adds finite torus coverage, saturation curve, uncovered classes, and prime-power lift scan.
- **Benchmark gauntlet**: includes constructed traps, especially the square-vs-recurrence failure that killed V3's judgment.

## Quick start

```bash
python oracle_nt_os_v4.py selftest
```

Expected result:

```json
{
  "selftest": "PASS",
  "version": "4.0.0-oracle-nt-os"
}
```

Analyze a sequence:

```bash
python oracle_nt_os_v4.py analyze-seq \
  --seq "0,1,4,9,16,25,36,49,64,81" \
  --label squares \
  --out out
```

Five-round KBK run:

```bash
python oracle_nt_os_v4.py run \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144,233" \
  --label fib \
  --rounds 5 \
  --out out
```

CRT covering lab:

```bash
python oracle_nt_os_v4.py crt-lab \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --max-modulus 200 \
  --out crt_out
```

Object ingest:

```bash
python oracle_nt_os_v4.py ingest \
  --object '{"kind":"crt_cover","base1":2,"base2":3,"c":1,"max_modulus":200}' \
  --label eg_like \
  --out out
```

Corpus list:

```bash
python oracle_nt_os_v4.py corpus-list --db out/oracle_nt_v4_corpus.sqlite
```

## Main commands

| Command | Purpose |
|---|---|
| `selftest` | Runs benchmark gauntlet plus regression checks. |
| `benchmark` | Runs adversarial benchmark suite. |
| `analyze-seq` | Single Oracle round for an integer sequence. |
| `run` | Multi-round KBK run with changing action types. |
| `crt-lab` | Covering-sieve finite torus and lift scan. |
| `ingest` | Intake for object registry payloads. |
| `corpus-list` | Inspect stored corpus objects. |

## Honest status

V4 is materially stronger than V3 because it fixes the biggest conceptual bug: prediction is not understanding. It still is not a replacement for Sage, PARI/GP, Lean, or a human number theorist. It is a disciplined orchestration and discovery-pressure system that makes the next mathematical attack sharper.

The next frontier after V4 is deeper first-class object support: elliptic curves, number fields, modular forms, and sieve problems with theorem-specific engines rather than generic routing.
