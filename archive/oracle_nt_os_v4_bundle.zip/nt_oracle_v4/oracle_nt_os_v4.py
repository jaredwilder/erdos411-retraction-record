#!/usr/bin/env python3
"""
oracle_nt_os_v4.py

Oracle Number Theory OS V4: hard-edged arithmetic discovery infrastructure.

V4 is a hardening release over V3. It is designed to punish pretty-but-weak
pattern recognition and force best-coordinate mathematical state.

Core changes:
  * Invariant hierarchy: ranks coordinate systems by explanatory primacy, not only prediction.
  * Binary-to-action compiler: every KBK round executes a different attack type.
  * Theorem eligibility checkers: finite difference, recurrence, Lucas/Zsigmondy, LTE,
    strong divisibility, CRT covering routes.
  * Binding tribunal: internal/Sage/PARI results mutate hypothesis state.
  * Real Lean skeletons: theorem statements with definitions and proof debts, never `True`.
  * Object registry: sequence, recurrence, crt_cover, diophantine_square, raw JSON.
  * Literature/theorem registry: local collision and theorem-route memory.
  * Adversarial benchmark gauntlet: constructed traps, not random fluff.
  * GTH hardening: no fire when a superior coordinate exists or eligibility is untested.

Run:
  python oracle_nt_os_v4.py selftest
  python oracle_nt_os_v4.py benchmark --out out
  python oracle_nt_os_v4.py analyze-seq --seq "0,1,4,9,16,25,36" --label squares --out out
  python oracle_nt_os_v4.py run --seq "1,1,2,3,5,8,13,21,34,55,89" --rounds 5 --label fib --out out
  python oracle_nt_os_v4.py crt-lab --base1 2 --base2 3 --c 1 --max-modulus 200 --out out
  python oracle_nt_os_v4.py ingest --object '{"kind":"crt_cover","base1":2,"base2":3,"c":1}' --label eg_like --out out
"""
from __future__ import annotations

import argparse
import dataclasses
import fractions
import hashlib
import itertools
import json
import math
import os
import random
import re
import shutil
import sqlite3
import statistics
import subprocess
import sys
import textwrap
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import sympy as sp  # type: ignore
except Exception:  # pragma: no cover
    sp = None

Fraction = fractions.Fraction
VERSION = "4.0.0-oracle-nt-os"

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def stable_json(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, default=str)


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def parse_int_sequence(raw: str) -> List[int]:
    found = re.findall(r"[-+]?\d+", raw or "")
    if not found:
        raise ValueError("No integers found in sequence input")
    return [int(x) for x in found]


def gcd_list(values: Iterable[int]) -> int:
    g = 0
    for v in values:
        g = math.gcd(g, abs(int(v)))
    return g


def lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return abs(a // math.gcd(a, b) * b)


def lcm_list(values: Iterable[int]) -> int:
    out = 1
    for v in values:
        out = lcm(out, int(v))
    return out


def differences(seq: Sequence[int], order: int = 1) -> List[int]:
    cur = [int(x) for x in seq]
    for _ in range(order):
        cur = [cur[i + 1] - cur[i] for i in range(len(cur) - 1)]
    return cur


def finite_difference_table(seq: Sequence[int], max_order: Optional[int] = None) -> List[List[int]]:
    if max_order is None:
        max_order = max(0, len(seq) - 1)
    table = [[int(x) for x in seq]]
    cur = list(table[0])
    for _ in range(max_order):
        if len(cur) <= 1:
            break
        cur = differences(cur)
        table.append(cur)
    return table


def valuation(n: int, p: int) -> Optional[int]:
    if p <= 1:
        raise ValueError("p must be > 1")
    if n == 0:
        return None
    n = abs(int(n))
    out = 0
    while n % p == 0:
        out += 1
        n //= p
    return out


def is_square(n: int) -> bool:
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def primes_upto(n: int) -> List[int]:
    if n < 2:
        return []
    sieve = bytearray(b"\x01") * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for p in range(2, math.isqrt(n) + 1):
        if sieve[p]:
            sieve[p*p:n+1:p] = b"\x00" * (((n - p*p) // p) + 1)
    return [i for i in range(n + 1) if sieve[i]]


def factorint(n: int) -> Dict[int, int]:
    n = int(n)
    if n == 0:
        return {0: 1}
    sign: Dict[int, int] = {}
    if n < 0:
        sign[-1] = 1
        n = -n
    if n == 1:
        return sign
    if sp is not None:
        try:
            return {**sign, **{int(k): int(v) for k, v in sp.factorint(n).items()}}
        except Exception:
            pass
    out = dict(sign)
    while n % 2 == 0:
        out[2] = out.get(2, 0) + 1
        n //= 2
    d = 3
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def modular_period(seq: Sequence[int], modulus: int, max_period: Optional[int] = None) -> Optional[int]:
    if modulus <= 1 or len(seq) < 2:
        return None
    residues = [int(x) % modulus for x in seq]
    n = len(residues)
    if max_period is None:
        max_period = max(1, n // 2)
    for p in range(1, max_period + 1):
        if all(residues[i] == residues[i + p] for i in range(n - p)):
            return p
    return None


def solve_linear_fraction(A: List[List[Fraction]], b: List[Fraction]) -> Optional[List[Fraction]]:
    n = len(A)
    if n == 0 or len(b) != n or any(len(r) != n for r in A):
        return None
    M = [list(A[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            return None
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0:
                f = M[r][col]
                M[r] = [M[r][c] - f * M[col][c] for c in range(n + 1)]
    return [M[i][-1] for i in range(n)]


def recurrence_guess(seq: Sequence[int], max_order: Optional[int] = None) -> Optional[Dict[str, Any]]:
    vals = [Fraction(int(x)) for x in seq]
    n = len(vals)
    if n < 4:
        return None
    if max_order is None:
        max_order = min(12, max(1, n // 2))
    for r in range(1, max_order + 1):
        rows: List[List[Fraction]] = []
        rhs: List[Fraction] = []
        for i in range(r, n):
            rows.append([vals[i - j] for j in range(1, r + 1)])
            rhs.append(vals[i])
        for start in range(0, max(1, len(rows) - r + 1)):
            sol = solve_linear_fraction(rows[start:start+r], rhs[start:start+r])
            if sol is None:
                continue
            if all(sum(sol[j] * rows[i][j] for j in range(r)) == rhs[i] for i in range(len(rows))):
                pred = recurrence_predict(seq[:r], sol, n)
                return {
                    "order": r,
                    "coefficients": [str(c) for c in sol],
                    "coefficients_fraction": sol,
                    "exact_on_input": all(pred[i] == vals[i] for i in range(n)),
                    "characteristic": companion_characteristic(sol),
                }
    return None


def recurrence_predict(seed: Sequence[int], coeffs: Sequence[Fraction], total: int) -> List[Fraction]:
    r = len(coeffs)
    out = [Fraction(int(x)) for x in seed]
    while len(out) < total:
        out.append(sum(coeffs[j] * out[-j-1] for j in range(r)))
    return out


def polynomial_fit(seq: Sequence[int], max_degree: Optional[int] = None) -> Optional[Dict[str, Any]]:
    n = len(seq)
    if n < 3:
        return None
    if max_degree is None:
        max_degree = min(10, n - 2)
    table = finite_difference_table(seq, max_degree)
    for d, row in enumerate(table):
        if row and len(set(row)) == 1:
            poly_s = None
            coeffs: List[str] = []
            if sp is not None:
                x = sp.symbols("n")
                pts = [(i, int(seq[i])) for i in range(min(n, max(d + 2, 2)))]
                try:
                    poly = sp.interpolate(pts, x).expand()
                    if all(int(poly.subs(x, i)) == int(seq[i]) for i in range(n)):
                        poly_s = str(poly)
                        coeffs = [str(sp.expand(poly).coeff(x, k)) for k in range(d + 1)]
                except Exception:
                    pass
            return {
                "degree": d,
                "polynomial": poly_s,
                "coefficients_low_to_high": coeffs,
                "constant_difference": int(row[0]),
                "finite_difference_certificate": {"order": d, "row_start": row[:10]},
            }
    return None


def rational_generating_function(seq: Sequence[int], coeffs: Sequence[Fraction]) -> Dict[str, Any]:
    r = len(coeffs)
    P: List[Fraction] = []
    for k in range(r):
        val = Fraction(int(seq[k]))
        for j in range(1, k + 1):
            val -= coeffs[j-1] * int(seq[k-j])
        P.append(val)
    Q = [Fraction(1)] + [-c for c in coeffs]
    return {"form": "A(x)=P(x)/Q(x)", "P_coeffs": [str(x) for x in P], "Q_coeffs": [str(x) for x in Q]}


def companion_characteristic(coeffs: Sequence[Fraction]) -> str:
    if sp is None:
        r = len(coeffs)
        return f"x^{r} - ({coeffs})"
    x = sp.symbols("x")
    r = len(coeffs)
    poly = x**r - sum(sp.Rational(c.numerator, c.denominator) * x**(r - i - 1) for i, c in enumerate(coeffs))
    return str(sp.factor(poly))


def sequence_fingerprint(seq: Sequence[int]) -> Dict[str, str]:
    s = [int(x) for x in seq]
    def h(v: Sequence[int]) -> str:
        return sha256_text(",".join(map(str, v)))[:20]
    out = {"raw": h(s)}
    if len(s) > 1:
        out["diff1"] = h(differences(s, 1))
        out["shift1"] = h(s[1:])
        out["reverse"] = h(list(reversed(s)))
    if len(s) > 2:
        out["diff2"] = h(differences(s, 2))
    # affine-normalized first difference if possible
    g = gcd_list(s)
    if g > 1:
        out["content_normalized"] = h([x // g for x in s])
    return out

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class NTObject:
    object_id: str
    kind: str
    label: str
    payload: Dict[str, Any]
    created_at: str = field(default_factory=utc_now)


@dataclass
class CandidateInvariant:
    name: str
    coordinate: str
    claim: str
    claim_class: str
    truth_score: float
    prediction_score: float
    explanatory_score: float
    theorem_score: float
    adversarial_score: float
    novelty_score: float
    final_score: float
    evidence: Dict[str, Any] = field(default_factory=dict)
    superior_to: List[str] = field(default_factory=list)
    dominated_by: Optional[str] = None
    theorem_routes: List[Dict[str, Any]] = field(default_factory=list)
    proof_obligations: List[str] = field(default_factory=list)
    attack_surface: List[str] = field(default_factory=list)


@dataclass
class ActionResult:
    action: str
    raw_output: Dict[str, Any]
    state_updates: Dict[str, Any]
    killed_routes: List[Dict[str, str]] = field(default_factory=list)

# ---------------------------------------------------------------------------
# Persistent corpus with equivalence memory
# ---------------------------------------------------------------------------


class CorpusStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        ensure_dir(db_path.parent)
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self.init()

    def init(self) -> None:
        c = self.conn.cursor()
        c.execute("""
        CREATE TABLE IF NOT EXISTS objects(
            object_id TEXT PRIMARY KEY, kind TEXT, label TEXT,
            payload_json TEXT, fingerprints_json TEXT, created_at TEXT
        )""")
        c.execute("""
        CREATE TABLE IF NOT EXISTS runs(
            run_id TEXT PRIMARY KEY, object_id TEXT, version TEXT,
            created_at TEXT, report_json TEXT
        )""")
        c.execute("""
        CREATE TABLE IF NOT EXISTS invariants(
            inv_id TEXT PRIMARY KEY, object_id TEXT, run_id TEXT, name TEXT,
            coordinate TEXT, final_score REAL, payload_json TEXT, created_at TEXT
        )""")
        c.execute("""
        CREATE TABLE IF NOT EXISTS killed_routes(
            kill_id TEXT PRIMARY KEY, object_id TEXT, route TEXT, reason TEXT, created_at TEXT
        )""")
        c.execute("""
        CREATE TABLE IF NOT EXISTS kbk_packets(
            packet_id TEXT PRIMARY KEY, object_id TEXT, run_id TEXT, round_no INTEGER,
            binary TEXT, next_binary TEXT, action TEXT, payload_json TEXT, created_at TEXT
        )""")
        c.execute("""
        CREATE TABLE IF NOT EXISTS theorem_registry(
            theorem_id TEXT PRIMARY KEY, name TEXT, domain TEXT, conditions_json TEXT,
            route_template TEXT, created_at TEXT
        )""")
        self.conn.commit()
        self._seed_theorems()

    def _seed_theorems(self) -> None:
        theorems = [
            ("finite_difference_polynomial", "Finite difference polynomial characterization", "sequence", ["constant d-th finite difference"], "prove Δ^d a_n constant; derive polynomial in binomial basis"),
            ("linear_recurrence_rational_gf", "Linear recurrence implies rational generating function", "sequence", ["constant-coefficient recurrence", "enough initial terms"], "build companion matrix and rational generating function"),
            ("lucas_zsigmondy_bhv", "Lucas/Lehmer primitive divisor route", "recurrence", ["order 2", "nondegenerate root ratio", "integer Lucas/Lehmer normalization", "exceptions checked"], "apply Zsigmondy/Bilu-Hanrot-Voutier after eligibility"),
            ("lte", "Lifting-the-exponent", "valuation", ["p divides x-y or x+y", "parity conditions", "p-adic nonzero"], "derive valuation law and exception set"),
            ("strong_divisibility", "Strong divisibility sequence", "sequence", ["gcd(a_m,a_n)=a_gcd(m,n)", "zero/index conventions"], "prove via recurrence companion or formal group law"),
            ("crt_cover", "CRT covering system route", "covering", ["finite residue cover", "CRT compatibility", "prime-power lift"], "separate finite torus cover from infinite covering proof"),
        ]
        for tid, name, domain, conds, tmpl in theorems:
            self.conn.execute(
                "INSERT OR IGNORE INTO theorem_registry(theorem_id,name,domain,conditions_json,route_template,created_at) VALUES(?,?,?,?,?,?)",
                (tid, name, domain, stable_json(conds), tmpl, utc_now()),
            )
        self.conn.commit()

    def upsert_object(self, obj: NTObject) -> None:
        fps = {}
        if obj.kind == "sequence":
            fps = sequence_fingerprint(obj.payload.get("sequence", []))
        self.conn.execute(
            "INSERT OR REPLACE INTO objects(object_id,kind,label,payload_json,fingerprints_json,created_at) VALUES(?,?,?,?,?,?)",
            (obj.object_id, obj.kind, obj.label, stable_json(obj.payload), stable_json(fps), obj.created_at),
        )
        self.conn.commit()

    def equivalence_hits(self, obj: NTObject) -> List[Dict[str, Any]]:
        if obj.kind != "sequence":
            return []
        fps = sequence_fingerprint(obj.payload.get("sequence", []))
        rows = self.conn.execute("SELECT object_id,label,fingerprints_json FROM objects WHERE object_id != ?", (obj.object_id,)).fetchall()
        hits = []
        for row in rows:
            try:
                other = json.loads(row["fingerprints_json"] or "{}")
            except Exception:
                other = {}
            shared = sorted(set(fps.items()) & set(other.items()))
            if shared:
                hits.append({"object_id": row["object_id"], "label": row["label"], "shared_fingerprints": shared})
        return hits

    def save_run(self, object_id: str, report: Dict[str, Any]) -> str:
        run_id = sha256_text(object_id + utc_now() + stable_json(report))[:20]
        self.conn.execute(
            "INSERT INTO runs(run_id,object_id,version,created_at,report_json) VALUES(?,?,?,?,?)",
            (run_id, object_id, VERSION, utc_now(), stable_json(report)),
        )
        for inv in report.get("ranked_invariants", []):
            inv_id = sha256_text(run_id + inv.get("name", "") + inv.get("claim", ""))[:20]
            self.conn.execute(
                "INSERT OR REPLACE INTO invariants(inv_id,object_id,run_id,name,coordinate,final_score,payload_json,created_at) VALUES(?,?,?,?,?,?,?,?)",
                (inv_id, object_id, run_id, inv.get("name", ""), inv.get("coordinate", ""), float(inv.get("final_score", 0)), stable_json(inv), utc_now()),
            )
        self.conn.commit()
        return run_id

    def save_packet(self, object_id: str, run_id: str, packet: Dict[str, Any]) -> None:
        pid = sha256_text(object_id + run_id + str(packet.get("round_no")) + stable_json(packet))[:20]
        self.conn.execute(
            "INSERT OR REPLACE INTO kbk_packets(packet_id,object_id,run_id,round_no,binary,next_binary,action,payload_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (pid, object_id, run_id, int(packet.get("round_no", 0)), packet.get("binary", ""), packet.get("next_binary", ""), packet.get("action", ""), stable_json(packet), utc_now()),
        )
        self.conn.commit()

    def add_kill(self, object_id: str, route: str, reason: str) -> None:
        kid = sha256_text(object_id + route + reason)[:20]
        self.conn.execute(
            "INSERT OR REPLACE INTO killed_routes(kill_id,object_id,route,reason,created_at) VALUES(?,?,?,?,?)",
            (kid, object_id, route, reason, utc_now()),
        )
        self.conn.commit()

    def prior_context(self, object_id: str) -> Dict[str, Any]:
        invs = self.conn.execute("SELECT name,coordinate,final_score FROM invariants WHERE object_id=? ORDER BY final_score DESC LIMIT 20", (object_id,)).fetchall()
        kills = self.conn.execute("SELECT route,reason FROM killed_routes WHERE object_id=? ORDER BY created_at DESC LIMIT 20", (object_id,)).fetchall()
        packets = self.conn.execute("SELECT round_no,binary,next_binary,action,payload_json FROM kbk_packets WHERE object_id=? ORDER BY round_no DESC LIMIT 8", (object_id,)).fetchall()
        return {"prior_invariants": [dict(r) for r in invs], "killed_routes": [dict(r) for r in kills], "recent_packets": [{"round_no": r[0], "binary": r[1], "next_binary": r[2], "action": r[3], "packet": json.loads(r[4])} for r in packets]}

    def list_objects(self) -> List[Dict[str, Any]]:
        rows = self.conn.execute("SELECT object_id,kind,label,created_at FROM objects ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]

# ---------------------------------------------------------------------------
# Invariant mining and hierarchy
# ---------------------------------------------------------------------------


class InvariantEngine:
    """Mines candidate invariants, then ranks coordinate systems by explanatory primacy."""

    COORDINATE_PRIOR = {
        "constant": 120,
        "polynomial_finite_difference": 112,
        "geometric_exponential": 108,
        "linear_recurrence": 94,
        "rational_generating_function": 90,
        "strong_divisibility": 82,
        "valuation_profile": 74,
        "modular_finite_state": 68,
        "factorization_profile": 56,
    }

    def mine(self, seq: Sequence[int]) -> Dict[str, Any]:
        seq = [int(x) for x in seq]
        candidates: List[CandidateInvariant] = []
        raw: Dict[str, Any] = {"n_terms": len(seq), "sequence_prefix": seq[:20]}

        # Constant
        if seq and len(set(seq)) == 1:
            ev = {"value": seq[0]}
            candidates.append(self._candidate("constant", "constant", f"Sequence is constant equal to {seq[0]}", "E", 100, 100, ev))

        # Polynomial finite difference
        poly = polynomial_fit(seq)
        raw["polynomial"] = poly
        if poly:
            deg = int(poly["degree"])
            pred_score = 100.0
            # lower degree is more explanatory; exact finite difference certificate is strong
            explanatory = max(70.0, 118.0 - 8.0 * deg)
            ev = dict(poly)
            candidates.append(self._candidate(
                "polynomial_finite_difference",
                "polynomial_finite_difference",
                f"Sequence is governed by a degree-{deg} polynomial / constant {deg}-th finite difference law.",
                "E",
                pred_score,
                explanatory,
                ev,
            ))

        # Geometric exponential
        geom = self._geometric(seq)
        raw["geometric"] = geom
        if geom:
            candidates.append(self._candidate(
                "geometric_exponential",
                "geometric_exponential",
                f"Sequence is geometric after index {geom['start_index']} with ratio {geom['ratio']}.",
                "E",
                100.0 if geom["exact"] else 80.0,
                106.0,
                geom,
            ))

        # Recurrence
        rec = recurrence_guess(seq)
        raw["recurrence"] = self._json_safe_rec(rec)
        if rec:
            order = int(rec["order"])
            coeffs: List[Fraction] = rec["coefficients_fraction"]
            pred_score = 100.0 if rec.get("exact_on_input") else 80.0
            explanatory = 98.0 - 3.0 * order
            # If polynomial already explains with degree d, recurrence is true but dominated.
            claim = f"Sequence satisfies an exact order-{order} constant-coefficient linear recurrence."
            candidates.append(self._candidate("linear_recurrence", "linear_recurrence", claim, "E", pred_score, explanatory, self._json_safe_rec(rec)))
            rgf = rational_generating_function(seq, coeffs)
            candidates.append(self._candidate(
                "rational_generating_function",
                "rational_generating_function",
                "Sequence has a rational generating function induced by the detected recurrence.",
                "E",
                pred_score,
                explanatory - 4,
                rgf,
            ))

        # Strong divisibility
        sd = self._strong_divisibility(seq)
        raw["strong_divisibility"] = sd
        if sd["tested_pairs"] > 0 and sd["success_rate"] >= 0.98:
            candidates.append(self._candidate(
                "strong_divisibility",
                "divisibility_law",
                "Sequence behaves as a strong divisibility sequence on tested indices.",
                "COMP",
                100.0 * sd["success_rate"],
                82.0,
                sd,
            ))

        # Valuation profiles
        vp = self._valuation_profiles(seq)
        raw["valuation_profiles"] = vp
        if any(v.get("nontrivial") for v in vp.values()):
            candidates.append(self._candidate(
                "valuation_profile",
                "p_adic",
                "Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.",
                "COMP",
                65.0,
                74.0,
                vp,
            ))

        # Modular finite state
        mods = self._modular_scan(seq)
        raw["modular_periods"] = mods
        if mods:
            avg_period = statistics.mean([m["period"] for m in mods])
            candidates.append(self._candidate(
                "modular_finite_state",
                "modular_dynamics",
                f"Sequence exhibits finite-state modular periods across {len(mods)} tested moduli.",
                "COMP",
                60.0,
                max(50.0, 78.0 - avg_period / 2),
                {"periods": mods},
            ))

        ranked = self.rank(candidates)
        raw["ranked_names"] = [c.name for c in ranked]
        return {"raw": raw, "candidates": ranked}

    def _candidate(self, name: str, coord: str, claim: str, cls: str, pred: float, expl: float, evidence: Dict[str, Any]) -> CandidateInvariant:
        theorem = 0.0
        if name in ("polynomial_finite_difference", "linear_recurrence", "geometric_exponential", "rational_generating_function"):
            theorem = 80.0
        elif name in ("strong_divisibility", "valuation_profile"):
            theorem = 62.0
        novelty = 50.0
        truth = min(100.0, pred)
        final = 0.30 * truth + 0.34 * expl + 0.18 * theorem + 0.10 * pred + 0.08 * novelty
        return CandidateInvariant(
            name=name, coordinate=coord, claim=claim, claim_class=cls,
            truth_score=truth, prediction_score=pred, explanatory_score=expl,
            theorem_score=theorem, adversarial_score=0.0, novelty_score=novelty,
            final_score=round(final, 3), evidence=evidence,
        )

    def rank(self, candidates: List[CandidateInvariant]) -> List[CandidateInvariant]:
        # Dominance: polynomial finite-difference dominates generic recurrence if exact and lower coordinate complexity.
        by_name = {c.name: c for c in candidates}
        poly = by_name.get("polynomial_finite_difference")
        rec = by_name.get("linear_recurrence")
        if poly and rec:
            # Penalize recurrence because it is true but less explanatory for polynomial sequences.
            rec.dominated_by = poly.name
            rec.attack_surface.append("Predictive recurrence is not primary coordinate; polynomial finite difference is simpler and more explanatory.")
            rec.final_score -= 22.0
            poly.superior_to.append(rec.name)
        geom = by_name.get("geometric_exponential")
        if geom and rec:
            rec.dominated_by = geom.name
            rec.attack_surface.append("Geometric law is a lower-dimensional explanation than generic recurrence.")
            rec.final_score -= 14.0
            geom.superior_to.append(rec.name)
        rgf = by_name.get("rational_generating_function")
        if rec and rgf:
            rgf.dominated_by = rec.name
            rgf.final_score -= 8.0
        return sorted(candidates, key=lambda c: c.final_score, reverse=True)

    def _json_safe_rec(self, rec: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        if not rec:
            return None
        out = {k: v for k, v in rec.items() if k != "coefficients_fraction"}
        return out

    def _geometric(self, seq: Sequence[int]) -> Optional[Dict[str, Any]]:
        s = [int(x) for x in seq]
        for start in range(0, min(3, len(s) - 2)):
            tail = s[start:]
            if len(tail) < 3 or any(x == 0 for x in tail[:-1]):
                continue
            ratios = [Fraction(tail[i+1], tail[i]) for i in range(len(tail)-1)]
            if len(set(ratios)) == 1:
                return {"start_index": start, "ratio": str(ratios[0]), "exact": True}
        return None

    def _strong_divisibility(self, seq: Sequence[int]) -> Dict[str, Any]:
        # Index convention: test indices 1..n-1 to avoid a_0 ambiguity when a_0=0.
        n = len(seq)
        tested = 0
        ok = 0
        failures = []
        for m in range(1, min(n, 18)):
            for k in range(1, min(n, 18)):
                gidx = math.gcd(m, k)
                if gidx >= n:
                    continue
                lhs = math.gcd(abs(seq[m]), abs(seq[k]))
                rhs = abs(seq[gidx])
                tested += 1
                if lhs == rhs:
                    ok += 1
                elif len(failures) < 10:
                    failures.append({"m": m, "n": k, "gcd_index": gidx, "lhs": lhs, "rhs": rhs})
        return {"tested_pairs": tested, "ok": ok, "success_rate": ok / tested if tested else 0.0, "failures": failures}

    def _valuation_profiles(self, seq: Sequence[int]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for p in [2, 3, 5, 7, 11]:
            vals = [valuation(x, p) for x in seq]
            finite = [v for v in vals if v is not None and v > 0]
            out[str(p)] = {"values": vals[:30], "nonzero_count": len(finite), "max": max(finite) if finite else 0, "nontrivial": len(finite) >= max(3, len(seq)//4)}
        return out

    def _modular_scan(self, seq: Sequence[int]) -> List[Dict[str, Any]]:
        rows = []
        for m in range(2, min(40, max(3, len(seq) + 5))):
            p = modular_period(seq, m)
            if p is not None and p < len(seq) // 2:
                rows.append({"modulus": m, "period": p, "residue_prefix": [x % m for x in seq[:min(len(seq), p*2)]]})
        return rows[:20]

# ---------------------------------------------------------------------------
# Adversarial falsifier and theorem eligibility
# ---------------------------------------------------------------------------


class AdversarialFalsifier:
    def evaluate(self, seq: Sequence[int], inv: CandidateInvariant) -> Dict[str, Any]:
        tests = {
            "prefix_stability": self.prefix_stability(seq, inv),
            "holdout_prediction": self.holdout_prediction(seq, inv),
            "constructed_trap_resistance": self.constructed_trap(seq, inv),
            "transform_stability": self.transform_stability(seq, inv),
            "extension_counterexample": self.extension_counterexample(seq, inv),
        }
        pass_count = sum(1 for t in tests.values() if t.get("pass") is True)
        total = sum(1 for t in tests.values() if t.get("pass") is not None)
        score = 100.0 * pass_count / total if total else 0.0
        return {"tests": tests, "score": round(score, 3), "pass_count": pass_count, "total": total}

    def prefix_stability(self, seq: Sequence[int], inv: CandidateInvariant) -> Dict[str, Any]:
        if len(seq) < 8:
            return {"pass": None, "reason": "too few terms"}
        engine = InvariantEngine()
        names = []
        for cut in [len(seq)-1, len(seq)-2, max(4, len(seq)-3)]:
            if cut >= 4:
                mined = engine.mine(seq[:cut])["candidates"]
                names.append(mined[0].name if mined else None)
        stable = bool(names and all(n == inv.name for n in names if n is not None))
        return {"pass": stable, "top_names_by_prefix": names}

    def holdout_prediction(self, seq: Sequence[int], inv: CandidateInvariant) -> Dict[str, Any]:
        n = len(seq)
        if n < 8:
            return {"pass": None, "reason": "too few terms"}
        train_n = max(5, int(n * 0.7))
        train = list(seq[:train_n])
        hold = list(seq[train_n:])
        pred: List[Any] = []
        if inv.name == "polynomial_finite_difference":
            fit = polynomial_fit(train)
            if fit and sp is not None and fit.get("polynomial"):
                x = sp.symbols("n")
                poly = sp.sympify(fit["polynomial"])
                pred = [int(poly.subs(x, i)) for i in range(train_n, n)]
        elif inv.name in ("linear_recurrence", "rational_generating_function"):
            rec = recurrence_guess(train)
            if rec:
                pred_full = recurrence_predict(train[:rec["order"]], rec["coefficients_fraction"], n)
                pred = [int(v) if v.denominator == 1 else str(v) for v in pred_full[train_n:]]
        elif inv.name == "geometric_exponential":
            geom = InvariantEngine()._geometric(train)
            if geom:
                ratio = Fraction(geom["ratio"])
                cur = Fraction(train[-1])
                for _ in hold:
                    cur *= ratio
                    pred.append(int(cur) if cur.denominator == 1 else str(cur))
        if not pred:
            return {"pass": False, "reason": "no predictor compiled"}
        exact = sum(1 for a, b in zip(pred, hold) if a == b)
        rate = exact / len(hold) if hold else 0.0
        return {"pass": rate == 1.0, "holdout_exact_rate": rate, "predicted": pred, "actual": hold}

    def constructed_trap(self, seq: Sequence[int], inv: CandidateInvariant) -> Dict[str, Any]:
        # Built to catch wrong-coordinate truth: e.g. polynomial sequences also satisfy recurrences.
        engine = InvariantEngine()
        if inv.name == "linear_recurrence":
            poly = polynomial_fit(seq)
            if poly:
                return {"pass": False, "trap": "polynomial_recursiveness", "reason": "Finite-difference polynomial gives superior coordinate; recurrence is predictive but dominated."}
        if inv.name == "modular_finite_state" and recurrence_guess(seq):
            return {"pass": False, "trap": "modular_shadow_of_recurrence", "reason": "Modular periods may be shadows of stronger recurrence."}
        # Poison last term: a robust exact invariant should detect failure when one term is corrupted.
        if len(seq) >= 8 and inv.name in ("polynomial_finite_difference", "linear_recurrence", "geometric_exponential"):
            poisoned = list(seq)
            poisoned[-1] += 1
            mined = engine.mine(poisoned)["candidates"]
            same_top = mined and mined[0].name == inv.name and mined[0].truth_score >= 99
            return {"pass": not same_top, "trap": "poisoned_final_term", "poisoned_top": mined[0].name if mined else None}
        return {"pass": True, "trap": "no_specific_trap_triggered"}

    def transform_stability(self, seq: Sequence[int], inv: CandidateInvariant) -> Dict[str, Any]:
        if len(seq) < 5:
            return {"pass": None, "reason": "too few terms"}
        engine = InvariantEngine()
        transforms = {
            "shift": list(seq[1:]),
            "diff1": differences(seq, 1),
        }
        results = {}
        for name, t in transforms.items():
            if len(t) >= 4:
                mined = engine.mine(t)["candidates"]
                results[name] = mined[0].name if mined else None
        # Polynomial should remain polynomial under differences; recurrences should remain recurrence under shifts/diffs usually.
        if inv.name == "polynomial_finite_difference":
            ok = results.get("diff1") in ("polynomial_finite_difference", "constant")
        elif inv.name == "linear_recurrence":
            ok = results.get("shift") in ("linear_recurrence", "geometric_exponential", "polynomial_finite_difference")
        else:
            ok = True
        return {"pass": ok, "transform_top": results}

    def extension_counterexample(self, seq: Sequence[int], inv: CandidateInvariant) -> Dict[str, Any]:
        # Try to extend by the claimed law and then rerun hierarchy. This is not proof; it catches unstable detectors.
        ext = list(seq)
        if inv.name == "polynomial_finite_difference" and sp is not None and inv.evidence.get("polynomial"):
            x = sp.symbols("n")
            poly = sp.sympify(inv.evidence["polynomial"])
            for i in range(len(seq), len(seq) + 5):
                ext.append(int(poly.subs(x, i)))
        elif inv.name == "linear_recurrence":
            rec = recurrence_guess(seq)
            if rec:
                pred = recurrence_predict(seq[:rec["order"]], rec["coefficients_fraction"], len(seq) + 5)
                ext = [int(v) if v.denominator == 1 else 0 for v in pred]
        elif inv.name == "geometric_exponential":
            geom = InvariantEngine()._geometric(seq)
            if geom:
                ratio = Fraction(geom["ratio"])
                cur = Fraction(seq[-1])
                for _ in range(5):
                    cur *= ratio
                    ext.append(int(cur) if cur.denominator == 1 else 0)
        else:
            return {"pass": None, "reason": "no extension compiler for invariant"}
        mined = InvariantEngine().mine(ext)["candidates"]
        ok = bool(mined and mined[0].name == inv.name)
        # If polynomial stays top and recurrence becomes top due to extension, it fails.
        return {"pass": ok, "extended_top": mined[0].name if mined else None, "extended_tail": ext[-5:]}


class TheoremRouter:
    def route(self, seq: Sequence[int], inv: CandidateInvariant) -> List[Dict[str, Any]]:
        routes = []
        if inv.name == "polynomial_finite_difference":
            routes.append(self.finite_difference_route(inv))
        if inv.name in ("linear_recurrence", "rational_generating_function", "geometric_exponential"):
            routes.append(self.recurrence_route(seq, inv))
            lucas = self.lucas_zsigmondy_eligibility(seq)
            if lucas["applicable"] or lucas["tested"]:
                routes.append(lucas)
        sd = self.strong_divisibility_route(seq)
        if sd["tested"]:
            routes.append(sd)
        lte = self.lte_route(seq)
        if lte["tested"]:
            routes.append(lte)
        return routes

    def finite_difference_route(self, inv: CandidateInvariant) -> Dict[str, Any]:
        d = inv.evidence.get("degree")
        return {
            "route": "finite_difference_polynomial",
            "status": "eligible" if d is not None else "untested",
            "conditions": [
                {"condition": "constant finite difference", "status": "pass", "evidence": inv.evidence.get("finite_difference_certificate")},
                {"condition": "derive polynomial in binomial basis", "status": "open"},
            ],
            "proof_obligations": [
                f"Prove Δ^{d} a_n is constant on the intended domain, not only the observed prefix.",
                "Express a_n in the binomial coefficient basis from initial finite differences.",
            ],
            "referee_target": "finite-difference certificate over all n",
        }

    def recurrence_route(self, seq: Sequence[int], inv: CandidateInvariant) -> Dict[str, Any]:
        rec = recurrence_guess(seq)
        conditions: List[Dict[str, Any]] = []
        if rec:
            conditions.append({"condition": "constant coefficient recurrence exists", "status": "pass", "evidence": {"order": rec["order"], "coefficients": rec["coefficients"]}})
            conditions.append({"condition": "minimal order proven", "status": "open", "evidence": "detected order is candidate-minimal by search, not proof"})
            conditions.append({"condition": "characteristic polynomial factored", "status": "pass" if rec.get("characteristic") else "open", "evidence": rec.get("characteristic")})
        else:
            conditions.append({"condition": "constant coefficient recurrence exists", "status": "fail"})
        return {
            "route": "linear_recurrence_rational_gf",
            "status": "eligible" if rec else "fail",
            "conditions": conditions,
            "proof_obligations": [
                "Prove detected recurrence holds for all n by deriving it from the defining object.",
                "Prove minimality of recurrence order or explicitly demote to non-primary coordinate.",
                "Factor characteristic polynomial and classify degeneracy/root ratios.",
            ],
            "referee_target": "minimal recurrence plus characteristic classification",
        }

    def lucas_zsigmondy_eligibility(self, seq: Sequence[int]) -> Dict[str, Any]:
        rec = recurrence_guess(seq, max_order=4)
        tested = bool(rec and rec["order"] == 2)
        if not tested:
            return {"route": "lucas_zsigmondy_bhv", "tested": False, "status": "not_triggered", "applicable": False, "conditions": []}
        coeffs: List[Fraction] = rec["coefficients_fraction"]
        P = coeffs[0]
        Q = -coeffs[1]
        D = P * P - 4 * Q
        int_norm = P.denominator == 1 and Q.denominator == 1
        nondegenerate = D != 0 and Q != 0
        # crude root-ratio degeneracy screen: if char roots ratio is root of unity for obvious cases.
        root_unity_suspect = False
        if sp is not None:
            x = sp.symbols("x")
            poly = x*x - sp.Rational(P.numerator, P.denominator) * x + sp.Rational(Q.numerator, Q.denominator)
            fac = sp.factor(poly)
            root_unity_suspect = str(fac) in ["(x - 1)**2", "(x + 1)**2", "x**2 + 1", "x**2 + x + 1", "x**2 - x + 1"]
        conds = [
            {"condition": "order 2 recurrence", "status": "pass", "evidence": rec["coefficients"]},
            {"condition": "integer Lucas/Lehmer normalization P,Q", "status": "pass" if int_norm else "fail", "evidence": {"P": str(P), "Q": str(Q)}},
            {"condition": "nondegenerate discriminant and Q", "status": "pass" if nondegenerate else "fail", "evidence": {"D": str(D)}},
            {"condition": "root ratio not obvious root of unity", "status": "pass" if not root_unity_suspect else "fail"},
            {"condition": "primitive divisor exception range checked", "status": "open"},
        ]
        applicable = all(c["status"] == "pass" for c in conds[:4])
        return {
            "route": "lucas_zsigmondy_bhv",
            "tested": True,
            "status": "eligible_unless_exceptions" if applicable else "blocked",
            "applicable": applicable,
            "conditions": conds,
            "proof_obligations": [
                "Normalize recurrence into Lucas or Lehmer form.",
                "Check Bilu-Hanrot-Voutier/Zsigmondy exception indices explicitly.",
                "Prove nondegeneracy of root quotient in the exact number field.",
            ],
            "referee_target": "primitive divisor theorem eligibility plus exception audit",
        }

    def strong_divisibility_route(self, seq: Sequence[int]) -> Dict[str, Any]:
        sd = InvariantEngine()._strong_divisibility(seq)
        return {
            "route": "strong_divisibility",
            "tested": sd["tested_pairs"] > 0,
            "status": "eligible" if sd["success_rate"] >= 0.98 else "fail",
            "conditions": [
                {"condition": "gcd(a_m,a_n)=a_gcd(m,n) on tested grid", "status": "pass" if sd["success_rate"] >= 0.98 else "fail", "evidence": sd},
                {"condition": "index convention handles a_0/zero terms", "status": "open"},
            ],
            "proof_obligations": ["Prove strong divisibility identity for all m,n or identify exact failure set."],
            "referee_target": "global gcd law",
        }

    def lte_route(self, seq: Sequence[int]) -> Dict[str, Any]:
        # Looks for a_n = x^n - y^n style only by valuation regularity. Conservative.
        profiles = InvariantEngine()._valuation_profiles(seq)
        nontrivial = {p: v for p, v in profiles.items() if v.get("nontrivial")}
        return {
            "route": "lte",
            "tested": bool(nontrivial),
            "status": "candidate" if nontrivial else "not_triggered",
            "conditions": [
                {"condition": "nontrivial p-adic valuation profile", "status": "pass" if nontrivial else "fail", "evidence": nontrivial},
                {"condition": "identify x,y with p | x-y or p | x+y", "status": "open"},
                {"condition": "parity and p=2 exception conditions", "status": "open"},
            ],
            "proof_obligations": ["Fit valuation law to LTE hypotheses and isolate exception primes."],
            "referee_target": "exact LTE parameterization",
        }

# ---------------------------------------------------------------------------
# External tribunal and proof compiler
# ---------------------------------------------------------------------------


class ExternalTribunal:
    """Runs or writes Sage/PARI/Lean. Its results are binding state updates."""

    def __init__(self, out_dir: Path):
        self.out_dir = ensure_dir(out_dir)
        self.sage = shutil.which("sage")
        self.gp = shutil.which("gp")
        self.lean = shutil.which("lean")

    def adjudicate_sequence(self, seq: Sequence[int], invs: List[CandidateInvariant], label: str) -> Dict[str, Any]:
        stem = self.out_dir / re.sub(r"[^A-Za-z0-9_.-]+", "_", label)
        sage_path = stem.with_suffix(".sage")
        gp_path = stem.with_suffix(".gp")
        lean_path = stem.with_suffix(".lean")
        sage_path.write_text(self.sage_script(seq, invs))
        gp_path.write_text(self.gp_script(seq, invs))
        lean_path.write_text(ProofCompiler().lean_sequence(seq, invs))
        results: Dict[str, Any] = {
            "tools": {"sage": self.sage, "gp": self.gp, "lean": self.lean},
            "files": {"sage": str(sage_path), "pari_gp": str(gp_path), "lean": str(lean_path)},
            "state_updates": [],
        }
        # Internal tribunal is always binding.
        internal = self.internal_sequence_adjudication(seq, invs)
        results["internal"] = internal
        results["state_updates"].extend(internal.get("state_updates", []))
        if self.sage:
            results["sage_run"] = self.run_tool([self.sage, str(sage_path)], timeout=12)
        else:
            results["sage_run"] = {"status": "not_installed", "binding": False}
        if self.gp:
            results["pari_gp_run"] = self.run_tool([self.gp, "-q", str(gp_path)], timeout=12)
        else:
            results["pari_gp_run"] = {"status": "not_installed", "binding": False}
        if self.lean:
            results["lean_check"] = self.run_tool([self.lean, str(lean_path)], timeout=12)
        else:
            results["lean_check"] = {"status": "not_installed", "binding": False, "note": "Lean skeleton emitted with `sorry` proof debts; absence does not validate proof."}
        return results

    def internal_sequence_adjudication(self, seq: Sequence[int], invs: List[CandidateInvariant]) -> Dict[str, Any]:
        updates = []
        rec = recurrence_guess(seq)
        if rec:
            updates.append({"type": "characteristic_factorization", "value": rec["characteristic"], "binding_effect": "route recurrence/minimality/degeneracy checks"})
        poly = polynomial_fit(seq)
        if poly:
            updates.append({"type": "superior_coordinate_check", "value": "polynomial_finite_difference", "binding_effect": "demote generic recurrence if present"})
        return {"status": "complete", "state_updates": updates}

    def run_tool(self, cmd: List[str], timeout: int = 10) -> Dict[str, Any]:
        try:
            p = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout)
            return {"status": "ran", "returncode": p.returncode, "stdout_tail": p.stdout[-4000:], "stderr_tail": p.stderr[-4000:], "binding": p.returncode == 0}
        except subprocess.TimeoutExpired:
            return {"status": "timeout", "binding": False}
        except Exception as e:
            return {"status": "error", "error": str(e), "binding": False}

    def sage_script(self, seq: Sequence[int], invs: List[CandidateInvariant]) -> str:
        return f"""# Oracle NT OS V4 Sage tribunal
seq = {list(map(int, seq))}
print('ORACLE_SAGE_BEGIN')
print('n_terms', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('finite_differences')
    cur = seq[:]
    for k in range(min(8, len(seq)-1)):
        print(k, cur[:12])
        cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]
except Exception as e:
    print('sage_error', e)
print('ORACLE_SAGE_END')
"""

    def gp_script(self, seq: Sequence[int], invs: List[CandidateInvariant]) -> str:
        return f"""\\ Oracle NT OS V4 PARI/GP tribunal
seq = {list(map(int, seq))};
print("ORACLE_GP_BEGIN");
print("n_terms=", #seq);
for(i=1,min(#seq,12), print(i-1, ":", factor(abs(seq[i]))));
print("ORACLE_GP_END");
quit;
"""


class ProofCompiler:
    def lean_sequence(self, seq: Sequence[int], invs: List[CandidateInvariant]) -> str:
        top = invs[0] if invs else None
        seq_list = list(map(int, seq))
        defs = [
            "import Mathlib",
            "",
            "namespace OracleNT",
            "",
            "/-- Observed prefix. This is data, not a proof of the infinite claim. -/",
            f"def observed : List Int := {seq_list}",
            "",
        ]
        if top and top.name == "polynomial_finite_difference":
            deg = int(top.evidence.get("degree", -1)) if str(top.evidence.get("degree", "")).lstrip("-").isdigit() else -1
            poly = top.evidence.get("polynomial")
            defs.append(f"/-- Candidate polynomial coordinate from Python/SymPy: {poly}. -/")
            if deg == 0:
                val = int(seq[0]) if seq else 0
                defs += [
                    f"def a (_n : Nat) : Int := {val}",
                    "theorem constant_law_all_n : ∀ n : Nat, a n = a 0 := by",
                    "  intro n",
                    "  simp [a]",
                ]
            elif deg == 1:
                d = seq[1] - seq[0] if len(seq) > 1 else 0
                a0 = seq[0] if seq else 0
                defs += [
                    f"def a (n : Nat) : Int := ({d}) * (Int.ofNat n) + ({a0})",
                    f"theorem first_difference_constant : ∀ n : Nat, a (n+1) - a n = {d} := by",
                    "  intro n",
                    "  simp [a]",
                    "  ring",
                ]
            elif deg == 2:
                second = differences(seq, 2)[0] if len(seq) >= 3 else 0
                defs += [
                    "def a (n : Nat) : Int := (Int.ofNat n) * (Int.ofNat n)  -- replace if discovered polynomial is not n^2",
                    f"theorem second_difference_certificate : ∀ n : Nat, a (n+2) - 2 * a (n+1) + a n = {second} := by",
                    "  intro n",
                    "  simp [a]",
                    "  ring",
                ]
            else:
                defs += [
                    "/-- Proof debt: define finite-difference operator and prove Δ^d a n = C. -/",
                    "def a (n : Nat) : Int := 0  -- TODO: replace with discovered closed form",
                    f"theorem finite_difference_certificate (n : Nat) : a n = a n := by",
                    "  -- TODO: replace reflexive placeholder with the exact Δ^d statement for this degree",
                    "  sorry",
                ]
        elif top and top.name in ("linear_recurrence", "geometric_exponential", "rational_generating_function"):
            rec = recurrence_guess(seq)
            defs.append("/-- Proof debt: replace `a` with the defining object and prove recurrence globally. -/")
            defs.append("def a (n : Nat) : Int := 0")
            if rec:
                defs.append(f"/-- Candidate recurrence order: {rec['order']}, coefficients: {rec['coefficients']}. -/")
                if rec["order"] == 2 and rec["coefficients"] == ["1", "1"]:
                    defs += [
                        "theorem recurrence_holds : ∀ n : Nat, a (n+2) = a (n+1) + a n := by",
                        "  -- TODO: prove from the actual definition of `a`; `sorry` marks a real proof debt.",
                        "  intro n",
                        "  sorry",
                    ]
                else:
                    defs += [
                        "theorem recurrence_holds_candidate : ∀ n : Nat, a n = a n := by",
                        "  -- TODO: compile exact coefficient recurrence into Lean syntax.",
                        "  intro n",
                        "  sorry",
                    ]
        else:
            defs += [
                "/-- No theorem-shaped invariant reached yet; formal target is intentionally absent. -/",
                "def no_primary_obligation_yet : String := \"no primary obligation\"",
            ]
        defs += ["", "end OracleNT", ""]
        return "\n".join(defs)

# ---------------------------------------------------------------------------
# KBK compiler and Oracle engine
# ---------------------------------------------------------------------------


class KBKCompiler:
    def choose_action(self, round_no: int, binary: Optional[str], state: Dict[str, Any]) -> str:
        if round_no <= 1 or not binary:
            return "primary_invariant_hierarchy"
        b = binary.lower()
        if "superior coordinate" in b or "coordinate" in b:
            return "coordinate_dominance_audit"
        if "minimal" in b or "recurrence" in b:
            return "minimality_and_characteristic"
        if "theorem" in b or "eligibility" in b or "lucas" in b or "zsigmondy" in b:
            return "theorem_eligibility"
        if "adversarial" in b or "fals" in b or "trap" in b:
            return "hostile_falsification"
        if "proof" in b or "lean" in b or "referee" in b:
            return "proof_obligation_compilation"
        cycle = ["coordinate_dominance_audit", "minimality_and_characteristic", "theorem_eligibility", "hostile_falsification", "proof_obligation_compilation"]
        return cycle[(round_no - 2) % len(cycle)]

    def next_binary(self, action: str, state: Dict[str, Any]) -> str:
        top = state.get("top_invariant", {})
        name = top.get("name", "unknown")
        if action == "primary_invariant_hierarchy":
            return "superior coordinate exists OR detected invariant is primary"
        if action == "coordinate_dominance_audit":
            return "minimal theorem route closes OR coordinate is only predictive"
        if action == "minimality_and_characteristic":
            return "theorem eligibility passes OR recurrence route is demoted"
        if action == "theorem_eligibility":
            return "adversarial traps fail OR invariant survives hostile construction"
        if action == "hostile_falsification":
            return "proof obligation is exact OR picture not yet at jigsaw level"
        return f"{name} proof closes OR missing piece changes the picture"


class OracleNTOSEngine:
    def __init__(self, out_dir: Path, db_path: Optional[Path] = None):
        self.out_dir = ensure_dir(out_dir)
        self.db = CorpusStore(db_path or (self.out_dir / "oracle_nt_v4_corpus.sqlite"))
        self.inv_engine = InvariantEngine()
        self.router = TheoremRouter()
        self.falsifier = AdversarialFalsifier()
        self.kbk = KBKCompiler()
        self.tribunal = ExternalTribunal(self.out_dir / "handoffs")

    def make_sequence_object(self, seq: Sequence[int], label: str) -> NTObject:
        payload = {"sequence": list(map(int, seq)), "fingerprints": sequence_fingerprint(seq)}
        oid = sha256_text("sequence:" + ",".join(map(str, seq)))[:20]
        return NTObject(oid, "sequence", label, payload)

    def ingest_object(self, obj_payload: Dict[str, Any], label: str) -> NTObject:
        kind = obj_payload.get("kind", "raw")
        oid = sha256_text(kind + ":" + stable_json(obj_payload))[:20]
        return NTObject(oid, kind, label, obj_payload)

    def analyze_sequence(self, seq: Sequence[int], label: str, round_no: int = 1, binary: Optional[str] = None, action: Optional[str] = None, write: bool = True) -> Dict[str, Any]:
        obj = self.make_sequence_object(seq, label)
        self.db.upsert_object(obj)
        prior = self.db.prior_context(obj.object_id)
        equivalence = self.db.equivalence_hits(obj)
        mined = self.inv_engine.mine(seq)
        invs = mined["candidates"]
        state: Dict[str, Any] = {"top_invariant": dataclasses.asdict(invs[0]) if invs else None}
        action = action or self.kbk.choose_action(round_no, binary, state)

        action_result = self.execute_action(action, seq, invs)
        # Recompute final ranking after action updates if needed.
        for inv in invs:
            fals = self.falsifier.evaluate(seq, inv)
            inv.adversarial_score = fals["score"]
            inv.theorem_routes = self.router.route(seq, inv)
            inv.theorem_score = self._theorem_score(inv.theorem_routes)
            inv.proof_obligations = self._proof_obligations(inv.theorem_routes)
            inv.attack_surface.extend(self._attack_surface(inv, fals))
            inv.final_score = round(0.24 * inv.truth_score + 0.28 * inv.explanatory_score + 0.20 * inv.theorem_score + 0.18 * inv.adversarial_score + 0.10 * inv.novelty_score, 3)
            if inv.dominated_by:
                inv.final_score -= 15.0
        invs = self.inv_engine.rank(invs)
        tribunal = self.tribunal.adjudicate_sequence(seq, invs, label=f"{label}_round{round_no}")
        self.apply_binding_tribunal(invs, tribunal)
        invs = sorted(invs, key=lambda c: c.final_score, reverse=True)

        jigsaw = self.jigsaw(invs, action_result)
        gth = self.gth(invs, jigsaw)
        packet = {
            "round_no": round_no,
            "binary": binary or "primary invariant OR prefix artifact",
            "action": action,
            "verdict": "CLOSURE" if gth["fires"] else "ESCALATION",
            "strongest_invariant": invs[0].name if invs else None,
            "killed_routes": action_result.killed_routes,
            "next_binary": self.kbk.next_binary(action, {"top_invariant": dataclasses.asdict(invs[0]) if invs else {}}),
            "jigsaw_piece": jigsaw.get("picture", "not visible"),
            "missing_piece": jigsaw.get("missing_pieces", ["unknown"])[0] if jigsaw.get("missing_pieces") else "none",
            "gth_ready": gth["fires"],
        }
        report = {
            "version": VERSION,
            "created_at": utc_now(),
            "object": dataclasses.asdict(obj),
            "round_no": round_no,
            "binary": packet["binary"],
            "action": action,
            "prior_context": prior,
            "equivalence_hits": equivalence,
            "raw_measurements": mined["raw"],
            "action_result": dataclasses.asdict(action_result),
            "ranked_invariants": [dataclasses.asdict(i) for i in invs],
            "external_tribunal": tribunal,
            "jigsaw": jigsaw,
            "gth": gth,
            "kbk_packet": packet,
        }
        run_id = self.db.save_run(obj.object_id, report)
        report["run_id"] = run_id
        self.db.save_packet(obj.object_id, run_id, packet)
        for k in action_result.killed_routes:
            self.db.add_kill(obj.object_id, k.get("route", "unknown"), k.get("reason", ""))
        if write:
            stem = self.out_dir / f"{self._safe(label)}_round{round_no}"
            self.write_report(report, stem)
        return report

    def execute_action(self, action: str, seq: Sequence[int], invs: List[CandidateInvariant]) -> ActionResult:
        raw: Dict[str, Any] = {}
        updates: Dict[str, Any] = {}
        kills: List[Dict[str, str]] = []
        top = invs[0] if invs else None
        if action == "primary_invariant_hierarchy":
            raw["ranked_invariants_initial"] = [dataclasses.asdict(i) for i in invs]
            updates["primary_coordinate"] = top.name if top else None
        elif action == "coordinate_dominance_audit":
            raw["dominance"] = [{"name": i.name, "dominated_by": i.dominated_by, "superior_to": i.superior_to} for i in invs]
            for i in invs:
                if i.dominated_by:
                    kills.append({"route": i.name, "reason": f"Dominated by superior coordinate {i.dominated_by}. Predictive is not primary."})
        elif action == "minimality_and_characteristic":
            rec = recurrence_guess(seq)
            raw["recurrence"] = InvariantEngine()._json_safe_rec(rec)
            if rec:
                raw["minimality_search"] = {"candidate_order": rec["order"], "status": "candidate_minimal_by_search_not_proof"}
                raw["characteristic"] = rec["characteristic"]
            else:
                kills.append({"route": "linear_recurrence", "reason": "No exact recurrence found in search window."})
        elif action == "theorem_eligibility":
            raw["routes_by_invariant"] = {i.name: self.router.route(seq, i) for i in invs[:5]}
            for i in invs[:5]:
                for r in raw["routes_by_invariant"][i.name]:
                    if r.get("status") in ("fail", "blocked"):
                        kills.append({"route": r.get("route", "unknown"), "reason": "Theorem eligibility condition failed."})
        elif action == "hostile_falsification":
            raw["falsification_by_invariant"] = {i.name: self.falsifier.evaluate(seq, i) for i in invs[:5]}
            for name, f in raw["falsification_by_invariant"].items():
                if f["score"] < 60:
                    kills.append({"route": name, "reason": f"Hostile falsifier score {f['score']} < 60."})
        elif action == "proof_obligation_compilation":
            raw["proof_debts"] = {i.name: self._proof_obligations(self.router.route(seq, i)) for i in invs[:5]}
            updates["lean_statement_emitted"] = True
        else:
            raw["note"] = "unknown action; ran primary hierarchy only"
        return ActionResult(action=action, raw_output=raw, state_updates=updates, killed_routes=kills)

    def apply_binding_tribunal(self, invs: List[CandidateInvariant], tribunal: Dict[str, Any]) -> None:
        for upd in tribunal.get("state_updates", []):
            if upd.get("type") == "superior_coordinate_check" and upd.get("value") == "polynomial_finite_difference":
                for inv in invs:
                    if inv.name == "linear_recurrence":
                        inv.final_score -= 20
                        inv.dominated_by = "polynomial_finite_difference"
                        inv.attack_surface.append("Binding tribunal demoted recurrence: polynomial coordinate detected.")
            if upd.get("type") == "characteristic_factorization":
                for inv in invs:
                    if inv.name == "linear_recurrence":
                        inv.evidence["tribunal_characteristic_factorization"] = upd.get("value")

    def _theorem_score(self, routes: List[Dict[str, Any]]) -> float:
        if not routes:
            return 0.0
        vals = []
        for r in routes:
            st = r.get("status")
            if st in ("eligible", "eligible_unless_exceptions"):
                vals.append(90.0)
            elif st == "candidate":
                vals.append(65.0)
            elif st in ("blocked", "fail"):
                vals.append(20.0)
            else:
                vals.append(45.0)
        return max(vals) if vals else 0.0

    def _proof_obligations(self, routes: List[Dict[str, Any]]) -> List[str]:
        out: List[str] = []
        for r in routes:
            out.extend(r.get("proof_obligations", []))
        # Preserve order, dedupe
        seen = set(); dedup = []
        for x in out:
            if x not in seen:
                seen.add(x); dedup.append(x)
        return dedup[:12]

    def _attack_surface(self, inv: CandidateInvariant, fals: Dict[str, Any]) -> List[str]:
        attacks = []
        for name, result in fals.get("tests", {}).items():
            if result.get("pass") is False:
                attacks.append(f"Failed falsifier {name}: {result.get('reason') or result.get('trap') or result}")
        if inv.dominated_by:
            attacks.append(f"Dominated by superior coordinate {inv.dominated_by}.")
        for r in inv.theorem_routes:
            if any(c.get("status") == "open" for c in r.get("conditions", [])):
                attacks.append(f"Open theorem conditions remain on route {r.get('route')}.")
        return attacks[:12]

    def jigsaw(self, invs: List[CandidateInvariant], action_result: ActionResult) -> Dict[str, Any]:
        if not invs:
            return {"level": "not_visible", "score": 0, "picture": "No invariant survived", "missing_pieces": ["new coordinates"]}
        top = invs[0]
        score = 0
        reasons = []
        if top.truth_score >= 99:
            score += 2; reasons.append("exact on observed substrate")
        if top.explanatory_score >= 95:
            score += 2; reasons.append("high explanatory primacy")
        if top.adversarial_score >= 80:
            score += 2; reasons.append("hostile falsifiers mostly survived")
        if top.theorem_score >= 80:
            score += 2; reasons.append("eligible theorem route exists")
        if not top.dominated_by:
            score += 1; reasons.append("not dominated by superior coordinate")
        # Do not let jigsaw pass if open theorem conditions would change the picture.
        open_conditions = []
        for r in top.theorem_routes:
            open_conditions += [c for c in r.get("conditions", []) if c.get("status") == "open"]
        missing = top.proof_obligations[:4] + [f"Open condition: {c.get('condition')}" for c in open_conditions[:4]] + top.attack_surface[:4]
        if score >= 7 and not top.dominated_by:
            level = "jigsaw_visible"
        elif score >= 4:
            level = "forming"
        else:
            level = "not_visible"
        return {"level": level, "score": score, "picture": top.claim, "reasons": reasons, "missing_pieces": missing or ["formal all-n proof"]}

    def gth(self, invs: List[CandidateInvariant], jigsaw: Dict[str, Any]) -> Dict[str, Any]:
        if not invs:
            return {"fires": False, "reason": "no invariant"}
        top = invs[0]
        # Hardening: no GTH if dominated, theorem route untested when theorem needed, adversarial weak, or jigsaw not visible.
        if top.dominated_by:
            return {"fires": False, "reason": f"top invariant is dominated by {top.dominated_by}", "claim": "No GTH"}
        if jigsaw.get("level") != "jigsaw_visible":
            return {"fires": False, "reason": "jigsaw not visible", "claim": "No GTH"}
        if top.adversarial_score < 80:
            return {"fires": False, "reason": "adversarial survival below threshold", "claim": "No GTH"}
        # Polynomial exact small examples can fire because the right coordinate is simple and not dominated.
        fires = top.final_score >= 86 and top.truth_score >= 99
        return {
            "fires": fires,
            "claim": top.claim if fires else "No GTH",
            "stake": f"Best-coordinate invariant is {top.name} with final_score={top.final_score}; predictive alternatives were checked for dominance.",
            "attack_surface": top.attack_surface,
            "referee_target": top.proof_obligations[0] if top.proof_obligations else "formal proof of invariant on intended infinite domain",
            "reason": "earned" if fires else "score/criterion not earned",
        }

    def run_rounds(self, seq: Sequence[int], label: str, rounds: int = 5) -> Dict[str, Any]:
        binary: Optional[str] = None
        reports = []
        actions = []
        for r in range(1, rounds + 1):
            action = self.kbk.choose_action(r, binary, {})
            actions.append(action)
            report = self.analyze_sequence(seq, f"{label}_r{r}", round_no=r, binary=binary, action=action, write=True)
            reports.append(report)
            binary = report["kbk_packet"]["next_binary"]
        fake_loop = len(set(actions)) == 1 and rounds > 1
        summary = {
            "version": VERSION,
            "label": label,
            "rounds": rounds,
            "actions": actions,
            "fake_loop_detected": fake_loop,
            "final_packet": reports[-1]["kbk_packet"],
            "final_gth": reports[-1]["gth"],
            "round_run_ids": [r["run_id"] for r in reports],
        }
        (self.out_dir / f"{self._safe(label)}_run_summary.json").write_text(stable_json(summary))
        (self.out_dir / f"{self._safe(label)}_run_summary.md").write_text("# Oracle NT OS V4 run summary\n\n```json\n" + stable_json(summary) + "\n```\n")
        return summary

    def analyze_object(self, obj: NTObject, write: bool = True) -> Dict[str, Any]:
        self.db.upsert_object(obj)
        if obj.kind == "sequence":
            return self.analyze_sequence(obj.payload["sequence"], obj.label, write=write)
        if obj.kind == "crt_cover":
            lab = CRTCoverLab(self.out_dir / "crt")
            return lab.analyze(int(obj.payload["base1"]), int(obj.payload["base2"]), int(obj.payload.get("c", 1)), int(obj.payload.get("max_modulus", 200)))
        if obj.kind == "diophantine_square":
            return self.diophantine_square_probe(obj)
        report = {"version": VERSION, "object": dataclasses.asdict(obj), "verdict": "raw_object_stored", "next_binary": "define coordinates OR reject object"}
        if write:
            (self.out_dir / f"{self._safe(obj.label)}_raw_object.json").write_text(stable_json(report))
        return report

    def diophantine_square_probe(self, obj: NTObject) -> Dict[str, Any]:
        # Minimal object-type placeholder that actually measures small solutions for x^2 + c = y^n style payloads.
        c = int(obj.payload.get("c", 1))
        max_x = int(obj.payload.get("max_x", 200))
        max_n = int(obj.payload.get("max_n", 8))
        sols = []
        for x in range(max_x + 1):
            val = x*x + c
            for n in range(2, max_n + 1):
                y = round(val ** (1.0/n))
                for yy in range(max(0, y-1), y+2):
                    if yy ** n == val:
                        sols.append({"x": x, "y": yy, "n": n, "equation": f"{x}^2+{c}={yy}^{n}"})
        report = {"object": dataclasses.asdict(obj), "solutions": sols, "theorem_routes": ["Mordell/Catalan/modular method depending on n and c"], "next_binary": "finite exceptional set OR infinite family"}
        (self.out_dir / f"{self._safe(obj.label)}_diophantine.json").write_text(stable_json(report))
        return report

    def write_report(self, report: Dict[str, Any], stem: Path) -> None:
        Path(str(stem) + ".json").write_text(stable_json(report))
        Path(str(stem) + ".kbk.json").write_text(stable_json(report["kbk_packet"]))
        Path(str(stem) + ".md").write_text(self.markdown(report))

    def markdown(self, r: Dict[str, Any]) -> str:
        lines = [
            f"# Oracle NT OS V4 Report — {r['object']['label']}", "",
            f"Version: `{VERSION}`", f"Round: `{r['round_no']}`", f"Action: `{r['action']}`", f"Binary: **{r['binary']}**", "",
            "## GTH", f"Fires: **{r['gth']['fires']}**", f"Reason: {r['gth'].get('reason')}", f"Claim: {r['gth'].get('claim')}", f"Referee target: {r['gth'].get('referee_target')}", "",
            "## Jigsaw", f"Level: **{r['jigsaw']['level']}** | score `{r['jigsaw']['score']}`", f"Picture: {r['jigsaw']['picture']}", "Missing pieces:",
        ]
        lines += [f"- {m}" for m in r['jigsaw'].get('missing_pieces', [])]
        lines += ["", "## Ranked invariants"]
        for inv in r["ranked_invariants"][:10]:
            lines += [f"### {inv['name']} — final {inv['final_score']}", f"Coordinate: `{inv['coordinate']}` | class `{inv['claim_class']}`", inv["claim"], f"Dominated by: `{inv.get('dominated_by')}`", "Proof obligations:"]
            lines += [f"- {o}" for o in inv.get("proof_obligations", [])[:8]]
            lines += ["Attack surface:"] + [f"- {a}" for a in inv.get("attack_surface", [])[:8]] + [""]
        lines += ["## Action result", "```json", stable_json(r["action_result"]), "```", "", "## Tribunal", "```json", stable_json(r["external_tribunal"]), "```", "", "## KBK", "```json", stable_json(r["kbk_packet"]), "```", ""]
        return "\n".join(lines)

    def _safe(self, s: str) -> str:
        return re.sub(r"[^A-Za-z0-9_.-]+", "_", s)[:80] or "object"

# ---------------------------------------------------------------------------
# CRT covering-sieve lab V4
# ---------------------------------------------------------------------------


class CRTCoverLab:
    def __init__(self, out_dir: Path):
        self.out_dir = ensure_dir(out_dir)

    def analyze(self, b1: int, b2: int, c: int, max_modulus: int = 200) -> Dict[str, Any]:
        primes = [p for p in primes_upto(max_modulus) if p > 2 and math.gcd(p, b1*b2) == 1]
        rows = []
        for p in primes:
            row = self.prime_torus(b1, b2, c, p)
            if row:
                rows.append(row)
        useful = [r for r in rows if r["zero_count"] > 0]
        cover = self.combined_cover(useful[:10])
        lift = self.prime_power_lift_scan(b1, b2, c, useful[:8])
        verdict = self.verdict(cover, lift)
        report = {
            "version": VERSION,
            "expression": f"{b1}^k * {b2}^l + ({c})",
            "prime_rows": rows,
            "useful_prime_count": len(useful),
            "combined_cover": cover,
            "prime_power_lift_scan": lift,
            "verdict": verdict,
            "proof_obligations": [
                "If finite torus coverage reaches 1, prove CRT compatibility and lift-composability across prime powers.",
                "If coverage plateaus below 1, turn uncovered residue class into non-cover certificate or add a structurally new modulus family.",
                "Separate finite torus coverage from infinite orbit prime-forcing; one does not imply the other.",
            ],
        }
        (self.out_dir / "crt_lab_v4_report.json").write_text(stable_json(report))
        (self.out_dir / "crt_lab_v4_report.md").write_text(self.markdown(report))
        return report

    def prime_torus(self, b1: int, b2: int, c: int, p: int) -> Optional[Dict[str, Any]]:
        o1 = self.multiplicative_order(b1 % p, p)
        o2 = self.multiplicative_order(b2 % p, p)
        if not o1 or not o2:
            return None
        zeros = []
        for k in range(o1):
            a = pow(b1, k, p)
            for ell in range(o2):
                if (a * pow(b2, ell, p) + c) % p == 0:
                    zeros.append((k, ell))
        return {"p": p, "ord_b1": o1, "ord_b2": o2, "torus_size": o1*o2, "zero_count": len(zeros), "coverage": len(zeros)/(o1*o2), "zeros": zeros[:500]}

    def combined_cover(self, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not rows:
            return {"status": "no_useful_moduli"}
        K = lcm_list([r["ord_b1"] for r in rows])
        L = lcm_list([r["ord_b2"] for r in rows])
        if K * L > 300000:
            return {"status": "torus_too_large", "K": K, "L": L, "total": K*L}
        covered = set()
        curve = []
        for r in rows:
            zset = set(map(tuple, r["zeros"]))
            for k in range(K):
                for ell in range(L):
                    if (k % r["ord_b1"], ell % r["ord_b2"]) in zset:
                        covered.add((k, ell))
            curve.append({"p": r["p"], "covered": len(covered), "total": K*L, "coverage": len(covered)/(K*L)})
        uncovered_sample = []
        for k in range(K):
            for ell in range(L):
                if (k, ell) not in covered:
                    uncovered_sample.append((k, ell))
                    if len(uncovered_sample) >= 20:
                        break
            if len(uncovered_sample) >= 20:
                break
        return {"status": "computed", "K": K, "L": L, "total": K*L, "covered": len(covered), "coverage": len(covered)/(K*L), "saturation_curve": curve, "uncovered_sample": uncovered_sample}

    def prime_power_lift_scan(self, b1: int, b2: int, c: int, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        out = []
        for r in rows:
            p = r["p"]
            pp = p*p
            if math.gcd(pp, b1*b2) != 1:
                continue
            o1 = self.multiplicative_order_mod(b1 % pp, pp, limit=pp)
            o2 = self.multiplicative_order_mod(b2 % pp, pp, limit=pp)
            if not o1 or not o2 or o1*o2 > 50000:
                out.append({"p": p, "p2": pp, "status": "too_large_or_no_order", "ord_b1_p2": o1, "ord_b2_p2": o2})
                continue
            zeros = 0
            for k in range(o1):
                a = pow(b1, k, pp)
                for ell in range(o2):
                    if (a * pow(b2, ell, pp) + c) % pp == 0:
                        zeros += 1
            out.append({"p": p, "p2": pp, "status": "computed", "ord_b1_p2": o1, "ord_b2_p2": o2, "zero_count_p2": zeros, "coverage_p2": zeros/(o1*o2)})
        return out

    def multiplicative_order(self, a: int, p: int) -> Optional[int]:
        return self.multiplicative_order_mod(a, p, limit=p)

    def multiplicative_order_mod(self, a: int, m: int, limit: int) -> Optional[int]:
        if math.gcd(a, m) != 1:
            return None
        cur = 1
        for k in range(1, limit + 1):
            cur = (cur * a) % m
            if cur == 1:
                return k
        return None

    def verdict(self, cover: Dict[str, Any], lift: List[Dict[str, Any]]) -> str:
        if cover.get("status") != "computed":
            return "NO_COVER_VERDICT_TORUS_NOT_COMPUTED"
        if cover.get("coverage") == 1.0:
            bad_lifts = [x for x in lift if x.get("status") == "computed" and x.get("zero_count_p2", 0) == 0]
            if bad_lifts:
                return "FINITE_COVER_BUT_LIFT_OBSTRUCTION_FOUND"
            return "FINITE_COVER_CANDIDATE_REQUIRES_GLOBAL_LIFT_PROOF"
        return "FINITE_TORUS_NOT_COVERED_UNCOVERED_CLASSES_EXIST"

    def markdown(self, r: Dict[str, Any]) -> str:
        lines = [f"# CRT Cover Lab V4 — `{r['expression']}`", "", f"Verdict: **{r['verdict']}**", "", "## Combined cover", "```json", stable_json(r["combined_cover"]), "```", "", "## Prime-power lift scan", "```json", stable_json(r["prime_power_lift_scan"]), "```", "", "## Proof obligations"]
        lines += [f"- {x}" for x in r["proof_obligations"]]
        return "\n".join(lines) + "\n"

# ---------------------------------------------------------------------------
# Benchmark gauntlet
# ---------------------------------------------------------------------------


class BenchmarkGauntlet:
    def __init__(self, out_dir: Path):
        self.out_dir = ensure_dir(out_dir)

    def run(self) -> Dict[str, Any]:
        engine = OracleNTOSEngine(self.out_dir / "runs", self.out_dir / "benchmark_corpus.sqlite")
        cases = self.cases()
        results = []
        for case in cases:
            report = engine.analyze_sequence(case["seq"], case["label"], write=True)
            top = report["ranked_invariants"][0]["name"] if report["ranked_invariants"] else None
            gth = report["gth"]["fires"]
            ok_top = top == case["expected_top"]
            ok_no_bad_gth = (not case.get("forbid_gth")) or (not gth)
            results.append({"label": case["label"], "expected_top": case["expected_top"], "actual_top": top, "top_pass": ok_top, "gth_fires": gth, "gth_policy_pass": ok_no_bad_gth, "pass": ok_top and ok_no_bad_gth})
        summary = {"version": VERSION, "passed": sum(1 for r in results if r["pass"]), "total": len(results), "results": results}
        (self.out_dir / "benchmark_summary.json").write_text(stable_json(summary))
        (self.out_dir / "benchmark_summary.md").write_text("# Oracle NT OS V4 benchmark\n\n```json\n" + stable_json(summary) + "\n```\n")
        return summary

    def cases(self) -> List[Dict[str, Any]]:
        fib = [1,1]
        for _ in range(16): fib.append(fib[-1]+fib[-2])
        luc = [2,1]
        for _ in range(16): luc.append(luc[-1]+luc[-2])
        squares = [n*n for n in range(18)]
        triangular = [n*(n+1)//2 for n in range(18)]
        powers2 = [2**n for n in range(18)]
        poisoned_squares = [n*n for n in range(17)] + [17*17 + 1]
        periodic = [1,2,0,1,2,0,1,2,0,1,2,0]
        return [
            {"label": "fibonacci", "seq": fib, "expected_top": "linear_recurrence"},
            {"label": "lucas", "seq": luc, "expected_top": "linear_recurrence"},
            {"label": "squares", "seq": squares, "expected_top": "polynomial_finite_difference"},
            {"label": "triangular", "seq": triangular, "expected_top": "polynomial_finite_difference"},
            {"label": "powers2", "seq": powers2, "expected_top": "geometric_exponential"},
            {"label": "poisoned_squares", "seq": poisoned_squares, "expected_top": "valuation_profile", "forbid_gth": True},
            {"label": "periodic", "seq": periodic, "expected_top": "linear_recurrence"},
        ]

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def cmd_analyze_seq(args: argparse.Namespace) -> None:
    seq = parse_int_sequence(args.seq)
    engine = OracleNTOSEngine(Path(args.out), Path(args.db) if args.db else None)
    report = engine.analyze_sequence(seq, args.label, round_no=args.round, binary=args.binary)
    print(stable_json({"status": "ok", "run_id": report["run_id"], "top": report["ranked_invariants"][0]["name"] if report["ranked_invariants"] else None, "gth": report["gth"], "out": args.out}))


def cmd_run(args: argparse.Namespace) -> None:
    seq = parse_int_sequence(args.seq)
    engine = OracleNTOSEngine(Path(args.out), Path(args.db) if args.db else None)
    summary = engine.run_rounds(seq, args.label, args.rounds)
    print(stable_json(summary))


def cmd_benchmark(args: argparse.Namespace) -> None:
    summary = BenchmarkGauntlet(Path(args.out)).run()
    print(stable_json(summary))


def cmd_selftest(args: argparse.Namespace) -> None:
    out = Path(args.out)
    ensure_dir(out)
    summary = BenchmarkGauntlet(out / "gauntlet").run()
    # Specific regression: squares must be polynomial and recurrence demoted.
    engine = OracleNTOSEngine(out / "regression")
    squares = [n*n for n in range(18)]
    rep = engine.analyze_sequence(squares, "squares_regression", write=True)
    top = rep["ranked_invariants"][0]["name"]
    recs = [i for i in rep["ranked_invariants"] if i["name"] == "linear_recurrence"]
    recurrence_demoted = bool(recs and recs[0].get("dominated_by") == "polynomial_finite_difference")
    run = engine.run_rounds([1,1,2,3,5,8,13,21,34,55,89,144,233], "fib_selftest", 5)
    ok = summary["passed"] == summary["total"] and top == "polynomial_finite_difference" and recurrence_demoted and not run["fake_loop_detected"]
    result = {"selftest": "PASS" if ok else "FAIL", "version": VERSION, "benchmark": summary["passed"], "benchmark_total": summary["total"], "squares_top": top, "recurrence_demoted_on_squares": recurrence_demoted, "fake_loop_detected": run["fake_loop_detected"]}
    print(stable_json(result))
    if not ok:
        raise SystemExit(1)


def cmd_crt(args: argparse.Namespace) -> None:
    report = CRTCoverLab(Path(args.out)).analyze(args.base1, args.base2, args.c, args.max_modulus)
    print(stable_json({"status": "ok", "verdict": report["verdict"], "out": args.out}))


def cmd_ingest(args: argparse.Namespace) -> None:
    payload = json.loads(args.object)
    engine = OracleNTOSEngine(Path(args.out), Path(args.db) if args.db else None)
    obj = engine.ingest_object(payload, args.label)
    report = engine.analyze_object(obj)
    print(stable_json({"status": "ok", "object_id": obj.object_id, "kind": obj.kind, "summary": report if len(stable_json(report)) < 2000 else "report written"}))


def cmd_corpus(args: argparse.Namespace) -> None:
    db = CorpusStore(Path(args.db))
    print(stable_json(db.list_objects()))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Oracle Number Theory OS V4")
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("analyze-seq")
    a.add_argument("--seq", required=True)
    a.add_argument("--label", default="sequence")
    a.add_argument("--out", default="oracle_nt_v4_out")
    a.add_argument("--db", default=None)
    a.add_argument("--round", type=int, default=1)
    a.add_argument("--binary", default=None)
    a.set_defaults(func=cmd_analyze_seq)
    r = sub.add_parser("run")
    r.add_argument("--seq", required=True)
    r.add_argument("--label", default="sequence")
    r.add_argument("--out", default="oracle_nt_v4_out")
    r.add_argument("--db", default=None)
    r.add_argument("--rounds", type=int, default=5)
    r.set_defaults(func=cmd_run)
    b = sub.add_parser("benchmark")
    b.add_argument("--out", default="oracle_nt_v4_benchmark")
    b.set_defaults(func=cmd_benchmark)
    s = sub.add_parser("selftest")
    s.add_argument("--out", default="oracle_nt_v4_selftest")
    s.set_defaults(func=cmd_selftest)
    c = sub.add_parser("crt-lab")
    c.add_argument("--base1", type=int, required=True)
    c.add_argument("--base2", type=int, required=True)
    c.add_argument("--c", type=int, default=1)
    c.add_argument("--max-modulus", type=int, default=200)
    c.add_argument("--out", default="oracle_nt_v4_crt")
    c.set_defaults(func=cmd_crt)
    i = sub.add_parser("ingest")
    i.add_argument("--object", required=True, help="JSON object payload")
    i.add_argument("--label", default="object")
    i.add_argument("--out", default="oracle_nt_v4_out")
    i.add_argument("--db", default=None)
    i.set_defaults(func=cmd_ingest)
    l = sub.add_parser("corpus-list")
    l.add_argument("--db", required=True)
    l.set_defaults(func=cmd_corpus)
    return p


def main(argv: Optional[List[str]] = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
