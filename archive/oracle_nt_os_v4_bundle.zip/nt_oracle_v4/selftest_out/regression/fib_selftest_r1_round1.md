# Oracle NT OS V4 Report — fib_selftest_r1

Version: `4.0.0-oracle-nt-os`
Round: `1`
Action: `primary_invariant_hierarchy`
Binary: **primary invariant OR prefix artifact**

## GTH
Fires: **True**
Reason: earned
Claim: Sequence satisfies an exact order-2 constant-coefficient linear recurrence.
Referee target: Prove detected recurrence holds for all n by deriving it from the defining object.

## Jigsaw
Level: **jigsaw_visible** | score `7`
Picture: Sequence satisfies an exact order-2 constant-coefficient linear recurrence.
Missing pieces:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Normalize recurrence into Lucas or Lehmer form.
- Open condition: minimal order proven
- Open condition: primitive divisor exception range checked
- Open condition: index convention handles a_0/zero terms
- Open condition: identify x,y with p | x-y or p | x+y
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route lucas_zsigmondy_bhv.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Ranked invariants
### linear_recurrence — final 90.76
Coordinate: `linear_recurrence` | class `E`
Sequence satisfies an exact order-2 constant-coefficient linear recurrence.
Dominated by: `None`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Normalize recurrence into Lucas or Lehmer form.
- Check Bilu-Hanrot-Voutier/Zsigmondy exception indices explicitly.
- Prove nondegeneracy of root quotient in the exact number field.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route lucas_zsigmondy_bhv.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### valuation_profile — final 63.32
Coordinate: `p_adic` | class `COMP`
Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['linear_recurrence', 'linear_recurrence', 'linear_recurrence']}
- Failed falsifier holdout_prediction: no predictor compiled
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### rational_generating_function — final 62.14
Coordinate: `rational_generating_function` | class `E`
Sequence has a rational generating function induced by the detected recurrence.
Dominated by: `linear_recurrence`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Normalize recurrence into Lucas or Lehmer form.
- Check Bilu-Hanrot-Voutier/Zsigmondy exception indices explicitly.
- Prove nondegeneracy of root quotient in the exact number field.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['linear_recurrence', 'linear_recurrence', 'linear_recurrence']}
- Dominated by superior coordinate linear_recurrence.
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route lucas_zsigmondy_bhv.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### modular_finite_state — final 58.32
Coordinate: `modular_dynamics` | class `COMP`
Sequence exhibits finite-state modular periods across 1 tested moduli.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['linear_recurrence', 'linear_recurrence', 'linear_recurrence']}
- Failed falsifier holdout_prediction: no predictor compiled
- Failed falsifier constructed_trap_resistance: Modular periods may be shadows of stronger recurrence.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Action result
```json
{
  "action": "primary_invariant_hierarchy",
  "killed_routes": [],
  "raw_output": {
    "ranked_invariants_initial": [
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence satisfies an exact order-2 constant-coefficient linear recurrence.",
        "claim_class": "E",
        "coordinate": "linear_recurrence",
        "dominated_by": null,
        "evidence": {
          "characteristic": "x**2 - x - 1",
          "coefficients": [
            "1",
            "1"
          ],
          "exact_on_input": true,
          "order": 2
        },
        "explanatory_score": 92.0,
        "final_score": 89.68,
        "name": "linear_recurrence",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence has a rational generating function induced by the detected recurrence.",
        "claim_class": "E",
        "coordinate": "rational_generating_function",
        "dominated_by": "linear_recurrence",
        "evidence": {
          "P_coeffs": [
            "1",
            "0"
          ],
          "Q_coeffs": [
            "1",
            "-1",
            "-1"
          ],
          "form": "A(x)=P(x)/Q(x)"
        },
        "explanatory_score": 88.0,
        "final_score": 80.32,
        "name": "rational_generating_function",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.",
        "claim_class": "COMP",
        "coordinate": "p_adic",
        "dominated_by": null,
        "evidence": {
          "11": {
            "max": 1,
            "nontrivial": false,
            "nonzero_count": 1,
            "values": [
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0
            ]
          },
          "2": {
            "max": 4,
            "nontrivial": true,
            "nonzero_count": 4,
            "values": [
              0,
              0,
              1,
              0,
              0,
              3,
              0,
              0,
              1,
              0,
              0,
              4,
              0
            ]
          },
          "3": {
            "max": 2,
            "nontrivial": true,
            "nonzero_count": 3,
            "values": [
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              2,
              0
            ]
          },
          "5": {
            "max": 1,
            "nontrivial": false,
            "nonzero_count": 2,
            "values": [
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0
            ]
          },
          "7": {
            "max": 1,
            "nontrivial": false,
            "nonzero_count": 1,
            "values": [
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0
            ]
          }
        },
        "explanatory_score": 74.0,
        "final_score": 66.32,
        "name": "valuation_profile",
        "novelty_score": 50.0,
        "prediction_score": 65.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 62.0,
        "truth_score": 65.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence exhibits finite-state modular periods across 1 tested moduli.",
        "claim_class": "COMP",
        "coordinate": "modular_dynamics",
        "dominated_by": null,
        "evidence": {
          "periods": [
            {
              "modulus": 2,
              "period": 3,
              "residue_prefix": [
                1,
                1,
                0,
                1,
                1,
                0
              ]
            }
          ]
        },
        "explanatory_score": 76.5,
        "final_score": 54.01,
        "name": "modular_finite_state",
        "novelty_score": 50.0,
        "prediction_score": 60.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 0.0,
        "truth_score": 60.0
      }
    ]
  },
  "state_updates": {
    "primary_coordinate": "linear_recurrence"
  }
}
```

## Tribunal
```json
{
  "files": {
    "lean": "/mnt/data/nt_oracle_v4/selftest_out/regression/handoffs/fib_selftest_r1_round1.lean",
    "pari_gp": "/mnt/data/nt_oracle_v4/selftest_out/regression/handoffs/fib_selftest_r1_round1.gp",
    "sage": "/mnt/data/nt_oracle_v4/selftest_out/regression/handoffs/fib_selftest_r1_round1.sage"
  },
  "internal": {
    "state_updates": [
      {
        "binding_effect": "route recurrence/minimality/degeneracy checks",
        "type": "characteristic_factorization",
        "value": "x**2 - x - 1"
      }
    ],
    "status": "complete"
  },
  "lean_check": {
    "binding": false,
    "note": "Lean skeleton emitted with `sorry` proof debts; absence does not validate proof.",
    "status": "not_installed"
  },
  "pari_gp_run": {
    "binding": false,
    "status": "not_installed"
  },
  "sage_run": {
    "binding": false,
    "status": "not_installed"
  },
  "state_updates": [
    {
      "binding_effect": "route recurrence/minimality/degeneracy checks",
      "type": "characteristic_factorization",
      "value": "x**2 - x - 1"
    }
  ],
  "tools": {
    "gp": null,
    "lean": null,
    "sage": null
  }
}
```

## KBK
```json
{
  "action": "primary_invariant_hierarchy",
  "binary": "primary invariant OR prefix artifact",
  "gth_ready": true,
  "jigsaw_piece": "Sequence satisfies an exact order-2 constant-coefficient linear recurrence.",
  "killed_routes": [],
  "missing_piece": "Prove detected recurrence holds for all n by deriving it from the defining object.",
  "next_binary": "superior coordinate exists OR detected invariant is primary",
  "round_no": 1,
  "strongest_invariant": "linear_recurrence",
  "verdict": "CLOSURE"
}
```
