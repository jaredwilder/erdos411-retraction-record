# Oracle NT OS V4 run summary

```json
{
  "actions": [
    "primary_invariant_hierarchy",
    "coordinate_dominance_audit",
    "coordinate_dominance_audit",
    "coordinate_dominance_audit",
    "coordinate_dominance_audit"
  ],
  "fake_loop_detected": false,
  "final_gth": {
    "attack_surface": [
      "Open theorem conditions remain on route linear_recurrence_rational_gf.",
      "Open theorem conditions remain on route lucas_zsigmondy_bhv.",
      "Open theorem conditions remain on route strong_divisibility.",
      "Open theorem conditions remain on route lte."
    ],
    "claim": "Sequence satisfies an exact order-2 constant-coefficient linear recurrence.",
    "fires": true,
    "reason": "earned",
    "referee_target": "Prove detected recurrence holds for all n by deriving it from the defining object.",
    "stake": "Best-coordinate invariant is linear_recurrence with final_score=90.76; predictive alternatives were checked for dominance."
  },
  "final_packet": {
    "action": "coordinate_dominance_audit",
    "binary": "minimal theorem route closes OR coordinate is only predictive",
    "gth_ready": true,
    "jigsaw_piece": "Sequence satisfies an exact order-2 constant-coefficient linear recurrence.",
    "killed_routes": [
      {
        "reason": "Dominated by superior coordinate linear_recurrence. Predictive is not primary.",
        "route": "rational_generating_function"
      }
    ],
    "missing_piece": "Prove detected recurrence holds for all n by deriving it from the defining object.",
    "next_binary": "minimal theorem route closes OR coordinate is only predictive",
    "round_no": 5,
    "strongest_invariant": "linear_recurrence",
    "verdict": "CLOSURE"
  },
  "label": "fib_selftest",
  "round_run_ids": [
    "6fe05c24083055a29090",
    "50a36d44f062c40c4874",
    "00e2a57182e9ea1d71a9",
    "9912a3dd3fb5c5fdc161",
    "5a9c02915ca7d5b9dede"
  ],
  "rounds": 5,
  "version": "4.0.0-oracle-nt-os"
}
```
