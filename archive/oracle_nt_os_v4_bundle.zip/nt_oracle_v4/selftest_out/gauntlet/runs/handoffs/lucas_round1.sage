# Oracle NT OS V4 Sage tribunal
seq = [2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199, 322, 521, 843, 1364, 2207, 3571]
print('ORACLE_SAGE_BEGIN')
print('n_terms', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('finite_differences')
    cur = seq[:]
    for k in range(min(8, len(seq)-1)):
        print(k, cur[:12])
        cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]
except Exception as e:
    print('sage_error', e)
print('ORACLE_SAGE_END')
