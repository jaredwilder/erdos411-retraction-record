\ Oracle NT OS V4 PARI/GP tribunal
seq = [2, 1, 3, 4, 7, 11, 18, 29, 47, 76, 123, 199, 322, 521, 843, 1364, 2207, 3571];
print("ORACLE_GP_BEGIN");
print("n_terms=", #seq);
for(i=1,min(#seq,12), print(i-1, ":", factor(abs(seq[i]))));
print("ORACLE_GP_END");
quit;
