\ Oracle NT OS V4 PARI/GP tribunal
seq = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072];
print("ORACLE_GP_BEGIN");
print("n_terms=", #seq);
for(i=1,min(#seq,12), print(i-1, ":", factor(abs(seq[i]))));
print("ORACLE_GP_END");
quit;
