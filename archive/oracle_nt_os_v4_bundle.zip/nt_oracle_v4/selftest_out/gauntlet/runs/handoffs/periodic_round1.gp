\ Oracle NT OS V4 PARI/GP tribunal
seq = [1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0];
print("ORACLE_GP_BEGIN");
print("n_terms=", #seq);
for(i=1,min(#seq,12), print(i-1, ":", factor(abs(seq[i]))));
print("ORACLE_GP_END");
quit;
