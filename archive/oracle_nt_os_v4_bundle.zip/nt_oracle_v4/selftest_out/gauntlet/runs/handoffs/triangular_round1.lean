import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120, 136, 153]

/-- Proof debt: show the 2-th finite difference is constant for all n. -/
def a (n : Nat) : Int := 0  -- replace with discovered closed form
theorem finite_difference_certificate : True := by
  -- TODO: replace `True` with Δ^d a n = C after importing/defining finite-difference operator
  trivial
theorem polynomial_law_all_n : ∀ n : Nat, a n = a n := by
  intro n
  rfl

end OracleNT
