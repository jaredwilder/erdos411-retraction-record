import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 290]

/-- No theorem-shaped invariant reached yet. -/
theorem no_primary_obligation_yet : True := by trivial

end OracleNT
