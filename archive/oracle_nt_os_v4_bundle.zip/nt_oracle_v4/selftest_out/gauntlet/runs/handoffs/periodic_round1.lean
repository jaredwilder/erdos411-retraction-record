import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0]

/-- Proof debt: replace a with defining object and prove recurrence globally. -/
def a (n : Nat) : Int := 0
/-- Candidate recurrence order: 3, coefficients: ['0', '0', '1'] -/
theorem recurrence_holds : ∀ n : Nat, a (n+2) = a (n+1) + a n := by
  -- TODO: this statement is only correct for Fibonacci-like order-2 routes; compiler emits a proof debt, not a proof
  intro n
  sorry

end OracleNT
