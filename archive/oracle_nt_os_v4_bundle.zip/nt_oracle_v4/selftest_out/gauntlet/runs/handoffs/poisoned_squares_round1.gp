\ Oracle NT OS V4 PARI/GP tribunal
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 290];
print("ORACLE_GP_BEGIN");
print("n_terms=", #seq);
for(i=1,min(#seq,12), print(i-1, ":", factor(abs(seq[i]))));
print("ORACLE_GP_END");
quit;
