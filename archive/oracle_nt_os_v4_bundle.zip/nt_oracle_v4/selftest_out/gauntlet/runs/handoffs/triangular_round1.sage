# Oracle NT OS V4 Sage tribunal
seq = [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120, 136, 153]
print('ORACLE_SAGE_BEGIN')
print('n_terms', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('finite_differences')
    cur = seq[:]
    for k in range(min(8, len(seq)-1)):
        print(k, cur[:12])
        cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]
except Exception as e:
    print('sage_error', e)
print('ORACLE_SAGE_END')
