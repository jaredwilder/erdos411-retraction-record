\ Oracle NT OS V4 PARI/GP tribunal
seq = [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120, 136, 153];
print("ORACLE_GP_BEGIN");
print("n_terms=", #seq);
for(i=1,min(#seq,12), print(i-1, ":", factor(abs(seq[i]))));
print("ORACLE_GP_END");
quit;
