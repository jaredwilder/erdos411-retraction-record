# Oracle NT OS V4 Sage tribunal
seq = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072]
print('ORACLE_SAGE_BEGIN')
print('n_terms', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('finite_differences')
    cur = seq[:]
    for k in range(min(8, len(seq)-1)):
        print(k, cur[:12])
        cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]
except Exception as e:
    print('sage_error', e)
print('ORACLE_SAGE_END')
