# Oracle NT OS V4 Sage tribunal
seq = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584]
print('ORACLE_SAGE_BEGIN')
print('n_terms', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('finite_differences')
    cur = seq[:]
    for k in range(min(8, len(seq)-1)):
        print(k, cur[:12])
        cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]
except Exception as e:
    print('sage_error', e)
print('ORACLE_SAGE_END')
