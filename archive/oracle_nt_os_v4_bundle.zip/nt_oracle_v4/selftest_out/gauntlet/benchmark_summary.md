# Oracle NT OS V4 benchmark

```json
{
  "passed": 6,
  "results": [
    {
      "actual_top": "linear_recurrence",
      "expected_top": "linear_recurrence",
      "gth_fires": true,
      "gth_policy_pass": true,
      "label": "fibonacci",
      "pass": true,
      "top_pass": true
    },
    {
      "actual_top": "linear_recurrence",
      "expected_top": "linear_recurrence",
      "gth_fires": true,
      "gth_policy_pass": true,
      "label": "lucas",
      "pass": true,
      "top_pass": true
    },
    {
      "actual_top": "polynomial_finite_difference",
      "expected_top": "polynomial_finite_difference",
      "gth_fires": true,
      "gth_policy_pass": true,
      "label": "squares",
      "pass": true,
      "top_pass": true
    },
    {
      "actual_top": "polynomial_finite_difference",
      "expected_top": "polynomial_finite_difference",
      "gth_fires": true,
      "gth_policy_pass": true,
      "label": "triangular",
      "pass": true,
      "top_pass": true
    },
    {
      "actual_top": "geometric_exponential",
      "expected_top": "geometric_exponential",
      "gth_fires": true,
      "gth_policy_pass": true,
      "label": "powers2",
      "pass": true,
      "top_pass": true
    },
    {
      "actual_top": "valuation_profile",
      "expected_top": "linear_recurrence",
      "gth_fires": false,
      "gth_policy_pass": true,
      "label": "poisoned_squares",
      "pass": false,
      "top_pass": false
    },
    {
      "actual_top": "linear_recurrence",
      "expected_top": "linear_recurrence",
      "gth_fires": true,
      "gth_policy_pass": true,
      "label": "periodic",
      "pass": true,
      "top_pass": true
    }
  ],
  "total": 7,
  "version": "4.0.0-oracle-nt-os"
}
```
