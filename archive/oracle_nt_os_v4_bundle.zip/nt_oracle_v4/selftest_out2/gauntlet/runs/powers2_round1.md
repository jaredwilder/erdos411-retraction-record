# Oracle NT OS V4 Report — powers2

Version: `4.0.0-oracle-nt-os`
Round: `1`
Action: `primary_invariant_hierarchy`
Binary: **primary invariant OR prefix artifact**

## GTH
Fires: **True**
Reason: earned
Claim: Sequence is geometric after index 0 with ratio 2.
Referee target: Prove detected recurrence holds for all n by deriving it from the defining object.

## Jigsaw
Level: **jigsaw_visible** | score `9`
Picture: Sequence is geometric after index 0 with ratio 2.
Missing pieces:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Open condition: minimal order proven
- Open condition: index convention handles a_0/zero terms
- Open condition: identify x,y with p | x-y or p | x+y
- Open condition: parity and p=2 exception conditions
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Ranked invariants
### geometric_exponential — final 94.68
Coordinate: `geometric_exponential` | class `E`
Sequence is geometric after index 0 with ratio 2.
Dominated by: `None`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### valuation_profile — final 63.32
Coordinate: `p_adic` | class `COMP`
Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['geometric_exponential', 'geometric_exponential', 'geometric_exponential']}
- Failed falsifier holdout_prediction: no predictor compiled
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### rational_generating_function — final 62.980000000000004
Coordinate: `rational_generating_function` | class `E`
Sequence has a rational generating function induced by the detected recurrence.
Dominated by: `linear_recurrence`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['geometric_exponential', 'geometric_exponential', 'geometric_exponential']}
- Dominated by superior coordinate linear_recurrence.
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### modular_finite_state — final 58.08
Coordinate: `modular_dynamics` | class `COMP`
Sequence exhibits finite-state modular periods across 7 tested moduli.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['geometric_exponential', 'geometric_exponential', 'geometric_exponential']}
- Failed falsifier holdout_prediction: no predictor compiled
- Failed falsifier constructed_trap_resistance: Modular periods may be shadows of stronger recurrence.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### linear_recurrence — final 55.400000000000006
Coordinate: `linear_recurrence` | class `E`
Sequence satisfies an exact order-1 constant-coefficient linear recurrence.
Dominated by: `geometric_exponential`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Geometric law is a lower-dimensional explanation than generic recurrence.
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['geometric_exponential', 'geometric_exponential', 'geometric_exponential']}
- Failed falsifier extension_counterexample: {'pass': False, 'extended_top': 'geometric_exponential', 'extended_tail': [262144, 524288, 1048576, 2097152, 4194304]}
- Dominated by superior coordinate geometric_exponential.
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.
- Geometric law is a lower-dimensional explanation than generic recurrence.

## Action result
```json
{
  "action": "primary_invariant_hierarchy",
  "killed_routes": [],
  "raw_output": {
    "ranked_invariants_initial": [
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence is geometric after index 0 with ratio 2.",
        "claim_class": "E",
        "coordinate": "geometric_exponential",
        "dominated_by": null,
        "evidence": {
          "exact": true,
          "ratio": "2",
          "start_index": 0
        },
        "explanatory_score": 106.0,
        "final_score": 94.44,
        "name": "geometric_exponential",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [
          "linear_recurrence"
        ],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence has a rational generating function induced by the detected recurrence.",
        "claim_class": "E",
        "coordinate": "rational_generating_function",
        "dominated_by": "linear_recurrence",
        "evidence": {
          "P_coeffs": [
            "1"
          ],
          "Q_coeffs": [
            "1",
            "-2"
          ],
          "form": "A(x)=P(x)/Q(x)"
        },
        "explanatory_score": 91.0,
        "final_score": 81.34,
        "name": "rational_generating_function",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [
          "Geometric law is a lower-dimensional explanation than generic recurrence."
        ],
        "claim": "Sequence satisfies an exact order-1 constant-coefficient linear recurrence.",
        "claim_class": "E",
        "coordinate": "linear_recurrence",
        "dominated_by": "geometric_exponential",
        "evidence": {
          "characteristic": "x - 2",
          "coefficients": [
            "2"
          ],
          "exact_on_input": true,
          "order": 1
        },
        "explanatory_score": 95.0,
        "final_score": 76.7,
        "name": "linear_recurrence",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.",
        "claim_class": "COMP",
        "coordinate": "p_adic",
        "dominated_by": null,
        "evidence": {
          "11": {
            "max": 0,
            "nontrivial": false,
            "nonzero_count": 0,
            "values": [
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]
          },
          "2": {
            "max": 17,
            "nontrivial": true,
            "nonzero_count": 17,
            "values": [
              0,
              1,
              2,
              3,
              4,
              5,
              6,
              7,
              8,
              9,
              10,
              11,
              12,
              13,
              14,
              15,
              16,
              17
            ]
          },
          "3": {
            "max": 0,
            "nontrivial": false,
            "nonzero_count": 0,
            "values": [
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]
          },
          "5": {
            "max": 0,
            "nontrivial": false,
            "nonzero_count": 0,
            "values": [
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]
          },
          "7": {
            "max": 0,
            "nontrivial": false,
            "nonzero_count": 0,
            "values": [
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]
          }
        },
        "explanatory_score": 74.0,
        "final_score": 66.32,
        "name": "valuation_profile",
        "novelty_score": 50.0,
        "prediction_score": 65.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 62.0,
        "truth_score": 65.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence exhibits finite-state modular periods across 7 tested moduli.",
        "claim_class": "COMP",
        "coordinate": "modular_dynamics",
        "dominated_by": null,
        "evidence": {
          "periods": [
            {
              "modulus": 3,
              "period": 2,
              "residue_prefix": [
                1,
                2,
                1,
                2
              ]
            },
            {
              "modulus": 5,
              "period": 4,
              "residue_prefix": [
                1,
                2,
                4,
                3,
                1,
                2,
                4,
                3
              ]
            },
            {
              "modulus": 7,
              "period": 3,
              "residue_prefix": [
                1,
                2,
                4,
                1,
                2,
                4
              ]
            },
            {
              "modulus": 9,
              "period": 6,
              "residue_prefix": [
                1,
                2,
                4,
                8,
                7,
                5,
                1,
                2,
                4,
                8,
                7,
                5
              ]
            },
            {
              "modulus": 15,
              "period": 4,
              "residue_prefix": [
                1,
                2,
                4,
                8,
                1,
                2,
                4,
                8
              ]
            },
            {
              "modulus": 17,
              "period": 8,
              "residue_prefix": [
                1,
                2,
                4,
                8,
                16,
                15,
                13,
                9,
                1,
                2,
                4,
                8,
                16,
                15,
                13,
                9
              ]
            },
            {
              "modulus": 21,
              "period": 6,
              "residue_prefix": [
                1,
                2,
                4,
                8,
                16,
                11,
                1,
                2,
                4,
                8,
                16,
                11
              ]
            }
          ]
        },
        "explanatory_score": 75.64285714285714,
        "final_score": 53.719,
        "name": "modular_finite_state",
        "novelty_score": 50.0,
        "prediction_score": 60.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 0.0,
        "truth_score": 60.0
      }
    ]
  },
  "state_updates": {
    "primary_coordinate": "geometric_exponential"
  }
}
```

## Tribunal
```json
{
  "files": {
    "lean": "/mnt/data/nt_oracle_v4/selftest_out2/gauntlet/runs/handoffs/powers2_round1.lean",
    "pari_gp": "/mnt/data/nt_oracle_v4/selftest_out2/gauntlet/runs/handoffs/powers2_round1.gp",
    "sage": "/mnt/data/nt_oracle_v4/selftest_out2/gauntlet/runs/handoffs/powers2_round1.sage"
  },
  "internal": {
    "state_updates": [
      {
        "binding_effect": "route recurrence/minimality/degeneracy checks",
        "type": "characteristic_factorization",
        "value": "x - 2"
      }
    ],
    "status": "complete"
  },
  "lean_check": {
    "binding": false,
    "note": "Lean skeleton emitted with `sorry` proof debts; absence does not validate proof.",
    "status": "not_installed"
  },
  "pari_gp_run": {
    "binding": false,
    "status": "not_installed"
  },
  "sage_run": {
    "binding": false,
    "status": "not_installed"
  },
  "state_updates": [
    {
      "binding_effect": "route recurrence/minimality/degeneracy checks",
      "type": "characteristic_factorization",
      "value": "x - 2"
    }
  ],
  "tools": {
    "gp": null,
    "lean": null,
    "sage": null
  }
}
```

## KBK
```json
{
  "action": "primary_invariant_hierarchy",
  "binary": "primary invariant OR prefix artifact",
  "gth_ready": true,
  "jigsaw_piece": "Sequence is geometric after index 0 with ratio 2.",
  "killed_routes": [],
  "missing_piece": "Prove detected recurrence holds for all n by deriving it from the defining object.",
  "next_binary": "superior coordinate exists OR detected invariant is primary",
  "round_no": 1,
  "strongest_invariant": "geometric_exponential",
  "verdict": "CLOSURE"
}
```
