import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072]

/-- Proof debt: replace `a` with the defining object and prove recurrence globally. -/
def a (n : Nat) : Int := 0
/-- Candidate recurrence order: 1, coefficients: ['2']. -/
theorem recurrence_holds_candidate : ∀ n : Nat, a n = a n := by
  -- TODO: compile exact coefficient recurrence into Lean syntax.
  intro n
  rfl

end OracleNT
