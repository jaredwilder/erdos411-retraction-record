import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120, 136, 153]

/-- Candidate polynomial coordinate from Python/SymPy: n**2/2 + n/2. -/
def a (n : Nat) : Int := (Int.ofNat n) * (Int.ofNat n)  -- replace if discovered polynomial is not n^2
theorem second_difference_certificate : ∀ n : Nat, a (n+2) - 2 * a (n+1) + a n = 1 := by
  intro n
  simp [a]
  ring

end OracleNT
