import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121, 144, 169, 196, 225, 256, 289]

/-- Candidate polynomial coordinate from Python/SymPy: n**2. -/
def a (n : Nat) : Int := (Int.ofNat n) * (Int.ofNat n)  -- replace if discovered polynomial is not n^2
theorem second_difference_certificate : ∀ n : Nat, a (n+2) - 2 * a (n+1) + a n = 2 := by
  intro n
  simp [a]
  ring

end OracleNT
