import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0]

/-- Proof debt: replace `a` with the defining object and prove recurrence globally. -/
def a (n : Nat) : Int := 0
/-- Candidate recurrence order: 3, coefficients: ['0', '0', '1']. -/
theorem recurrence_holds_candidate : ∀ n : Nat, a n = a n := by
  -- TODO: compile exact coefficient recurrence into Lean syntax.
  intro n
  rfl

end OracleNT
