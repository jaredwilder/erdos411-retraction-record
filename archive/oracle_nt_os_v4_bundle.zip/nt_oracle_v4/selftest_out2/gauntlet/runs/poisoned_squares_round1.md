# Oracle NT OS V4 Report — poisoned_squares

Version: `4.0.0-oracle-nt-os`
Round: `1`
Action: `primary_invariant_hierarchy`
Binary: **primary invariant OR prefix artifact**

## GTH
Fires: **False**
Reason: jigsaw not visible
Claim: No GTH
Referee target: None

## Jigsaw
Level: **not_visible** | score `1`
Picture: Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.
Missing pieces:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
- Open condition: index convention handles a_0/zero terms
- Open condition: identify x,y with p | x-y or p | x+y
- Open condition: parity and p=2 exception conditions
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['polynomial_finite_difference', 'polynomial_finite_difference', 'polynomial_finite_difference']}
- Failed falsifier holdout_prediction: no predictor compiled
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Ranked invariants
### valuation_profile — final 63.32
Coordinate: `p_adic` | class `COMP`
Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['polynomial_finite_difference', 'polynomial_finite_difference', 'polynomial_finite_difference']}
- Failed falsifier holdout_prediction: no predictor compiled
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Action result
```json
{
  "action": "primary_invariant_hierarchy",
  "killed_routes": [],
  "raw_output": {
    "ranked_invariants_initial": [
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.",
        "claim_class": "COMP",
        "coordinate": "p_adic",
        "dominated_by": null,
        "evidence": {
          "11": {
            "max": 2,
            "nontrivial": false,
            "nonzero_count": 1,
            "values": [
              null,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              0,
              0
            ]
          },
          "2": {
            "max": 8,
            "nontrivial": true,
            "nonzero_count": 9,
            "values": [
              null,
              0,
              2,
              0,
              4,
              0,
              2,
              0,
              6,
              0,
              2,
              0,
              4,
              0,
              2,
              0,
              8,
              1
            ]
          },
          "3": {
            "max": 4,
            "nontrivial": true,
            "nonzero_count": 5,
            "values": [
              null,
              0,
              0,
              2,
              0,
              0,
              2,
              0,
              0,
              4,
              0,
              0,
              2,
              0,
              0,
              2,
              0,
              0
            ]
          },
          "5": {
            "max": 2,
            "nontrivial": true,
            "nonzero_count": 4,
            "values": [
              null,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              2,
              0,
              1
            ]
          },
          "7": {
            "max": 2,
            "nontrivial": false,
            "nonzero_count": 2,
            "values": [
              null,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0
            ]
          }
        },
        "explanatory_score": 74.0,
        "final_score": 66.32,
        "name": "valuation_profile",
        "novelty_score": 50.0,
        "prediction_score": 65.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 62.0,
        "truth_score": 65.0
      }
    ]
  },
  "state_updates": {
    "primary_coordinate": "valuation_profile"
  }
}
```

## Tribunal
```json
{
  "files": {
    "lean": "/mnt/data/nt_oracle_v4/selftest_out2/gauntlet/runs/handoffs/poisoned_squares_round1.lean",
    "pari_gp": "/mnt/data/nt_oracle_v4/selftest_out2/gauntlet/runs/handoffs/poisoned_squares_round1.gp",
    "sage": "/mnt/data/nt_oracle_v4/selftest_out2/gauntlet/runs/handoffs/poisoned_squares_round1.sage"
  },
  "internal": {
    "state_updates": [],
    "status": "complete"
  },
  "lean_check": {
    "binding": false,
    "note": "Lean skeleton emitted with `sorry` proof debts; absence does not validate proof.",
    "status": "not_installed"
  },
  "pari_gp_run": {
    "binding": false,
    "status": "not_installed"
  },
  "sage_run": {
    "binding": false,
    "status": "not_installed"
  },
  "state_updates": [],
  "tools": {
    "gp": null,
    "lean": null,
    "sage": null
  }
}
```

## KBK
```json
{
  "action": "primary_invariant_hierarchy",
  "binary": "primary invariant OR prefix artifact",
  "gth_ready": false,
  "jigsaw_piece": "Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.",
  "killed_routes": [],
  "missing_piece": "Prove strong divisibility identity for all m,n or identify exact failure set.",
  "next_binary": "superior coordinate exists OR detected invariant is primary",
  "round_no": 1,
  "strongest_invariant": "valuation_profile",
  "verdict": "ESCALATION"
}
```
