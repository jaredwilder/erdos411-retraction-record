import Mathlib

namespace OracleNT

/-- Observed prefix. This is data, not a proof of the infinite claim. -/
def observed : List Int := [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233]

/-- Proof debt: replace `a` with the defining object and prove recurrence globally. -/
def a (n : Nat) : Int := 0
/-- Candidate recurrence order: 2, coefficients: ['1', '1']. -/
theorem recurrence_holds : ∀ n : Nat, a (n+2) = a (n+1) + a n := by
  -- TODO: prove from the actual definition of `a`; `sorry` marks a real proof debt.
  intro n
  sorry

end OracleNT
