# Oracle NT OS V4 Report — fib_selftest_r2

Version: `4.0.0-oracle-nt-os`
Round: `2`
Action: `coordinate_dominance_audit`
Binary: **superior coordinate exists OR detected invariant is primary**

## GTH
Fires: **True**
Reason: earned
Claim: Sequence satisfies an exact order-2 constant-coefficient linear recurrence.
Referee target: Prove detected recurrence holds for all n by deriving it from the defining object.

## Jigsaw
Level: **jigsaw_visible** | score `7`
Picture: Sequence satisfies an exact order-2 constant-coefficient linear recurrence.
Missing pieces:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Normalize recurrence into Lucas or Lehmer form.
- Open condition: minimal order proven
- Open condition: primitive divisor exception range checked
- Open condition: index convention handles a_0/zero terms
- Open condition: identify x,y with p | x-y or p | x+y
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route lucas_zsigmondy_bhv.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Ranked invariants
### linear_recurrence — final 90.76
Coordinate: `linear_recurrence` | class `E`
Sequence satisfies an exact order-2 constant-coefficient linear recurrence.
Dominated by: `None`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Normalize recurrence into Lucas or Lehmer form.
- Check Bilu-Hanrot-Voutier/Zsigmondy exception indices explicitly.
- Prove nondegeneracy of root quotient in the exact number field.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route lucas_zsigmondy_bhv.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### valuation_profile — final 63.32
Coordinate: `p_adic` | class `COMP`
Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['linear_recurrence', 'linear_recurrence', 'linear_recurrence']}
- Failed falsifier holdout_prediction: no predictor compiled
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### rational_generating_function — final 62.14
Coordinate: `rational_generating_function` | class `E`
Sequence has a rational generating function induced by the detected recurrence.
Dominated by: `linear_recurrence`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Normalize recurrence into Lucas or Lehmer form.
- Check Bilu-Hanrot-Voutier/Zsigmondy exception indices explicitly.
- Prove nondegeneracy of root quotient in the exact number field.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['linear_recurrence', 'linear_recurrence', 'linear_recurrence']}
- Dominated by superior coordinate linear_recurrence.
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route lucas_zsigmondy_bhv.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### modular_finite_state — final 58.32
Coordinate: `modular_dynamics` | class `COMP`
Sequence exhibits finite-state modular periods across 1 tested moduli.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['linear_recurrence', 'linear_recurrence', 'linear_recurrence']}
- Failed falsifier holdout_prediction: no predictor compiled
- Failed falsifier constructed_trap_resistance: Modular periods may be shadows of stronger recurrence.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Action result
```json
{
  "action": "coordinate_dominance_audit",
  "killed_routes": [
    {
      "reason": "Dominated by superior coordinate linear_recurrence. Predictive is not primary.",
      "route": "rational_generating_function"
    }
  ],
  "raw_output": {
    "dominance": [
      {
        "dominated_by": null,
        "name": "linear_recurrence",
        "superior_to": []
      },
      {
        "dominated_by": "linear_recurrence",
        "name": "rational_generating_function",
        "superior_to": []
      },
      {
        "dominated_by": null,
        "name": "valuation_profile",
        "superior_to": []
      },
      {
        "dominated_by": null,
        "name": "modular_finite_state",
        "superior_to": []
      }
    ]
  },
  "state_updates": {}
}
```

## Tribunal
```json
{
  "files": {
    "lean": "/mnt/data/nt_oracle_v4/selftest_out2/regression/handoffs/fib_selftest_r2_round2.lean",
    "pari_gp": "/mnt/data/nt_oracle_v4/selftest_out2/regression/handoffs/fib_selftest_r2_round2.gp",
    "sage": "/mnt/data/nt_oracle_v4/selftest_out2/regression/handoffs/fib_selftest_r2_round2.sage"
  },
  "internal": {
    "state_updates": [
      {
        "binding_effect": "route recurrence/minimality/degeneracy checks",
        "type": "characteristic_factorization",
        "value": "x**2 - x - 1"
      }
    ],
    "status": "complete"
  },
  "lean_check": {
    "binding": false,
    "note": "Lean skeleton emitted with `sorry` proof debts; absence does not validate proof.",
    "status": "not_installed"
  },
  "pari_gp_run": {
    "binding": false,
    "status": "not_installed"
  },
  "sage_run": {
    "binding": false,
    "status": "not_installed"
  },
  "state_updates": [
    {
      "binding_effect": "route recurrence/minimality/degeneracy checks",
      "type": "characteristic_factorization",
      "value": "x**2 - x - 1"
    }
  ],
  "tools": {
    "gp": null,
    "lean": null,
    "sage": null
  }
}
```

## KBK
```json
{
  "action": "coordinate_dominance_audit",
  "binary": "superior coordinate exists OR detected invariant is primary",
  "gth_ready": true,
  "jigsaw_piece": "Sequence satisfies an exact order-2 constant-coefficient linear recurrence.",
  "killed_routes": [
    {
      "reason": "Dominated by superior coordinate linear_recurrence. Predictive is not primary.",
      "route": "rational_generating_function"
    }
  ],
  "missing_piece": "Prove detected recurrence holds for all n by deriving it from the defining object.",
  "next_binary": "minimal theorem route closes OR coordinate is only predictive",
  "round_no": 2,
  "strongest_invariant": "linear_recurrence",
  "verdict": "CLOSURE"
}
```
