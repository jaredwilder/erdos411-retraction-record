# Oracle NT OS V4 run summary

```json
{
  "actions": [
    "primary_invariant_hierarchy",
    "coordinate_dominance_audit",
    "coordinate_dominance_audit",
    "coordinate_dominance_audit",
    "coordinate_dominance_audit"
  ],
  "fake_loop_detected": false,
  "final_gth": {
    "attack_surface": [
      "Open theorem conditions remain on route linear_recurrence_rational_gf.",
      "Open theorem conditions remain on route lucas_zsigmondy_bhv.",
      "Open theorem conditions remain on route strong_divisibility.",
      "Open theorem conditions remain on route lte."
    ],
    "claim": "Sequence satisfies an exact order-2 constant-coefficient linear recurrence.",
    "fires": true,
    "reason": "earned",
    "referee_target": "Prove detected recurrence holds for all n by deriving it from the defining object.",
    "stake": "Best-coordinate invariant is linear_recurrence with final_score=90.76; predictive alternatives were checked for dominance."
  },
  "final_packet": {
    "action": "coordinate_dominance_audit",
    "binary": "minimal theorem route closes OR coordinate is only predictive",
    "gth_ready": true,
    "jigsaw_piece": "Sequence satisfies an exact order-2 constant-coefficient linear recurrence.",
    "killed_routes": [
      {
        "reason": "Dominated by superior coordinate linear_recurrence. Predictive is not primary.",
        "route": "rational_generating_function"
      }
    ],
    "missing_piece": "Prove detected recurrence holds for all n by deriving it from the defining object.",
    "next_binary": "minimal theorem route closes OR coordinate is only predictive",
    "round_no": 5,
    "strongest_invariant": "linear_recurrence",
    "verdict": "CLOSURE"
  },
  "label": "fib_selftest",
  "round_run_ids": [
    "fed58efb40be0c8de4a7",
    "51f2ca95eb9a31cede28",
    "fc34a5bbedbe6f7f75a5",
    "a63a5eb4029e1062df13",
    "c91036851f3204ab2dbd"
  ],
  "rounds": 5,
  "version": "4.0.0-oracle-nt-os"
}
```
