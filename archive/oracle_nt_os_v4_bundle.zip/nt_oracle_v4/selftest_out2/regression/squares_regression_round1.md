# Oracle NT OS V4 Report — squares_regression

Version: `4.0.0-oracle-nt-os`
Round: `1`
Action: `primary_invariant_hierarchy`
Binary: **primary invariant OR prefix artifact**

## GTH
Fires: **True**
Reason: earned
Claim: Sequence is governed by a degree-2 polynomial / constant 2-th finite difference law.
Referee target: Prove Δ^2 a_n is constant on the intended domain, not only the observed prefix.

## Jigsaw
Level: **jigsaw_visible** | score `9`
Picture: Sequence is governed by a degree-2 polynomial / constant 2-th finite difference law.
Missing pieces:
- Prove Δ^2 a_n is constant on the intended domain, not only the observed prefix.
- Express a_n in the binomial coefficient basis from initial finite differences.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
- Open condition: derive polynomial in binomial basis
- Open condition: index convention handles a_0/zero terms
- Open condition: identify x,y with p | x-y or p | x+y
- Open condition: parity and p=2 exception conditions
- Open theorem conditions remain on route finite_difference_polynomial.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Ranked invariants
### polynomial_finite_difference — final 93.56
Coordinate: `polynomial_finite_difference` | class `E`
Sequence is governed by a degree-2 polynomial / constant 2-th finite difference law.
Dominated by: `None`
Proof obligations:
- Prove Δ^2 a_n is constant on the intended domain, not only the observed prefix.
- Express a_n in the binomial coefficient basis from initial finite differences.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Open theorem conditions remain on route finite_difference_polynomial.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### strong_divisibility — final 78.96
Coordinate: `divisibility_law` | class `COMP`
Sequence behaves as a strong divisibility sequence on tested indices.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['polynomial_finite_difference', 'polynomial_finite_difference', 'polynomial_finite_difference']}
- Failed falsifier holdout_prediction: no predictor compiled
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### valuation_profile — final 68.32
Coordinate: `p_adic` | class `COMP`
Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['polynomial_finite_difference', 'polynomial_finite_difference', 'polynomial_finite_difference']}
- Failed falsifier holdout_prediction: no predictor compiled
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### modular_finite_state — final 63.071
Coordinate: `modular_dynamics` | class `COMP`
Sequence exhibits finite-state modular periods across 9 tested moduli.
Dominated by: `None`
Proof obligations:
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['polynomial_finite_difference', 'polynomial_finite_difference', 'polynomial_finite_difference']}
- Failed falsifier holdout_prediction: no predictor compiled
- Failed falsifier constructed_trap_resistance: Modular periods may be shadows of stronger recurrence.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### rational_generating_function — final 61.3
Coordinate: `rational_generating_function` | class `E`
Sequence has a rational generating function induced by the detected recurrence.
Dominated by: `linear_recurrence`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['polynomial_finite_difference', 'polynomial_finite_difference', 'polynomial_finite_difference']}
- Dominated by superior coordinate linear_recurrence.
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

### linear_recurrence — final 22.120000000000005
Coordinate: `linear_recurrence` | class `E`
Sequence satisfies an exact order-3 constant-coefficient linear recurrence.
Dominated by: `polynomial_finite_difference`
Proof obligations:
- Prove detected recurrence holds for all n by deriving it from the defining object.
- Prove minimality of recurrence order or explicitly demote to non-primary coordinate.
- Factor characteristic polynomial and classify degeneracy/root ratios.
- Prove strong divisibility identity for all m,n or identify exact failure set.
- Fit valuation law to LTE hypotheses and isolate exception primes.
Attack surface:
- Predictive recurrence is not primary coordinate; polynomial finite difference is simpler and more explanatory.
- Failed falsifier prefix_stability: {'pass': False, 'top_names_by_prefix': ['polynomial_finite_difference', 'polynomial_finite_difference', 'polynomial_finite_difference']}
- Failed falsifier constructed_trap_resistance: Finite-difference polynomial gives superior coordinate; recurrence is predictive but dominated.
- Failed falsifier extension_counterexample: {'pass': False, 'extended_top': 'polynomial_finite_difference', 'extended_tail': [324, 361, 400, 441, 484]}
- Dominated by superior coordinate polynomial_finite_difference.
- Open theorem conditions remain on route linear_recurrence_rational_gf.
- Open theorem conditions remain on route strong_divisibility.
- Open theorem conditions remain on route lte.

## Action result
```json
{
  "action": "primary_invariant_hierarchy",
  "killed_routes": [],
  "raw_output": {
    "ranked_invariants_initial": [
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence is governed by a degree-2 polynomial / constant 2-th finite difference law.",
        "claim_class": "E",
        "coordinate": "polynomial_finite_difference",
        "dominated_by": null,
        "evidence": {
          "coefficients_low_to_high": [
            "0",
            "0",
            "1"
          ],
          "constant_difference": 2,
          "degree": 2,
          "finite_difference_certificate": {
            "order": 2,
            "row_start": [
              2,
              2,
              2,
              2,
              2,
              2,
              2,
              2,
              2,
              2
            ]
          },
          "polynomial": "n**2"
        },
        "explanatory_score": 102.0,
        "final_score": 93.08,
        "name": "polynomial_finite_difference",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [
          "linear_recurrence"
        ],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence behaves as a strong divisibility sequence on tested indices.",
        "claim_class": "COMP",
        "coordinate": "divisibility_law",
        "dominated_by": null,
        "evidence": {
          "failures": [],
          "ok": 289,
          "success_rate": 1.0,
          "tested_pairs": 289
        },
        "explanatory_score": 82.0,
        "final_score": 83.04,
        "name": "strong_divisibility",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 62.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence has a rational generating function induced by the detected recurrence.",
        "claim_class": "E",
        "coordinate": "rational_generating_function",
        "dominated_by": "linear_recurrence",
        "evidence": {
          "P_coeffs": [
            "0",
            "1",
            "1"
          ],
          "Q_coeffs": [
            "1",
            "-3",
            "3",
            "-1"
          ],
          "form": "A(x)=P(x)/Q(x)"
        },
        "explanatory_score": 85.0,
        "final_score": 79.3,
        "name": "rational_generating_function",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [
          "Predictive recurrence is not primary coordinate; polynomial finite difference is simpler and more explanatory."
        ],
        "claim": "Sequence satisfies an exact order-3 constant-coefficient linear recurrence.",
        "claim_class": "E",
        "coordinate": "linear_recurrence",
        "dominated_by": "polynomial_finite_difference",
        "evidence": {
          "characteristic": "(x - 1)**3",
          "coefficients": [
            "3",
            "-3",
            "1"
          ],
          "exact_on_input": true,
          "order": 3
        },
        "explanatory_score": 89.0,
        "final_score": 66.66,
        "name": "linear_recurrence",
        "novelty_score": 50.0,
        "prediction_score": 100.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 80.0,
        "truth_score": 100.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence has nontrivial p-adic valuation structure requiring LTE / formal group routing.",
        "claim_class": "COMP",
        "coordinate": "p_adic",
        "dominated_by": null,
        "evidence": {
          "11": {
            "max": 2,
            "nontrivial": false,
            "nonzero_count": 1,
            "values": [
              null,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              0,
              0
            ]
          },
          "2": {
            "max": 8,
            "nontrivial": true,
            "nonzero_count": 8,
            "values": [
              null,
              0,
              2,
              0,
              4,
              0,
              2,
              0,
              6,
              0,
              2,
              0,
              4,
              0,
              2,
              0,
              8,
              0
            ]
          },
          "3": {
            "max": 4,
            "nontrivial": true,
            "nonzero_count": 5,
            "values": [
              null,
              0,
              0,
              2,
              0,
              0,
              2,
              0,
              0,
              4,
              0,
              0,
              2,
              0,
              0,
              2,
              0,
              0
            ]
          },
          "5": {
            "max": 2,
            "nontrivial": false,
            "nonzero_count": 3,
            "values": [
              null,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              2,
              0,
              0
            ]
          },
          "7": {
            "max": 2,
            "nontrivial": false,
            "nonzero_count": 2,
            "values": [
              null,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0
            ]
          }
        },
        "explanatory_score": 74.0,
        "final_score": 66.32,
        "name": "valuation_profile",
        "novelty_score": 50.0,
        "prediction_score": 65.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 62.0,
        "truth_score": 65.0
      },
      {
        "adversarial_score": 0.0,
        "attack_surface": [],
        "claim": "Sequence exhibits finite-state modular periods across 9 tested moduli.",
        "claim_class": "COMP",
        "coordinate": "modular_dynamics",
        "dominated_by": null,
        "evidence": {
          "periods": [
            {
              "modulus": 2,
              "period": 2,
              "residue_prefix": [
                0,
                1,
                0,
                1
              ]
            },
            {
              "modulus": 3,
              "period": 3,
              "residue_prefix": [
                0,
                1,
                1,
                0,
                1,
                1
              ]
            },
            {
              "modulus": 4,
              "period": 2,
              "residue_prefix": [
                0,
                1,
                0,
                1
              ]
            },
            {
              "modulus": 5,
              "period": 5,
              "residue_prefix": [
                0,
                1,
                4,
                4,
                1,
                0,
                1,
                4,
                4,
                1
              ]
            },
            {
              "modulus": 6,
              "period": 6,
              "residue_prefix": [
                0,
                1,
                4,
                3,
                4,
                1,
                0,
                1,
                4,
                3,
                4,
                1
              ]
            },
            {
              "modulus": 7,
              "period": 7,
              "residue_prefix": [
                0,
                1,
                4,
                2,
                2,
                4,
                1,
                0,
                1,
                4,
                2,
                2,
                4,
                1
              ]
            },
            {
              "modulus": 8,
              "period": 4,
              "residue_prefix": [
                0,
                1,
                4,
                1,
                0,
                1,
                4,
                1
              ]
            },
            {
              "modulus": 12,
              "period": 6,
              "residue_prefix": [
                0,
                1,
                4,
                9,
                4,
                1,
                0,
                1,
                4,
                9,
                4,
                1
              ]
            },
            {
              "modulus": 16,
              "period": 8,
              "residue_prefix": [
                0,
                1,
                4,
                9,
                0,
                9,
                4,
                1,
                0,
                1,
                4,
                9,
                0,
                9,
                4,
                1
              ]
            }
          ]
        },
        "explanatory_score": 75.61111111111111,
        "final_score": 53.708,
        "name": "modular_finite_state",
        "novelty_score": 50.0,
        "prediction_score": 60.0,
        "proof_obligations": [],
        "superior_to": [],
        "theorem_routes": [],
        "theorem_score": 0.0,
        "truth_score": 60.0
      }
    ]
  },
  "state_updates": {
    "primary_coordinate": "polynomial_finite_difference"
  }
}
```

## Tribunal
```json
{
  "files": {
    "lean": "/mnt/data/nt_oracle_v4/selftest_out2/regression/handoffs/squares_regression_round1.lean",
    "pari_gp": "/mnt/data/nt_oracle_v4/selftest_out2/regression/handoffs/squares_regression_round1.gp",
    "sage": "/mnt/data/nt_oracle_v4/selftest_out2/regression/handoffs/squares_regression_round1.sage"
  },
  "internal": {
    "state_updates": [
      {
        "binding_effect": "route recurrence/minimality/degeneracy checks",
        "type": "characteristic_factorization",
        "value": "(x - 1)**3"
      },
      {
        "binding_effect": "demote generic recurrence if present",
        "type": "superior_coordinate_check",
        "value": "polynomial_finite_difference"
      }
    ],
    "status": "complete"
  },
  "lean_check": {
    "binding": false,
    "note": "Lean skeleton emitted with `sorry` proof debts; absence does not validate proof.",
    "status": "not_installed"
  },
  "pari_gp_run": {
    "binding": false,
    "status": "not_installed"
  },
  "sage_run": {
    "binding": false,
    "status": "not_installed"
  },
  "state_updates": [
    {
      "binding_effect": "route recurrence/minimality/degeneracy checks",
      "type": "characteristic_factorization",
      "value": "(x - 1)**3"
    },
    {
      "binding_effect": "demote generic recurrence if present",
      "type": "superior_coordinate_check",
      "value": "polynomial_finite_difference"
    }
  ],
  "tools": {
    "gp": null,
    "lean": null,
    "sage": null
  }
}
```

## KBK
```json
{
  "action": "primary_invariant_hierarchy",
  "binary": "primary invariant OR prefix artifact",
  "gth_ready": true,
  "jigsaw_piece": "Sequence is governed by a degree-2 polynomial / constant 2-th finite difference law.",
  "killed_routes": [],
  "missing_piece": "Prove \u0394^2 a_n is constant on the intended domain, not only the observed prefix.",
  "next_binary": "superior coordinate exists OR detected invariant is primary",
  "round_no": 1,
  "strongest_invariant": "polynomial_finite_difference",
  "verdict": "CLOSURE"
}
```
