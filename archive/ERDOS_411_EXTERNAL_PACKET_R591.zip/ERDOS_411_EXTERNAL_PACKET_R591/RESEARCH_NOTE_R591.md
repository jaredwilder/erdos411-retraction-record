# A Bounded Computational Certificate for the Exceptional Branches in Erdős Problem #411

**Prepared by:** Jared Wilder  
**Packet:** R591 external note  
**Status:** bounded computational-theoretical certificate package, not an infinite symbolic proof

---

## Abstract

Let \(g(n)=n+\varphi(n)\), and let \(g_k\) denote its iterates. Erdős Problem #411 asks for which \(n,r\) one has

\[
g_{k+r}(n)=2g_k(n)
\]

for all sufficiently large \(k\). Recent work on the \(r=2\) case identifies the six visible families

\[
2^a\{1,3,5,7,35,47\}
\]

and reduces possible further exceptions to sparse prime-filtered/totient channels.

This packet gives a bounded computational certificate for those exceptional channels. The main certified statements are:

\[
\varphi(m)=\frac23(m+1),\qquad \frac{4m+1}{3}\text{ prime},\qquad m<2^{64}
\Longrightarrow m\in\{5,35\},
\]

and, for the Cambie/prime-power tail,

\[
p\le10^6,\qquad 2\le t\le30,\qquad 4p^t\le10^{50}
\Longrightarrow
g_k(2p^t)\ne4p^t.
\]

The \(t=1\) tail is covered through the D-branch ledger up to

\[
p<24,595,658,764,946,068,820
\]

with survivors \(p=7,47\).

---

## 1. What this packet claims

This is a bounded computational-theoretical result.

It claims:

1. The prime-filtered totient-defect branch has no solutions below \(2^{64}\) beyond \(m=5,35\).
2. The \(t=1\) Cambie tail is covered by the D-branch ledger to the induced \(p\)-bound.
3. The \(t\ge2\) Cambie tail has no hits in the R591 chamber.
4. All previously unresolved R590 underflow cases in the R591 chamber were classified as overshoots by exact Python factorization.

It does **not** claim:

1. A complete infinite symbolic proof of Erdős #411.
2. A formal Lean proof.
3. A proof that no further exceptions exist outside the certified bounds.

---

## 2. D-branch certificate

The D-branch is

\[
\varphi(m)=\frac23(m+1),\qquad P=\frac{4m+1}{3}\text{ prime}.
\]

The certificate closes

\[
m<2^{64}.
\]

The output statement is:

\[
\boxed{
\varphi(m)=\frac23(m+1),\quad \frac{4m+1}{3}\text{ prime},\quad m<2^{64}
\Rightarrow m\in\{5,35\}.
}
\]

The core computational mechanism is a prefix-window/divisor-pair search using the identities:

\[
E(a)=\frac{3\varphi(a)-2a}{2},\qquad
p=1+\frac{a+1}{E(a)}
\]

and, for \(a=Br\),

\[
dT=B^2+AB+A,\qquad
r=1+\frac{B+d}{A},\qquad
p=1+\frac{B+T}{A}.
\]

All non-chain divisor births below the certified bound die by composite \(p\) or composite prime-filter \(P\).

---

## 3. Cambie tail certificate

The remaining tail has the form

\[
g_k(2p^t)=4p^t,\qquad p\equiv7\pmod8.
\]

For \(t=1\), the equation is equivalent to the D-branch ledger. This gives:

\[
p<24,595,658,764,946,068,820
\Longrightarrow
p\in\{7,47\}.
\]

For \(t\ge2\), R591 directly classified the chamber

\[
p\le1,000,000,\qquad 2\le t\le30,\qquad 4p^t\le10^{50}.
\]

R591 output:

```text
prime rows:              19,669
t-cases total:           148,345
step-2 hits:             0
step-2 underflow primes: 348
step-2 overflow primes:  19,321
x1 source births:        0
underflow t-cases:       2,662
underflow statuses:      {'OVERSHOOT': 2662}
bad cases:               0
```

Thus every R591 underflow case overshoots; there are no hits, no source births, no descent violations, and no unresolved caps.

---

## 4. Evidence files

The final handoff zip is included:

```text
ERDOS_411_FINAL_HANDOFF_R591.zip
ERDOS_411_FINAL_HANDOFF_R591.zip.sha256
```

Inside it:

```text
FINAL_WRITEUP_GTH.md
EXECUTIVE_GTH_STATEMENT.md
EVIDENCE_LEDGER.json
SHA256SUMS.txt
evidence/ORACLE_R591_FINAL_UNDERFLOW_CLASSIFIER_GTH_SUMMARY.md
evidence/oracle_r591_final_underflow_classifier_gth_report.json
evidence/oracle_r591_final_underflow_classifier_gth.py
evidence/oracle_r591_final_underflow_classifier_gth.sha256
evidence/ORACLE_R591_FINAL_UNDERFLOW_CLASSIFIER_GTH_ARTIFACTS.zip
```

---

## 5. Suggested reviewer ask

The best reviewer ask is not “please accept that Erdős #411 is solved.”

The right ask is:

> Can you audit whether this bounded certificate is correct, and whether the D-branch / Cambie-tail reductions are aligned with the exceptional channels in the current \(r=2\) analysis?

That is concrete, falsifiable, and respectful of the difference between a bounded certificate and an infinite proof.

---

## 6. One-sentence version

We certify, by reproducible Python/data artifacts, that the two exceptional channels currently left by the \(r=2\) analysis of Erdős #411 have no further solutions in the stated bounded chambers, supporting exactly the six known families \(2^a\{1,3,5,7,35,47\}\).
