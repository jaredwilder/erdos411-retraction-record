# Erdős #411: Winning Data One-Pager

## Headline now

A bounded computational certificate for the exceptional \(r=2\) branches in Erdős Problem #411.

## Hard data

- D-branch closed below \(2^{64}\): only \(m=5,35\).
- Cambie \(t=1\): covered by D-ledger up to \(p<24,595,658,764,946,068,820\), only \(p=7,47\).
- Cambie \(t\ge2\), R591: \(p\le10^6\), \(2\le t\le30\), \(4p^t\le10^{50}\): no hits.
- R591 classified all \(2,662\) underflow t-cases as overshoots.
- Step-2 hit is symbolically impossible for every prime \(p>3\).
- R592/R593/R595: every strict underflow prime \(p\le20,000,000\) overshoots by depth 3.
- Weakest multiplicative safety factor in the depth-3 inequality: 5.987722094488442.
- Largest required ratio: 0.06111855590513829.
- Smallest actual \(\phi(C_2)/C_2\): 0.19866506746258308.

## Internet-famous proof target

Prove:

\[
D>0 \Longrightarrow M=(p-1)\phi(C_2)-pD>0.
\]

That collapses the Cambie \(t\ge2\) tail.
