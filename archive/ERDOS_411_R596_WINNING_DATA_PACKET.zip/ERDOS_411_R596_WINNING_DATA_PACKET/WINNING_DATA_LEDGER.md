# R596 — Winning Data Ledger for Erdős #411

## Clean headline now

**A bounded computational certificate for the exceptional \(r=2\) branches in Erdős Problem #411.**

## Stronger headline we are chasing

**Completing the \(r=2\) case of Erdős Problem #411.**

---

# Winning data

## 1. D-branch

```text
Claim: phi(m)=2(m+1)/3 and (4m+1)/3 prime has no solutions below 2^64 except m=5,35.
Scope: m < 2^64
Status: bounded certified
```

Break it by finding:

```text
m < 2^64, m not in {5,35},
phi(m)=2(m+1)/3,
(4m+1)/3 prime.
```

No such \(m\) appears in the certificate ledger.

---

## 2. Cambie tail, t=1

```text
Covered by D-ledger.
p < 24,595,658,764,946,068,820
survivors: p = 7,47
```

---

## 3. Cambie tail, t>=2, R591 chamber

```text
p <= 1,000,000
2 <= t <= 30
4*p^t <= 10^50
```

R591 hard numbers:

```text
prime rows:              19669
t-cases total:           148345
step-2 hits:             0
step-2 underflow primes: 348
underflow t-cases:       2662
status counts:           {'OVERSHOOT': 2662}
bad cases:               0
```

Data verdict:

```text
No hits.
No source births.
No descent violations.
Every underflow overshoots.
No unresolved caps.
```

---

## 4. Symbolic theorem fragment

For \(t\ge2\), the step-2 hit equation is impossible for every prime \(p>3\).

A step-2 hit would require:

```text
phi(3p - 1) = p(p+1)/(p-1) = p + 2 + 2/(p-1)
```

For prime \(p>3\), this is not an integer.

Data verdict:

```text
Step-2 hit is dead symbolically.
```

---

## 5. Shock result: depth-3 overshoot

R592/R593/R595 chamber:

```text
p <= 20,000,000
p ≡ 7 mod 8
prime p tested:          317668
step-2 underflow primes: 5277
underflow overshoots:    5277
bad / unresolved:        0
max overshoot depth:     3
```

R593/R595 inequality voice:

```text
M positive:                       5277
M nonpositive:                    0
source in C2 count:               0
weakest multiplicative safety:    5.987722094488442
weakest safety p:                 10323647
largest required ratio:           0.06111855590513829
smallest actual phi(C2)/C2:       0.19866506746258308
weakest additive margin M:        496
```

Data verdict:

```text
Every strict underflow prime p<=20,000,000 overshoots by depth 3.
No failures.
No unresolved cases.
Weakest multiplicative safety is still almost 6x.
```

---

# The proof target now

Define:

```text
C1 = 3p - 1
C2 = p*C1 + (p - 1)*phi(C1)
D  = 4p^2 - C2
M  = (p - 1)*phi(C2) - p*D
```

The theorem to prove:

```text
For every prime p ≡ 7 mod 8, p>3:
if D>0, then M>0.
```

This theorem collapses the Cambie \(t\ge2\) tail.

---

# GTH

**Winning data is locked.**

This is not a random experiment pile anymore. It is:

1. a bounded certificate package;
2. a symbolic theorem fragment;
3. a shock chamber through \(p\le20,000,000\);
4. a one-inequality proof target.

The internet-famous headline is not earned yet as a theorem, but the path to it is now concrete.
