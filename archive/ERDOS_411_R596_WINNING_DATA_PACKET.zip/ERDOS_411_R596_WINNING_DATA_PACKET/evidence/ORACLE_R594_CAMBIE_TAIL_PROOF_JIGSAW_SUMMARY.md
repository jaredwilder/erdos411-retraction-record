# ORACLE R594 — Cambie Tail Proof Jigsaw

## Mission

Chase the internet-famous headline:

```text
Completing the r=2 case of Erdős Problem #411
```

This round attacks the Cambie `t>=2` tail by converting R593 into explicit theorem algebra.

## Extracted algebra

Let:

```text
C1 = 3p - 1
C2 = p*C1 + (p - 1)*phi(C1)
D  = 4p^2 - C2
delta = p + 1 - phi(3p - 1)
```

Python verified exactly:

```text
D = p + 1 + (p - 1)*delta
```

failures:

```text
0
```

Depth-3 overshoot is equivalent to:

```text
M = (p - 1)*phi(C2) - p*D > 0
```

## Chamber

```text
p <= 20,000,000
p ≡ 7 mod 8
```

Underflow records:

```text
5,277
```

## Critical statistics

```text
min M:                  496
arg min M p:            7
min phi(C2)/need:       5.987722094488442
arg min ratio p:        10323647
max D/p^2:              0.23039283911616348
arg max D/p^2 p:        2155487
min phi(C2)/C2:         0.19866506746258308
arg min phi ratio p:    13218407
max C2/phi(C2):         5.03359756585461
```

## Theorem target

For prime `p ≡ 7 mod 8`, define:

```text
delta = p + 1 - phi(3p - 1)
C2 = 4p^2 - p - 1 - (p - 1)*delta
```

If `delta >= 1`, prove:

```text
(p - 1)*phi(C2) > p * [p + 1 + (p - 1)*delta]
```

That completes the Cambie `t>=2` tail.

## GTH

This is now a one-inequality proof hunt.
