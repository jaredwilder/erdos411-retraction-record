# Ferrari 20-Round Science Packet

## Mother-safe summary

This packet is the clean version of the work. We stopped chasing impressive language and forced the machine to answer one narrow mathematical question. The result is not a global theorem yet, and it does not pretend to be. It is a real narrowed object: two nonunit diagonal residue cells, `(20,20)` and `(40,40)`, survive a large adversarial search because they sit inside two explicit protected subfibers. That is something to be proud of because the process removed the fake parts before keeping the real part.

## Earned verdict

`PROMOTE_PROTECTED_MOD20_SUBFIBER_OBJECT`

## The object we earned

- Active cells: `(20,20)` and `(40,40)` in the base `60 x 60` lattice.

- Parent family: `{5,7,11,13,17,31,41,61,241}`.

- Parent period: `120 x 240`.

- Protected subfiber for `(20,20)`: `k ≡ 80 mod 120`, `l ≡ 80 mod 240`.

- Protected subfiber for `(40,40)`: `k ≡ 40 mod 120`, `l ≡ 160 mod 240`.

## Twenty rounds

| Round | Binary/Test | Result | Verdict |
|---:|---|---|---|
| 01 | Runlock loaded | Used active state from RUNLOCK. No new framework. | Proceed |
| 02 | Classifier compression | q non-enlarging iff q divides gcd(2^K-1,3^L-1). | Promoted exact coordinate |
| 03 | Danger closure state | For {5,7,11}, danger primes are 13,31,61 and residual set is 1749. | Accepted starting state |
| 04 | Unit-cell cleanup | (0,0) demoted because N(0,0)=2 and all moduli are odd. | Removed junk |
| 05 | Nonunit target isolation | The live nonunit cells are (20,20) and (40,40). | Kept only nontrivial target |
| 06 | Parent family established | Parent family [5, 7, 11, 13, 17, 31, 41, 61, 241] has period 120 x 240. | Finite quotient fixed |
| 07 | Parent subfiber table | Each target cell has 8 subfibers in the parent quotient. | Measured |
| 08 | First target survivor | (20,20) has exactly one parent survivor: subfiber (80 mod 120, 80 mod 240). | Protected subfiber found |
| 09 | Second target survivor | (40,40) has exactly one parent survivor: subfiber (40 mod 120, 160 mod 240). | Protected subfiber found |
| 10 | Complement coverage | The other 14 target subfibers are covered by moduli 17, 41, and/or 241. | Exact finite table |
| 11 | Race8 replayed branches | 52 replayed q3 branches preserved the protected subfibers. | No destroyer |
| 12 | Race8 survivor concentration | 102964 surviving lifts across Race8 targets all lie in the protected subfibers. | No pattern exception |
| 13 | Race8 skipped branch pressure | 54 previously skipped branches still leave the simple protected seed uncovered. | Skip weakness reduced |
| 14 | Extended q3 search | 262 q3 primes from 1009 to 2999 tested for protected-subfiber existence. | No destroyer |
| 15 | Seed failure handled | For q3=1409 and 1697 the first seed can be covered, but the next protected lift survives. | Subfiber, not seed |
| 16 | Search effort compression | Median protected search found a lift in 1.0 try; max was 2 tries despite candidate spaces up to 2247001. | Strong practical signal |
| 17 | Protected-subfiber statement | The object is no longer vague mod-20 symmetry; it is two explicit protected subfibers. | Object sharpened |
| 18 | Referee value | A hostile reviewer can now attack a concrete finite quotient lemma, not a story. | Engageable |
| 19 | Limits recorded | No global theorem, no q3>2999, no unbounded depth, no all-cell result. | No overclaim |
| 20 | Next binary locked | Prove protected-subfiber preservation as a finite quotient lemma or find q3>2999 destroyer. | Next attack |

## Replay-backed numbers

- Race8 replayed q3 branches: `52`.

- Race8 surviving lifts across the two target cells: `102964`.

- Race8 pattern exceptions: `0`.

- Race8 skipped branches checked by simple protected seeds: `54`.

- Skipped branches where protected seeds failed: `0`.

- Extended q3 search: `262` primes from `1009` to `2999`.

- Extended search destroyers: `0`.

- Median tries to find protected lift: `1.0`. Max tries: `2`.

- Largest protected candidate space encountered: `2247001`.

## Exact parent subfiber table

| Cell | Lift | Subfiber | Survives? | Covering moduli |
|---|---|---|---|---|
| (20, 20) | (20, 20) | (20, 20) | False | [41] |
| (20, 20) | (20, 80) | (20, 80) | False | [17, 241] |
| (20, 20) | (20, 140) | (20, 140) | False | [41] |
| (20, 20) | (20, 200) | (20, 200) | False | [241] |
| (20, 20) | (80, 20) | (80, 20) | False | [41, 241] |
| (20, 20) | (80, 80) | (80, 80) | True | [] |
| (20, 20) | (80, 140) | (80, 140) | False | [41, 241] |
| (20, 20) | (80, 200) | (80, 200) | False | [17] |
| (40, 40) | (40, 40) | (40, 40) | False | [17] |
| (40, 40) | (40, 100) | (40, 100) | False | [41, 241] |
| (40, 40) | (40, 160) | (40, 160) | True | [] |
| (40, 40) | (40, 220) | (40, 220) | False | [41, 241] |
| (40, 40) | (100, 40) | (100, 40) | False | [241] |
| (40, 40) | (100, 100) | (100, 100) | False | [41] |
| (40, 40) | (100, 160) | (100, 160) | False | [17, 241] |
| (40, 40) | (100, 220) | (100, 220) | False | [41] |

## What this does not claim

- global theorem
- q3 primes above 2999
- unbounded recursive depth
- all residual cells
- formal proof

## Next locked binary

Can the protected subfiber preservation be proven as a finite quotient lemma, or does q3 beyond 2999 produce a first protected-subfiber destroyer?

## Why this is worth showing

The win is not that a final theorem appeared. The win is that the process stopped protecting ego. It demoted fake mysteries, deleted the trivial unit cell, isolated two nonunit targets, found their exact protected subfibers, and then stress-tested those subfibers beyond the previous bounds. That is scientific movement: smaller, cleaner, harder to fool.
