# ORACLE R593 — Depth-3 Overshoot Theorem Miner

## Mission

Mine the exact theorem behind R592:

```text
If step-2 underflows, depth-3 overshoots.
```

## Definitions

```text
C1 = 3p - 1
C2 = p*C1 + (p - 1)*phi(C1)
D  = 4p^2 - C2
C3 = p*C2 + (p - 1)*phi(C2)
```

Step-2 underflow means:

```text
D > 0
```

Depth-3 overshoot is equivalent to:

```text
C3 > 4p^3
```

Equivalently:

```text
M = (p - 1)*phi(C2) - p*D > 0
```

## Python chamber

```text
p <= 20,000,000
p ≡ 7 mod 8
```

## Results

```text
prime p tested:             317,668
underflow primes:           5,277
M positive:                 5,277
M nonpositive:              0
C3 margin positive:         5,277
C3 margin nonpositive:      0
source in C2 count:         0
```

## Extremes

```text
min M:                      496
arg min M p:                7
min C3 margin:              496
arg min C3 margin p:        7
max D:                      73956398535056
min M/p:                    (70.85714285714286, 7)
min M/p^2:                  (10.122448979591837, 7)
max D/p^2:                  (0.23039283911616348, 2155487)
```

## Theorem candidate

```text
For every prime p ≡ 7 mod 8, p > 3:
if D = 4p^2 - C2 > 0,
then M = (p - 1)*phi(C2) - p*D > 0.
```

That theorem would prove every strict step-2 underflow overshoots at depth 3.

## GTH

This is the internet-famous proof target: prove `M > 0` under `D > 0`.
