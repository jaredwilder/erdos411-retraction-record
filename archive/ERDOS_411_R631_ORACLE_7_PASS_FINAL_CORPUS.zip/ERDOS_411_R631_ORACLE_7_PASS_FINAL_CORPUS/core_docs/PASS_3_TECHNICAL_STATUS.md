# PASS 3 — Technical Status, No Narrative Fog

## Main theorem target

\[
2^a\{1,3,5,7,35,47\}.
\]

## Current status

Not proved unconditionally.

## Fixed gates from R625

```text
Gate 0: Reduction integrity
Gate 1: D prime-filter closure
Gate 2: Lemma A global ratio lock
Gate 3: Lemma B / Cambie-tail closure
```

## Gate 0

Reduction needs a clean manuscript statement, likely citing external Steinerberger/Hercher context.

Status: structurally known in the working stack but not packaged as a polished proof.

## Gate 1

D prime-filter closure target:

\[
\varphi(m)=\frac23(m+1),\quad \frac{4m+1}{3}\text{ prime}
\Rightarrow m\in\{5,35\}.
\]

Status:

```text
m < 2^64 certified.
patched generator zero survivors through B <= 100000.
global theorem not proved.
```

## Gate 2

Lemma A exact target:

\[
D>0
\Rightarrow
\frac{\varphi(N)}{N}>
\frac{(4N+1)(26N^2+43N+8)}
{3N(2N-1)(34N+7)}.
\]

Status:

```text
Exact threshold derived.
Strong chamber evidence.
Global theorem not proved.
```

## Gate 3

Old route:

\[
\frac{\operatorname{odd}(C_2)}
{\varphi(\operatorname{odd}(C_2))}
<\frac83
\]

at depth 3.

Status:

```text
False globally.
```

Counterexample:

\[
N=5\cdot 11^3\cdot17^4\cdot23^3\cdot41^2.
\]

Therefore Gate 3 must be reformulated as later-depth Cambie-tail death, not depth-3 Lemma B.

## Correct hard statement now

\[
\boxed{
\textbf{The depth-3 overshoot proof route is dead; any valid proof must handle later-depth death.}
}
\]
