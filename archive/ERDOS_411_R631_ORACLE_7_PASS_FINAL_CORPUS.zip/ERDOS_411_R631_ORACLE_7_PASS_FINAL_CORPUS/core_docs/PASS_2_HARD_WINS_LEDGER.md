# PASS 2 — Hard Wins Ledger

## Win 1 — Cambie step-2 hit is symbolically impossible

For \(p\equiv7\pmod8\), \(t\ge2\), with

\[
C_1=3p-1,
\]

\[
C_2=p(3p-1)+(p-1)\varphi(3p-1),
\]

a step-2 hit \(C_2=4p^2\) forces

\[
\varphi(3p-1)=\frac{p(p+1)}{p-1}
=p+2+\frac2{p-1}.
\]

For prime \(p>3\), this is not an integer.

\[
\boxed{\textbf{No Cambie }t\ge2\textbf{ tail hits at step 2.}}
\]

## Win 2 — Exact \(N\)-form

Let

\[
N=\frac{3p-1}{4}.
\]

Then

\[
p=\frac{4N+1}{3},
\quad
\varphi(3p-1)=2\varphi(N),
\]

and

\[
C_2=4pN+2(p-1)\varphi(N).
\]

Strict underflow is

\[
D=4p^2-C_2>0.
\]

Equivalently,

\[
(4N+1)(N+1)-3(2N-1)\varphi(N)>0.
\]

Thus

\[
\frac{\varphi(N)}{N}
<
\frac{(N+1)(4N+1)}{3N(2N-1)}
=
\frac23+\frac{7N+1}{3N(2N-1)}.
\]

## Win 3 — Exact Lemma A threshold

Lemma A is equivalent to

\[
\boxed{
\frac{\varphi(N)}{N}>
\frac{(4N+1)(26N^2+43N+8)}
{3N(2N-1)(34N+7)}.
}
\]

The limiting threshold is

\[
\boxed{\frac{26}{51}}.
\]

## Win 4 — D-branch parent/divisor identities

For

\[
\varphi(m)=\frac23(m+1),
\]

define

\[
E(a)=\frac{3\varphi(a)-2a}{2}.
\]

Then

\[
p=1+\frac{a+1}{E(a)}.
\]

For \(a=Br\), \(A=E(B)\), \(d=E(Br)\),

\[
dT=B^2+AB+A,
\]

\[
r=1+\frac{B+d}{A},
\qquad
p=1+\frac{B+T}{A}.
\]

This is the exact D-generator architecture.

## Win 5 — D overgeneration caught and patched

The naive D generator produced fake survivors such as \(m=539\) and \(m=291599\).

Independent checks showed they failed the original D equation / largest-prime / coprimality assumptions.

The patched generator added:

```text
gcd(B,r)=1
gcd(B,p)=1
p is largest prime factor of m=Brp
3phi(m)=2(m+1)
P=(4m+1)/3=2phi(m)-1
```

After patching:

```text
B <= 100000
SURVIVOR count: 0
SKIPPED count: 0
```

## Win 6 — Strong bounded D certificate

A hard prior certificate supports:

\[
\varphi(m)=\frac23(m+1),
\quad
\frac{4m+1}{3}\text{ prime},
\quad
m<2^{64}
\Rightarrow
m\in\{5,35\}.
\]

## Win 7 — Known D chain prime-filter behavior

Known D solutions:

\[
m=5,\ 35,\ 1295,\ 1679615,\ldots
\]

Prime filter \(P=(4m+1)/3\):

```text
m=5       -> P=7 prime
m=35      -> P=47 prime
m=1295    -> P=1727=11*157 composite
m=1679615 -> P=2239487=23*97369 composite
```

## Win 8 — Forbidden-signature board

Lemma B failure was reduced to explicit forbidden signatures:

```text
FS01 {3,5,7,11,13,43}
FS02 {3,5,7,11,13,41}
FS03 {3,5,7,11,17,23}
FS04 {3,5,7,11,13,37}
FS05 {3,5,7,11,13,31}
FS06 {3,5,7,11,17,19}
FS07 {3,5,7,11,13,29}
FS08 {3,5,7,11,13,23}
FS09 {3,5,7,11,13,19}
FS10 {3,5,7,11,13,17}
```

## Win 9 — Real obstruction to the depth-3 route

The case

\[
N=5\cdot 11^3\cdot17^4\cdot23^3\cdot41^2
\]

has

\[
p=\frac{4N+1}{3}=15157713825745847
\]

prime, \(p\equiv7\pmod8\), strict underflow, and \(C_2\) hitting FS03 and FS06.

This disproves the global depth-3 Lemma B route.

## Win 10 — Correct next fork

The next exact target is:

\[
\boxed{
\textbf{For the audited obstruction, does the full Cambie orbit die at a later depth or produce a genuine survivor?}
}
\]

This is not random. This is the next real mathematical fork.
