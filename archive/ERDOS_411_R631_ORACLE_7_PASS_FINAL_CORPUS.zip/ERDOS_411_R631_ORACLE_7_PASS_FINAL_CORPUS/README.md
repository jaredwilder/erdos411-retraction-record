# PASS 7 — Final Corpus README

Created: 2026-05-14T15:34:03Z

## What this corpus is

This is the final seven-pass consolidation of the Erdős #411 \(r=2\) Oracle session.

It is designed to preserve the real mathematical value without pretending we reached a complete proof.

## Read order

1. `core_docs/PASS_1_BOLD_OUTWARD_POSTURE.md`
2. `core_docs/PASS_2_HARD_WINS_LEDGER.md`
3. `core_docs/PASS_3_TECHNICAL_STATUS.md`
4. `audit/PASS_4_OBSTRUCTION_AUDIT.md`
5. `public_posture/PASS_5_PUBLIC_POSTURE.md`
6. `public_posture/PASS_6_EXTERNAL_AUDIT_EMAIL.md`
7. `EVIDENCE_INDEX.json`

## Most important sentence

\[
oxed{	extbf{The depth-3 Lemma B proof route is false globally; the next real target is later-depth Cambie-tail death.}}
\]

## What is included

Evidence packets copied into `evidence_packets/`:

```json
[
  "ERDOS_411_R630_INDEPENDENT_COUNTEREXAMPLE_AUDIT.zip",
  "ERDOS_411_R629_GATE3_FORBIDDEN_SIGNATURE_DIRECT.zip",
  "ERDOS_411_R628_GATE3_SHORTCUT_BREAK_ANALYSIS.zip",
  "ERDOS_411_R627_GATE3_TARGETED_SEARCH.zip",
  "ERDOS_411_R626_GATE3_ONE_STROKE_WALL_FAST.zip",
  "ERDOS_411_R625_GOALPOST_CONTAINMENT_CONTRACT.zip",
  "ERDOS_411_R624_D_GLOBAL_STRUCTURE_SPRINT.zip",
  "ERDOS_411_R623_D_DIRECT_ATTACK_AND_EXHAUSTIVENESS.zip",
  "ERDOS_411_R622_BARE_MINIMUM_POSTURE_FROM_R621.zip",
  "ERDOS_411_R621_D_SURVIVOR_CLASSIFIER_AND_PATCH.zip",
  "ERDOS_411_R620_D_CERTIFICATE_GENERATOR_MVP.zip",
  "ERDOS_411_R619_CLOSURE_LOOP_SPRINT.zip",
  "ERDOS_411_R618_MVP_LEMMA_B_AND_D_GENERATOR.zip",
  "ERDOS_411_R617_MVP_DUE_DILIGENCE_OPTIMIZED.zip",
  "ERDOS_411_R616_FINISH_LINE_PACKET.zip",
  "ERDOS_411_R615_PARALLEL_FERRARI_LANE_HUNTER.zip",
  "ERDOS_411_R614_LANE_HUNTER_THREE_GAP_WIN_CHECK.zip",
  "ERDOS_411_R613_RATIO_PRESSURE_THEOREM_HUNTER.zip",
  "ERDOS_411_R612_PRIME_UNDERFLOW_CONSTRAINTS.zip",
  "ERDOS_411_R611_MULTI_LOOP_FORMAL_PROOF_HUNTER.zip",
  "ERDOS_411_R610_FORMALIZE_7_13_FORCES_PHI_N_MOD3_ZERO.zip",
  "ERDOS_411_R609B_CORRECTED_7_13_BLOCKS_3.zip",
  "ERDOS_411_R608_50_ANGLE_QUICK_HITTER_SWARM.zip",
  "ERDOS_411_R607_TOTIENT_RESIDUE_LIFT_ATTACK.zip",
  "ERDOS_411_R605_SUBMISSION_GRADE_PACKET.zip",
  "ERDOS_411_R604_FS08_KILLSHOT_MODULAR_ARMOR.zip",
  "ERDOS_411_R603_COMPLETE_CLOSURE_FORBIDDEN_SIGNATURE_BOARD.zip",
  "ERDOS_411_R602_GTH_THEOREM_LOCK_TESTS_LEMMA_B.zip",
  "ERDOS_411_R601_ORACLE_KBK_LEMMA_B_ATTACK.zip",
  "ERDOS_411_R600_ORACLE_KBK_LEMMA_A_ATTACK.zip",
  "ERDOS_411_R599_FULL_VICTORY_PROOF_FRONTIER.zip",
  "ERDOS_411_R597_ABSOLUTE_KILLSHOT_PACKET.zip",
  "ERDOS_411_R596_WINNING_DATA_PACKET.zip",
  "ORACLE_R595_DATA_VOICE_TOTIENT_RATIO_CERTIFICATE_ARTIFACTS.zip",
  "ORACLE_R594_CAMBIE_TAIL_PROOF_JIGSAW_ARTIFACTS.zip",
  "ORACLE_R593_DEPTH3_OVERSHOOT_THEOREM_MINER_ARTIFACTS.zip",
  "ORACLE_R592_PROOF_EXTRACTION_SHOCK_CERTIFICATE_ARTIFACTS.zip",
  "ORACLE_R591_FINAL_UNDERFLOW_CLASSIFIER_GTH_ARTIFACTS.zip",
  "ERDOS_411_EXTERNAL_PACKET_R591.zip"
]
```

Missing expected packets:

```json
[]
```

## Final posture

```text
Complete proof: no.
Serious corpus: yes.
Hard wins: yes.
Reproducible obstruction: yes.
Correct next target: yes.
```

## Next exact mathematical target

For

\[
N=5\cdot 11^3\cdot17^4\cdot23^3\cdot41^2,
\quad
p=rac{4N+1}{3},
\]

analyze the full Cambie orbit and prove one of:

```text
A. it dies later, preserving the six-family theorem;
B. it generates a genuine new survivor/counterexample;
C. it exposes a new structural class requiring classification.
```
