# PASS 4 — Independent Obstruction Audit

## Obstruction

\[
N=5^1\cdot 11^3\cdot17^4\cdot23^3\cdot41^2.
\]

Raw values:

```text
N = 11368285369309385
phi(N) = 7261633221990400
p = (4N+1)/3 = 15157713825745847
```

Checks:

```text
all N primes are 2 mod 3: true
p integer: true
p prime: true
p mod 8: 7
strict underflow: true
```

## \(C_2\)

\[
C_2=909408381842538869397100991253180.
\]

Factorization:

\[
C_2=
2^2\cdot3^2\cdot5\cdot7\cdot11^3\cdot17^3\cdot19\cdot23^2\cdot41
\cdot267836929931788141.
\]

This hits:

```text
FS03 = {3,5,7,11,17,23}
FS06 = {3,5,7,11,17,19}
```

## Odd damage

\[
\frac{\operatorname{odd}(C_2)}{\varphi(\operatorname{odd}(C_2))}
=
2.8918768988715278.
\]

But

\[
\frac83=2.6666666666666665.
\]

So the depth-3 Lemma B inequality fails.

## Local orbit check

For \(t=2,3,4\),

```text
x1 = p^(t-1)(3p-1)
x2 = p^(t-2)C2
x2 < 4p^t
x2/(4p^t) ≈ 0.989535899195309
```

This confirms genuine depth-2 strict underflow.

## Meaning

This is not a proof of a counterexample to Erdős #411.

It is a counterexample to the proposed global depth-3 proof route.

The next question is whether this orbit dies later.
