# PASS 6 — External Audit Email

Subject: Audit request: Erdős #411 r=2 certificate stack + depth-3 obstruction

Dear [Name],

I am sending a compact audit packet for a Python-first attack on the \(r=2\) case of Erdős Problem #411.

The target families are

\[
2^a\{1,3,5,7,35,47\}.
\]

This packet does **not** claim a complete unconditional proof.

It contains:

1. exact Cambie-tail recurrence;
2. a symbolic proof that no \(t\ge2\) Cambie tail hits at step 2;
3. the exact \(N=(3p-1)/4\) formulation;
4. the exact Lemma A ratio threshold;
5. D-branch parent/divisor identities;
6. a patched D generator and verifier architecture;
7. a bounded prime-filter D certificate below \(2^{64}\);
8. a finite forbidden-signature board for the depth-3 route;
9. an independently audited obstruction showing the global depth-3 Lemma B route is false.

The obstruction is:

\[
N=5\cdot 11^3\cdot17^4\cdot23^3\cdot41^2,
\quad
p=\frac{4N+1}{3}=15157713825745847.
\]

Here \(p\) is prime, \(p\equiv7\pmod8\), strict underflow holds, and \(C_2\) hits FS03 and FS06. Thus the depth-3 Lemma B inequality fails for this generated case.

The audit request is:

```text
Can you verify the algebra/certificates and determine whether this obstruction dies at a later iterate or points to a deeper issue?
```

Best,
Jared
