# PASS 5 — Public / External Posture

## Title

A Computational Certificate and Obstruction Audit for the \(r=2\) Case of Erdős Problem #411

## Abstract

We present a Python-first certificate program for the \(r=2\) case of Erdős Problem #411. The work isolates the six visible families

\[
2^a\{1,3,5,7,35,47\}
\]

and develops exact algebraic reductions for the D-branch and Cambie-tail channels. We prove a symbolic no-step-2 theorem for Cambie \(t\ge2\) tails, derive exact \(N\)-form recurrences and ratio thresholds, implement and patch a D-branch divisor generator, and verify a prime-filter D certificate below \(2^{64}\). We also construct a finite forbidden-signature board for the depth-3 Lemma B route.

The major new finding is an explicit strict-underflow prime Cambie obstruction that disproves the global depth-3 Lemma B strategy. Thus any final proof must use a later-depth orbit-death theorem or another mechanism.

## Bold claim

\[
\boxed{
\textbf{The old depth-3 route is dead. The six-family picture survives only if later-depth Cambie-tail death takes over.}
}
\]

## Challenge

All artifacts, scripts, hashes, and counterexample audits are included. The challenge is explicit:

```text
1. Break the algebra.
2. Break the certificates.
3. Break the obstruction audit.
4. Or prove the later-depth death theorem.
```

## What not to claim

Do not claim a complete unconditional proof.

## What to claim

Claim a serious computational certificate, exact reduction stack, D-generator architecture, and a new obstruction to a natural proof route.
