# Oracle Number Theory OS V9

**Build:** Source, Interpolation, Literature, State

V9 is the trust-boundary hardening pass against the V8 hostile review. It converts the V8 failure list into explicit gates and hostile acceptance checks.

## What V9 hard-blocks

1. Free-text `--definition-source` cannot unlock theorem-grade scope.
2. CLI `--formal-recurrence` always creates `GENERATED_EXTENSION`, never `FORMAL_DEFINITION`.
3. Formal theorem scope requires object JSON with a verified source status.
4. Formal-definition/terms contradiction is object-fatal.
5. High-degree polynomial interpolation is detected and blocked like high-order recurrence interpolation.
6. Classification GTH is blocked for interpolation-risk prefixes.
7. Canonical Fibonacci `0,1,1,2,...` is detected as known/basic.
8. Novelty scores are capped when literature search is incomplete.
9. OEIS/local collisions include verified prefix-match metadata.
10. KBK uses a global/explicit corpus path and has `status` / `continue` commands.
11. `continue` refuses the wrong next action unless explicitly overridden.
12. Proof artifacts are tagged by scope, so finite-prefix interpolants do not masquerade as theorem certificates.
13. Known-family metadata is carried into analysis for theorem-coordinate normalization.
14. Missing Sage/PARI/Lean remains a binding demotion/blocker.
15. Acceptance attacks hostile CLI paths, not just internal constructors.

## Run selftest

```bash
python oracle_nt_os_v9.py selftest --out v9_selftest_out
```

Expected:

```json
{
  "version": "9.0.0-oracle-nt-os-source-interpolation-literature-state",
  "selftest": "PASS",
  "green_checks": 24,
  "total_checks": 24
}
```

## Hostile examples

Fake source cannot unlock theorem scope:

```bash
python oracle_nt_os_v9.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_fake_source \
  --formal-recurrence "1,1" \
  --definition-source "lol trust me bro" \
  --out out_v9
```

Short junk becomes interpolation risk, not explanation:

```bash
python oracle_nt_os_v9.py analyze-seq \
  --seq "3,8,5,13,21,7" \
  --label sixjunk \
  --out out_v9
```

Canonical Fibonacci is known/basic:

```bash
python oracle_nt_os_v9.py analyze-seq \
  --seq "0,1,1,2,3,5,8,13,21,34" \
  --label fib0 \
  --out out_v9
```

KBK state machine:

```bash
python oracle_nt_os_v9.py status --run-id <RUN_ID> --corpus ~/.oracle_nt/corpus_v9.sqlite
python oracle_nt_os_v9.py continue --run-id <RUN_ID> --action <REQUIRED_ACTION>
```

## Verified source statuses

Formal/literature scope requires one of:

- `VERIFIED_FORMAL_OBJECT_JSON`
- `LOCAL_VERIFIED_SCHEMA`
- `OEIS_VERIFIED`
- `LITERATURE_VERIFIED`

Free text is metadata only. It never upgrades a generated prefix into a theorem object.
