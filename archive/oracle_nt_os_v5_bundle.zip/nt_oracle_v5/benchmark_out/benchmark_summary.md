# V5 Benchmark Gauntlet

Passed 29/32

```json
{
  "passed": 29,
  "results": [
    {
      "expected": "exact_linear_recurrence",
      "label": "fibonacci_0_1",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.12'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": "exact_linear_recurrence",
      "label": "fibonacci_1_1",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": "exact_linear_recurrence",
      "label": "lucas",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.12'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "squares",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "triangular",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "exact_geometric_progression",
      "label": "powers2",
      "ok": true,
      "status": "Primary=exact_geometric_progression. Classification possible; theorem GTH blocked by ['LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions'].",
      "top": "exact_geometric_progression"
    },
    {
      "expected": "exact_periodic_sequence",
      "label": "periodic",
      "ok": true,
      "status": "Primary=exact_periodic_sequence. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.08'].",
      "top": "exact_periodic_sequence"
    },
    {
      "expected": "single_corruption_over_simple_law",
      "label": "poisoned_squares",
      "ok": false,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": "single_corruption_over_simple_law",
      "label": "poisoned_fibonacci",
      "ok": true,
      "status": "Primary=single_corruption_over_simple_law. Classification possible; theorem GTH blocked by ['primary invariant status PREFIX_CERTIFIED'].",
      "top": "single_corruption_over_simple_law"
    },
    {
      "expected": "single_corruption_over_simple_law",
      "label": "poisoned_periodic",
      "ok": false,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": null,
      "label": "somos4_prefix",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "high_degree_polynomial",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.20', 'research_value_score_too_low:0.25'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "exact_geometric_progression",
      "label": "geometric3",
      "ok": true,
      "status": "Primary=exact_geometric_progression. Classification possible; theorem GTH blocked by ['LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions'].",
      "top": "exact_geometric_progression"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "affine_squares",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "diff_squares",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. Classification possible; theorem GTH blocked by ['Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "constant7",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof', 'LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "naturals",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. Classification possible; theorem GTH blocked by ['Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "cubes",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.31', 'research_value_score_too_low:0.35'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "quartic",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.23', 'research_value_score_too_low:0.30'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "exact_periodic_sequence",
      "label": "alternating",
      "ok": false,
      "status": "Primary=exact_geometric_progression. Classification possible; theorem GTH blocked by ['LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions'].",
      "top": "exact_geometric_progression"
    },
    {
      "expected": "exact_linear_recurrence",
      "label": "linear_rec_order3",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": null,
      "label": "factorial",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": null,
      "label": "primes",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": null,
      "label": "divisor_count_small",
      "ok": true,
      "status": "Primary=valuation_profile. Classification possible; theorem GTH blocked by ['primary invariant status PREFIX_CERTIFIED'].",
      "top": "valuation_profile"
    },
    {
      "expected": "exact_linear_recurrence",
      "label": "mersenne",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof', 'LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": null,
      "label": "fermat_tiny",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "shifted_triangular",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.39', 'research_value_score_too_low:0.40'].",
      "top": "polynomial_finite_difference"
    },
    {
      "expected": "exact_linear_recurrence",
      "label": "scaled_fib",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": "exact_linear_recurrence",
      "label": "sign_alternating_linear",
      "ok": true,
      "status": "Primary=exact_linear_recurrence. Classification possible; theorem GTH blocked by ['Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio'].",
      "top": "exact_linear_recurrence"
    },
    {
      "expected": null,
      "label": "random_fixed",
      "ok": true,
      "status": "Primary=valuation_profile. Classification possible; theorem GTH blocked by ['primary invariant status PREFIX_CERTIFIED'].",
      "top": "valuation_profile"
    },
    {
      "expected": null,
      "label": "padic_powers",
      "ok": true,
      "status": "Primary=strong_divisibility_prefix. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof', 'primary invariant status PREFIX_CERTIFIED'].",
      "top": "strong_divisibility_prefix"
    },
    {
      "expected": "polynomial_finite_difference",
      "label": "binomial_n_choose_2",
      "ok": true,
      "status": "Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10'].",
      "top": "polynomial_finite_difference"
    }
  ],
  "total": 32,
  "version": "5.0.0-oracle-nt-os"
}
```
