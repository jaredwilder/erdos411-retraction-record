# Oracle NT OS V5 Report — quartic

Version: `5.0.0-oracle-nt-os`
Verdict: **GTH_TIERED**

Status: Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.23', 'research_value_score_too_low:0.30'].

## Top invariants

### polynomial_finite_difference — score 0.801
Status: `THEOREM_READY` | coordinate: `finite_difference_polynomial`
Open: []
Blockers: []
Demotions: []

### exact_linear_recurrence — score 0.6236
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: ['recurrence_true_but_polynomial_coordinate_is_primary']

### valuation_profile — score 0.4212
Status: `PREFIX_CERTIFIED` | coordinate: `p_adic_profile`
Open: ['derive_exact_p_adic_law']
Blockers: []
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `THEOREM_GTH_ELIGIBLE` fires=True blockers=[]
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.23', 'research_value_score_too_low:0.30']
- **proof_target**: `PROOF_TARGET_READY` fires=True blockers=[]

## KBK next experiment

Binary: **nontrivial novelty seam exists OR known-family closure**

```bash
python oracle_nt_os_v5.py attack --action search_for_nontrivial_transform_or_generalization --seq "0,2,18,84,260,630,1302,2408,4104,6570,10010,14652,20748,28574" --label quartic --out /mnt/data/nt_oracle_v5/benchmark_out/runs
```

## Theorem routes

### finite_difference_polynomial — THEOREM_READY
Open: []
Obligations:
- Prove by finite differences that a(n) = n**4 + n for all n in the intended domain.

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['5', '-10', '10', '-5', '1'].
- Prove no recurrence of order < 5 fits the sequence under the intended generation rule.
