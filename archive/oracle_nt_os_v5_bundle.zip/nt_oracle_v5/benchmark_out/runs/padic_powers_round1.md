# Oracle NT OS V5 Report — padic_powers

Version: `5.0.0-oracle-nt-os`
Verdict: **CLASSIFICATION**

Status: Primary=strong_divisibility_prefix. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof', 'primary invariant status PREFIX_CERTIFIED'].

## Top invariants

### strong_divisibility_prefix — score 0.6729
Status: `PREFIX_CERTIFIED` | coordinate: `divisibility_lattice`
Open: ['prove_strong_divisibility_for_all_indices']
Blockers: []
Demotions: []

### valuation_profile — score 0.4212
Status: `PREFIX_CERTIFIED` | coordinate: `p_adic_profile`
Open: ['derive_exact_p_adic_law']
Blockers: []
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['strong_divisibility_sequence: all_indices_proof', 'primary invariant status PREFIX_CERTIFIED']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.45', 'research_value_score_too_low:0.55']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['strong_divisibility_sequence: open all_indices_proof']

## KBK next experiment

Binary: **strong divisibility extends OR divisibility route killed**

```bash
python oracle_nt_os_v5.py attack --action audit_strong_divisibility_then_proof_route --seq "1,2,1,4,1,2,1,8,1,2,1,4,1,2,1,16,1" --label padic_powers --out /mnt/data/nt_oracle_v5/benchmark_out/runs
```

## Theorem routes

### strong_divisibility_sequence — GTH_BLOCKED_BY_OPEN_CONDITION
Open: ['all_indices_proof']
Obligations:
- Prove gcd(a_m,a_n)=a_gcd(m,n) for all positive m,n using recurrence or divisibility-lattice structure.
