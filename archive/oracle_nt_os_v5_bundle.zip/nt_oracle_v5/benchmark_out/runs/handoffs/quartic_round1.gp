\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [0, 2, 18, 84, 260, 630, 1302, 2408, 4104, 6570, 10010, 14652, 20748, 28574];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
