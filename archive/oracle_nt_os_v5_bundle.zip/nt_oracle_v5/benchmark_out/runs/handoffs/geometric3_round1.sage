# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [1, 3, 9, 27, 81, 243, 729, 2187, 6561, 19683, 59049, 177147, 531441, 1594323]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['3']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
