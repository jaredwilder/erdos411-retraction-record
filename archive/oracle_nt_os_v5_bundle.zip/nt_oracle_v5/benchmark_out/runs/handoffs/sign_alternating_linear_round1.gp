\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [1, -2, 3, -4, 5, -6, 7, -8, 9, -10, 11, -12, 13, -14];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
