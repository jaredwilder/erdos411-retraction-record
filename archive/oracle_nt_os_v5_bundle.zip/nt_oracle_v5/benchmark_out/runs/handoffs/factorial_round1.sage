# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['25', '-200', '600', '-600', '120']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
