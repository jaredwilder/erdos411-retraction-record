\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
