\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
