# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 107, 121, 144, 169, 196, 225]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['-3', '-6', '-10', '-15', '-21', '3479/8', '-1267/2', '2065/8']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
