\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [0, 0, 1, 1, 2, 4, 7, 13, 24, 44, 81, 149, 274];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
