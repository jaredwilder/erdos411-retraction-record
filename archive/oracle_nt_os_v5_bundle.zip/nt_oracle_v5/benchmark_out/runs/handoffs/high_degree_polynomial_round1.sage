# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [1, 1, 21, 493, 3337, 13761, 42781, 110461, 249873, 511777, 970021, 1727661, 2923801, 4741153, 7414317, 11238781]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['7', '-21', '35', '-35', '21', '-7', '1']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
