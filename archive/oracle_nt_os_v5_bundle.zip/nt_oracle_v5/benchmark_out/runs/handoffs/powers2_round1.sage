# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['2']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
