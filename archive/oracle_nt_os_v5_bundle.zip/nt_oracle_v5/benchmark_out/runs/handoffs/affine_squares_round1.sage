# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [7, 12, 27, 52, 87, 132, 187, 252, 327, 412, 507, 612, 727, 852, 987, 1132]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['3', '-3', '1']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
