\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [1, 2, 1, 4, 1, 2, 1, 8, 1, 2, 1, 4, 1, 2, 1, 16, 1];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
