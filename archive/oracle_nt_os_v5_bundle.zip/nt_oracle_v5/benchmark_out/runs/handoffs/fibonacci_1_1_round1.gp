\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
