# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['14/9', '7/9', '-157/54', '25/27', '73/18', '-37/9']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
