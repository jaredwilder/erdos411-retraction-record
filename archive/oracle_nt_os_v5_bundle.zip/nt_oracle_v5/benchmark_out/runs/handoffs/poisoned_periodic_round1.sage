# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [1, 2, 3, 1, 2, 3, 1, 99, 3, 1, 2, 3]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['-485/133', '0', '-1', '-485/133', '-8051/133', '2754/19']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
