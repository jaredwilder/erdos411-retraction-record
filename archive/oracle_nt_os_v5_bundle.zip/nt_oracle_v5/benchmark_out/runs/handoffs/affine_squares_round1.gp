\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [7, 12, 27, 52, 87, 132, 187, 252, 327, 412, 507, 612, 727, 852, 987, 1132];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
