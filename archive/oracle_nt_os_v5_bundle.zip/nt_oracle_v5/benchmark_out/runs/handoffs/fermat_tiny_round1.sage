# Auto-generated Oracle NT OS V5 Sage tribunal handoff
A = [3, 5, 17, 257, 65537, 4294967297]
print('Sequence length', len(A))
try:
    R.<x> = PolynomialRing(QQ)
    coeffs = ['332215617/4597', '-8730846140/4597', '12669248880/4597']
    if coeffs:
        k = len(coeffs)
        cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
        print('Characteristic polynomial:', cp)
        print('Factorization:', cp.factor())
        print('ORACLE_JSON:', {'charpoly_factored': str(cp.factor())})
except Exception as e:
    print('SAGE_ERROR', e)
