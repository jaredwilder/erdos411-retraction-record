\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5, 8, 9];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
