\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [1, 1, 21, 493, 3337, 13761, 42781, 110461, 249873, 511777, 970021, 1727661, 2923801, 4741153, 7414317, 11238781];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
