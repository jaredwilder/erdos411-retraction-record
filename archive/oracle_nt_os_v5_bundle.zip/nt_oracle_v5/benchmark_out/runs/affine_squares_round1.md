# Oracle NT OS V5 Report — affine_squares

Version: `5.0.0-oracle-nt-os`
Verdict: **GTH_TIERED**

Status: Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10'].

## Top invariants

### polynomial_finite_difference — score 0.7675
Status: `THEOREM_READY` | coordinate: `finite_difference_polynomial`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### exact_linear_recurrence — score 0.6056
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: ['recurrence_true_but_polynomial_coordinate_is_primary', 'known_family_classification_not_novel']

### valuation_profile — score 0.4212
Status: `PREFIX_CERTIFIED` | coordinate: `p_adic_profile`
Open: ['derive_exact_p_adic_law']
Blockers: []
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `THEOREM_GTH_ELIGIBLE` fires=True blockers=[]
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10', 'research_value_score_too_low:0.15']
- **proof_target**: `PROOF_TARGET_READY` fires=True blockers=[]

## KBK next experiment

Binary: **nontrivial novelty seam exists OR known-family closure**

```bash
python oracle_nt_os_v5.py attack --action search_for_nontrivial_transform_or_generalization --seq "7,12,27,52,87,132,187,252,327,412,507,612,727,852,987,1132" --label affine_squares --out /mnt/data/nt_oracle_v5/benchmark_out/runs
```

## Theorem routes

### finite_difference_polynomial — THEOREM_READY
Open: []
Obligations:
- Prove by finite differences that a(n) = 5*n**2 + 7 for all n in the intended domain.

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['3', '-3', '1'].
- Prove no recurrence of order < 3 fits the sequence under the intended generation rule.
