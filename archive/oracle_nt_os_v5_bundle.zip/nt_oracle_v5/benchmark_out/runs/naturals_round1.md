# Oracle NT OS V5 Report — naturals

Version: `5.0.0-oracle-nt-os`
Verdict: **CLASSIFICATION**

Status: Primary=polynomial_finite_difference. Classification possible; theorem GTH blocked by ['Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio'].

## Top invariants

### polynomial_finite_difference — score 0.7675
Status: `THEOREM_READY` | coordinate: `finite_difference_polynomial`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### exact_linear_recurrence — score 0.6056
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: ['recurrence_true_but_polynomial_coordinate_is_primary', 'known_family_classification_not_novel']

### valuation_profile — score 0.3502
Status: `OBSERVED_ONLY` | coordinate: `p_adic_profile`
Open: ['repair_corruption_before_p_adic_claim']
Blockers: ['valuation_profile_may_be_artifact_of_single_corruption']
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10', 'research_value_score_too_low:0.15']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['Lucas_Lehmer_Zsigmondy_BHV: open discriminant_nonzero']

## KBK next experiment

Binary: **Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio closes OR route is killed**

```bash
python oracle_nt_os_v5.py attack --action measure_top_open_condition --seq "0,1,2,3,4,5,6,7,8,9,10,11,12,13" --label naturals --out /mnt/data/nt_oracle_v5/benchmark_out/runs
```

## Theorem routes

### finite_difference_polynomial — THEOREM_READY
Open: []
Obligations:
- Prove by finite differences that a(n) = n for all n in the intended domain.

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['2', '-1'].
- Prove no recurrence of order < 2 fits the sequence under the intended generation rule.

### Lucas_Lehmer_Zsigmondy_BHV — GTH_BLOCKED_BY_OPEN_CONDITION
Open: ['discriminant_nonzero', 'nondegenerate_root_ratio']
Obligations:
- Show recurrence is Lucas/Lehmer-normalized with P=2, Q=1, discriminant=0.
- Apply primitive divisor theorem after explicitly listing exception indices.
