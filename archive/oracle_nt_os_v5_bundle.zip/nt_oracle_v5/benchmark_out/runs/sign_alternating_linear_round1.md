# Oracle NT OS V5 Report — sign_alternating_linear

Version: `5.0.0-oracle-nt-os`
Verdict: **CLASSIFICATION**

Status: Primary=exact_linear_recurrence. Classification possible; theorem GTH blocked by ['Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio'].

## Top invariants

### exact_linear_recurrence — score 0.7516
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: []

### single_corruption_over_simple_law — score 0.7158
Status: `PREFIX_CERTIFIED` | coordinate: `data_integrity`
Open: ['operator_confirm_or_repair_suspect_term']
Blockers: ['do_not_promote_weaker_opportunistic_invariant_until_corruption_checked']
Demotions: []

### valuation_profile — score 0.3502
Status: `OBSERVED_ONLY` | coordinate: `p_adic_profile`
Open: ['repair_corruption_before_p_adic_claim']
Blockers: ['valuation_profile_may_be_artifact_of_single_corruption']
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['Lucas_Lehmer_Zsigmondy_BHV: open discriminant_nonzero']

## KBK next experiment

Binary: **Lucas_Lehmer_Zsigmondy_BHV: discriminant_nonzero,nondegenerate_root_ratio closes OR route is killed**

```bash
python oracle_nt_os_v5.py attack --action measure_top_open_condition --seq "1,-2,3,-4,5,-6,7,-8,9,-10,11,-12,13,-14" --label sign_alternating_linear --out /mnt/data/nt_oracle_v5/benchmark_out/runs
```

## Theorem routes

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['-2', '-1'].
- Prove no recurrence of order < 2 fits the sequence under the intended generation rule.

### Lucas_Lehmer_Zsigmondy_BHV — GTH_BLOCKED_BY_OPEN_CONDITION
Open: ['discriminant_nonzero', 'nondegenerate_root_ratio']
Obligations:
- Show recurrence is Lucas/Lehmer-normalized with P=-2, Q=1, discriminant=0.
- Apply primitive divisor theorem after explicitly listing exception indices.
