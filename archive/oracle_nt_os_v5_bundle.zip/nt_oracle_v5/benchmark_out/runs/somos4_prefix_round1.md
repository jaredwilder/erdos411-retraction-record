# Oracle NT OS V5 Report — somos4_prefix

Version: `5.0.0-oracle-nt-os`
Verdict: **CLASSIFICATION**

Status: Primary=exact_linear_recurrence. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof'].

## Top invariants

### exact_linear_recurrence — score 0.7516
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: []

### strong_divisibility_prefix — score 0.6729
Status: `PREFIX_CERTIFIED` | coordinate: `divisibility_lattice`
Open: ['prove_strong_divisibility_for_all_indices']
Blockers: []
Demotions: []

### valuation_profile — score 0.4212
Status: `PREFIX_CERTIFIED` | coordinate: `p_adic_profile`
Open: ['derive_exact_p_adic_law']
Blockers: []
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['strong_divisibility_sequence: all_indices_proof']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['strong_divisibility_sequence: open all_indices_proof']

## KBK next experiment

Binary: **strong divisibility extends OR divisibility route killed**

```bash
python oracle_nt_os_v5.py attack --action audit_strong_divisibility_then_proof_route --seq "1,1,1,1,2,3,7,23,59,314,1529,8209,83313,620297" --label somos4_prefix --out /mnt/data/nt_oracle_v5/benchmark_out/runs
```

## Theorem routes

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['17618/4223', '-64289/4223', '1708952/4223', '-1581656/4223', '-3782911/4223', '-14280938/4223', '16394271/4223'].
- Prove no recurrence of order < 7 fits the sequence under the intended generation rule.

### strong_divisibility_sequence — GTH_BLOCKED_BY_OPEN_CONDITION
Open: ['all_indices_proof']
Obligations:
- Prove gcd(a_m,a_n)=a_gcd(m,n) for all positive m,n using recurrence or divisibility-lattice structure.
