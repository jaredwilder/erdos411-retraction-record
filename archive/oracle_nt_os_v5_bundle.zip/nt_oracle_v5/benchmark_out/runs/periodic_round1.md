# Oracle NT OS V5 Report — periodic

Version: `5.0.0-oracle-nt-os`
Verdict: **GTH_TIERED**

Status: Primary=exact_periodic_sequence. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.08'].

## Top invariants

### exact_periodic_sequence — score 0.7285
Status: `THEOREM_READY` | coordinate: `finite_automaton_periodic`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### exact_linear_recurrence — score 0.685
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### valuation_profile — score 0.4212
Status: `PREFIX_CERTIFIED` | coordinate: `p_adic_profile`
Open: ['derive_exact_p_adic_law']
Blockers: []
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `THEOREM_GTH_ELIGIBLE` fires=True blockers=[]
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.08', 'research_value_score_too_low:0.10']
- **proof_target**: `PROOF_TARGET_READY` fires=True blockers=[]

## KBK next experiment

Binary: **nontrivial novelty seam exists OR known-family closure**

```bash
python oracle_nt_os_v5.py attack --action search_for_nontrivial_transform_or_generalization --seq "1,2,3,1,2,3,1,2,3,1,2,3" --label periodic --out /mnt/data/nt_oracle_v5/benchmark_out/runs
```

## Theorem routes

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['0', '0', '1'].
- Prove no recurrence of order < 3 fits the sequence under the intended generation rule.
