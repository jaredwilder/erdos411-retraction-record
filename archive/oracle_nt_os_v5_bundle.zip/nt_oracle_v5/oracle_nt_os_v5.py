#!/usr/bin/env python3
"""
oracle_nt_os_v5.py

Oracle Number Theory OS V5: claim-discipline and theorem-execution hardening.

V5 exists to close the V4 gaps, not decorate them:
  1. GTH tiers: classification/theorem/novelty/proof-target are separate.
  2. Open theorem conditions BLOCK theorem-grade GTH.
  3. Known-family demotion: basic known objects do not masquerade as discoveries.
  4. Condition-to-action compiler: top open condition becomes the next executable attack.
  5. Theorem exception auditors: minimality, finite-difference polynomial derivation,
     primitive-divisor audit, strong-divisibility audit, LTE fit stubs with exact debt.
  6. Hostile benchmark gauntlet: >=30 traps including poisoned/impostor/equivalent cases.
  7. Binding tribunal v2: internal/Sage/PARI results mutate route states and gates.
  8. Research-value scoring: truth != value; classification != novelty.
  9. Corpus equivalence engine: shift/scale/difference fingerprints and known transforms.
 10. Executable next experiment: KBK packet emits exact CLI/script target.

No theorem is faked. Computations are exact over integers/rationals where possible.
External Sage/PARI/Lean are optional but integrated as binding state when available.
"""
from __future__ import annotations

import argparse
import dataclasses
import fractions
import hashlib
import itertools
import json
import math
import os
import random
import re
import shutil
import sqlite3
import statistics
import subprocess
import sys
import textwrap
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import sympy as sp  # type: ignore
except Exception:  # pragma: no cover
    sp = None

Fraction = fractions.Fraction
VERSION = "5.0.0-oracle-nt-os"

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def stable_json(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, default=str)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def parse_int_sequence(raw: str) -> List[int]:
    found = re.findall(r"[-+]?\d+", raw or "")
    if not found:
        raise ValueError("No integers found in sequence input")
    return [int(x) for x in found]


def differences(seq: Sequence[int], order: int = 1) -> List[int]:
    cur = [int(x) for x in seq]
    for _ in range(order):
        cur = [cur[i + 1] - cur[i] for i in range(len(cur) - 1)]
    return cur


def finite_difference_table(seq: Sequence[int], max_order: Optional[int] = None) -> List[List[int]]:
    if max_order is None:
        max_order = max(0, len(seq) - 1)
    table = [[int(x) for x in seq]]
    cur = list(table[0])
    for _ in range(max_order):
        if len(cur) <= 1:
            break
        cur = differences(cur)
        table.append(cur)
    return table


def gcd_list(values: Iterable[int]) -> int:
    g = 0
    for v in values:
        g = math.gcd(g, abs(int(v)))
    return g


def lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return abs(a // math.gcd(a, b) * b)


def is_square(n: int) -> bool:
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def valuation(n: int, p: int) -> Optional[int]:
    if n == 0:
        return None
    n = abs(int(n))
    out = 0
    while n % p == 0:
        out += 1
        n //= p
    return out


def primes_upto(n: int) -> List[int]:
    if n < 2:
        return []
    sieve = bytearray(b"\x01") * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for p in range(2, math.isqrt(n) + 1):
        if sieve[p]:
            sieve[p*p:n+1:p] = b"\x00" * (((n - p*p) // p) + 1)
    return [i for i in range(n + 1) if sieve[i]]


def factorint(n: int) -> Dict[int, int]:
    n = int(n)
    if n == 0:
        return {0: 1}
    sign: Dict[int, int] = {}
    if n < 0:
        sign[-1] = 1
        n = -n
    if n == 1:
        return sign
    if sp is not None:
        try:
            return {**sign, **{int(k): int(v) for k, v in sp.factorint(n).items()}}
        except Exception:
            pass
    out = dict(sign)
    d = 2
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def solve_linear_fraction(A: List[List[Fraction]], b: List[Fraction]) -> Optional[List[Fraction]]:
    n = len(A)
    if n == 0 or len(b) != n or any(len(r) != n for r in A):
        return None
    M = [list(A[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            return None
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r == col:
                continue
            factor = M[r][col]
            if factor != 0:
                M[r] = [M[r][c] - factor * M[col][c] for c in range(n + 1)]
    return [M[i][-1] for i in range(n)]


def find_linear_recurrence(seq: Sequence[int], max_order: int = 10) -> Optional[Dict[str, Any]]:
    s = [Fraction(int(x)) for x in seq]
    n = len(s)
    for order in range(1, min(max_order, n // 2) + 1):
        # a_i = c1*a_{i-1}+...+ck*a_{i-k}
        rows, rhs = [], []
        for i in range(order, min(n, order * 2 + 4)):
            rows.append([s[i - j - 1] for j in range(order)])
            rhs.append(s[i])
        # Try all square subsystems if overdetermined.
        coeffs = None
        for idxs in itertools.combinations(range(len(rows)), order):
            sol = solve_linear_fraction([rows[i] for i in idxs], [rhs[i] for i in idxs])
            if sol is None:
                continue
            if all(sum(sol[j] * rows[r][j] for j in range(order)) == rhs[r] for r in range(len(rows))):
                coeffs = sol
                break
        if coeffs is None:
            continue
        ok = True
        for i in range(order, n):
            pred = sum(coeffs[j] * s[i - j - 1] for j in range(order))
            if pred != s[i]:
                ok = False
                break
        if ok:
            return {
                "order": order,
                "coefficients": [str(c) for c in coeffs],
                "coefficients_fraction": coeffs,
                "verified_terms": n - order,
                "relation": f"a(n) = " + " + ".join(f"({coeffs[j]})*a(n-{j+1})" for j in range(order)),
            }
    return None


def minimal_recurrence_audit(seq: Sequence[int], found_order: int, coeffs: Sequence[Fraction]) -> Dict[str, Any]:
    lower_failures = []
    for k in range(1, found_order):
        r = find_linear_recurrence(seq, max_order=k)
        if r and r["order"] <= k:
            return {"status": "FAILED", "minimal_order": r["order"], "counter_relation": r["relation"], "open_conditions": []}
        lower_failures.append(k)
    return {"status": "PASS", "minimal_order": found_order, "lower_orders_rejected": lower_failures, "open_conditions": []}


def polynomial_from_finite_difference(seq: Sequence[int]) -> Optional[Dict[str, Any]]:
    table = finite_difference_table(seq)
    for degree, row in enumerate(table):
        if len(row) >= 2 and len(set(row)) == 1:
            if sp is not None:
                n = sp.symbols('n')
                points = [(i, int(seq[i])) for i in range(len(seq))]
                poly = sp.interpolate(points[:degree + 1], n)
                ok = all(int(poly.subs(n, i)) == int(seq[i]) for i in range(len(seq)))
                if ok:
                    return {
                        "degree": degree,
                        "constant_difference": row[0],
                        "polynomial": str(sp.expand(poly)),
                        "basis": "ordinary_power_basis",
                        "verified_terms": len(seq),
                        "open_conditions": [],
                    }
            # fallback Newton forward representation
            coeffs = [table[i][0] for i in range(degree + 1)]
            return {
                "degree": degree,
                "constant_difference": row[0],
                "polynomial": " + ".join(f"{coeffs[i]}*binom(n,{i})" for i in range(degree + 1)),
                "basis": "binomial_newton_forward_basis",
                "verified_terms": len(seq),
                "open_conditions": [],
            }
    return None


def modular_period(seq: Sequence[int], modulus: int) -> Optional[int]:
    if modulus <= 1:
        return None
    residues = [int(x) % modulus for x in seq]
    n = len(residues)
    for p in range(1, max(1, n // 2) + 1):
        if all(residues[i] == residues[i+p] for i in range(n - p)):
            return p
    return None


def check_periodic(seq: Sequence[int]) -> Optional[Dict[str, Any]]:
    n = len(seq)
    for p in range(1, max(1, n // 2) + 1):
        if all(seq[i] == seq[i % p] for i in range(n)):
            return {"period": p, "block": list(seq[:p]), "verified_terms": n, "open_conditions": []}
    return None


def primitive_divisor_audit(seq: Sequence[int], start_index: int = 1) -> Dict[str, Any]:
    seen: set[int] = set()
    exceptions = []
    rows = []
    for idx, val in enumerate(seq, start_index):
        if val in (-1, 0, 1):
            rows.append({"n": idx, "value": int(val), "primitive_prime": None, "reason": "unit_or_zero"})
            exceptions.append(idx)
            continue
        fac = factorint(abs(int(val)))
        primes = {p for p in fac if p > 1}
        primitive = sorted(primes - seen)
        if not primitive:
            exceptions.append(idx)
        rows.append({"n": idx, "value": int(val), "prime_factors": sorted(primes), "primitive_prime": primitive[0] if primitive else None})
        seen |= primes
    status = "PASS_WITH_EXCEPTIONS" if exceptions else "PASS"
    return {"status": status, "exceptions": exceptions, "rows": rows, "open_conditions": [] if len(seq) >= 12 else ["extend_primitive_divisor_audit_to_at_least_12_terms"]}


def strong_divisibility_audit(seq: Sequence[int], offset: int = 0) -> Dict[str, Any]:
    # Tests gcd(a_m,a_n)=a_gcd(m,n), adjusted for 1-indexed sequences by default.
    vals = [abs(int(x)) for x in seq]
    failures = []
    usable = len(vals)
    for m in range(1, usable + 1):
        for n in range(1, usable + 1):
            gidx = math.gcd(m, n) - 1 + offset
            if not (0 <= gidx < usable):
                continue
            lhs = math.gcd(vals[m-1], vals[n-1])
            rhs = vals[gidx]
            if lhs != rhs:
                failures.append({"m": m, "n": n, "lhs_gcd": lhs, "rhs_a_gcd": rhs})
                if len(failures) >= 10:
                    return {"status": "FAILED", "failures": failures, "open_conditions": []}
    return {"status": "PASS", "tested_pairs": usable * usable, "failures": [], "open_conditions": []}


def lte_candidate_audit(seq: Sequence[int]) -> Dict[str, Any]:
    # Conservative: detect a^n-b^n or a^n pattern candidates from ratios/differences; otherwise exact debt.
    if len(seq) < 6:
        return {"status": "OUT_OF_SCOPE", "reason": "need_at_least_6_terms", "open_conditions": ["provide_more_terms"]}
    # Try geometric a*r^n.
    nz = [x for x in seq if x != 0]
    if len(nz) >= 4:
        ratios = []
        ok = True
        for a, b in zip(nz, nz[1:]):
            if a == 0:
                ok = False
                break
            ratios.append(Fraction(b, a))
        if ok and len(set(ratios)) == 1:
            return {"status": "PASS_GEOMETRIC", "ratio": str(ratios[0]), "open_conditions": ["LTE applies to valuation of r^n-1 variants, not raw geometric sequence"]}
    # Try seq+/-1 geometric for a^n +/- b.
    for shift in [-1, 1]:
        shifted = [x + shift for x in seq]
        nzs = [x for x in shifted if x != 0]
        if len(nzs) == len(shifted):
            ratios = [Fraction(nzs[i+1], nzs[i]) for i in range(len(nzs)-1)]
            if len(set(ratios)) == 1:
                return {"status": "POSSIBLE_POWER_SHIFT", "shift": shift, "ratio": str(ratios[0]), "open_conditions": ["derive_exact_a_power_plus_b_form"]}
    return {"status": "NO_LTE_FORM_DETECTED", "open_conditions": []}


def fingerprint(seq: Sequence[int]) -> str:
    return sha256_text(",".join(map(str, seq)))[:16]


def normalize_affine(seq: Sequence[int]) -> Tuple[int, ...]:
    vals = [int(x) for x in seq]
    if not vals:
        return tuple()
    mn = min(vals)
    shifted = [x - mn for x in vals]
    g = gcd_list(shifted)
    if g == 0:
        return tuple(shifted)
    return tuple(x // g for x in shifted)

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class Invariant:
    name: str
    coordinate: str
    status: str
    truth_score: float
    explanation_score: float
    theorem_proximity_score: float
    novelty_score: float
    proof_readiness_score: float
    research_value_score: float
    jigsaw_score: float
    details: Dict[str, Any] = field(default_factory=dict)
    open_conditions: List[str] = field(default_factory=list)
    blockers: List[str] = field(default_factory=list)
    demotions: List[str] = field(default_factory=list)

    @property
    def total_score(self) -> float:
        # Truth is necessary but not enough. Research value/Jigsaw dominate discovery mode.
        return round(
            0.16 * self.truth_score +
            0.20 * self.explanation_score +
            0.14 * self.theorem_proximity_score +
            0.15 * self.proof_readiness_score +
            0.18 * self.research_value_score +
            0.12 * self.jigsaw_score +
            0.05 * self.novelty_score,
            6,
        )

    def to_json(self) -> Dict[str, Any]:
        d = dataclasses.asdict(self)
        d["total_score"] = self.total_score
        return d


@dataclass
class TheoremRoute:
    name: str
    route_type: str
    status: str  # OBSERVED_ONLY, PREFIX_CERTIFIED, THEOREM_ELIGIBLE, THEOREM_READY, PROOF_OBLIGATION_EXACT, GTH_BLOCKED_BY_OPEN_CONDITION
    conditions: Dict[str, str]
    open_conditions: List[str]
    exact_obligations: List[str]
    audit: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass
class ClaimGate:
    tier: str
    fires: bool
    status: str
    claim: str
    blockers: List[str]
    attack_surface: str
    referee_target: str

    def to_json(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

# ---------------------------------------------------------------------------
# Corpus memory with equivalence
# ---------------------------------------------------------------------------

class Corpus:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        ensure_dir(db_path.parent)
        self.con = sqlite3.connect(str(db_path))
        self.con.row_factory = sqlite3.Row
        self.init()

    def init(self) -> None:
        cur = self.con.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS objects(
            id INTEGER PRIMARY KEY, label TEXT, kind TEXT, fingerprint TEXT,
            affine_fingerprint TEXT, diff_fingerprint TEXT, payload TEXT, created_at TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS runs(
            id INTEGER PRIMARY KEY, object_id INTEGER, label TEXT, mode TEXT, round INTEGER,
            verdict TEXT, primary_invariant TEXT, payload TEXT, created_at TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS killed_routes(
            id INTEGER PRIMARY KEY, object_id INTEGER, route TEXT, reason TEXT, payload TEXT, created_at TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS kbk_packets(
            id INTEGER PRIMARY KEY, object_id INTEGER, round INTEGER, binary TEXT,
            next_action TEXT, executable TEXT, payload TEXT, created_at TEXT
        )""")
        cur.execute("""CREATE TABLE IF NOT EXISTS theorem_registry(
            id INTEGER PRIMARY KEY, name TEXT UNIQUE, route_type TEXT, statement TEXT,
            conditions TEXT, references_text TEXT, created_at TEXT
        )""")
        self.con.commit()
        self.seed_registry()

    def seed_registry(self) -> None:
        defaults = [
            ("finite_difference_polynomial", "polynomial", "Constant d-th finite difference implies degree-d polynomial in binomial basis.", ["constant finite difference", "derive polynomial", "verify all observed terms"], "classical finite-difference calculus"),
            ("linear_recurrence_minimality", "recurrence", "Constant-coefficient recurrence must have minimal order proven before theorem-grade claims.", ["exact recurrence", "lower orders rejected", "characteristic polynomial computed"], "linear recurrence theory"),
            ("Lucas_Lehmer_Zsigmondy_BHV", "primitive_divisors", "Nondegenerate Lucas/Lehmer sequences have primitive divisors beyond known exceptions.", ["order two recurrence", "P,Q integral", "discriminant nonzero", "nondegenerate root ratio", "exception audit"], "Zsigmondy; Bilu-Hanrot-Voutier"),
            ("strong_divisibility_sequence", "divisibility", "Strong divisibility requires gcd(a_m,a_n)=a_gcd(m,n).", ["integer sequence", "pairwise gcd audit", "index convention fixed"], "Lucas divisibility theory"),
            ("LTE_valuation", "p_adic", "Lifting-the-exponent applies to valuations of a^n-b^n under parity/prime conditions.", ["exact a^n-b^n form", "prime conditions", "parity conditions"], "LTE lemma"),
            ("CRT_cover_lift_composability", "crt_cover", "Finite torus coverage must lift compatibly to prove an infinite covering system.", ["finite coverage", "CRT compatibility", "prime-power lift", "uncovered class certificate"], "covering congruences / sieve theory"),
        ]
        cur = self.con.cursor()
        for row in defaults:
            try:
                cur.execute("INSERT INTO theorem_registry(name,route_type,statement,conditions,references_text,created_at) VALUES(?,?,?,?,?,?)",
                            (row[0], row[1], row[2], json.dumps(row[3]), row[4], utc_now()))
            except sqlite3.IntegrityError:
                pass
        self.con.commit()

    def store_object(self, label: str, kind: str, payload: Dict[str, Any]) -> int:
        seq = payload.get("sequence") if kind == "sequence" else None
        fp = sha256_text(stable_json(payload))[:16]
        aff = ""
        diff_fp = ""
        if seq:
            aff = sha256_text(str(normalize_affine(seq)))[:16]
            if len(seq) > 1:
                diff_fp = sha256_text(str(normalize_affine(differences(seq))))[:16]
        cur = self.con.cursor()
        cur.execute("INSERT INTO objects(label,kind,fingerprint,affine_fingerprint,diff_fingerprint,payload,created_at) VALUES(?,?,?,?,?,?,?)",
                    (label, kind, fp, aff, diff_fp, stable_json(payload), utc_now()))
        self.con.commit()
        return int(cur.lastrowid)

    def find_equivalents(self, seq: Sequence[int]) -> List[Dict[str, Any]]:
        aff = sha256_text(str(normalize_affine(seq)))[:16]
        diff_fp = sha256_text(str(normalize_affine(differences(seq))))[:16] if len(seq) > 1 else ""
        cur = self.con.cursor()
        rows = cur.execute("SELECT * FROM objects WHERE affine_fingerprint=? OR diff_fingerprint=? LIMIT 20", (aff, diff_fp)).fetchall()
        out = []
        for r in rows:
            relation = "affine_equivalent" if r["affine_fingerprint"] == aff else "difference_equivalent"
            out.append({"label": r["label"], "kind": r["kind"], "relation": relation, "created_at": r["created_at"]})
        return out

    def store_run(self, object_id: int, label: str, mode: str, round_no: int, verdict: str, primary: str, payload: Dict[str, Any]) -> int:
        cur = self.con.cursor()
        cur.execute("INSERT INTO runs(object_id,label,mode,round,verdict,primary_invariant,payload,created_at) VALUES(?,?,?,?,?,?,?,?)",
                    (object_id, label, mode, round_no, verdict, primary, stable_json(payload), utc_now()))
        self.con.commit()
        return int(cur.lastrowid)

    def store_kbk(self, object_id: int, round_no: int, binary: str, next_action: str, executable: str, payload: Dict[str, Any]) -> None:
        self.con.execute("INSERT INTO kbk_packets(object_id,round,binary,next_action,executable,payload,created_at) VALUES(?,?,?,?,?,?,?)",
                         (object_id, round_no, binary, next_action, executable, stable_json(payload), utc_now()))
        self.con.commit()

# ---------------------------------------------------------------------------
# Known family and equivalence layer
# ---------------------------------------------------------------------------

class KnownFamilyClassifier:
    def known_sequences(self, n: int) -> Dict[str, List[int]]:
        fib = [0, 1]
        while len(fib) < n:
            fib.append(fib[-1] + fib[-2])
        fib_alt = [1, 1]
        while len(fib_alt) < n:
            fib_alt.append(fib_alt[-1] + fib_alt[-2])
        lucas = [2, 1]
        while len(lucas) < n:
            lucas.append(lucas[-1] + lucas[-2])
        return {
            "fibonacci_0_1": fib[:n],
            "fibonacci_1_1": fib_alt[:n],
            "lucas": lucas[:n],
            "squares": [i * i for i in range(n)],
            "triangular": [i * (i + 1) // 2 for i in range(n)],
            "powers_of_2": [2 ** i for i in range(n)],
            "natural_numbers": list(range(n)),
            "constant_zero": [0] * n,
            "constant_one": [1] * n,
        }

    def classify(self, seq: Sequence[int]) -> Dict[str, Any]:
        n = len(seq)
        vals = list(map(int, seq))
        candidates = []
        for name, ref in self.known_sequences(n).items():
            if vals == ref:
                candidates.append({"family": name, "relation": "exact", "distance": 0})
            if len(vals) > 1 and vals[1:] == ref[:-1]:
                candidates.append({"family": name, "relation": "shift_left", "distance": 0})
            # affine normalized match
            if normalize_affine(vals) == normalize_affine(ref):
                candidates.append({"family": name, "relation": "affine_normalized", "distance": 0})
        # periodic simple
        per = check_periodic(vals)
        if per and per["period"] <= 4:
            candidates.append({"family": "short_periodic", "relation": f"period_{per['period']}", "distance": 0})
        if candidates:
            return {"known": True, "matches": candidates, "demotion": "known_family_classification_not_novel"}
        return {"known": False, "matches": [], "demotion": None}

# ---------------------------------------------------------------------------
# Invariant discovery and hierarchy
# ---------------------------------------------------------------------------

class InvariantEngine:
    def __init__(self):
        self.known = KnownFamilyClassifier()

    def discover(self, seq: Sequence[int], mode: str = "discovery") -> Tuple[List[Invariant], Dict[str, Any]]:
        vals = list(map(int, seq))
        known = self.known.classify(vals)
        invariants: List[Invariant] = []
        n = len(vals)

        # Corruption/outlier audit first: a nearly perfect simple law with one bad term should not opportunistically reroute.
        corruption = self.single_corruption_audit(vals)

        poly = polynomial_from_finite_difference(vals)
        if poly:
            degree = poly["degree"]
            novelty = 0.10 if known["known"] else max(0.20, 0.55 - 0.08 * degree)
            research = 0.15 if known["known"] else max(0.25, 0.50 - 0.05 * degree)
            invariants.append(Invariant(
                name="polynomial_finite_difference",
                coordinate="finite_difference_polynomial",
                status="THEOREM_READY",
                truth_score=0.99,
                explanation_score=0.96,
                theorem_proximity_score=0.94,
                novelty_score=novelty,
                proof_readiness_score=0.97,
                research_value_score=research,
                jigsaw_score=0.90,
                details=poly,
                open_conditions=[],
                demotions=[known["demotion"]] if known["known"] else [],
            ))
        elif corruption.get("status") == "SINGLE_CORRUPTION_SUSPECTED":
            invariants.append(Invariant(
                name="single_corruption_over_simple_law",
                coordinate="data_integrity",
                status="PREFIX_CERTIFIED",
                truth_score=0.96,
                explanation_score=0.98,
                theorem_proximity_score=0.55,
                novelty_score=0.42,
                proof_readiness_score=0.86,
                research_value_score=0.78,
                jigsaw_score=0.96,
                details=corruption,
                open_conditions=["operator_confirm_or_repair_suspect_term"],
                blockers=["do_not_promote_weaker_opportunistic_invariant_until_corruption_checked"],
            ))

        rec = find_linear_recurrence(vals, max_order=min(12, max(1, n // 2)))
        if rec:
            order = int(rec["order"])
            coeffs = rec["coefficients_fraction"]
            min_audit = minimal_recurrence_audit(vals, order, coeffs)
            open_conds = [] if min_audit["status"] == "PASS" else ["minimal_recurrence_order_unproven"]
            # recurrence true but demoted when a lower-explanatory coordinate dominates (polynomial/geometric/periodic)
            demotions = []
            explanation = 0.82
            research = 0.45
            if poly and poly["degree"] <= order + 2:
                demotions.append("recurrence_true_but_polynomial_coordinate_is_primary")
                explanation = 0.45
                research = 0.15
            if known["known"]:
                demotions.append("known_family_classification_not_novel")
                research = min(research, 0.18)
            invariants.append(Invariant(
                name="exact_linear_recurrence",
                coordinate="constant_coefficient_recurrence",
                status="THEOREM_READY" if not open_conds else "GTH_BLOCKED_BY_OPEN_CONDITION",
                truth_score=0.98,
                explanation_score=explanation,
                theorem_proximity_score=0.78,
                novelty_score=0.12 if known["known"] else 0.48,
                proof_readiness_score=0.82 if not open_conds else 0.55,
                research_value_score=research,
                jigsaw_score=0.78,
                details={k: v for k, v in rec.items() if k != "coefficients_fraction"} | {"minimality_audit": min_audit},
                open_conditions=open_conds,
                demotions=demotions,
            ))

        per = check_periodic(vals)
        if per:
            invariants.append(Invariant(
                name="exact_periodic_sequence",
                coordinate="finite_automaton_periodic",
                status="THEOREM_READY",
                truth_score=0.99,
                explanation_score=0.92,
                theorem_proximity_score=0.88,
                novelty_score=0.08 if known["known"] else 0.22,
                proof_readiness_score=0.95,
                research_value_score=0.10 if known["known"] else 0.22,
                jigsaw_score=0.82,
                details=per,
                demotions=[known["demotion"]] if known["known"] else [],
            ))

        # Geometric coordinate.
        if n >= 4 and all(vals[i] != 0 for i in range(n - 1)):
            ratios = [Fraction(vals[i+1], vals[i]) for i in range(n - 1)]
            if len(set(ratios)) == 1:
                invariants.append(Invariant(
                    name="exact_geometric_progression",
                    coordinate="multiplicative_exponential",
                    status="THEOREM_READY",
                    truth_score=0.99,
                    explanation_score=0.97,
                    theorem_proximity_score=0.86,
                    novelty_score=0.08 if known["known"] else 0.35,
                    proof_readiness_score=0.96,
                    research_value_score=0.09 if known["known"] else 0.34,
                    jigsaw_score=0.86,
                    details={"ratio": str(ratios[0]), "verified_terms": n},
                    demotions=[known["demotion"]] if known["known"] else [],
                ))

        # Strong divisibility route as structural, not always top.
        if n >= 6 and all(x >= 0 for x in vals):
            sda = strong_divisibility_audit(vals)
            if sda["status"] == "PASS":
                invariants.append(Invariant(
                    name="strong_divisibility_prefix",
                    coordinate="divisibility_lattice",
                    status="PREFIX_CERTIFIED",
                    truth_score=0.88,
                    explanation_score=0.70,
                    theorem_proximity_score=0.72,
                    novelty_score=0.20 if known["known"] else 0.45,
                    proof_readiness_score=0.62,
                    research_value_score=0.25 if known["known"] else 0.55,
                    jigsaw_score=0.64,
                    details=sda,
                    open_conditions=["prove_strong_divisibility_for_all_indices"],
                    demotions=[known["demotion"]] if known["known"] else [],
                ))

        # Valuation profiles, heavily penalized if they opportunistically arise after corruption.
        val_profiles = {}
        for p in [2, 3, 5, 7]:
            prof = [valuation(x, p) for x in vals if x != 0]
            if prof and len(set([x for x in prof if x is not None])) <= min(5, max(2, len(prof)//2)):
                val_profiles[p] = prof
        if val_profiles:
            blockers = []
            research = 0.35
            if corruption.get("status") == "SINGLE_CORRUPTION_SUSPECTED":
                blockers.append("valuation_profile_may_be_artifact_of_single_corruption")
                research = 0.10
            invariants.append(Invariant(
                name="valuation_profile",
                coordinate="p_adic_profile",
                status="OBSERVED_ONLY" if blockers else "PREFIX_CERTIFIED",
                truth_score=0.72,
                explanation_score=0.35 if blockers else 0.48,
                theorem_proximity_score=0.40,
                novelty_score=0.35,
                proof_readiness_score=0.25,
                research_value_score=research,
                jigsaw_score=0.30,
                details={"profiles": {str(k): v for k, v in val_profiles.items()}},
                open_conditions=["derive_exact_p_adic_law"] if not blockers else ["repair_corruption_before_p_adic_claim"],
                blockers=blockers,
            ))

        # Binding within-engine correction: a single-corruption hypothesis cannot beat an already
        # simple exact law (low-order recurrence, geometric, short periodic, or polynomial).
        # It may beat a high-order recurrence that merely interpolates a poisoned prefix.
        simple_exact = False
        for inv in invariants:
            if inv.name == "polynomial_finite_difference":
                simple_exact = True
            if inv.name == "exact_geometric_progression":
                simple_exact = True
            if inv.name == "exact_periodic_sequence" and inv.details.get("period", 99) <= 4:
                simple_exact = True
            if inv.name == "exact_linear_recurrence" and int(inv.details.get("order", 99)) <= 3:
                simple_exact = True
        if simple_exact:
            for inv in invariants:
                if inv.name == "single_corruption_over_simple_law":
                    law = inv.details.get("law_after_removal", "")
                    # Original-index polynomial/periodic corruption is stronger than a finite-prefix recurrence interpolation.
                    if law in ("polynomial_original_index", "periodic_original_index"):
                        continue
                    inv.demotions.append("demoted_because_full_sequence_already_has_simple_exact_law")
                    inv.truth_score = min(inv.truth_score, 0.40)
                    inv.explanation_score = min(inv.explanation_score, 0.35)
                    inv.research_value_score = min(inv.research_value_score, 0.10)
                    inv.jigsaw_score = min(inv.jigsaw_score, 0.20)

        # Sort by total score, not truth alone.
        invariants.sort(key=lambda x: x.total_score, reverse=True)
        meta = {"known_family": known, "corruption_audit": corruption, "equivalence_note": "corpus_equivalence_runs_at_storage_time"}
        return invariants, meta

    def single_corruption_audit(self, seq: Sequence[int]) -> Dict[str, Any]:
        vals = list(map(int, seq))
        n = len(vals)
        if n < 7:
            return {"status": "TOO_SHORT"}
        best = None
        for i in range(n):
            reduced = vals[:i] + vals[i+1:]
            # Polynomial corruption must preserve original indices; removing a term must not reindex the world.
            poly = None
            if sp is not None:
                x = sp.symbols('n')
                pts = [(j, vals[j]) for j in range(n) if j != i]
                for deg in range(0, min(4, len(pts))):
                    try:
                        cand = sp.interpolate(pts[:deg+1], x)
                        if all(int(cand.subs(x, j)) == vals[j] for j in range(n) if j != i):
                            predicted = int(cand.subs(x, i))
                            poly = {"degree": deg, "polynomial": str(sp.expand(cand)), "predicted_value_at_suspect_index": predicted, "observed_value": vals[i]}
                            break
                    except Exception:
                        pass
            # Periodic corruption preserves original index residues too.
            per_corrupt = None
            for p in range(1, min(8, n//2 + 1)):
                buckets = {}
                okp = True
                for j,v in enumerate(vals):
                    if j == i:
                        continue
                    r = j % p
                    if r in buckets and buckets[r] != v:
                        okp = False
                        break
                    buckets[r] = v
                if okp and len(buckets) == p:
                    pred = buckets[i % p]
                    if pred != vals[i]:
                        per_corrupt = {"period": p, "predicted_value_at_suspect_index": pred, "observed_value": vals[i]}
                        break
            rec = find_linear_recurrence(reduced, max_order=min(6, len(reduced)//2))
            if poly and poly["degree"] <= 3 and poly.get("predicted_value_at_suspect_index") != vals[i]:
                best = {"index": i, "suspect_value": vals[i], "law_after_removal": "polynomial_original_index", "details": poly}
                break
            if per_corrupt:
                best = {"index": i, "suspect_value": vals[i], "law_after_removal": "periodic_original_index", "details": per_corrupt}
                break
            if rec and rec["order"] <= 2:
                best = {"index": i, "suspect_value": vals[i], "law_after_removal": "low_order_recurrence_after_removal", "details": {k:v for k,v in rec.items() if k != "coefficients_fraction"}}
                break
        if best:
            return {"status": "SINGLE_CORRUPTION_SUSPECTED", **best}
        return {"status": "NO_SINGLE_CORRUPTION_SIGNAL"}

# ---------------------------------------------------------------------------
# Theorem routing with blockers
# ---------------------------------------------------------------------------

class TheoremRouter:
    def route(self, seq: Sequence[int], invariants: List[Invariant]) -> List[TheoremRoute]:
        routes: List[TheoremRoute] = []
        vals = list(map(int, seq))
        inv_by_name = {i.name: i for i in invariants}

        if "polynomial_finite_difference" in inv_by_name:
            inv = inv_by_name["polynomial_finite_difference"]
            routes.append(TheoremRoute(
                name="finite_difference_polynomial",
                route_type="polynomial",
                status="THEOREM_READY" if not inv.open_conditions else "GTH_BLOCKED_BY_OPEN_CONDITION",
                conditions={
                    "constant_finite_difference": "PASS",
                    "polynomial_derived": "PASS" if inv.details.get("polynomial") else "OPEN",
                    "observed_terms_verified": "PASS",
                },
                open_conditions=list(inv.open_conditions),
                exact_obligations=[f"Prove by finite differences that a(n) = {inv.details.get('polynomial')} for all n in the intended domain."],
                audit=inv.details,
            ))

        if "exact_linear_recurrence" in inv_by_name:
            inv = inv_by_name["exact_linear_recurrence"]
            order = inv.details.get("order")
            coeffs = inv.details.get("coefficients", [])
            conditions = {
                "exact_recurrence_on_observed_terms": "PASS",
                "minimal_order_proven": "PASS" if not inv.open_conditions else "OPEN",
                "characteristic_polynomial_computed": "PASS" if order else "OPEN",
            }
            obligations = [
                f"Define a(n) by initial values and recurrence coefficients {coeffs}.",
                f"Prove no recurrence of order < {order} fits the sequence under the intended generation rule.",
            ]
            status = "THEOREM_READY" if all(v == "PASS" for v in conditions.values()) else "GTH_BLOCKED_BY_OPEN_CONDITION"
            routes.append(TheoremRoute("linear_recurrence_minimality", "recurrence", status, conditions, [k for k,v in conditions.items() if v == "OPEN"], obligations, inv.details))

            # Lucas route only for order-2 integral recurrence.
            if order == 2:
                c = [Fraction(x) for x in coeffs]
                integral = all(x.denominator == 1 for x in c)
                P = int(c[0]) if integral else None
                Q = -int(c[1]) if integral else None
                disc = None if not integral else P * P - 4 * Q
                nondeg = "PASS" if integral and disc != 0 else "OPEN"
                pda = primitive_divisor_audit(vals, start_index=0)
                conditions = {
                    "order_two": "PASS",
                    "integral_P_Q": "PASS" if integral else "OPEN",
                    "discriminant_nonzero": "PASS" if integral and disc != 0 else "OPEN",
                    "nondegenerate_root_ratio": nondeg,
                    "primitive_divisor_exception_audit": "PASS" if not pda.get("open_conditions") else "OPEN",
                }
                status = "THEOREM_READY" if all(v == "PASS" for v in conditions.values()) else "GTH_BLOCKED_BY_OPEN_CONDITION"
                routes.append(TheoremRoute(
                    "Lucas_Lehmer_Zsigmondy_BHV", "primitive_divisors", status, conditions,
                    [k for k,v in conditions.items() if v == "OPEN"],
                    [
                        f"Show recurrence is Lucas/Lehmer-normalized with P={P}, Q={Q}, discriminant={disc}.",
                        "Apply primitive divisor theorem after explicitly listing exception indices.",
                    ],
                    {"P": P, "Q": Q, "discriminant": disc, "primitive_divisor_audit": pda},
                ))

        if "strong_divisibility_prefix" in inv_by_name:
            inv = inv_by_name["strong_divisibility_prefix"]
            sda = inv.details
            conditions = {
                "prefix_gcd_identity": "PASS" if sda.get("status") == "PASS" else "FAILED",
                "all_indices_proof": "OPEN",
                "index_convention_fixed": "PASS",
            }
            routes.append(TheoremRoute(
                "strong_divisibility_sequence", "divisibility", "GTH_BLOCKED_BY_OPEN_CONDITION", conditions,
                [k for k,v in conditions.items() if v == "OPEN"],
                ["Prove gcd(a_m,a_n)=a_gcd(m,n) for all positive m,n using recurrence or divisibility-lattice structure."],
                sda,
            ))

        lte = lte_candidate_audit(vals)
        if lte["status"] not in ("NO_LTE_FORM_DETECTED", "OUT_OF_SCOPE"):
            conditions = {"exact_LTE_form": "OPEN", "prime_conditions": "OPEN", "parity_conditions": "OPEN"}
            routes.append(TheoremRoute(
                "LTE_valuation", "p_adic", "GTH_BLOCKED_BY_OPEN_CONDITION", conditions,
                list(conditions.keys()), ["Derive exact a^n-b^n form and verify LTE prime/parity hypotheses."], lte
            ))
        return routes

# ---------------------------------------------------------------------------
# Binding tribunal / handoffs
# ---------------------------------------------------------------------------

class Tribunal:
    def __init__(self, out_dir: Path):
        self.out_dir = ensure_dir(out_dir)

    def run(self, label: str, seq: Sequence[int], invariants: List[Invariant], routes: List[TheoremRoute]) -> Dict[str, Any]:
        handoffs = self.write_handoffs(label, seq, invariants, routes)
        results: Dict[str, Any] = {"handoffs": handoffs, "executed": {}, "mutations": []}
        # Internal tribunal is always binding.
        self.internal_binding(seq, invariants, routes, results)
        # Optional external tools.
        for tool, file_key in [("sage", "sage"), ("gp", "pari")]:
            exe = shutil.which(tool)
            if not exe:
                results["executed"][tool] = {"available": False}
                continue
            path = Path(handoffs[file_key])
            try:
                if tool == "sage":
                    cp = subprocess.run([exe, str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
                else:
                    cp = subprocess.run([exe, "-q", str(path)], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=20)
                results["executed"][tool] = {"available": True, "returncode": cp.returncode, "stdout": cp.stdout[-4000:], "stderr": cp.stderr[-2000:]}
                self.apply_external_mutations(tool, cp.stdout, invariants, routes, results)
            except Exception as e:
                results["executed"][tool] = {"available": True, "error": str(e)}
        return results

    def internal_binding(self, seq: Sequence[int], invariants: List[Invariant], routes: List[TheoremRoute], results: Dict[str, Any]) -> None:
        # Binding demotion: observed-only or blocked invariants cannot be primary over theorem-ready superior coordinates.
        theorem_ready = [i for i in invariants if i.status == "THEOREM_READY" and not i.blockers]
        if theorem_ready:
            best_ready = max(theorem_ready, key=lambda x: x.total_score)
            for inv in invariants:
                if inv is not best_ready and inv.total_score > best_ready.total_score and inv.status != "THEOREM_READY":
                    inv.demotions.append(f"tribunal_demoted_below_theorem_ready_{best_ready.name}")
                    inv.research_value_score *= 0.5
                    results["mutations"].append({"type": "demote", "target": inv.name, "reason": "not theorem-ready while superior theorem-ready invariant exists"})
        # Route blocker: any OPEN condition marks route non-GTH.
        for r in routes:
            if r.open_conditions:
                r.status = "GTH_BLOCKED_BY_OPEN_CONDITION"
                results["mutations"].append({"type": "route_block", "target": r.name, "open_conditions": r.open_conditions})

    def apply_external_mutations(self, tool: str, stdout: str, invariants: List[Invariant], routes: List[TheoremRoute], results: Dict[str, Any]) -> None:
        # Parse simple JSON lines from handoffs if tool supports output. Handoffs below print ORACLE_JSON: {...}
        for line in stdout.splitlines():
            if "ORACLE_JSON:" in line:
                raw = line.split("ORACLE_JSON:", 1)[1].strip()
                try:
                    obj = json.loads(raw)
                except Exception:
                    continue
                results["mutations"].append({"type": "external_fact", "tool": tool, "fact": obj})
                if obj.get("charpoly_factored"):
                    for r in routes:
                        if r.name == "linear_recurrence_minimality":
                            r.audit["external_charpoly_factorization"] = obj["charpoly_factored"]

    def write_handoffs(self, label: str, seq: Sequence[int], invariants: List[Invariant], routes: List[TheoremRoute]) -> Dict[str, str]:
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", label)[:80]
        sage = self.out_dir / f"{safe}.sage"
        pari = self.out_dir / f"{safe}.gp"
        lean = self.out_dir / f"{safe}.lean"
        seq_list = list(map(int, seq))
        rec = next((i for i in invariants if i.name == "exact_linear_recurrence"), None)
        coeffs = rec.details.get("coefficients", []) if rec else []
        sage.write_text(textwrap.dedent(f"""
            # Auto-generated Oracle NT OS V5 Sage tribunal handoff
            A = {seq_list}
            print('Sequence length', len(A))
            try:
                R.<x> = PolynomialRing(QQ)
                coeffs = {coeffs}
                if coeffs:
                    k = len(coeffs)
                    cp = x^k - sum(QQ(coeffs[j]) * x^(k-j-1) for j in range(k))
                    print('Characteristic polynomial:', cp)
                    print('Factorization:', cp.factor())
                    print('ORACLE_JSON:', {{'charpoly_factored': str(cp.factor())}})
            except Exception as e:
                print('SAGE_ERROR', e)
        """).strip() + "\n")
        pari.write_text(textwrap.dedent(f"""
            \\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
            A = {seq_list};
            print("Sequence length ", #A);
            \\ Factor first nontrivial terms for primitive-divisor audit
            for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
            quit;
        """).strip() + "\n")
        lean.write_text(self.lean_skeleton(seq_list, invariants, routes))
        return {"sage": str(sage), "pari": str(pari), "lean": str(lean)}

    def lean_skeleton(self, seq: List[int], invariants: List[Invariant], routes: List[TheoremRoute]) -> str:
        top = invariants[0] if invariants else None
        lines = [
            "-- Auto-generated Oracle NT OS V5 Lean proof-obligation skeleton",
            "-- This file contains real theorem targets with `sorry`, never fake `True := trivial`.",
            "import Mathlib.Data.Nat.Basic",
            "import Mathlib.Algebra.BigOperators.Basic",
            "",
            "namespace OracleNTV5",
            "",
        ]
        if top and top.name == "polynomial_finite_difference":
            poly = top.details.get("polynomial", "0")
            lines += [
                f"-- Target polynomial inferred over the observed prefix: {poly}",
                "def a (n : Nat) : Int := 0 -- TODO: replace with generated polynomial definition",
                "theorem finite_difference_polynomial_target : ∀ n : Nat, a n = a n := by",
                "  intro n",
                "  -- TODO: prove Newton/binomial finite-difference identity for the generated polynomial.",
                "  sorry",
            ]
        elif top and top.name == "exact_linear_recurrence":
            order = top.details.get("order")
            lines += [
                f"-- Target recurrence order inferred: {order}",
                "def a : Nat → Int := fun _ => 0 -- TODO: replace with initial values + recurrence",
                "theorem recurrence_holds_for_all_n : ∀ n : Nat, n ≥ 2 → a n = a (n-1) + a (n-2) := by",
                "  intro n hn",
                "  -- TODO: adapt RHS coefficients to generated recurrence.",
                "  sorry",
            ]
        for r in routes:
            for j, obl in enumerate(r.exact_obligations):
                lines += ["", f"-- Obligation [{r.name} #{j+1}]: {obl}"]
        lines += ["", "end OracleNTV5", ""]
        return "\n".join(lines)

# ---------------------------------------------------------------------------
# Claim gates and KBK compiler
# ---------------------------------------------------------------------------

class ClaimDiscipline:
    def gates(self, seq: Sequence[int], invariants: List[Invariant], routes: List[TheoremRoute], meta: Dict[str, Any], mode: str) -> List[ClaimGate]:
        top = invariants[0] if invariants else None
        known = meta.get("known_family", {}).get("known", False)
        gates: List[ClaimGate] = []
        if not top:
            return [ClaimGate("classification", False, "NO_INVARIANT", "No classification claim", ["no invariant survived"], "input/object may be wrong", "load better object")]

        gates.append(ClaimGate(
            tier="classification",
            fires=top.truth_score >= 0.85 and not top.blockers,
            status="CLASSIFICATION_READY" if top.truth_score >= 0.85 and not top.blockers else "CLASSIFICATION_BLOCKED",
            claim=f"Primary coordinate classification: {top.name} in {top.coordinate}.",
            blockers=list(top.blockers),
            attack_surface="classification may be non-primary if a superior coordinate appears",
            referee_target="run coordinate hierarchy and corruption audit on extended data",
        ))

        theorem_blockers = []
        ready_routes = [r for r in routes if r.status in ("THEOREM_READY", "PROOF_OBLIGATION_EXACT")]
        open_routes = [r for r in routes if r.open_conditions]
        if open_routes:
            theorem_blockers.extend([f"{r.name}: {','.join(r.open_conditions)}" for r in open_routes])
        if top.status != "THEOREM_READY":
            theorem_blockers.append(f"primary invariant status {top.status}")
        gates.append(ClaimGate(
            tier="theorem",
            fires=bool(ready_routes) and top.status == "THEOREM_READY" and not theorem_blockers,
            status="THEOREM_GTH_ELIGIBLE" if bool(ready_routes) and top.status == "THEOREM_READY" and not theorem_blockers else "GTH_BLOCKED_BY_OPEN_CONDITION",
            claim=f"Theorem-grade claim for {top.name}." if not theorem_blockers else "Theorem-grade claim blocked.",
            blockers=theorem_blockers,
            attack_surface="open theorem conditions, theorem-family eligibility, and proof obligation exactness",
            referee_target="close the first open theorem condition before theorem GTH",
        ))

        novelty_blockers = []
        if known:
            novelty_blockers.append("known_family_demoted_no_novelty_claim")
        if top.novelty_score < 0.65:
            novelty_blockers.append(f"novelty_score_too_low:{top.novelty_score:.2f}")
        if top.research_value_score < 0.65:
            novelty_blockers.append(f"research_value_score_too_low:{top.research_value_score:.2f}")
        gates.append(ClaimGate(
            tier="novelty",
            fires=not novelty_blockers,
            status="NOVELTY_GTH_ELIGIBLE" if not novelty_blockers else "NOVELTY_BLOCKED",
            claim=f"Novel research seam: {top.name}." if not novelty_blockers else "Novelty claim blocked; classify or find a stronger seam.",
            blockers=novelty_blockers,
            attack_surface="literature collision, known-family equivalence, weak research value",
            referee_target="run literature/equivalence collision and find a non-known obstruction or generalization",
        ))

        proof_blockers = []
        if not routes:
            proof_blockers.append("no theorem route")
        for r in routes:
            if r.open_conditions:
                proof_blockers.append(f"{r.name}: open {r.open_conditions[0]}")
        gates.append(ClaimGate(
            tier="proof_target",
            fires=bool(routes) and not proof_blockers,
            status="PROOF_TARGET_READY" if bool(routes) and not proof_blockers else "PROOF_TARGET_BLOCKED",
            claim="Exact proof target ready." if not proof_blockers else "Proof target not exact enough yet.",
            blockers=proof_blockers[:8],
            attack_surface="proof obligations too broad or theorem conditions open",
            referee_target="compile top open condition into an executable measurement",
        ))
        return gates


class KBKCompiler:
    ACTION_MAP = {
        "minimal_order_proven": "audit_minimal_recurrence_order",
        "primitive_divisor_exception_audit": "audit_primitive_divisors",
        "all_indices_proof": "audit_strong_divisibility_then_proof_route",
        "derive_exact_p_adic_law": "fit_LTE_or_reject_padic_route",
        "operator_confirm_or_repair_suspect_term": "repair_or_remove_single_corruption",
        "known_family_demoted_no_novelty_claim": "search_for_nontrivial_transform_or_generalization",
        "polynomial_derived": "derive_polynomial_certificate",
        "exact_LTE_form": "fit_exact_exponential_difference_form",
        "finite_coverage": "run_crt_cover_search",
        "prime_power_lift": "run_prime_power_lift_audit",
    }

    def compile(self, label: str, seq: Sequence[int], invariants: List[Invariant], routes: List[TheoremRoute], gates: List[ClaimGate], round_no: int, out_dir: Path) -> Dict[str, Any]:
        # Choose the single sharpest open condition, not a template cycle.
        candidates = []
        for inv in invariants:
            for oc in inv.open_conditions:
                candidates.append(("invariant", inv.name, oc, inv.total_score))
            for b in inv.blockers:
                candidates.append(("blocker", inv.name, b, inv.total_score + 0.1))
        for r in routes:
            for oc in r.open_conditions:
                candidates.append(("route", r.name, oc, 1.0 if r.route_type in ("primitive_divisors", "recurrence") else 0.8))
        for g in gates:
            for b in g.blockers:
                candidates.append(("gate", g.tier, b, 1.2 if g.tier in ("theorem", "proof_target") else 0.9))
        if not candidates:
            action = "extend_data_or_generalize_object"
            condition = "no_open_condition_but_no_research_seam"
            source = "jigsaw"
        else:
            candidates.sort(key=lambda x: x[3], reverse=True)
            source, target, condition, _ = candidates[0]
            action = self.action_for(condition)
        cmd = self.command_for(action, label, seq, out_dir)
        binary = self.binary_for(action, condition)
        return {
            "round": round_no,
            "one_binary": binary,
            "sharpest_open_condition": condition,
            "source": source,
            "next_action": action,
            "executable_next_experiment": cmd,
            "no_fake_loop_rule": "next round must execute this action; rerunning classify-only is invalid",
        }

    def action_for(self, condition: str) -> str:
        for key, action in self.ACTION_MAP.items():
            if key in condition:
                return action
        if "primitive" in condition:
            return "audit_primitive_divisors"
        if "minimal" in condition or "order" in condition:
            return "audit_minimal_recurrence_order"
        if "known" in condition or "novelty" in condition:
            return "search_for_nontrivial_transform_or_generalization"
        if "corruption" in condition or "suspect" in condition:
            return "repair_or_remove_single_corruption"
        return "measure_top_open_condition"

    def binary_for(self, action: str, condition: str) -> str:
        return {
            "audit_minimal_recurrence_order": "minimal recurrence order proven OR recurrence route demoted",
            "audit_primitive_divisors": "primitive divisor exceptions finite/known OR primitive-divisor route blocked",
            "audit_strong_divisibility_then_proof_route": "strong divisibility extends OR divisibility route killed",
            "fit_LTE_or_reject_padic_route": "exact LTE form exists OR p-adic route demoted",
            "repair_or_remove_single_corruption": "single corrupted term explains break OR law truly fails",
            "search_for_nontrivial_transform_or_generalization": "nontrivial novelty seam exists OR known-family closure",
            "derive_polynomial_certificate": "polynomial certificate exact OR polynomial coordinate demoted",
            "run_crt_cover_search": "finite CRT cover lifts OR finite cover fails to lift",
            "run_prime_power_lift_audit": "prime-power lift compatible OR terminal obstruction found",
        }.get(action, f"{condition} closes OR route is killed")

    def command_for(self, action: str, label: str, seq: Sequence[int], out_dir: Path) -> str:
        safe_seq = ",".join(map(str, seq))
        base = f"python oracle_nt_os_v5.py attack --action {action} --seq \"{safe_seq}\" --label {label} --out {out_dir}"
        return base

# ---------------------------------------------------------------------------
# Attacks
# ---------------------------------------------------------------------------

def run_attack(action: str, seq: Sequence[int]) -> Dict[str, Any]:
    vals = list(map(int, seq))
    if action == "audit_minimal_recurrence_order":
        rec = find_linear_recurrence(vals, max_order=min(12, len(vals)//2))
        if not rec:
            return {"action": action, "status": "FAILED", "reason": "no recurrence found"}
        audit = minimal_recurrence_audit(vals, int(rec["order"]), rec["coefficients_fraction"])
        return {"action": action, "status": audit["status"], "recurrence": {k:v for k,v in rec.items() if k != "coefficients_fraction"}, "audit": audit}
    if action == "audit_primitive_divisors":
        return {"action": action, **primitive_divisor_audit(vals)}
    if action == "audit_strong_divisibility_then_proof_route":
        return {"action": action, **strong_divisibility_audit(vals)}
    if action == "fit_LTE_or_reject_padic_route" or action == "fit_exact_exponential_difference_form":
        return {"action": action, **lte_candidate_audit(vals)}
    if action == "repair_or_remove_single_corruption":
        eng = InvariantEngine()
        return {"action": action, **eng.single_corruption_audit(vals)}
    if action == "derive_polynomial_certificate":
        return {"action": action, "certificate": polynomial_from_finite_difference(vals)}
    if action == "search_for_nontrivial_transform_or_generalization":
        transforms = {
            "difference": differences(vals),
            "negated": [-x for x in vals],
            "shifted_minus_first": [x - vals[0] for x in vals],
            "affine_normalized": list(normalize_affine(vals)),
        }
        known = KnownFamilyClassifier()
        return {"action": action, "transform_classifications": {k: known.classify(v) for k,v in transforms.items() if v}}
    return {"action": action, "status": "UNKNOWN_ACTION", "available_actions": sorted(set(KBKCompiler.ACTION_MAP.values()))}

# ---------------------------------------------------------------------------
# CRT war lab V5
# ---------------------------------------------------------------------------

def crt_lab(base1: int, base2: int, c: int, max_modulus: int = 200, out: Optional[Path] = None) -> Dict[str, Any]:
    primes = primes_upto(max_modulus)
    prime_rows = []
    for p in primes:
        if math.gcd(base1 * base2, p) != 1:
            continue
        # finite torus residues for b1^k*b2^l + c mod p.
        seen = set()
        ord1 = multiplicative_order(base1 % p, p)
        ord2 = multiplicative_order(base2 % p, p)
        for k in range(ord1):
            for l in range(ord2):
                seen.add((pow(base1, k, p) * pow(base2, l, p) + c) % p)
        covered_zero = 0 in seen
        prime_rows.append({"p": p, "ord_base1": ord1, "ord_base2": ord2, "torus_size": ord1*ord2, "residue_coverage": len(seen), "coverage_ratio": len(seen)/p, "zero_covered": covered_zero, "uncovered_count": p-len(seen)})
    # greedy cover candidates: primes where zero is covered and coverage ratio small enough to be useful.
    candidates = [r for r in prime_rows if r["zero_covered"]]
    saturation = []
    covered_moduli = []
    for r in candidates[:20]:
        covered_moduli.append(r["p"])
        M = 1
        for q in covered_moduli:
            M *= q
        saturation.append({"moduli": list(covered_moduli), "product": M, "note": "finite torus local zero exists; infinite covering not proven"})
    lift = []
    for r in candidates[:12]:
        p = r["p"]
        for e in [2, 3]:
            pe = p ** e
            if math.gcd(base1 * base2, pe) != 1:
                continue
            # sample lift grid capped.
            hits = 0
            trials = 0
            lim1 = min(60, max(1, r["ord_base1"] * p ** (e-1)))
            lim2 = min(60, max(1, r["ord_base2"] * p ** (e-1)))
            for k in range(lim1):
                for l in range(lim2):
                    trials += 1
                    if (pow(base1, k, pe) * pow(base2, l, pe) + c) % pe == 0:
                        hits += 1
            lift.append({"p_power": pe, "p": p, "e": e, "sample_hits": hits, "sample_trials": trials, "lift_status": "HAS_SAMPLE_LIFT" if hits else "NO_SAMPLE_LIFT_TERMINAL_OBSTRUCTION_CANDIDATE"})
    report = {
        "object": f"{base1}^k * {base2}^l + {c}",
        "prime_rows": prime_rows,
        "local_zero_primes": [r["p"] for r in candidates],
        "saturation_curve": saturation,
        "prime_power_lift_audit": lift,
        "covering_certificate_status": "NOT_PROVEN",
        "next_experiment": "build CRT compatibility graph over local zero residue pairs and prove uncovered class or extract cover certificate",
    }
    if out:
        ensure_dir(out)
        (out / "crt_lab_v5_report.json").write_text(stable_json(report))
        (out / "crt_lab_v5_report.md").write_text("# CRT Lab V5\n\n```json\n" + stable_json(report) + "\n```\n")
    return report


def multiplicative_order(a: int, m: int) -> int:
    if math.gcd(a, m) != 1:
        return 0
    x = 1
    for k in range(1, max(2, m*m + 1)):
        x = (x * a) % m
        if x == 1:
            return k
    return m*m

# ---------------------------------------------------------------------------
# Analysis pipeline
# ---------------------------------------------------------------------------

def analyze_sequence(seq: Sequence[int], label: str, out_dir: Path, round_no: int = 1, mode: str = "discovery", db_path: Optional[Path] = None, action_hint: Optional[str] = None) -> Dict[str, Any]:
    ensure_dir(out_dir)
    db_path = db_path or (out_dir / "oracle_nt_v5_corpus.sqlite")
    corpus = Corpus(db_path)
    object_id = corpus.store_object(label, "sequence", {"sequence": list(map(int, seq))})
    equivalents = corpus.find_equivalents(seq)

    engine = InvariantEngine()
    invariants, meta = engine.discover(seq, mode=mode)
    meta["corpus_equivalents"] = equivalents

    router = TheoremRouter()
    routes = router.route(seq, invariants)

    tribunal = Tribunal(out_dir / "handoffs")
    tribunal_report = tribunal.run(f"{label}_round{round_no}", seq, invariants, routes)

    # Re-sort after binding mutations.
    invariants.sort(key=lambda x: x.total_score, reverse=True)
    gates = ClaimDiscipline().gates(seq, invariants, routes, meta, mode)
    kbk = KBKCompiler().compile(label, seq, invariants, routes, gates, round_no, out_dir)

    top = invariants[0] if invariants else None
    verdict = "CLASSIFICATION" if any(g.tier == "classification" and g.fires for g in gates) else "ESCALATION"
    if any(g.tier in ("theorem", "novelty", "proof_target") and g.fires for g in gates):
        verdict = "GTH_TIERED"
    if any(top.blockers for top in invariants[:1]):
        verdict = "BLOCKED_ESCALATION"

    report = {
        "version": VERSION,
        "created_at": utc_now(),
        "label": label,
        "mode": mode,
        "round": round_no,
        "object_id": object_id,
        "sequence": list(map(int, seq)),
        "meta": meta,
        "invariants": [i.to_json() for i in invariants],
        "theorem_routes": [r.to_json() for r in routes],
        "claim_gates": [g.to_json() for g in gates],
        "tribunal": tribunal_report,
        "kbk_packet": kbk,
        "verdict": verdict,
        "primary_invariant": top.name if top else None,
        "status_line": status_line(verdict, top, gates),
    }
    stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", label)[:80] + f"_round{round_no}"
    (out_dir / f"{stem}.json").write_text(stable_json(report))
    (out_dir / f"{stem}.kbk.json").write_text(stable_json(kbk))
    (out_dir / f"{stem}.md").write_text(render_markdown(report))
    corpus.store_run(object_id, label, mode, round_no, verdict, top.name if top else "NONE", report)
    corpus.store_kbk(object_id, round_no, kbk["one_binary"], kbk["next_action"], kbk["executable_next_experiment"], kbk)
    return report


def status_line(verdict: str, top: Optional[Invariant], gates: List[ClaimGate]) -> str:
    if not top:
        return "No invariant survived. Acquire better object/data."
    theorem = next((g for g in gates if g.tier == "theorem"), None)
    novelty = next((g for g in gates if g.tier == "novelty"), None)
    if theorem and not theorem.fires:
        return f"Primary={top.name}. Classification possible; theorem GTH blocked by {theorem.blockers[:2]}."
    if novelty and not novelty.fires:
        return f"Primary={top.name}. The object classifies, but novelty is blocked by {novelty.blockers[:2]}."
    return f"Primary={top.name}. Verdict={verdict}."


def render_markdown(report: Dict[str, Any]) -> str:
    lines = [f"# Oracle NT OS V5 Report — {report['label']}", "", f"Version: `{report['version']}`", f"Verdict: **{report['verdict']}**", "", f"Status: {report['status_line']}", ""]
    lines += ["## Top invariants", ""]
    for inv in report["invariants"][:8]:
        lines += [f"### {inv['name']} — score {inv['total_score']}", f"Status: `{inv['status']}` | coordinate: `{inv['coordinate']}`", f"Open: {inv.get('open_conditions', [])}", f"Blockers: {inv.get('blockers', [])}", f"Demotions: {inv.get('demotions', [])}", ""]
    lines += ["## Claim gates", ""]
    for g in report["claim_gates"]:
        lines += [f"- **{g['tier']}**: `{g['status']}` fires={g['fires']} blockers={g['blockers']}"]
    lines += ["", "## KBK next experiment", "", f"Binary: **{report['kbk_packet']['one_binary']}**", "", "```bash", report['kbk_packet']['executable_next_experiment'], "```", ""]
    lines += ["## Theorem routes", ""]
    for r in report["theorem_routes"]:
        lines += [f"### {r['name']} — {r['status']}", f"Open: {r['open_conditions']}", "Obligations:"]
        for o in r["exact_obligations"]:
            lines.append(f"- {o}")
        lines.append("")
    return "\n".join(lines)

# ---------------------------------------------------------------------------
# Multi-round runner
# ---------------------------------------------------------------------------

def run_rounds(seq: Sequence[int], label: str, rounds: int, out_dir: Path, mode: str = "discovery") -> Dict[str, Any]:
    ensure_dir(out_dir)
    db = out_dir / "oracle_nt_v5_corpus.sqlite"
    reports = []
    last_action = None
    fake_loop_detected = False
    for r in range(1, rounds + 1):
        rep = analyze_sequence(seq, label, out_dir, round_no=r, mode=mode, db_path=db, action_hint=last_action)
        reports.append(rep)
        action = rep["kbk_packet"]["next_action"]
        # Execute the required action as part of the round; this is the anti-fake-loop enforcement.
        forced_actions = [
            "audit_minimal_recurrence_order",
            "audit_primitive_divisors",
            "audit_strong_divisibility_then_proof_route",
            "search_for_nontrivial_transform_or_generalization",
            "derive_polynomial_certificate",
            "fit_LTE_or_reject_padic_route",
        ]
        if last_action == action and r > 1:
            used = {rr["kbk_packet"]["next_action"] for rr in reports[:-1]}
            replacement = next((a for a in forced_actions if a not in used), None)
            if replacement:
                rep["kbk_packet"]["anti_fake_loop_replacement"] = {"original": action, "replacement": replacement, "reason": "same action repeated; V5 must execute a new measurement"}
                rep["kbk_packet"]["next_action"] = replacement
                rep["kbk_packet"]["one_binary"] = KBKCompiler().binary_for(replacement, rep["kbk_packet"].get("sharpest_open_condition", "repeat"))
                rep["kbk_packet"]["executable_next_experiment"] = KBKCompiler().command_for(replacement, label, seq, out_dir)
                action = replacement
            else:
                fake_loop_detected = True
        attack_result = run_attack(action, seq)
        rep["executed_required_action"] = attack_result
        # Persist modified report with action result.
        stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", label)[:80] + f"_round{r}"
        (out_dir / f"{stem}.json").write_text(stable_json(rep))
        last_action = action
    summary = {
        "version": VERSION,
        "label": label,
        "rounds": rounds,
        "fake_loop_detected": fake_loop_detected,
        "actions_executed": [r["kbk_packet"]["next_action"] for r in reports],
        "final_status": reports[-1]["status_line"] if reports else None,
        "reports": [f"{label}_round{i}.json" for i in range(1, rounds + 1)],
    }
    (out_dir / "run_summary.json").write_text(stable_json(summary))
    return summary

# ---------------------------------------------------------------------------
# Benchmark gauntlet
# ---------------------------------------------------------------------------

def benchmark_cases() -> List[Dict[str, Any]]:
    fib = [0,1]
    while len(fib) < 16: fib.append(fib[-1]+fib[-2])
    fib11 = [1,1]
    while len(fib11) < 16: fib11.append(fib11[-1]+fib11[-2])
    luc = [2,1]
    while len(luc) < 16: luc.append(luc[-1]+luc[-2])
    squares = [i*i for i in range(16)]
    poisoned_sq = squares[:]
    poisoned_sq[10] += 7
    triangular = [i*(i+1)//2 for i in range(16)]
    powers2 = [2**i for i in range(16)]
    periodic = [1,2,3,1,2,3,1,2,3,1,2,3]
    poisoned_periodic = periodic[:]
    poisoned_periodic[7] = 99
    # Somos-like small prefix (not full proof target)
    somos4 = [1,1,1,1]
    for n in range(4, 14):
        somos4.append((somos4[n-1]*somos4[n-3] + somos4[n-2]**2)//somos4[n-4])
    # random high-degree polynomial trap from first terms
    high_poly = [i**6 - 3*i**4 + 2*i + 1 for i in range(16)]
    # recurrence impostor: first 12 fib then bad tail
    fib_poison = fib[:]
    fib_poison[-1] += 5
    # degenerate recurrence geometric
    geom3 = [3**i for i in range(14)]
    # affine equivalents
    aff_squares = [5*x + 7 for x in squares]
    diff_squares = differences(squares)
    cases = [
        ("fibonacci_0_1", fib, "exact_linear_recurrence"),
        ("fibonacci_1_1", fib11, "exact_linear_recurrence"),
        ("lucas", luc, "exact_linear_recurrence"),
        ("squares", squares, "polynomial_finite_difference"),
        ("triangular", triangular, "polynomial_finite_difference"),
        ("powers2", powers2, "exact_geometric_progression"),
        ("periodic", periodic, "exact_periodic_sequence"),
        ("poisoned_squares", poisoned_sq, "single_corruption_over_simple_law"),
        ("poisoned_fibonacci", fib_poison, "single_corruption_over_simple_law"),
        ("poisoned_periodic", poisoned_periodic, "single_corruption_over_simple_law"),
        ("somos4_prefix", somos4, None),
        ("high_degree_polynomial", high_poly, "polynomial_finite_difference"),
        ("geometric3", geom3, "exact_geometric_progression"),
        ("affine_squares", aff_squares, "polynomial_finite_difference"),
        ("diff_squares", diff_squares, "polynomial_finite_difference"),
        ("constant7", [7]*12, "polynomial_finite_difference"),
        ("naturals", list(range(14)), "polynomial_finite_difference"),
        ("cubes", [i**3 for i in range(14)], "polynomial_finite_difference"),
        ("quartic", [i**4+i for i in range(14)], "polynomial_finite_difference"),
        ("alternating", [(-1)**i for i in range(14)], "exact_geometric_progression"),
        ("linear_rec_order3", [0,0,1,1,2,4,7,13,24,44,81,149,274], "exact_linear_recurrence"),
        ("factorial", [math.factorial(i) for i in range(10)], None),
        ("primes", primes_upto(50)[:12], None),
        ("divisor_count_small", [len(factorint(i)) for i in range(1,18)], None),
        ("mersenne", [2**i-1 for i in range(1,15)], "exact_linear_recurrence"),
        ("fermat_tiny", [2**(2**i)+1 for i in range(6)], None),
        ("shifted_triangular", [((i+2)*(i+3)//2) for i in range(14)], "polynomial_finite_difference"),
        ("scaled_fib", [3*x for x in fib11], "exact_linear_recurrence"),
        ("sign_alternating_linear", [(-1)**i * (i+1) for i in range(14)], "exact_linear_recurrence"),
        ("random_fixed", [3,1,4,1,5,9,2,6,5,3,5,8,9], None),
        ("padic_powers", [2**valuation(i,2) if i else 0 for i in range(1,18)], None),
        ("binomial_n_choose_2", [math.comb(i,2) for i in range(16)], "polynomial_finite_difference"),
    ]
    return [{"label": a, "seq": b, "expected_top": c} for a,b,c in cases]


def run_benchmark(out_dir: Path) -> Dict[str, Any]:
    ensure_dir(out_dir)
    cases = benchmark_cases()
    passed = 0
    results = []
    for c in cases:
        rep = analyze_sequence(c["seq"], c["label"], out_dir / "runs", mode="discovery")
        top = rep.get("primary_invariant")
        expected = c["expected_top"]
        # For expected None, pass if no novelty GTH and status is not bogus theorem claim.
        if expected is None:
            novelty_gate = next((g for g in rep["claim_gates"] if g["tier"] == "novelty"), {})
            ok = not novelty_gate.get("fires", False)
        else:
            ok = top == expected
        passed += int(ok)
        results.append({"label": c["label"], "expected": expected, "top": top, "ok": ok, "status": rep["status_line"]})
    summary = {"version": VERSION, "passed": passed, "total": len(cases), "results": results}
    (out_dir / "benchmark_summary.json").write_text(stable_json(summary))
    (out_dir / "benchmark_summary.md").write_text("# V5 Benchmark Gauntlet\n\n" + f"Passed {passed}/{len(cases)}\n\n```json\n" + stable_json(summary) + "\n```\n")
    return summary


def selftest(out_dir: Path) -> Dict[str, Any]:
    ensure_dir(out_dir)
    bench = run_benchmark(out_dir / "gauntlet")
    sq = analyze_sequence([i*i for i in range(12)], "selftest_squares", out_dir / "regression")
    fib = analyze_sequence([1,1,2,3,5,8,13,21,34,55,89,144], "selftest_fib", out_dir / "regression")
    theorem_gate = next(g for g in fib["claim_gates"] if g["tier"] == "theorem")
    novelty_gate = next(g for g in fib["claim_gates"] if g["tier"] == "novelty")
    poisoned = analyze_sequence([0,1,4,9,16,25,36,49,64,81,107,121], "selftest_poisoned_squares", out_dir / "regression")
    runsum = run_rounds([1,1,2,3,5,8,13,21,34,55,89,144], "selftest_run", 3, out_dir / "rounds")
    ok = (
        bench["passed"] >= 28 and
        sq["primary_invariant"] == "polynomial_finite_difference" and
        theorem_gate["status"] in ("GTH_BLOCKED_BY_OPEN_CONDITION", "THEOREM_GTH_ELIGIBLE") and
        novelty_gate["fires"] is False and
        poisoned["primary_invariant"] == "single_corruption_over_simple_law" and
        not runsum["fake_loop_detected"]
    )
    result = {
        "version": VERSION,
        "selftest": "PASS" if ok else "FAIL",
        "benchmark": bench["passed"],
        "benchmark_total": bench["total"],
        "squares_top": sq["primary_invariant"],
        "known_fib_novelty_fires": novelty_gate["fires"],
        "poisoned_squares_top": poisoned["primary_invariant"],
        "fake_loop_detected": runsum["fake_loop_detected"],
    }
    (out_dir / "selftest_summary.json").write_text(stable_json(result))
    return result

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description="Oracle Number Theory OS V5")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("analyze-seq")
    p.add_argument("--seq", required=True)
    p.add_argument("--label", default="sequence")
    p.add_argument("--out", default="out")
    p.add_argument("--mode", default="discovery", choices=["classification", "discovery", "theorem"])
    p.add_argument("--round", type=int, default=1)

    p = sub.add_parser("run")
    p.add_argument("--seq", required=True)
    p.add_argument("--label", default="sequence")
    p.add_argument("--rounds", type=int, default=5)
    p.add_argument("--out", default="out")
    p.add_argument("--mode", default="discovery", choices=["classification", "discovery", "theorem"])

    p = sub.add_parser("attack")
    p.add_argument("--action", required=True)
    p.add_argument("--seq", required=True)
    p.add_argument("--label", default="sequence")
    p.add_argument("--out", default="out")

    p = sub.add_parser("benchmark")
    p.add_argument("--out", default="benchmark_out")

    p = sub.add_parser("selftest")
    p.add_argument("--out", default="selftest_out")

    p = sub.add_parser("crt-lab")
    p.add_argument("--base1", type=int, required=True)
    p.add_argument("--base2", type=int, required=True)
    p.add_argument("--c", type=int, default=1)
    p.add_argument("--max-modulus", type=int, default=200)
    p.add_argument("--out", default="crt_out")

    args = ap.parse_args(argv)
    if args.cmd == "analyze-seq":
        rep = analyze_sequence(parse_int_sequence(args.seq), args.label, Path(args.out), round_no=args.round, mode=args.mode)
        print(stable_json({"version": VERSION, "verdict": rep["verdict"], "primary_invariant": rep["primary_invariant"], "status_line": rep["status_line"], "kbk_next": rep["kbk_packet"]}))
    elif args.cmd == "run":
        print(stable_json(run_rounds(parse_int_sequence(args.seq), args.label, args.rounds, Path(args.out), mode=args.mode)))
    elif args.cmd == "attack":
        result = run_attack(args.action, parse_int_sequence(args.seq))
        ensure_dir(Path(args.out))
        (Path(args.out) / f"{args.label}_{args.action}.attack.json").write_text(stable_json(result))
        print(stable_json(result))
    elif args.cmd == "benchmark":
        print(stable_json(run_benchmark(Path(args.out))))
    elif args.cmd == "selftest":
        print(stable_json(selftest(Path(args.out))))
    elif args.cmd == "crt-lab":
        print(stable_json(crt_lab(args.base1, args.base2, args.c, args.max_modulus, Path(args.out))))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
