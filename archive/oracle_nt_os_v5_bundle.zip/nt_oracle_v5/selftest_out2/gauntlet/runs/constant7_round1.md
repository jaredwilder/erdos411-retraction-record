# Oracle NT OS V5 Report — constant7

Version: `5.0.0-oracle-nt-os`
Verdict: **CLASSIFICATION**

Status: Primary=polynomial_finite_difference. Classification possible; theorem GTH blocked by ['strong_divisibility_sequence: all_indices_proof', 'LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions'].

## Top invariants

### polynomial_finite_difference — score 0.7675
Status: `THEOREM_READY` | coordinate: `finite_difference_polynomial`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### exact_geometric_progression — score 0.7402
Status: `THEOREM_READY` | coordinate: `multiplicative_exponential`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### exact_periodic_sequence — score 0.7285
Status: `THEOREM_READY` | coordinate: `finite_automaton_periodic`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### strong_divisibility_prefix — score 0.6064
Status: `PREFIX_CERTIFIED` | coordinate: `divisibility_lattice`
Open: ['prove_strong_divisibility_for_all_indices']
Blockers: []
Demotions: ['known_family_classification_not_novel']

### exact_linear_recurrence — score 0.6056
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: ['recurrence_true_but_polynomial_coordinate_is_primary', 'known_family_classification_not_novel']

### valuation_profile — score 0.3502
Status: `OBSERVED_ONLY` | coordinate: `p_adic_profile`
Open: ['repair_corruption_before_p_adic_claim']
Blockers: ['valuation_profile_may_be_artifact_of_single_corruption']
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['strong_divisibility_sequence: all_indices_proof', 'LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.10', 'research_value_score_too_low:0.15']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['strong_divisibility_sequence: open all_indices_proof', 'LTE_valuation: open exact_LTE_form']

## KBK next experiment

Binary: **strong divisibility extends OR divisibility route killed**

```bash
python oracle_nt_os_v5.py attack --action audit_strong_divisibility_then_proof_route --seq "7,7,7,7,7,7,7,7,7,7,7,7" --label constant7 --out /mnt/data/nt_oracle_v5/selftest_out2/gauntlet/runs
```

## Theorem routes

### finite_difference_polynomial — THEOREM_READY
Open: []
Obligations:
- Prove by finite differences that a(n) = 7 for all n in the intended domain.

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['1'].
- Prove no recurrence of order < 1 fits the sequence under the intended generation rule.

### strong_divisibility_sequence — GTH_BLOCKED_BY_OPEN_CONDITION
Open: ['all_indices_proof']
Obligations:
- Prove gcd(a_m,a_n)=a_gcd(m,n) for all positive m,n using recurrence or divisibility-lattice structure.

### LTE_valuation — GTH_BLOCKED_BY_OPEN_CONDITION
Open: ['exact_LTE_form', 'prime_conditions', 'parity_conditions']
Obligations:
- Derive exact a^n-b^n form and verify LTE prime/parity hypotheses.
