# Oracle NT OS V5 Report — geometric3

Version: `5.0.0-oracle-nt-os`
Verdict: **CLASSIFICATION**

Status: Primary=exact_geometric_progression. Classification possible; theorem GTH blocked by ['LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions'].

## Top invariants

### exact_geometric_progression — score 0.7987
Status: `THEOREM_READY` | coordinate: `multiplicative_exponential`
Open: []
Blockers: []
Demotions: []

### exact_linear_recurrence — score 0.7516
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: []

### single_corruption_over_simple_law — score 0.7158
Status: `PREFIX_CERTIFIED` | coordinate: `data_integrity`
Open: ['operator_confirm_or_repair_suspect_term']
Blockers: ['do_not_promote_weaker_opportunistic_invariant_until_corruption_checked']
Demotions: []

### valuation_profile — score 0.3502
Status: `OBSERVED_ONLY` | coordinate: `p_adic_profile`
Open: ['repair_corruption_before_p_adic_claim']
Blockers: ['valuation_profile_may_be_artifact_of_single_corruption']
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.35', 'research_value_score_too_low:0.34']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['LTE_valuation: open exact_LTE_form']

## KBK next experiment

Binary: **LTE_valuation: exact_LTE_form,prime_conditions,parity_conditions closes OR route is killed**

```bash
python oracle_nt_os_v5.py attack --action fit_exact_exponential_difference_form --seq "1,3,9,27,81,243,729,2187,6561,19683,59049,177147,531441,1594323" --label geometric3 --out /mnt/data/nt_oracle_v5/selftest_out2/gauntlet/runs
```

## Theorem routes

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['3'].
- Prove no recurrence of order < 1 fits the sequence under the intended generation rule.

### LTE_valuation — GTH_BLOCKED_BY_OPEN_CONDITION
Open: ['exact_LTE_form', 'prime_conditions', 'parity_conditions']
Obligations:
- Derive exact a^n-b^n form and verify LTE prime/parity hypotheses.
