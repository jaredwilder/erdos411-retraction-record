# Oracle NT OS V5 Report — linear_rec_order3

Version: `5.0.0-oracle-nt-os`
Verdict: **GTH_TIERED**

Status: Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45'].

## Top invariants

### exact_linear_recurrence — score 0.7516
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: []

### valuation_profile — score 0.4212
Status: `PREFIX_CERTIFIED` | coordinate: `p_adic_profile`
Open: ['derive_exact_p_adic_law']
Blockers: []
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `THEOREM_GTH_ELIGIBLE` fires=True blockers=[]
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.48', 'research_value_score_too_low:0.45']
- **proof_target**: `PROOF_TARGET_READY` fires=True blockers=[]

## KBK next experiment

Binary: **nontrivial novelty seam exists OR known-family closure**

```bash
python oracle_nt_os_v5.py attack --action search_for_nontrivial_transform_or_generalization --seq "0,0,1,1,2,4,7,13,24,44,81,149,274" --label linear_rec_order3 --out /mnt/data/nt_oracle_v5/selftest_out2/gauntlet/runs
```

## Theorem routes

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['1', '1', '1'].
- Prove no recurrence of order < 3 fits the sequence under the intended generation rule.
