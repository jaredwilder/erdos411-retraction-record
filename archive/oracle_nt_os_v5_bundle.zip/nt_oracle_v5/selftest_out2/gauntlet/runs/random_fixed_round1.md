# Oracle NT OS V5 Report — random_fixed

Version: `5.0.0-oracle-nt-os`
Verdict: **ESCALATION**

Status: Primary=valuation_profile. Classification possible; theorem GTH blocked by ['primary invariant status PREFIX_CERTIFIED'].

## Top invariants

### valuation_profile — score 0.4212
Status: `PREFIX_CERTIFIED` | coordinate: `p_adic_profile`
Open: ['derive_exact_p_adic_law']
Blockers: []
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_BLOCKED` fires=False blockers=[]
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['primary invariant status PREFIX_CERTIFIED']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.35', 'research_value_score_too_low:0.35']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['no theorem route']

## KBK next experiment

Binary: **primary invariant status PREFIX_CERTIFIED closes OR route is killed**

```bash
python oracle_nt_os_v5.py attack --action measure_top_open_condition --seq "3,1,4,1,5,9,2,6,5,3,5,8,9" --label random_fixed --out /mnt/data/nt_oracle_v5/selftest_out2/gauntlet/runs
```

## Theorem routes
