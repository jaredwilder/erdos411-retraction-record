# Oracle NT OS V5 Report — poisoned_fibonacci

Version: `5.0.0-oracle-nt-os`
Verdict: **BLOCKED_ESCALATION**

Status: Primary=single_corruption_over_simple_law. Classification possible; theorem GTH blocked by ['primary invariant status PREFIX_CERTIFIED'].

## Top invariants

### single_corruption_over_simple_law — score 0.7158
Status: `PREFIX_CERTIFIED` | coordinate: `data_integrity`
Open: ['operator_confirm_or_repair_suspect_term']
Blockers: ['do_not_promote_weaker_opportunistic_invariant_until_corruption_checked']
Demotions: []

### valuation_profile — score 0.3502
Status: `OBSERVED_ONLY` | coordinate: `p_adic_profile`
Open: ['repair_corruption_before_p_adic_claim']
Blockers: ['valuation_profile_may_be_artifact_of_single_corruption']
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_BLOCKED` fires=False blockers=['do_not_promote_weaker_opportunistic_invariant_until_corruption_checked']
- **theorem**: `GTH_BLOCKED_BY_OPEN_CONDITION` fires=False blockers=['primary invariant status PREFIX_CERTIFIED']
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.30', 'research_value_score_too_low:0.62']
- **proof_target**: `PROOF_TARGET_BLOCKED` fires=False blockers=['no theorem route']

## KBK next experiment

Binary: **primary invariant status PREFIX_CERTIFIED closes OR route is killed**

```bash
python oracle_nt_os_v5.py attack --action measure_top_open_condition --seq "0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,615" --label poisoned_fibonacci --out /mnt/data/nt_oracle_v5/selftest_out2/gauntlet/runs
```

## Theorem routes
