# Oracle NT OS V5 Report — cubes

Version: `5.0.0-oracle-nt-os`
Verdict: **GTH_TIERED**

Status: Primary=polynomial_finite_difference. The object classifies, but novelty is blocked by ['novelty_score_too_low:0.31', 'research_value_score_too_low:0.35'].

## Top invariants

### polynomial_finite_difference — score 0.814
Status: `THEOREM_READY` | coordinate: `finite_difference_polynomial`
Open: []
Blockers: []
Demotions: []

### exact_linear_recurrence — score 0.6236
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: ['recurrence_true_but_polynomial_coordinate_is_primary']

### valuation_profile — score 0.3502
Status: `OBSERVED_ONLY` | coordinate: `p_adic_profile`
Open: ['repair_corruption_before_p_adic_claim']
Blockers: ['valuation_profile_may_be_artifact_of_single_corruption']
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `THEOREM_GTH_ELIGIBLE` fires=True blockers=[]
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['novelty_score_too_low:0.31', 'research_value_score_too_low:0.35']
- **proof_target**: `PROOF_TARGET_READY` fires=True blockers=[]

## KBK next experiment

Binary: **nontrivial novelty seam exists OR known-family closure**

```bash
python oracle_nt_os_v5.py attack --action search_for_nontrivial_transform_or_generalization --seq "0,1,8,27,64,125,216,343,512,729,1000,1331,1728,2197" --label cubes --out /mnt/data/nt_oracle_v5/selftest_out/gauntlet/runs
```

## Theorem routes

### finite_difference_polynomial — THEOREM_READY
Open: []
Obligations:
- Prove by finite differences that a(n) = n**3 for all n in the intended domain.

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['4', '-6', '4', '-1'].
- Prove no recurrence of order < 4 fits the sequence under the intended generation rule.
