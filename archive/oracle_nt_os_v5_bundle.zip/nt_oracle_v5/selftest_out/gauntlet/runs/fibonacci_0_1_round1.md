# Oracle NT OS V5 Report — fibonacci_0_1

Version: `5.0.0-oracle-nt-os`
Verdict: **GTH_TIERED**

Status: Primary=exact_linear_recurrence. The object classifies, but novelty is blocked by ['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.12'].

## Top invariants

### exact_linear_recurrence — score 0.685
Status: `THEOREM_READY` | coordinate: `constant_coefficient_recurrence`
Open: []
Blockers: []
Demotions: ['known_family_classification_not_novel']

### single_corruption_over_simple_law — score 0.66
Status: `PREFIX_CERTIFIED` | coordinate: `data_integrity`
Open: ['operator_confirm_or_repair_suspect_term']
Blockers: ['do_not_promote_weaker_opportunistic_invariant_until_corruption_checked']
Demotions: ['tribunal_demoted_below_theorem_ready_exact_linear_recurrence']

### valuation_profile — score 0.3502
Status: `OBSERVED_ONLY` | coordinate: `p_adic_profile`
Open: ['repair_corruption_before_p_adic_claim']
Blockers: ['valuation_profile_may_be_artifact_of_single_corruption']
Demotions: []

## Claim gates

- **classification**: `CLASSIFICATION_READY` fires=True blockers=[]
- **theorem**: `THEOREM_GTH_ELIGIBLE` fires=True blockers=[]
- **novelty**: `NOVELTY_BLOCKED` fires=False blockers=['known_family_demoted_no_novelty_claim', 'novelty_score_too_low:0.12', 'research_value_score_too_low:0.18']
- **proof_target**: `PROOF_TARGET_READY` fires=True blockers=[]

## KBK next experiment

Binary: **nontrivial novelty seam exists OR known-family closure**

```bash
python oracle_nt_os_v5.py attack --action search_for_nontrivial_transform_or_generalization --seq "0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610" --label fibonacci_0_1 --out /mnt/data/nt_oracle_v5/selftest_out/gauntlet/runs
```

## Theorem routes

### linear_recurrence_minimality — THEOREM_READY
Open: []
Obligations:
- Define a(n) by initial values and recurrence coefficients ['1', '1'].
- Prove no recurrence of order < 2 fits the sequence under the intended generation rule.

### Lucas_Lehmer_Zsigmondy_BHV — THEOREM_READY
Open: []
Obligations:
- Show recurrence is Lucas/Lehmer-normalized with P=1, Q=-1, discriminant=5.
- Apply primitive divisor theorem after explicitly listing exception indices.
