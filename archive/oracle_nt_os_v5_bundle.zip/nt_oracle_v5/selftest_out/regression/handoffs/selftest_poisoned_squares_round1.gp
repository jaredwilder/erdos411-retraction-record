\ Auto-generated Oracle NT OS V5 PARI/GP tribunal handoff
A = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 107, 121];
print("Sequence length ", #A);
\ Factor first nontrivial terms for primitive-divisor audit
for(i=1,min(#A,20), if(abs(A[i])>1, print([i,A[i],factor(abs(A[i]))])));
quit;
