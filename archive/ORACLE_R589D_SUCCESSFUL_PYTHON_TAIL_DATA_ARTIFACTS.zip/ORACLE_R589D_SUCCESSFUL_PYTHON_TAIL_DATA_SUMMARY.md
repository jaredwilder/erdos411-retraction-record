# ORACLE R589D — Successful Python Tail Data

## Chamber

```text
p <= 1,000,000
p ≡ 7 mod 8
2 <= t <= 30
4*p^t <= 10^50
```

## Step-2 formula scan

Python used:

```text
x1 = p^(t-1)*(3p-1)
x2 = p^(t-2)*[p*(3p-1)+(p-1)*phi(3p-1)]
```

Counts:

```text
prime p tested:          19,669
t-cases counted:         148,345
B = 4p^2 hits:           0
B < 4p^2 underflow p:    348
B > 4p^2 overflow p:     19,321
x1 p-source births:      0
minimum margin:          -124638340176
```

## Conservative continuation subset

```text
continued overshoots:        8
continued hits:              0
continued p-sources:         0
continued descent violations:0
skipped large-factor cases:  2654
```

## t=1 via D-ledger

```text
m < 2^64
p < 24,595,658,764,946,068,820
survivors: p = 7, 47
```

## Data verdict

This artifact is clean and successful. It does **not** claim all underflows are dead. It records the exact underflow chamber as the next Python target.
