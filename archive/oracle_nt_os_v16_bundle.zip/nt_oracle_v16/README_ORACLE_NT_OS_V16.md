# Oracle NT OS V16 — Discovery Foundry

V16 implements the Heat Packet requirement: discovery pressure, not just discovery-gate verification.

Core loop:

```text
candidate population -> heat scoring -> one selected binary -> tool execution -> frontier delta or failure asset -> next KBK binary
```

## Main commands

```bash
python oracle_nt_os_v16.py selftest --out v16_selftest
```

```bash
python oracle_nt_os_v16.py generate-candidates \
  --topic crt_lift \
  --n 64 \
  --out v16_candidates.json
```

```bash
python oracle_nt_os_v16.py score-candidates \
  --candidates v16_candidates.json \
  --out v16_heat_scores.json
```

```bash
python oracle_nt_os_v16.py select-binary \
  --scores v16_heat_scores.json \
  --out v16_selected_binary.json
```

```bash
python oracle_nt_os_v16.py crt-extension-pressure \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --base-moduli 5 7 11 \
  --extension-primes 13 17 19 23 29 31 \
  --out v16_crt_extension_pressure
```

## What it proves

V16 proves that the machine can generate a candidate frontier mutation pool, score it, select one KBK binary, execute the selected CRT extension-pressure test, emit replayable extension certificates, verify the discovery packet, and produce the next KBK binary.

## What it does not prove

It does not prove the global covering theorem. It does not prove EG203. It produces a finite extension-persistence/fragility classification over the stated modulus family and extension primes.

## Main V16 result from proof run

For base moduli `{5,7,11}` and extension primes `{13,17,19,23,29,31}`, V16 found mixed behavior:

- q=13: `MODULUS_DEPENDENT_ARTIFACT`, persistence ratio ≈ 0.9129
- q=17: `PERSISTENT_OBSTRUCTION`, persistence ratio = 1.0
- q=19: `PERSISTENT_OBSTRUCTION`, persistence ratio = 1.0
- q=23: `PERSISTENT_OBSTRUCTION`, persistence ratio = 1.0
- q=29: `PERSISTENT_OBSTRUCTION`, persistence ratio = 1.0
- q=31: `MODULUS_DEPENDENT_ARTIFACT`, persistence ratio ≈ 0.9721

Next KBK binary:

```text
Classify extension-prime features that predict persistence versus fragility.
```
