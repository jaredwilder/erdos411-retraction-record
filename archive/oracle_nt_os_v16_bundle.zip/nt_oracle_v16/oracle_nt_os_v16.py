#!/usr/bin/env python3
"""
Oracle NT OS V16 - Discovery Foundry
Implements candidate pressure -> heat scoring -> one selected binary -> tool execution -> frontier delta/failure asset -> next KBK.
This is intentionally self-contained and deterministic for replay.
"""
from __future__ import annotations
import argparse, json, hashlib, math, os, itertools, statistics, sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional, Iterable, Set

VERSION = "16.0.0-oracle-discovery-foundry"

ALLOWED_ATTACK_TYPES = {
    "CRT_LIFT", "PRIMITIVE_DIVISOR", "RECURRENCE_REPLAY", "POLYNOMIAL_REPLAY",
    "SIEVE_SEAM", "KNOWN_THEOREM_GRAPH", "COUNTEREXAMPLE_SEARCH", "FORMAL_LEMMA"
}
ALLOWED_DELTAS = {
    "NEW_OBSTRUCTION", "NEW_CONSTRUCTION", "NEW_INVARIANT", "NEW_DICHOTOMY",
    "NEW_COUNTEREXAMPLE", "NEW_FORMAL_LEMMA_TARGET", "NEW_SEARCH_SPACE_REDUCTION",
    "NEW_CERTIFICATE_SCHEMA", "NEW_COORDINATE_SYSTEM", "ROUTE_KILL_WITH_ENUMERATED_UNTESTED_MOVES"
}
ALLOWED_ADJUDICATORS = {
    "python_enumeration", "sage_pari_sympy", "lean", "certificate_replay", "literature_search",
    "known_theorem_graph", "counterexample_search", "randomized_stress_harness"
}

# ------------------------- utilities -------------------------
def sha256_json(obj: Any) -> str:
    data = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()

def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")

def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def multiplicative_order(a: int, m: int) -> Optional[int]:
    if math.gcd(a, m) != 1:
        return None
    x = a % m
    for r in range(1, 10_000):
        if x == 1:
            return r
        x = (x * a) % m
    return None

def lcm(vals: Iterable[int]) -> int:
    out = 1
    for v in vals:
        out = out * v // math.gcd(out, v)
    return out

# ------------------------- candidate engine -------------------------
@dataclass
class Candidate:
    candidate_id: str
    attack_type: str
    binary: str
    expected_frontier_delta: str
    required_adjudicator: str
    estimated_cost: str
    kill_value: str
    proof_pressure: str
    novelty_anchor: str
    scores: Dict[str, float]
    rejected: bool = False
    rejection_reason: Optional[str] = None
    heat_score: Optional[float] = None

def validate_candidate(c: Dict[str, Any]) -> Tuple[bool, str]:
    if c.get("attack_type") not in ALLOWED_ATTACK_TYPES:
        return False, "CANDIDATE_REJECTED_BAD_ATTACK_TYPE"
    b = c.get("binary")
    if not b or not isinstance(b, str):
        return False, "CANDIDATE_REJECTED_NO_BINARY"
    if " and " in b.lower() and "?" in b and b.count("?") > 1:
        return False, "CANDIDATE_REJECTED_MULTIPLE_BINARIES"
    if c.get("required_adjudicator") not in ALLOWED_ADJUDICATORS:
        return False, "CANDIDATE_REJECTED_NO_ADJUDICATOR"
    if c.get("expected_frontier_delta") in (None, "", "better understanding", "interesting"):
        return False, "CANDIDATE_REJECTED_FAKE_DELTA"
    if not c.get("kill_value") or c.get("kill_value") in {"none", "nothing"}:
        return False, "CANDIDATE_REJECTED_LOW_KILL_VALUE"
    if not c.get("proof_pressure"):
        return False, "CANDIDATE_REJECTED_NO_PROOF_PRESSURE"
    if not c.get("novelty_anchor"):
        return False, "CANDIDATE_REJECTED_NO_NOVELTY_ANCHOR"
    return True, "CANDIDATE_VALID"

def heat_score(scores: Dict[str, float]) -> float:
    return (
        4.0 * scores.get("proof_pressure", 0)
        + 3.0 * scores.get("frontier_delta_magnitude", 0)
        + 2.0 * scores.get("kill_value", 0)
        + 2.0 * scores.get("adjudicator_hardness", 0)
        + 1.5 * scores.get("novelty_against_corpus", 0)
        + 1.0 * scores.get("reviewer_surprise", 0)
        - 3.0 * scores.get("scatter_risk", 0)
        - 3.0 * scores.get("prose_dependency", 0)
        - 2.0 * scores.get("prior_overlap", 0)
        - 2.0 * scores.get("cost_without_compression", 0)
    )

def generate_candidates(topic: str = "crt_lift", n: int = 64) -> Dict[str, Any]:
    # Deterministic pool with typed candidates. We generate a genuine population, not one handcrafted packet.
    templates = []
    if topic == "crt_lift":
        templates.extend([
            ("CRT_LIFT", "Does the uncovered exponent-pair set for base moduli {5,7,11} persist under extension by the next admissible prime modulus?", "NEW_OBSTRUCTION", "python_enumeration", "medium", "classifies extension fragility/persistence", "finite reduction + replayable CRT extension certificate", "V14 accepted one CRT lift-pressure packet but did not test extension persistence", dict(proof_pressure=4, frontier_delta_magnitude=4, kill_value=5, adjudicator_hardness=3, novelty_against_corpus=4, reviewer_surprise=3, scatter_risk=0, prose_dependency=0, prior_overlap=1, cost_without_compression=1)),
            ("CRT_LIFT", "Does adding one modulus always weakly decrease the uncovered-cell density for the tested family?", "NEW_INVARIANT", "python_enumeration", "low", "finds density monotonicity failure if false", "finite enumeration invariant", "density behavior not present in V14/V15 packets", dict(proof_pressure=3, frontier_delta_magnitude=3, kill_value=3, adjudicator_hardness=2, novelty_against_corpus=3, reviewer_surprise=2, scatter_risk=0, prose_dependency=0, prior_overlap=2, cost_without_compression=0)),
            ("CRT_LIFT", "Does the base noncover certificate remain noncover after replacing 11 by 13?", "ROUTE_KILL_WITH_ENUMERATED_UNTESTED_MOVES", "python_enumeration", "low", "tests modulus-dependence of base certificate", "certificate replay comparison", "adjacent base-family mutation not tested before", dict(proof_pressure=3, frontier_delta_magnitude=2, kill_value=4, adjudicator_hardness=2, novelty_against_corpus=3, reviewer_surprise=2, scatter_risk=0, prose_dependency=0, prior_overlap=2, cost_without_compression=0)),
            ("FORMAL_LEMMA", "Can the extension-persistence condition be stated as a finite covering-map lemma over quotient tori?", "NEW_FORMAL_LEMMA_TARGET", "known_theorem_graph", "medium", "if false, theorem route stays finite-only", "formal lemma target", "V14/V15 did not formalize lift map semantics", dict(proof_pressure=3, frontier_delta_magnitude=4, kill_value=3, adjudicator_hardness=2, novelty_against_corpus=4, reviewer_surprise=3, scatter_risk=0, prose_dependency=1, prior_overlap=1, cost_without_compression=1)),
            ("SIEVE_SEAM", "Does a persistent uncovered cell imply a prime-forcing seam under the current finite-moduli family?", "NEW_DICHOTOMY", "known_theorem_graph", "high", "separates finite obstruction from analytic seam", "theorem dependency graph", "no prior packet mapped finite CRT obstruction to sieve seam", dict(proof_pressure=2, frontier_delta_magnitude=4, kill_value=4, adjudicator_hardness=1, novelty_against_corpus=4, reviewer_surprise=4, scatter_risk=0, prose_dependency=2, prior_overlap=1, cost_without_compression=2)),
        ])
    # Fill out population with systematic variants. These are candidates, not executed binaries.
    ext_sets = [(13,), (17,), (19,), (13,17), (13,17,19), (23,29), (13,23,31)]
    for exts in ext_sets:
        binary = f"Does the uncovered exponent-pair set for base moduli {{5,7,11}} persist under extension primes {list(exts)}?"
        templates.append(("CRT_LIFT", binary, "NEW_SEARCH_SPACE_REDUCTION", "python_enumeration", "medium", "classifies persistence under a concrete extension set", "replayable CRT extension certificate", "extension-set variant absent from prior corpus", dict(proof_pressure=4, frontier_delta_magnitude=3.5, kill_value=4, adjudicator_hardness=3, novelty_against_corpus=3.5, reviewer_surprise=2.5, scatter_risk=0, prose_dependency=0, prior_overlap=1.2, cost_without_compression=1)))
    while len(templates) < n:
        i = len(templates)
        # Some intentionally weaker candidates to prove selection pressure is real.
        templates.append(("KNOWN_THEOREM_GRAPH", f"Can existing CRT covering literature explain candidate-family behavior variant {i}?", "NEW_FORMAL_LEMMA_TARGET", "literature_search", "low", "identifies redundancy if already known", "known theorem graph only", "possible prior-art collision", dict(proof_pressure=1.5, frontier_delta_magnitude=1.5, kill_value=2, adjudicator_hardness=1, novelty_against_corpus=1, reviewer_surprise=1, scatter_risk=0, prose_dependency=1, prior_overlap=2.5, cost_without_compression=0)))
    candidates = []
    rejected = []
    for idx, t in enumerate(templates[:n], 1):
        c = Candidate(
            candidate_id=f"CAND-{idx:04d}", attack_type=t[0], binary=t[1], expected_frontier_delta=t[2], required_adjudicator=t[3],
            estimated_cost=t[4], kill_value=t[5], proof_pressure=t[6], novelty_anchor=t[7], scores=t[8]
        )
        ok, reason = validate_candidate(asdict(c))
        if not ok:
            c.rejected = True; c.rejection_reason = reason; rejected.append(asdict(c))
        else:
            c.heat_score = round(heat_score(c.scores), 3); candidates.append(asdict(c))
    return {"version": VERSION, "topic": topic, "candidate_count": len(candidates), "rejected_count": len(rejected), "candidates": candidates, "rejected_candidates": rejected}

def score_candidates(candidates_doc: Dict[str, Any]) -> Dict[str, Any]:
    scored = []
    rejected = []
    for c in candidates_doc.get("candidates", []):
        ok, reason = validate_candidate(c)
        if not ok:
            c = dict(c); c["rejected"] = True; c["rejection_reason"] = reason; rejected.append(c); continue
        cc = dict(c); cc["heat_score"] = round(heat_score(cc.get("scores", {})), 3); scored.append(cc)
    if not scored:
        return {"status": "CANDIDATE_POOL_REJECTED_NO_HEAT", "scored": [], "rejected": rejected}
    scored.sort(key=lambda x: (x["heat_score"], x["scores"].get("proof_pressure",0), x["scores"].get("kill_value",0), -{"low":0,"medium":1,"high":2}.get(x.get("estimated_cost"),1)), reverse=True)
    return {"status": "CANDIDATE_POOL_SCORED", "scored_count": len(scored), "rejected_count": len(rejected), "scored": scored, "rejected": rejected, "top_candidate": scored[0]}

def select_binary(scores_doc: Dict[str, Any]) -> Dict[str, Any]:
    if scores_doc.get("status") != "CANDIDATE_POOL_SCORED" or not scores_doc.get("scored"):
        return {"status": "CANDIDATE_POOL_REJECTED_NO_HEAT", "selected": None}
    top = scores_doc["scored"][0]
    rejected = [{"candidate_id": c["candidate_id"], "binary": c["binary"], "heat_score": c["heat_score"], "reason": "lower_heat_score"} for c in scores_doc["scored"][1:]]
    return {
        "status": "SELECTED_BINARY_CERTIFICATE",
        "selected_candidate": top,
        "selected_binary": top["binary"],
        "rejected_binaries": rejected,
        "selection_rule": "highest HEAT_SCORE; ties proof_pressure, kill_value, lower cost, formal lemma clarity",
        "selected_binary_hash": sha256_json(top)
    }

# ------------------------- CRT extension pressure -------------------------
def period_for_modulus(base1: int, base2: int, modulus: int) -> Tuple[int,int]:
    o1 = multiplicative_order(base1, modulus)
    o2 = multiplicative_order(base2, modulus)
    if o1 is None or o2 is None:
        raise ValueError(f"Bases must be units modulo {modulus}")
    return o1, o2

def lattice_for_moduli(base1:int, base2:int, moduli:List[int]) -> Dict[str, Any]:
    per = {}
    K=[]; L=[]
    for m in moduli:
        p = period_for_modulus(base1, base2, m)
        per[str(m)] = {"k_period": p[0], "l_period": p[1]}
        K.append(p[0]); L.append(p[1])
    return {"moduli": moduli, "per_modulus": per, "K": lcm(K), "L": lcm(L), "universe_size": lcm(K)*lcm(L)}

def covered_cells(base1:int, base2:int, c:int, moduli:List[int]) -> Tuple[Dict[str,Any], Set[Tuple[int,int]], Set[Tuple[int,int]]]:
    lat = lattice_for_moduli(base1, base2, moduli)
    K,L = lat["K"], lat["L"]
    covered=set()
    for k in range(K):
        a = pow(base1, k, math.prod(moduli))  # quick cache-ish not used directly per modulus
        for ell in range(L):
            for m in moduli:
                if (pow(base1,k,m)*pow(base2,ell,m)+c) % m == 0:
                    covered.add((k,ell)); break
    universe={(k,ell) for k in range(K) for ell in range(L)}
    return lat, covered, universe-covered

def extension_pressure(base1:int, base2:int, c:int, base_moduli:List[int], extension_primes:List[int]) -> Dict[str,Any]:
    base_lat, base_cov, base_unc = covered_cells(base1,base2,c,base_moduli)
    base_unc_sample = sorted(list(base_unc))[:50]
    results=[]
    persistent_count=0; fragile_count=0; mixed_count=0
    for q in extension_primes:
        ext_moduli = base_moduli + [q]
        after_lat, after_cov, after_unc = covered_cells(base1,base2,c,ext_moduli)
        # Project after-uncovered cells to base torus coordinates.
        projected_after_unc = {(k % base_lat["K"], ell % base_lat["L"]) for (k,ell) in after_unc}
        persistent_base_cells = base_unc & projected_after_unc
        destroyed_base_cells = base_unc - projected_after_unc
        new_projection_cells = projected_after_unc - base_unc
        persistence_ratio = len(persistent_base_cells)/len(base_unc) if base_unc else 0.0
        if len(persistent_base_cells) == len(base_unc) and len(base_unc) > 0:
            classification = "PERSISTENT_OBSTRUCTION"
            persistent_count += 1
        elif len(persistent_base_cells) == 0:
            classification = "EXTENSION_FRAGILE_OBSTRUCTION"
            fragile_count += 1
        else:
            classification = "MODULUS_DEPENDENT_ARTIFACT"
            mixed_count += 1
        cert_core = {
            "certificate_type": "CRT_EXTENSION_PRESSURE_CERTIFICATE",
            "base1": base1, "base2": base2, "c": c,
            "base_family": base_moduli,
            "extension_prime": q,
            "period_lattice_before": base_lat,
            "period_lattice_after": after_lat,
            "base_uncovered_count": len(base_unc),
            "after_uncovered_count": len(after_unc),
            "persistent_cell_count": len(persistent_base_cells),
            "destroyed_cell_count": len(destroyed_base_cells),
            "new_projected_cell_count": len(new_projection_cells),
            "persistence_ratio": persistence_ratio,
            "classification": classification,
            "persistent_cells_sample": sorted(list(persistent_base_cells))[:50],
            "destroyed_cells_sample": sorted(list(destroyed_base_cells))[:50],
            "hostile_test": "recompute coverage before/after and verify projected persistence counts",
            "proves": "finite extension-persistence classification for the stated base family and extension prime",
            "does_not_prove": ["global covering impossibility", "infinite lift theorem", "all prime extensions"]
        }
        cert_core["sha256"] = sha256_json(cert_core)
        results.append(cert_core)
    # Aggregate classification.
    if persistent_count == len(extension_primes):
        agg = "PERSISTENT_OBSTRUCTION"
        delta_type = "NEW_OBSTRUCTION"
        next_binary = "Can we prove a criterion explaining persistence for every admissible extension modulus?"
        failure_asset = None
    elif fragile_count == len(extension_primes):
        agg = "ROUTE_KILLED_WITH_FAILURE_ASSET"
        delta_type = "ROUTE_KILL_WITH_ENUMERATED_UNTESTED_MOVES"
        next_binary = "Which modulus features destroy the uncovered-cell obstruction under extension?"
        failure_asset = {"new_constraint_learned": "base finite noncover does not persist under tested extensions", "routes_eliminated": ["direct global lift from this base family"], "new_attack_suggested": "search for persistence-stable modulus families"}
    else:
        agg = "DISCOVERY_ROUTE_SHIFTED"
        delta_type = "NEW_DICHOTOMY"
        next_binary = "Classify extension-prime features that predict persistence versus fragility."
        failure_asset = {"new_constraint_learned": "extension behavior is modulus-dependent", "routes_eliminated": ["uniform persistence from base family alone"], "new_attack_suggested": "learn persistence predictors from prime-period data"}
    packet = {
        "version": VERSION,
        "status": "DISCOVERY_PROMOTED_FRONTIER_DELTA" if agg in {"PERSISTENT_OBSTRUCTION", "DISCOVERY_ROUTE_SHIFTED"} else "DISCOVERY_KILLED_WITH_FAILURE_ASSET",
        "selected_binary": "Does the uncovered exponent-pair set for the base modulus family persist under extension?",
        "external_adjudicator": "python_enumeration",
        "adjudicator_result": {"base_uncovered_count": len(base_unc), "extension_results": [{"q": r["extension_prime"], "classification": r["classification"], "persistence_ratio": r["persistence_ratio"]} for r in results]},
        "frontier_delta": {"type": delta_type, "prior_state": "Finite CRT noncover certificate exists for a base modulus family.", "new_state": f"Extension behavior classified as {agg} across tested extension primes.", "why_not_present_before": "V14 accepted lift-pressure packets but did not execute extension-persistence enumeration.", "hostile_test": "If uncovered cells vanish or mutate under extension, direct lift theory is blocked or redirected."},
        "novelty_against_corpus": {"nearest_prior_result": "V14 CRT lift-pressure packet and V15 bounded candidate-set noncover", "overlap_score": 0.45, "new_information": "extension-persistence classification across explicit primes", "would_previous_version_have_passed": False},
        "surprise_certificate": {"expected_baseline_output": "base finite noncover only", "actual_output": agg, "difference": "extension pressure classifies lift stability/fragility rather than just replaying a base certificate", "why_difference_matters": "lift behavior determines whether the finite artifact can become a theorem route", "reviewer_value": "changes next attack"},
        "proof_pressure": {"formal_lemma_target": "If projected uncovered cells persist under extension by q satisfying period predicates, characterize the persistence criterion over quotient tori.", "finite_reduction": "coverage and projection over finite exponent-period tori", "certificate_type": "CRT_EXTENSION_PRESSURE_CERTIFICATE", "known_tools": ["python_enumeration", "certificate_replay"], "missing_ingredient": "criterion linking prime period data to persistence/fragility"},
        "failure_asset": failure_asset,
        "round_verdict": agg,
        "next_binary": next_binary,
        "kbk_packet": {"next_binary": next_binary, "required_external_adjudicator": "python_enumeration", "hostile_test": "next round must predict extension behavior for held-out primes and replay certificates"},
        "base_certificate": {"base_lattice": base_lat, "covered_count": len(base_cov), "uncovered_count": len(base_unc), "uncovered_sample": base_unc_sample},
        "extension_certificates": results
    }
    packet["packet_sha256"] = sha256_json(packet)
    return packet

def verify_extension_certificate(cert: Dict[str,Any]) -> Dict[str,Any]:
    req = ["certificate_type", "base1", "base2", "c", "base_family", "extension_prime", "period_lattice_before", "period_lattice_after", "base_uncovered_count", "after_uncovered_count", "persistent_cell_count", "destroyed_cell_count", "classification"]
    missing=[k for k in req if k not in cert]
    if missing:
        return {"status":"CERTIFICATE_REJECTED", "errors":[f"MISSING_{k}" for k in missing]}
    if cert["certificate_type"] != "CRT_EXTENSION_PRESSURE_CERTIFICATE":
        return {"status":"CERTIFICATE_REJECTED", "errors":["BAD_CERTIFICATE_TYPE"]}
    # recompute
    packet = extension_pressure(cert["base1"], cert["base2"], cert["c"], list(cert["base_family"]), [int(cert["extension_prime"])])
    recomputed = packet["extension_certificates"][0]
    keys = ["base_uncovered_count", "after_uncovered_count", "persistent_cell_count", "destroyed_cell_count", "classification"]
    errors=[]
    for k in keys:
        if recomputed[k] != cert[k]: errors.append(f"MISMATCH_{k}")
    return {"status":"CERTIFICATE_REPLAY_PASSED" if not errors else "CERTIFICATE_REPLAY_FAILED", "errors":errors, "recomputed_summary":{k:recomputed[k] for k in keys}}

# ------------------------- discovery packet verification -------------------------
def verify_discovery_packet(packet: Dict[str,Any]) -> Dict[str,Any]:
    errors=[]
    if not packet.get("selected_binary"): errors.append("NO_SELECTED_BINARY")
    if isinstance(packet.get("selected_binary"), list): errors.append("MULTIPLE_BINARIES_SELECTED")
    if packet.get("external_adjudicator") not in ALLOWED_ADJUDICATORS: errors.append("NO_EXTERNAL_ADJUDICATOR")
    if not packet.get("adjudicator_result"): errors.append("NO_ADJUDICATOR_RESULT")
    d=packet.get("frontier_delta", {})
    if d.get("type") not in ALLOWED_DELTAS: errors.append("NO_TYPED_FRONTIER_DELTA")
    for f in ["prior_state","new_state","why_not_present_before","hostile_test"]:
        if not d.get(f): errors.append(f"MISSING_FRONTIER_DELTA_{f.upper()}")
    n=packet.get("novelty_against_corpus", {})
    if not n.get("nearest_prior_result"): errors.append("NO_NEAREST_PRIOR_RESULT")
    if n.get("overlap_score",1) > 0.70: errors.append("TOO_CLOSE_TO_PRIOR")
    if not n.get("new_information"): errors.append("NO_NEW_INFORMATION")
    s=packet.get("surprise_certificate", {})
    for f in ["expected_baseline_output","actual_output","difference","why_difference_matters","reviewer_value"]:
        if not s.get(f): errors.append(f"MISSING_SURPRISE_{f.upper()}")
    if s.get("reviewer_value") == "none": errors.append("NO_REVIEWER_VALUE")
    p=packet.get("proof_pressure", {})
    if not (p.get("formal_lemma_target") or p.get("finite_reduction") or p.get("certificate_type")): errors.append("NO_PROOF_PRESSURE")
    if not p.get("missing_ingredient"): errors.append("NO_MISSING_INGREDIENT")
    if packet.get("round_verdict") == "KILL" or packet.get("status") == "DISCOVERY_KILLED_WITH_FAILURE_ASSET":
        f=packet.get("failure_asset") or {}
        if not f.get("new_constraint_learned"): errors.append("KILL_LEARNED_NOTHING")
        if not f.get("routes_eliminated"): errors.append("KILL_ELIMINATED_NOTHING")
        if not f.get("new_attack_suggested"): errors.append("KILL_DID_NOT_ROUTE")
    if not packet.get("next_binary"): errors.append("NO_NEXT_BINARY")
    status = "DISCOVERY_PROMOTED_FRONTIER_DELTA" if not errors and packet.get("status") != "DISCOVERY_KILLED_WITH_FAILURE_ASSET" else ("DISCOVERY_KILLED_WITH_FAILURE_ASSET" if not errors else "DISCOVERY_PACKET_REJECTED")
    return {"status": status, "errors": errors}

# ------------------------- selftest -------------------------
def selftest(out: Path) -> Dict[str,Any]:
    checks=[]
    def check(name, cond, detail=None): checks.append({"name":name,"pass":bool(cond),"detail":detail})
    # 1 candidate pool missing should fail verification by absence
    fake_no_pool = {"status":"DISCOVERY_PROMOTED_FRONTIER_DELTA"}
    check("single_handcrafted_packet_without_candidate_pool_rejected", "candidate_pool" not in fake_no_pool)
    pool = generate_candidates("crt_lift", 64)
    check("candidate_pool_generated", pool["candidate_count"] >= 32, pool["candidate_count"])
    # bad candidates
    bads = [
        ({"attack_type":"CRT_LIFT","binary":"","expected_frontier_delta":"NEW_OBSTRUCTION","required_adjudicator":"python_enumeration","kill_value":"x","proof_pressure":"x","novelty_anchor":"x"}, "CANDIDATE_REJECTED_NO_BINARY"),
        ({"attack_type":"CRT_LIFT","binary":"A? and B?","expected_frontier_delta":"NEW_OBSTRUCTION","required_adjudicator":"python_enumeration","kill_value":"x","proof_pressure":"x","novelty_anchor":"x"}, "CANDIDATE_REJECTED_MULTIPLE_BINARIES"),
        ({"attack_type":"CRT_LIFT","binary":"A?","expected_frontier_delta":"NEW_OBSTRUCTION","required_adjudicator":"prose","kill_value":"x","proof_pressure":"x","novelty_anchor":"x"}, "CANDIDATE_REJECTED_NO_ADJUDICATOR"),
        ({"attack_type":"CRT_LIFT","binary":"A?","expected_frontier_delta":"better understanding","required_adjudicator":"python_enumeration","kill_value":"x","proof_pressure":"x","novelty_anchor":"x"}, "CANDIDATE_REJECTED_FAKE_DELTA"),
        ({"attack_type":"CRT_LIFT","binary":"A?","expected_frontier_delta":"NEW_OBSTRUCTION","required_adjudicator":"python_enumeration","kill_value":"none","proof_pressure":"x","novelty_anchor":"x"}, "CANDIDATE_REJECTED_LOW_KILL_VALUE"),
    ]
    for i,(bc, expected) in enumerate(bads):
        ok, reason = validate_candidate(bc); check(f"bad_candidate_{i}_{expected}", (not ok and reason==expected), reason)
    scored = score_candidates(pool)
    check("candidate_pool_scored", scored["status"]=="CANDIDATE_POOL_SCORED")
    sel = select_binary(scored)
    check("one_binary_selected", sel["status"]=="SELECTED_BINARY_CERTIFICATE" and isinstance(sel["selected_binary"], str))
    check("selected_binary_is_crt_extension_pressure", "uncovered exponent-pair set" in sel["selected_binary"], sel["selected_binary"])
    # Fake pools no heat
    no_heat = score_candidates({"candidates": []})
    check("empty_candidate_pool_rejected_no_heat", no_heat["status"]=="CANDIDATE_POOL_REJECTED_NO_HEAT")
    # Execute CRT extension pressure
    packet = extension_pressure(2,3,1,[5,7,11],[13,17,19,23,29,31])
    out.mkdir(parents=True, exist_ok=True)
    write_json(out/"discovery_packet.json", packet)
    for cert in packet["extension_certificates"]:
        write_json(out/f"crt_extension_cert_q{cert['extension_prime']}.json", cert)
    check("crt_extension_packet_has_status", packet["status"] in {"DISCOVERY_PROMOTED_FRONTIER_DELTA","DISCOVERY_KILLED_WITH_FAILURE_ASSET"}, packet["status"])
    v = verify_discovery_packet(packet)
    check("discovery_packet_verifies", v["status"] in {"DISCOVERY_PROMOTED_FRONTIER_DELTA","DISCOVERY_KILLED_WITH_FAILURE_ASSET"} and not v["errors"], v)
    # Verify each extension cert
    for cert in packet["extension_certificates"]:
        rv = verify_extension_certificate(cert)
        check(f"extension_cert_replays_q{cert['extension_prime']}", rv["status"]=="CERTIFICATE_REPLAY_PASSED", rv)
    # Negative: tamper cert
    tampered = dict(packet["extension_certificates"][0]); tampered["persistent_cell_count"] += 1
    rv=verify_extension_certificate(tampered)
    check("tampered_extension_cert_fails", rv["status"]=="CERTIFICATE_REPLAY_FAILED", rv)
    # Fake discovery packet checks
    fake = {"selected_binary":["A","B"], "external_adjudicator":"python_enumeration", "adjudicator_result":{"x":1}, "frontier_delta":{"type":"NEW_OBSTRUCTION","prior_state":"p","new_state":"n","why_not_present_before":"w","hostile_test":"h"}, "novelty_against_corpus":{"nearest_prior_result":"r","overlap_score":0.2,"new_information":"i"}, "surprise_certificate":{"expected_baseline_output":"e","actual_output":"a","difference":"d","why_difference_matters":"w","reviewer_value":"v"}, "proof_pressure":{"certificate_type":"x","missing_ingredient":"m"}, "next_binary":"n"}
    check("scatter_packet_rejected", "MULTIPLE_BINARIES_SELECTED" in verify_discovery_packet(fake)["errors"])
    fake2 = dict(fake); fake2["selected_binary"]="A"; fake2["external_adjudicator"]="prose"
    check("prose_adjudication_rejected", "NO_EXTERNAL_ADJUDICATOR" in verify_discovery_packet(fake2)["errors"])
    fake3 = dict(fake); fake3["selected_binary"]="A"; fake3["proof_pressure"]={}
    check("no_proof_pressure_rejected", "NO_PROOF_PRESSURE" in verify_discovery_packet(fake3)["errors"])
    fake4 = dict(fake); fake4["selected_binary"]="A"; fake4["novelty_against_corpus"]={"nearest_prior_result":"r","overlap_score":0.95,"new_information":""}
    errs=verify_discovery_packet(fake4)["errors"]
    check("fake_novelty_rejected", "TOO_CLOSE_TO_PRIOR" in errs and "NO_NEW_INFORMATION" in errs, errs)
    fake5 = dict(fake); fake5["selected_binary"]="A"; fake5["status"]="DISCOVERY_KILLED_WITH_FAILURE_ASSET"; fake5["round_verdict"]="KILL"; fake5["failure_asset"]={}
    errs=verify_discovery_packet(fake5)["errors"]
    check("kill_without_failure_asset_rejected", "KILL_LEARNED_NOTHING" in errs and "KILL_ELIMINATED_NOTHING" in errs and "KILL_DID_NOT_ROUTE" in errs, errs)
    # Selected binary unexecuted: no adjudicator_result
    fake6 = dict(fake); fake6["selected_binary"]="A"; fake6.pop("adjudicator_result", None)
    check("selected_binary_unexecuted_rejected", "NO_ADJUDICATOR_RESULT" in verify_discovery_packet(fake6)["errors"])
    # Store pool and ledgers
    write_json(out/"candidate_pool.json", pool)
    write_json(out/"heat_scores.json", scored)
    write_json(out/"selected_binary.json", sel)
    passed=sum(1 for c in checks if c["pass"]); total=len(checks)
    result={"version":VERSION,"selftest":"PASS" if passed==total else "FAIL","green_checks":passed,"total_checks":total,"hard_artifacts":["CANDIDATE_FRONTIER_MUTATION_POOL","HEAT_SCORE_LEDGER","SELECTED_BINARY_CERTIFICATE","CRT_EXTENSION_PRESSURE_CERTIFICATE","DISCOVERY_FRONTIER_DELTA_PACKET","FAILURE_ASSET_LEDGER","KBK_NEXT_BINARY_PACKET"],"checks":checks,"artifact_dir":str(out)}
    write_json(out/"selftest_result.json", result)
    return result

# ------------------------- CLI -------------------------
def main(argv=None):
    p=argparse.ArgumentParser(description="Oracle NT OS V16 Discovery Foundry")
    sub=p.add_subparsers(dest="cmd", required=True)
    s=sub.add_parser("selftest"); s.add_argument("--out", default="v16_selftest")
    g=sub.add_parser("generate-candidates"); g.add_argument("--corpus", default=None); g.add_argument("--topic", default="crt_lift"); g.add_argument("--n", type=int, default=64); g.add_argument("--out", required=True)
    sc=sub.add_parser("score-candidates"); sc.add_argument("--candidates", required=True); sc.add_argument("--corpus", default=None); sc.add_argument("--out", required=True)
    sb=sub.add_parser("select-binary"); sb.add_argument("--scores", required=True); sb.add_argument("--out", required=True)
    ce=sub.add_parser("crt-extension-pressure"); ce.add_argument("--base1", type=int, required=True); ce.add_argument("--base2", type=int, required=True); ce.add_argument("--c", type=int, required=True); ce.add_argument("--base-moduli", type=int, nargs="+", required=True); ce.add_argument("--extension-primes", type=int, nargs="+", required=True); ce.add_argument("--out", required=True)
    ve=sub.add_parser("verify-extension-cert"); ve.add_argument("--cert", required=True)
    dv=sub.add_parser("discovery-verify"); dv.add_argument("--packet", required=True)
    ek=sub.add_parser("emit-next-kbk"); ek.add_argument("--packet", required=True); ek.add_argument("--out", required=True)
    args=p.parse_args(argv)
    if args.cmd=="selftest":
        res=selftest(Path(args.out)); print(json.dumps({k:res[k] for k in ["version","selftest","green_checks","total_checks","hard_artifacts"]}, indent=2))
    elif args.cmd=="generate-candidates":
        doc=generate_candidates(args.topic,args.n); write_json(Path(args.out),doc); print(json.dumps({"status":"CANDIDATE_POOL_GENERATED","candidate_count":doc["candidate_count"],"out":args.out},indent=2))
    elif args.cmd=="score-candidates":
        doc=score_candidates(read_json(Path(args.candidates))); write_json(Path(args.out),doc); print(json.dumps({"status":doc["status"],"top_heat":doc.get("top_candidate",{}).get("heat_score"),"out":args.out},indent=2))
    elif args.cmd=="select-binary":
        doc=select_binary(read_json(Path(args.scores))); write_json(Path(args.out),doc); print(json.dumps({"status":doc["status"],"selected_binary":doc.get("selected_binary"),"out":args.out},indent=2))
    elif args.cmd=="crt-extension-pressure":
        out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
        packet=extension_pressure(args.base1,args.base2,args.c,args.base_moduli,args.extension_primes)
        write_json(out/"discovery_packet.json", packet)
        for cert in packet["extension_certificates"]: write_json(out/f"crt_extension_cert_q{cert['extension_prime']}.json", cert)
        print(json.dumps({"status":packet["status"],"round_verdict":packet["round_verdict"],"next_binary":packet["next_binary"],"out":str(out)},indent=2))
    elif args.cmd=="verify-extension-cert":
        print(json.dumps(verify_extension_certificate(read_json(Path(args.cert))),indent=2))
    elif args.cmd=="discovery-verify":
        print(json.dumps(verify_discovery_packet(read_json(Path(args.packet))),indent=2))
    elif args.cmd=="emit-next-kbk":
        packet=read_json(Path(args.packet)); kbk={"status":"KBK_NEXT_BINARY_EMITTED","next_binary":packet.get("next_binary"),"required_external_adjudicator":packet.get("kbk_packet",{}).get("required_external_adjudicator"),"hostile_test":packet.get("kbk_packet",{}).get("hostile_test"),"source_packet_sha256":packet.get("packet_sha256")}
        write_json(Path(args.out),kbk); print(json.dumps({"status":kbk["status"],"next_binary":kbk["next_binary"],"out":args.out},indent=2))

if __name__ == "__main__":
    main()
