# V16 Discovery Foundry Report

## Contract

The Heat Packet says V15 must stop being a bouncer and become a foundry: candidate pressure, selection pressure, tool execution, frontier delta/failure asset, and next KBK.

## Build

V16 implements that foundry loop.

Selftest result:

```json
{
  "version": "16.0.0-oracle-discovery-foundry",
  "selftest": "PASS",
  "green_checks": 26,
  "total_checks": 26,
  "hard_artifacts": [
    "CANDIDATE_FRONTIER_MUTATION_POOL",
    "HEAT_SCORE_LEDGER",
    "SELECTED_BINARY_CERTIFICATE",
    "CRT_EXTENSION_PRESSURE_CERTIFICATE",
    "DISCOVERY_FRONTIER_DELTA_PACKET",
    "FAILURE_ASSET_LEDGER",
    "KBK_NEXT_BINARY_PACKET"
  ]
}
```

## Proof Run

Command:

```bash
python oracle_nt_os_v16.py crt-extension-pressure \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --base-moduli 5 7 11 \
  --extension-primes 13 17 19 23 29 31 \
  --out /mnt/data/v16_crt_extension_pressure
```

Discovery packet verification:

```json
{
  "status": "DISCOVERY_PROMOTED_FRONTIER_DELTA",
  "errors": []
}
```

## Mathematical Result

Base uncovered count for `{5,7,11}`:

```text
2010
```

Extension classifications:

| q | classification | persistence ratio |
|---|---:|---:|
| 13 | MODULUS_DEPENDENT_ARTIFACT | 0.9129353233830846 |
| 17 | PERSISTENT_OBSTRUCTION | 1.0 |
| 19 | PERSISTENT_OBSTRUCTION | 1.0 |
| 23 | PERSISTENT_OBSTRUCTION | 1.0 |
| 29 | PERSISTENT_OBSTRUCTION | 1.0 |
| 31 | MODULUS_DEPENDENT_ARTIFACT | 0.972139303482587 |

## Frontier Delta

The result is mixed: some prime extensions preserve all projected uncovered cells, while others destroy part of the uncovered set. This is not a global theorem, but it is a real discovery-pressure output because it creates a new classifier target:

```text
Classify extension-prime features that predict persistence versus fragility.
```

## Why this is not V14/V15 old behavior

Old behavior: replay or reject a single packet.

V16 behavior: generate candidates, score candidates, select one binary, run finite enumeration, classify extension behavior, emit replay certificates, and produce the next KBK binary.
