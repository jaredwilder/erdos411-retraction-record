# V18 Ferrari Race 8: Mod-20 Diagonal Symmetry vs Adversarial q3 Destruction

## Verdict

```text
PROMOTE_MOD20_DIAGONAL_SYMMETRY
```

## Active Binary

```text
Can diagonal nonunit tight cells (20,20) and (40,40) be explained by a mod-20/order-lattice symmetry, or can an adversarial q3 branch outside current bounds destroy them?
```

## What Was Tested

- Target cells: `(20,20)` and `(40,40)` modulo the base `60×60` lattice.
- Parent family: `[5, 7, 11, 13, 17, 31, 41, 61, 241]`.
- Adversarial q3 primes outside previous q3 bound: primes in `301..997`.
- For each replayed q3 branch: add q3, compute danger closure, enumerate surviving lifts for both target cells, and check destruction.

## Summary

```json
{
  "q3_range": [
    301,
    997
  ],
  "candidate_q3_count": 106,
  "replayed_q3_count": 52,
  "skipped_q3_count": 54,
  "destroying_branches": 0,
  "min_surviving_lift_count_over_replayed": 6,
  "max_surviving_lift_count_over_replayed": 3721,
  "target_cells": [
    [
      20,
      20
    ],
    [
      40,
      40
    ]
  ],
  "mod20_diagonal_pattern": true,
  "elapsed_seconds": 0.928
}
```

## Earned Statement

For every replayed adversarial q3 branch outside the previous q3 bound, the nonunit diagonal target cells (20,20) and (40,40) retained surviving uncovered lifts. The target cells are exactly the nonzero diagonal multiples of 20 modulo 60, promoting mod-20 diagonal symmetry as the live theorem target.

## What Was Not Tested

- q3 primes above 997
- branches exceeding configured fiber/modtest limits
- unbounded recursive depth
- all non-tight residual cells
- formal proof of mod-20 symmetry

## Exact Next Binary

```text
Can the mod-20 diagonal symmetry be proven from the order structure of 6^20 modulo all danger-closure moduli, rather than by branch enumeration?
```

## Artifacts

- `race8_mod20_adversarial_certificate.json`
- `race8_referee_forge_packet.json`
- `race8_adversarial_q3_rows.csv`
- `race8_skipped_q3_rows.csv`
