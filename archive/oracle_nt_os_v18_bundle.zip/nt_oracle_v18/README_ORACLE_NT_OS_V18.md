# Oracle NT OS V18 — Referee Forge

V18 implements the Referee Forge layer: an output is not science unless it creates referee-coercive value.

## Core command

```bash
python oracle_nt_os_v18.py referee-forge-crt \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --base-moduli 5 7 11 \
  --prime-max 997 \
  --out v18_referee_forge_q997
```

## Selftest

```bash
python oracle_nt_os_v18.py selftest --out v18_selftest_out
```

## Verifier gates

- one binary
- external adjudicator
- frontier delta
- referee value
- field collision
- formalization tax
- family transfer
- proof-failure ledger when needed
- minimum publishable unit
- representation mutation
- conjecture compiler
- positive Referee Forge score

## Live V18 target

Selected binary:

> Does extension-lattice enlargement give a referee-grade, field-novel, formalizable stability principle for finite CRT noncover obstructions, or is the q<=997 law only a one-family computational artifact?

The generated packet is `referee_forge_packet.v18.json`.
