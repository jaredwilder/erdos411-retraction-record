# Subfiber Hitting-Set Certificate

## Verdict

`PROMOTE_SUBFIBER_COVERAGE_OBSTRUCTION`

## Active binary

Can actual danger moduli cover every lift in the target subfiber for `(20,20)` or `(40,40)`?

## Scope

Race8 replayed actual q3 danger-closure branches for q3 in `[301,997]`.

## Target subfibers

- `(20,20)` target subfiber seed: `k ≡ 80 mod 120`, `l ≡ 80 mod 240`
- `(40,40)` target subfiber seed: `k ≡ 40 mod 120`, `l ≡ 160 mod 240`

## Result

- Replayed branches: `52`
- Branches destroying either target subfiber: `0`
- Minimum surviving lifts for `(20,20)`: `6`
- Minimum surviving lifts for `(40,40)`: `6`

Because the union of all actual danger moduli in each replayed branch leaves at least one surviving lift in each target subfiber, no subset of those same branch moduli can cover the subfiber.

## What was not tested

- q3 branches that were skipped in Race8 for fiber/area limits
- q3 primes outside [301,997] in this exact hitting-set replay
- unbounded recursive depth
- arbitrary combinations of moduli not arising as an actual replayed danger-closure branch

## Certificate

`subfiber_hitting_set_certificate.json`

SHA-256: `080a5970a54f8ddfbfa97bcc5fdabf1f8a362448071c2705201a7713febb71df`
