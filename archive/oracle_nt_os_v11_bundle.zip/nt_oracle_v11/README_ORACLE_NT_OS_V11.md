# Oracle Number Theory OS V11

**Version:** `11.0.0-oracle-nt-os-certificate-factory`

V11 is the certificate-factory build. It stops treating local receipts, local schemas, and user-provided source labels as theorem-grade verification. The tool now separates local analysis from external verification and ships replayable certificate generators/verifiers for narrow claims.

## What V11 is for

V11 is not a theorem prover and does not claim to solve number theory by itself. It is a disciplined research workbench that forces every serious claim into one of these states:

1. finite-prefix classification,
2. local-only schema/certificate,
3. replayable narrow certificate,
4. external/literature/OEIS/formal verification required,
5. blocked.

## Contract fixes implemented

- User JSON cannot self-assign verified source status.
- Local sealing does not unlock theorem-grade claims.
- Analyzer-issued trust is separated from user-claimed source metadata.
- Formal recurrence and polynomial objects emit replayable certificates.
- Polynomial verification respects `index_start`.
- Canonical Fibonacci `0,1,1,2,...` is known-family classification, not interpolation risk.
- Short junk sequences are blocked as interpolation risk.
- OEIS/literature collision requires exact returned term matching for online results.
- KBK continuation requires a real artifact, not only a matching action string.
- CRT emits a replayable finite-torus uncovered-pair certificate.
- Diophantine local emits a replayable modular obstruction certificate.
- Strong-divisibility and primitive-divisor routes for Fibonacci/Lucas now produce canonical proof-plan/convention state instead of pretending proof closure.
- Selftest includes source-trust fuzzing and interpolation fuzzing.

## Run selftest

```bash
python oracle_nt_os_v11.py selftest --out v11_selftest_out
```

Expected:

```json
{
  "version": "11.0.0-oracle-nt-os-certificate-factory",
  "selftest": "PASS",
  "green_checks": 20,
  "total_checks": 20
}
```

## Analyze a sequence

```bash
python oracle_nt_os_v11.py analyze-seq \
  --seq "0,1,1,2,3,5,8,13,21,34" \
  --label fib0 \
  --out out_v11
```

## Fake source hostile test

This will **not** unlock theorem-grade claims:

```bash
python oracle_nt_os_v11.py analyze-seq \
  --seq "1,1,2,3,5,8,13" \
  --label fake_source_cli \
  --formal-recurrence "1,1" \
  --definition-source "lol trust me bro" \
  --out out_v11
```

The CLI recurrence flag creates `GENERATED_EXTENSION`, not `FORMAL_DEFINITION`.

## Seal object locally

```bash
python oracle_nt_os_v11.py seal-object --object-json object.json
```

Local seal result: `LOCAL_RECEIPT_SEALED`.

That is **not external verification** and cannot unlock theorem-grade claims.

## CRT certificate

```bash
python oracle_nt_os_v11.py crt-war \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --max-modulus 120 \
  --out crt_out_v11
```

Then replay:

```bash
python oracle_nt_os_v11.py verify-cert --certificate crt_out_v11/crt_certificate.v11.json
```

## Diophantine local obstruction certificate

```bash
python oracle_nt_os_v11.py diophantine-local \
  --A 1 \
  --B 1 \
  --C 3 \
  --bound 97 \
  --out dio_out_v11
```

Then replay:

```bash
python oracle_nt_os_v11.py verify-cert --certificate dio_out_v11/diophantine_certificate.v11.json
```

## KBK continuation

V11 creates KBK packets that require an artifact. The `continue` command refuses missing artifacts:

```bash
python oracle_nt_os_v11.py continue \
  --run-id <RUN_ID> \
  --action <REQUIRED_ACTION> \
  --artifact certificate.json
```

A matching action string alone is not enough.

## Hard limitation

V11 still does not represent a public mathematical breakthrough by itself. The point of this build is that it now produces and verifies narrow hard artifacts instead of hiding behind polished reports.
