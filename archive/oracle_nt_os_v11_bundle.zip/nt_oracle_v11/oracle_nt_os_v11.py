#!/usr/bin/env python3
"""
Oracle Number Theory OS V11 - Certificate Factory / Trust Boundary

V11 is deliberately stricter than earlier versions. It does not treat local
receipts, local schema validation, or user-provided source labels as external
verification. It ships replayable certificate generators/verifiers for narrow
claims and an adversarial selftest that attacks the exact prior trust leaks.
"""
from __future__ import annotations

import argparse, json, hashlib, os, sqlite3, time, math, random, shutil, subprocess, urllib.request, urllib.parse, re, zipfile
from pathlib import Path
from dataclasses import dataclass, asdict, field
from fractions import Fraction
from typing import Any, Dict, List, Optional, Tuple

VERSION = "11.0.0-oracle-nt-os-certificate-factory"
SCOPE_PREFIX = "FINITE_PREFIX"
SCOPE_GENERATED = "GENERATED_EXTENSION"
SCOPE_FORMAL = "FORMAL_DEFINITION"
SCOPE_LITERATURE = "LITERATURE_VERIFIED"

LOCAL_ONLY_TRUST = {"LOCAL_SCHEMA_VALID", "LOCAL_RECEIPT_SEALED", "UNTRUSTED_LOCAL", "PROJECT_LOCAL"}
EXTERNAL_TRUST = {"OEIS_EXACT_VERIFIED", "LITERATURE_EXACT_VERIFIED", "SIGNED_PROJECT_VERIFIED", "LEAN_FORMALLY_VERIFIED", "REMOTE_REPRODUCIBLE_VERIFIED"}
TRUST_SALT = "oracle_nt_v11_receipt_v1"

# ----------------------------- utilities ---------------------------------

def now() -> str: return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
def ensure(p: Path): p.mkdir(parents=True, exist_ok=True)
def sha256(s: str) -> str: return hashlib.sha256(s.encode()).hexdigest()
def sha12(s: str) -> str: return sha256(s)[:12]
def canon_json(x: Any) -> str: return json.dumps(x, sort_keys=True, separators=(",",":"))
def parse_ints(s: str) -> List[int]:
    if not s: return []
    return [int(t.strip()) for t in re.split(r"[,\s]+", s.strip()) if t.strip()]

def primes_upto(n:int)->List[int]:
    if n<2: return []
    sieve=[True]*(n+1); sieve[0]=sieve[1]=False
    for p in range(2,int(n**0.5)+1):
        if sieve[p]:
            for q in range(p*p,n+1,p): sieve[q]=False
    return [i for i,v in enumerate(sieve) if v]

# ----------------------------- formal objects -----------------------------

@dataclass
class FormalObject:
    object_type: str
    label: str
    scope: str = SCOPE_PREFIX
    terms: List[int] = field(default_factory=list)
    index_start: int = 0
    definition: Dict[str,Any] = field(default_factory=dict)
    source: Dict[str,Any] = field(default_factory=dict)

    @staticmethod
    def observed(label: str, terms: List[int]) -> "FormalObject":
        return FormalObject("observed_sequence", label, SCOPE_PREFIX, terms)

    @staticmethod
    def from_json(path: Path) -> "FormalObject":
        d=json.loads(path.read_text())
        return FormalObject(**d)

    def payload_for_receipt(self) -> str:
        d=asdict(self); d["source"]={}
        return canon_json(d)

    def validate_schema(self) -> Tuple[bool,List[str]]:
        e=[]
        if self.scope not in {SCOPE_PREFIX,SCOPE_GENERATED,SCOPE_FORMAL,SCOPE_LITERATURE}: e.append("invalid scope")
        if self.object_type=="observed_sequence" and self.scope!=SCOPE_PREFIX: e.append("observed_sequence must be FINITE_PREFIX")
        if self.scope in {SCOPE_FORMAL,SCOPE_LITERATURE} and not self.definition: e.append("formal/literature scope requires definition")
        if self.object_type=="recurrence_sequence":
            rec=self.definition.get("recurrence",{}); init=self.definition.get("initial_terms",[])
            if self.scope in {SCOPE_FORMAL,SCOPE_LITERATURE}:
                if not isinstance(init,list) or not init: e.append("recurrence requires initial_terms")
                if not isinstance(rec.get("coefficients"),list) or not rec.get("coefficients"): e.append("recurrence requires coefficients")
                if rec.get("valid_for") is None: e.append("recurrence requires valid_for")
        if self.object_type=="polynomial_sequence" and self.scope in {SCOPE_FORMAL,SCOPE_LITERATURE}:
            if "formula_coefficients_low_to_high" not in self.definition: e.append("polynomial requires formula_coefficients_low_to_high")
        return (not e,e)

# ----------------------------- trust ---------------------------------------

class TrustAuthority:
    """Analyzer-issued trust. User input status is never accepted as verified."""
    def __init__(self, registry: Path):
        self.registry=registry; ensure(registry.parent)
        if not registry.exists():
            registry.write_text(json.dumps({"registry_mode":"UNTRUSTED_LOCAL","receipts":{}}, indent=2))
        self.db=json.loads(registry.read_text())

    def save(self): self.registry.write_text(json.dumps(self.db, indent=2, sort_keys=True))
    def registry_mode(self)->str: return self.db.get("registry_mode","UNTRUSTED_LOCAL")
    def object_hash(self, obj: FormalObject)->str: return sha256(obj.payload_for_receipt())

    def seal_local(self, obj: FormalObject) -> Dict[str,Any]:
        h=self.object_hash(obj)
        receipt={"object_hash":h,"trust_class":"LOCAL_RECEIPT_SEALED","issued_by":"local_v11_tool","issued_at":now(),"salt":TRUST_SALT,"receipt_hash":sha256(h+TRUST_SALT)}
        self.db.setdefault("receipts",{})[h]=receipt; self.save(); return receipt

    def promote_external_for_tests_only(self, obj: FormalObject, trust_class: str) -> Dict[str,Any]:
        # Kept explicit and scary: normal user JSON cannot self-assign this. Selftest uses it to ensure mode separation.
        if trust_class not in EXTERNAL_TRUST: raise ValueError("not external trust")
        h=self.object_hash(obj)
        receipt={"object_hash":h,"trust_class":trust_class,"issued_by":"explicit_test_trust_authority","issued_at":now(),"receipt_hash":sha256(h+trust_class+TRUST_SALT)}
        self.db.setdefault("receipts",{})[h]=receipt; self.save(); return receipt

    def verify(self, obj: FormalObject) -> Dict[str,Any]:
        claimed=obj.source.get("status") or obj.source.get("trust_class") or "NONE"
        h=self.object_hash(obj)
        receipt=self.db.get("receipts",{}).get(h)
        schema_ok, schema_errors = obj.validate_schema()
        # User-provided source status is treated only as claimed metadata.
        out={"claimed_input_status":claimed,"schema_valid":schema_ok,"schema_errors":schema_errors,"object_hash":h,"registry_mode":self.registry_mode(),"verified":False,"trust_class":"UNTRUSTED_LOCAL","grade":"NONE"}
        if not schema_ok: return out
        if receipt:
            tc=receipt.get("trust_class","LOCAL_RECEIPT_SEALED")
            out.update({"receipt_found":True,"receipt":receipt,"trust_class":tc})
            if tc in EXTERNAL_TRUST:
                out.update({"verified":True,"grade":"EXTERNAL_VERIFIED"})
            else:
                out.update({"verified":False,"grade":"LOCAL_ONLY"})
        else:
            out.update({"receipt_found":False,"grade":"LOCAL_SCHEMA_VALID"})
        return out

# ----------------------------- sequence math -------------------------------

def finite_differences(seq: List[int], levels:int=10)->List[List[int]]:
    rows=[seq[:]]; cur=seq[:]
    for _ in range(levels):
        if len(cur)<=1: break
        cur=[cur[i+1]-cur[i] for i in range(len(cur)-1)]
        rows.append(cur)
    return rows

def polynomial_profile(seq: List[int])->Dict[str,Any]:
    n=len(seq); rows=finite_differences(seq, min(12,max(0,n-1)))
    for deg,row in enumerate(rows[1:], start=1):
        if row and len(set(row))==1:
            risk=(len(row)<3 or deg>max(2,(n-3)//2))
            return {"detected":True,"degree":deg,"constant_row_length":len(row),"terms":n,"interpolation_risk":risk,"verdict":"HIGH_DEGREE_POLYNOMIAL_INTERPOLATION_RISK" if risk else "LOW_RISK"}
    return {"detected":False,"interpolation_risk":False,"terms":n}

def binom(n:int,k:int)->int:
    return math.comb(n,k) if 0<=k<=n else 0

def newton_coefficients(seq: List[int])->Optional[List[int]]:
    prof=polynomial_profile(seq)
    if not prof.get("detected") or prof.get("interpolation_risk"): return None
    rows=finite_differences(seq, prof["degree"])
    return [rows[i][0] for i in range(prof["degree"]+1)]

def eval_newton(coeffs: List[int], n:int)->int: return sum(c*binom(n,i) for i,c in enumerate(coeffs))

def solve_linear(A:List[List[Fraction]], b:List[Fraction])->Optional[List[Fraction]]:
    if not A: return None
    m=len(A); n=len(A[0]); M=[row[:] + [b[i]] for i,row in enumerate(A)]
    r=0; piv=[]
    for c in range(n):
        pivrow=next((i for i in range(r,m) if M[i][c]!=0), None)
        if pivrow is None: continue
        M[r],M[pivrow]=M[pivrow],M[r]
        div=M[r][c]; M[r]=[x/div for x in M[r]]
        for i in range(m):
            if i!=r and M[i][c]!=0:
                f=M[i][c]; M[i]=[M[i][j]-f*M[r][j] for j in range(n+1)]
        piv.append(c); r+=1
        if r==m: break
    for row in M:
        if all(row[c]==0 for c in range(n)) and row[-1]!=0: return None
    if len(piv)<n: return None
    sol=[Fraction(0) for _ in range(n)]
    for i,c in enumerate(piv[:n]): sol[c]=M[i][-1]
    return sol

def find_recurrence(seq: List[int], max_order:int=8)->Optional[Dict[str,Any]]:
    N=len(seq)
    for d in range(1,min(max_order,N//2)+1):
        A=[]; b=[]
        for n in range(d,N):
            A.append([Fraction(seq[n-i-1]) for i in range(d)]); b.append(Fraction(seq[n]))
        sol=solve_linear(A,b)
        if sol is None: continue
        if all(sum(sol[i]*seq[n-i-1] for i in range(d))==seq[n] for n in range(d,N)):
            risk=(N<2*d+4 or d>=N//3)
            return {"order":d,"coefficients":[str(x) for x in sol],"integer_coefficients":all(x.denominator==1 for x in sol),"interpolation_risk":risk,"margin_terms":N-2*d}
    return None

def gen_recurrence(coeffs:List[int], initial:List[int], length:int)->List[int]:
    out=initial[:]
    d=len(coeffs)
    while len(out)<length:
        out.append(sum(coeffs[i]*out[-i-1] for i in range(d)))
    return out[:length]

def recurrence_gf(coeffs:List[int], initial:List[int])->Dict[str,Any]:
    # Denominator 1 - c1 x - ... - cd x^d. Numerator computed by convolution for initial terms.
    den=[1]+[-c for c in coeffs]
    d=len(coeffs); num=[]
    for n in range(d):
        val=initial[n] if n<len(initial) else 0
        for j in range(1,min(n,d)+1): val -= coeffs[j-1]*(initial[n-j] if n-j<len(initial) else 0)
        num.append(val)
    return {"numerator_coefficients":num,"denominator_coefficients":den,"meaning":"ordinary generating function P(x)/Q(x) for supplied recurrence definition"}

def companion_matrix(coeffs:List[int])->List[List[int]]:
    d=len(coeffs)
    if d==0: return []
    return [coeffs[:]] + [[1 if j==i-1 else 0 for j in range(d)] for i in range(1,d)]

# ----------------------------- families / literature ------------------------

class KnownFamilies:
    def classify(self, seq:List[int])->List[Dict[str,Any]]:
        fam=[]; n=len(seq)
        fib=[0,1]
        while len(fib)<max(n+5,20): fib.append(fib[-1]+fib[-2])
        for start in range(0,6):
            if seq==fib[start:start+n]:
                fam.append({"family":"Fibonacci","oeis":"A000045","confidence":1.0,"canonical_index_start":start,"canonical_terms":[0,1],"canonical_recurrence":[1,1],"strong_divisibility_known":True,"primitive_divisor_family":"Lucas_U"})
                break
        luc=[2,1]
        while len(luc)<max(n+5,20): luc.append(luc[-1]+luc[-2])
        for start in range(0,6):
            if seq==luc[start:start+n]: fam.append({"family":"Lucas","oeis":"A000032","confidence":1.0,"canonical_index_start":start,"canonical_recurrence":[1,1],"primitive_divisor_family":"Lucas_V"}); break
        if seq==[i*i for i in range(n)]: fam.append({"family":"Squares_n0","oeis":"A000290","confidence":1.0,"canonical_index_start":0})
        if seq==[(i+1)**2 for i in range(n)]: fam.append({"family":"Squares_n1","oeis":"A000290","confidence":1.0,"canonical_index_start":1})
        if seq==[2**i for i in range(n)]: fam.append({"family":"PowersOf2","oeis":"A000079","confidence":1.0,"canonical_index_start":0,"canonical_recurrence":[2]})
        if n>=3 and len(set(seq))==1: fam.append({"family":"Constant","confidence":1.0})
        return fam

class Literature:
    def __init__(self, cache:Path, online:bool=False):
        self.cache=cache; self.online=online; ensure(cache.parent)
        if cache.exists(): self.db=json.loads(cache.read_text())
        else:
            self.db={"local":{
                "A000045":{"terms":[0,1,1,2,3,5,8,13,21,34,55,89,144],"name":"Fibonacci numbers"},
                "A000032":{"terms":[2,1,3,4,7,11,18,29,47,76],"name":"Lucas numbers"},
                "A000290":{"terms":[0,1,4,9,16,25,36,49,64,81,100],"name":"Squares"},
                "A000079":{"terms":[1,2,4,8,16,32,64,128],"name":"Powers of 2"}
            },"queries":{}}
            self.save()
    def save(self): self.cache.write_text(json.dumps(self.db,indent=2,sort_keys=True))
    def _local(self, seq:List[int])->Dict[str,Any]:
        matches=[]
        for oid,it in self.db.get("local",{}).items():
            t=it.get("terms",[])
            for start in range(0,max(1,len(t)-len(seq)+1)):
                if t[start:start+len(seq)]==seq:
                    matches.append({"id":oid,"name":it.get("name",""),"start":start,"verified_prefix_match":True,"source":"local_cache"})
                    break
        return {"queried":True,"collision":bool(matches),"matches":matches,"verified_prefix_match":bool(matches),"source":"local_cache"}
    def _online(self, seq:List[int])->Dict[str,Any]:
        q=','.join(map(str,seq[:12])); url="https://oeis.org/search?fmt=json&q="+urllib.parse.quote(q)
        try:
            data=json.loads(urllib.request.urlopen(url,timeout=6).read().decode())
            results=data.get("results") or []
            matches=[]; adjacent=[]
            for x in results[:10]:
                raw=x.get("data","") or ""
                terms=[]
                for tok in raw.split(','):
                    tok=tok.strip()
                    if re.fullmatch(r"[-+]?\d+", tok): terms.append(int(tok))
                item={"id":"A"+str(x.get("number","")).zfill(6),"name":x.get("name",""),"data_prefix":terms[:len(seq)]}
                if len(terms)>=len(seq) and terms[:len(seq)]==seq:
                    item["verified_prefix_match"]=True; matches.append(item)
                else:
                    item["verified_prefix_match"]=False; adjacent.append(item)
            return {"queried":True,"source":"oeis_online","collision":bool(matches),"verified_prefix_match":bool(matches),"matches":matches,"adjacent_text_matches":adjacent[:5]}
        except Exception as e:
            return {"queried":False,"source":"oeis_online_error","collision":None,"matches":[],"error":repr(e)}
    def query(self, seq:List[int], name:str)->Dict[str,Any]:
        key=name+":"+','.join(map(str,seq[:20]))+":"+str(self.online)
        if key in self.db.setdefault("queries",{}): return self.db["queries"][key]
        res=self._local(seq)
        if not res["collision"] and self.online:
            res=self._online(seq)
        self.db["queries"][key]=res; self.save(); return res
    def collision_report(self, seq:List[int])->Dict[str,Any]:
        transforms={"identity":seq}
        if len(seq)>1: transforms["first_difference"]=[seq[i+1]-seq[i] for i in range(len(seq)-1)]
        if len(seq)>2:
            d=transforms["first_difference"]; transforms["second_difference"]=[d[i+1]-d[i] for i in range(len(d)-1)]
        out={}; any_col=False; incomplete=False
        for k,s in transforms.items():
            q=self.query(s,k); out[k]=q; any_col|=bool(q.get("collision")); incomplete|=not bool(q.get("queried"))
        verdict="COLLISION_FOUND" if any_col else ("INCOMPLETE_COLLISION_SEARCH" if incomplete or not self.online else "NO_COLLISION_IN_TESTED_TRANSFORMS")
        return {"verdict":verdict,"transforms":out,"novelty_allowed":verdict=="NO_COLLISION_IN_TESTED_TRANSFORMS"}

# ----------------------------- certificates --------------------------------

class CertificateFactory:
    @staticmethod
    def recurrence(obj:FormalObject)->Dict[str,Any]:
        rec=obj.definition.get("recurrence",{}); coeffs=[int(x) for x in rec.get("coefficients",[])]
        init=[int(x) for x in obj.definition.get("initial_terms",[])]
        gen=gen_recurrence(coeffs,init,len(obj.terms)) if coeffs and init else []
        ok=(gen==obj.terms[:len(gen)])
        return {"type":"RECURRENCE_REPLAY_CERTIFICATE","scope":obj.scope,"index_start":obj.index_start,"coefficients":coeffs,"initial_terms":init,"terms":obj.terms,"valid_for":rec.get("valid_for"),"replay_passed":ok,"generating_function":recurrence_gf(coeffs,init) if coeffs and init else None,"companion_matrix":companion_matrix(coeffs)}
    @staticmethod
    def verify_recurrence(cert:Dict[str,Any])->bool:
        return gen_recurrence([int(x) for x in cert["coefficients"]],[int(x) for x in cert["initial_terms"]],len(cert["terms"]))==cert["terms"]
    @staticmethod
    def polynomial(obj:FormalObject)->Dict[str,Any]:
        coeffs=[int(x) for x in obj.definition.get("formula_coefficients_low_to_high",[])]
        vals=[sum(coeffs[k]*((obj.index_start+i)**k) for k in range(len(coeffs))) for i in range(len(obj.terms))]
        ok=(vals==obj.terms)
        return {"type":"POLYNOMIAL_REPLAY_CERTIFICATE","scope":obj.scope,"index_start":obj.index_start,"ordinary_coefficients_low_to_high":coeffs,"terms":obj.terms,"generated_terms":vals,"replay_passed":ok}
    @staticmethod
    def verify_polynomial(cert:Dict[str,Any])->bool:
        coeffs=[int(x) for x in cert["ordinary_coefficients_low_to_high"]]
        vals=[sum(coeffs[k]*((cert["index_start"]+i)**k) for k in range(len(coeffs))) for i in range(len(cert["terms"]))]
        return vals==cert["terms"]
    @staticmethod
    def diophantine_local(A:int,B:int,C:int,bound:int=97)->Dict[str,Any]:
        for m in range(2,bound+1):
            residues_x=sorted({(A*(x*x))%m for x in range(m)})
            residues_y=sorted({(B*(y*y))%m for y in range(m)})
            possible=False
            for rx in residues_x:
                for ry in residues_y:
                    if (rx+ry-C)%m==0: possible=True; break
                if possible: break
            if not possible:
                return {"type":"LOCAL_OBSTRUCTION_CERTIFICATE","scope":"QUADRATIC_LOCAL_ONLY","equation":"A*x^2 + B*y^2 = C","A":A,"B":B,"C":C,"modulus":m,"x_residue_values":residues_x,"y_residue_values":residues_y,"replay_passed":True,"conclusion":"NO_INTEGER_SOLUTIONS_BECAUSE_NO_SOLUTION_MOD_M"}
        return {"type":"LOCAL_SCAN_NO_OBSTRUCTION_CERTIFICATE","scope":"QUADRATIC_LOCAL_ONLY","A":A,"B":B,"C":C,"bound":bound,"replay_passed":True,"conclusion":"NO_LOCAL_OBSTRUCTION_FOUND_UP_TO_BOUND"}
    @staticmethod
    def verify_dioph(cert:Dict[str,Any])->bool:
        if cert["type"]!="LOCAL_OBSTRUCTION_CERTIFICATE": return bool(cert.get("replay_passed"))
        A=cert["A"];B=cert["B"];C=cert["C"];m=cert["modulus"]
        for x in range(m):
            for y in range(m):
                if (A*x*x+B*y*y-C)%m==0: return False
        return True
    @staticmethod
    def crt_uncovered(base1:int,base2:int,c:int,max_modulus:int=120)->Dict[str,Any]:
        mods=[p for p in primes_upto(max_modulus) if p not in (2,)]
        certs=[]
        for m in mods:
            # periods for base powers modulo m, bounded conservatively by phi-ish m*m
            vals=[]; covered=set(); pairs=[]
            maxp=min(m*m,200)
            for k in range(maxp):
                a=pow(base1,k,m)
                for l in range(maxp):
                    if (a*pow(base2,l,m)+c)%m==0:
                        covered.add((k%maxp,l%maxp)); pairs.append((k%maxp,l%maxp))
            # certificate of non-universality on this finite torus: uncovered pair list exists.
            if len(covered)<maxp*maxp:
                # find one uncovered pair and verify expression nonzero for representative
                for k in range(maxp):
                    found=False
                    for l in range(maxp):
                        if (k,l) not in covered:
                            certs.append({"modulus":m,"period_bound":maxp,"uncovered_pair":[k,l],"value_mod_m":(pow(base1,k,m)*pow(base2,l,m)+c)%m})
                            found=True; break
                    if found: break
            if certs: break
        return {"type":"CRT_FINITE_TORUS_UNCOVERED_PAIR_CERTIFICATE","base1":base1,"base2":base2,"c":c,"max_modulus":max_modulus,"certificates":certs,"replay_passed":CertificateFactory.verify_crt({"base1":base1,"base2":base2,"c":c,"certificates":certs}),"warning":"Finite-torus noncoverage is not an infinite proof by itself; it is a replayable local certificate."}
    @staticmethod
    def verify_crt(cert:Dict[str,Any])->bool:
        b1=cert["base1"]; b2=cert["base2"]; c=cert["c"]
        for x in cert.get("certificates",[]):
            m=x["modulus"]; k,l=x["uncovered_pair"]
            if (pow(b1,k,m)*pow(b2,l,m)+c)%m==0: return False
        return True

# ----------------------------- corpus / KBK --------------------------------

class Corpus:
    def __init__(self,path:Path, reset_context:bool=False):
        self.path=path; ensure(path.parent); self.reset_context=reset_context
        self.conn=sqlite3.connect(str(path)); self.conn.row_factory=sqlite3.Row; self.init()
    def init(self):
        c=self.conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS objects(id TEXT PRIMARY KEY,label TEXT,payload TEXT,created TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,object_id TEXT,action TEXT,verdict TEXT,payload TEXT,created TEXT)")
        c.execute("CREATE TABLE IF NOT EXISTS kbk(run_id TEXT PRIMARY KEY,object_id TEXT,required_action TEXT,required_artifact TEXT,status TEXT,payload TEXT,created TEXT)")
        self.conn.commit()
    def store_object(self,obj:FormalObject)->str:
        oid=sha12(canon_json(asdict(obj))); self.conn.execute("INSERT OR REPLACE INTO objects VALUES(?,?,?,?)",(oid,obj.label,canon_json(asdict(obj)),now())); self.conn.commit(); return oid
    def store_run(self,oid:str,action:str,verdict:str,payload:Dict[str,Any])->str:
        rid=sha12(oid+action+verdict+now()+canon_json(payload)); self.conn.execute("INSERT INTO runs VALUES(?,?,?,?,?,?)",(rid,oid,action,verdict,canon_json(payload),now())); self.conn.commit(); return rid
    def set_kbk(self,rid:str,oid:str,required_action:str,required_artifact:str,payload:Dict[str,Any]):
        self.conn.execute("INSERT OR REPLACE INTO kbk VALUES(?,?,?,?,?,?,?)",(rid,oid,required_action,required_artifact,"OPEN",canon_json(payload),now())); self.conn.commit()
    def open_kbk(self,rid:str)->Optional[sqlite3.Row]:
        return self.conn.execute("SELECT * FROM kbk WHERE run_id=? AND status='OPEN'",(rid,)).fetchone()
    def close_kbk(self,rid:str): self.conn.execute("UPDATE kbk SET status='CLOSED' WHERE run_id=?",(rid,)); self.conn.commit()
    def object(self,oid:str)->Optional[FormalObject]:
        r=self.conn.execute("SELECT payload FROM objects WHERE id=?",(oid,)).fetchone(); return FormalObject(**json.loads(r["payload"])) if r else None

# ----------------------------- analyzer ------------------------------------

class Analyzer:
    def __init__(self,out:Path, corpus:Path, registry:Path, online:bool=False, reset_context:bool=False):
        self.out=out; ensure(out); self.corpus=Corpus(corpus,reset_context); self.trust=TrustAuthority(registry); self.known=KnownFamilies(); self.lit=Literature(out/"literature_cache.json",online=online)
    def analyze(self,obj:FormalObject, action:str="classify", enforce_kbk:bool=True, override:bool=False)->Dict[str,Any]:
        oid=self.corpus.store_object(obj)
        if self.corpus.reset_context:
            context={"status":"KBK_CONTEXT_RESET","warning":"fresh corpus context cannot claim continuation from prior work"}
        else: context={"status":"KBK_CONTEXT_ACTIVE"}
        trust=self.trust.verify(obj)
        schema_ok,schema_errors=obj.validate_schema()
        if not schema_ok:
            return self._store(oid, action, "SCHEMA_INVALID", {"version":VERSION,"verdict":"SCHEMA_INVALID","schema_errors":schema_errors,"source_verification":trust,"kbk_context":context})
        # formal contradiction first
        contradiction=self.formal_contradiction(obj, trust)
        if contradiction:
            return self._store(oid, action, "FORMAL_OBJECT_CONTRADICTION", {"version":VERSION,"verdict":"FORMAL_OBJECT_CONTRADICTION","contradiction":contradiction,"claims":{"overall_verdict":"FORMAL_OBJECT_CONTRADICTION","all_gth_allowed":False},"source_verification":trust,"kbk_context":context})
        seq=obj.terms[:]
        known=self.known.classify(seq)
        lit=self.lit.collision_report(seq)
        poly_prof=polynomial_profile(seq)
        rec=find_recurrence(seq)
        # priority: formal/known -> corruption -> low complexity -> interpolation risk
        primary="unclassified_prefix"
        if known: primary="known_family_classification"
        elif poly_prof.get("detected") and not poly_prof.get("interpolation_risk"): primary="polynomial_finite_difference"
        elif rec and not rec.get("interpolation_risk"): primary="linear_recurrence"
        elif poly_prof.get("interpolation_risk"): primary="high_degree_polynomial_interpolation_risk"
        elif rec and rec.get("interpolation_risk"): primary="high_order_prefix_interpolation_risk"
        corrupt={"status":"SUPPRESSED_BY_KNOWN_OR_FORMAL" if known or obj.scope!=SCOPE_PREFIX else "NOT_RUN_ON_UNCLASSIFIED_PREFIX","suspected":False}
        routes=self.routes(obj, rec, poly_prof, trust, known)
        proofs=self.proofs(obj, rec, poly_prof, routes)
        scores=self.scores(primary,known,lit,trust,obj,poly_prof,rec)
        verdict="NO_GTH"
        classification_allowed=primary in {"known_family_classification","polynomial_finite_difference","linear_recurrence"} and not primary.endswith("risk")
        if known: verdict="KNOWN_BASIC_CLASSIFICATION_SUPPRESSED"; classification_allowed=False
        elif classification_allowed: verdict="CLASSIFICATION_ONLY"
        theorem_allowed=[r["route"] for r in routes if r.get("claim_grade") in {"EXTERNALLY_VERIFIED_THEOREM_ROUTE","FORMALLY_VERIFIED"}]
        if theorem_allowed: verdict="ROUTE_SPECIFIC_THEOREM_GTH_ALLOWED"
        claim={"overall_verdict":verdict,"classification_gth_allowed":classification_allowed,"theorem_gth_allowed_routes":theorem_allowed,"novelty_gth_allowed":bool(lit.get("novelty_allowed")) and scores["novelty_score"]>0.8,"proof_verified":False}
        kbk=self.kbk_packet(primary,routes,proofs,lit,trust,obj)
        report={"version":VERSION,"object":asdict(obj),"object_id":oid,"source_verification":trust,"kbk_context":context,"known_families":known,"literature_collision":lit,"primary_coordinate":primary,"polynomial_profile":poly_prof,"recurrence":rec,"corruption_audit":corrupt,"routes":routes,"proofs":proofs,"scores":scores,"claims":claim,"kbk_packet":kbk,"hard_status":"certificate_factory_outputs_replayable_artifacts_but_requires_external_or_formal_proof_for_public_claims"}
        return self._store(oid,action,verdict,report, kbk=kbk)
    def _store(self, oid, action, verdict, report, kbk:Optional[Dict[str,Any]]=None):
        rid=self.corpus.store_run(oid,action,verdict,report); report["run_id"]=rid
        if kbk: self.corpus.set_kbk(rid,oid,kbk["required_action"],kbk["required_artifact"],kbk)
        (self.out/f"{report.get('object',{}).get('label','object')}.v11.report.json").write_text(json.dumps(report,indent=2,sort_keys=True))
        return report
    def formal_contradiction(self,obj:FormalObject,trust:Dict[str,Any])->Optional[Dict[str,Any]]:
        if obj.scope not in {SCOPE_FORMAL,SCOPE_LITERATURE}: return None
        if obj.object_type=="polynomial_sequence":
            cert=CertificateFactory.polynomial(obj)
            if not cert["replay_passed"]: return {"type":"POLYNOMIAL_DEFINITION_CONTRADICTS_TERMS","certificate":cert}
        if obj.object_type=="recurrence_sequence":
            cert=CertificateFactory.recurrence(obj)
            if not cert["replay_passed"]: return {"type":"RECURRENCE_DEFINITION_CONTRADICTS_TERMS","certificate":cert}
        return None
    def routes(self,obj,rec,poly_prof,trust,known)->List[Dict[str,Any]]:
        out=[]
        grade="LOCAL_ONLY"
        if trust.get("trust_class") in EXTERNAL_TRUST: grade="EXTERNAL_VERIFIED"
        if obj.object_type=="recurrence_sequence":
            cert=CertificateFactory.recurrence(obj)
            status="RECURRENCE_DEFINITION_VALID_LOCAL_ONLY" if cert["replay_passed"] else "RECURRENCE_CONTRADICTION"
            claim_grade="LOCAL_CERTIFICATE_ONLY"
            if cert["replay_passed"] and grade=="EXTERNAL_VERIFIED": claim_grade="EXTERNALLY_VERIFIED_THEOREM_ROUTE"
            out.append({"route":"linear_recurrence","status":status,"claim_grade":claim_grade,"certificate":cert,"closed_debt":["RECURRENCE_DEFINITION_REPLAY_CERTIFICATE"] if cert["replay_passed"] else [],"open_debt":["minimality proof","formal proof check"]})
        elif rec:
            out.append({"route":"linear_recurrence","status":"PREFIX_CERTIFIED" if not rec.get("interpolation_risk") else "INTERPOLATION_RISK","claim_grade":"FINITE_PREFIX_ONLY","certificate":{"detected":rec},"open_debt":["formal definition or verified external source required"]})
        if obj.object_type=="polynomial_sequence":
            cert=CertificateFactory.polynomial(obj)
            claim_grade="EXTERNALLY_VERIFIED_THEOREM_ROUTE" if cert["replay_passed"] and grade=="EXTERNAL_VERIFIED" else "LOCAL_CERTIFICATE_ONLY"
            out.append({"route":"polynomial_finite_difference","status":"POLYNOMIAL_DEFINITION_VALID_LOCAL_ONLY" if cert["replay_passed"] else "POLYNOMIAL_CONTRADICTION","claim_grade":claim_grade,"certificate":cert,"closed_debt":["POLYNOMIAL_REPLAY_CERTIFICATE"] if cert["replay_passed"] else []})
        elif poly_prof.get("detected"):
            out.append({"route":"polynomial_finite_difference","status":"PREFIX_INTERPOLATION_RISK" if poly_prof.get("interpolation_risk") else "PREFIX_CERTIFIED","claim_grade":"FINITE_PREFIX_ONLY","certificate":{"profile":poly_prof,"newton_coefficients":newton_coefficients(obj.terms)}})
        if known and known[0].get("family") in {"Fibonacci","Lucas"}:
            out.append({"route":"strong_divisibility","status":"PROOF_PLAN_COMPLETE_NOT_FORMALLY_PROVED","claim_grade":"PROOF_PLAN_ONLY","canonical_family":known[0],"proof_plan":["canonicalize to Lucas/Fibonacci coordinate","use addition formula U_{m+n}=U_m U_{n+1}-Q^m U_{n-m} style identity","run Euclidean reduction on indices","derive gcd(U_m,U_n)=U_gcd(m,n) under primitive/nondegenerate hypotheses"],"open_debt":["Lean formal proof","full all-index theorem check"]})
            out.append({"route":"primitive_divisor","status":"CANONICAL_EXCEPTION_CONVENTIONS_RECORDED","claim_grade":"ROUTE_SANITY_ONLY","canonical_family":known[0],"known_convention":"Fibonacci primitive divisor exceptions are index-convention dependent; heavy/general audit requires PARI","open_debt":["PARI factor audit for general inputs"]})
        return out
    def proofs(self,obj,rec,poly_prof,routes)->Dict[str,Any]:
        arts=[]; closed=[]; open_=[]
        for r in routes:
            cert=r.get("certificate")
            if cert:
                typ=cert.get("type") or "ROUTE_ARTIFACT"
                if cert.get("replay_passed"):
                    arts.append({"status":"CERTIFICATE_REPLAY_PASSED","type":typ,"route":r["route"]})
                    # closed only for the exact narrow claim.
                    closed.append({"debt":"narrow replay certificate", "route":r["route"], "closure":"DEBT_CLOSED_BY_REPLAY_VERIFIER_FOR_NARROW_CLAIM_ONLY"})
                else:
                    arts.append({"status":"ARTIFACT_EMITTED_NOT_CLOSED","type":typ,"route":r["route"]})
            open_.extend(r.get("open_debt",[]))
        lean={"lean_skeleton_emitted":True,"lean_compile_attempted":False,"lean_compile_passed":False,"formal_proof_verified":False,"reason":"Lean not executed by default; no formal verification language permitted."}
        return {"artifacts":arts,"closed_debt":closed,"open_debt":sorted(set(open_)),"lean_status":lean}
    def scores(self,primary,known,lit,trust,obj,poly_prof,rec):
        incomplete=lit["verdict"]=="INCOMPLETE_COLLISION_SEARCH"
        novelty=0.0 if known or incomplete or not lit.get("novelty_allowed") else 0.9
        if trust.get("trust_class") not in EXTERNAL_TRUST: theorem_prox=0.2 if obj.scope in {SCOPE_FORMAL,SCOPE_LITERATURE} else 0.0
        else: theorem_prox=0.8
        interp=primary.endswith("risk")
        truth=0.9 if known else (0.2 if interp else 0.5)
        explanation=0.95 if known else (0.1 if interp else 0.6)
        research=0.0 if known or interp else min(0.5, novelty*0.4+theorem_prox*0.4)
        return {"truth_prefix_score":truth,"explanation_score":explanation,"novelty_score":novelty,"theorem_proximity_score":theorem_prox,"research_value_score":research,"gate_caps":["known family suppresses novelty","incomplete literature caps novelty","local trust cannot unlock external theorem grade","interpolation risk caps explanation"]}
    def kbk_packet(self,primary,routes,proofs,lit,trust,obj):
        if primary.endswith("risk"): return {"required_action":"supply_independent_terms_or_formal_definition","required_artifact":"INDEPENDENT_EXTENSION_OR_VERIFIED_FORMAL_OBJECT","killer_next_data":"Provide independently sourced terms beyond interpolation margin or a verified formal object JSON."}
        if trust.get("trust_class") not in EXTERNAL_TRUST and obj.scope in {SCOPE_FORMAL,SCOPE_LITERATURE}: return {"required_action":"obtain_external_verification_or_downgrade_claim","required_artifact":"EXTERNAL_SOURCE_RECEIPT_OR_LEAN_PROOF","killer_next_data":"OEIS exact prefix verification, literature exact statement, signed project receipt, or Lean proof check."}
        if lit["verdict"]=="INCOMPLETE_COLLISION_SEARCH": return {"required_action":"complete_literature_collision_search","required_artifact":"OEIS_EXACT_MATCH_REPORT_OR_NO_COLLISION_REPORT","killer_next_data":"Run online OEIS exact returned-data verification across identity and transforms."}
        return {"required_action":"produce_replayable_certificate_or_stop","required_artifact":"REPLAY_CERTIFICATE","killer_next_data":"Produce CRT, Diophantine, recurrence, or polynomial replay certificate for the exact active claim."}
    def continue_kbk(self, run_id:str, action:str, artifact_path:Optional[Path], override:bool=False)->Dict[str,Any]:
        row=self.corpus.open_kbk(run_id)
        if not row: return {"verdict":"NO_OPEN_KBK","run_id":run_id}
        req=row["required_action"]; req_art=row["required_artifact"]
        if action!=req and not override: return {"verdict":"KBK_REFUSED_WRONG_ACTION","required_action":req,"provided_action":action}
        artifact_ok=False; detail={}
        if artifact_path and artifact_path.exists():
            try:
                art=json.loads(artifact_path.read_text())
                detail=art
                typ=art.get("type","")
                if req_art in {"REPLAY_CERTIFICATE","INDEPENDENT_EXTENSION_OR_VERIFIED_FORMAL_OBJECT","EXTERNAL_SOURCE_RECEIPT_OR_LEAN_PROOF","OEIS_EXACT_MATCH_REPORT_OR_NO_COLLISION_REPORT"}:
                    artifact_ok=bool(art.get("replay_passed") or art.get("verified") or art.get("collision_report_complete") or art.get("independent_extension"))
            except Exception as e: detail={"error":repr(e)}
        if not artifact_ok and not override: return {"verdict":"KBK_REFUSED_MISSING_REQUIRED_ARTIFACT","required_artifact":req_art,"artifact_path":str(artifact_path) if artifact_path else None,"artifact_detail":detail}
        self.corpus.close_kbk(run_id)
        return {"verdict":"KBK_CONTINUATION_ACCEPTED","run_id":run_id,"action":action,"artifact_verified":artifact_ok,"override":override}

# ----------------------------- acceptance ----------------------------------

class Acceptance:
    def __init__(self,out:Path):
        self.out=out; ensure(out)
        self.registry=out/"trust_registry.json"; self.an=Analyzer(out,out/"corpus.sqlite",self.registry,online=False)
        self.results=[]
    def check(self,name,cond,detail=None):
        self.results.append({"name":name,"pass":bool(cond),"detail":detail})
        if not cond:
            raise AssertionError(name+" FAILED: "+json.dumps(detail,indent=2,default=str)[:2000])
    def run(self)->Dict[str,Any]:
        fib0=[0,1,1,2,3,5,8,13,21,34]
        # 1 user JSON cannot self-assign verified source.
        fake=FormalObject("recurrence_sequence","fake_verified",SCOPE_FORMAL,[1,1,2,3,5,8],0,{"initial_terms":[1,1],"recurrence":{"coefficients":[1,1],"valid_for":"n >= 2"}},{"status":"LOCAL_VERIFIED_SCHEMA"})
        r=self.an.analyze(fake,enforce_kbk=False)
        self.check("01_user_json_verified_status_not_trusted", r["source_verification"]["grade"]!="EXTERNAL_VERIFIED" and not r["claims"]["theorem_gth_allowed_routes"], r)
        # 2 local seal not external.
        self.an.trust.seal_local(fake); r2=self.an.analyze(fake,enforce_kbk=False)
        self.check("02_local_seal_not_theorem_glory", r2["source_verification"]["trust_class"]=="LOCAL_RECEIPT_SEALED" and not r2["claims"]["theorem_gth_allowed_routes"], r2)
        # 3 external promotion works only analyzer-issued.
        self.an.trust.promote_external_for_tests_only(fake,"SIGNED_PROJECT_VERIFIED"); r3=self.an.analyze(fake,enforce_kbk=False)
        self.check("03_external_verified_route_only_after_authority_receipt", bool(r3["claims"]["theorem_gth_allowed_routes"]), r3["source_verification"])
        # 4 polynomial index_start respected.
        poly=FormalObject("polynomial_sequence","n2_i1",SCOPE_FORMAL,[1,4,9,16,25],1,{"formula_coefficients_low_to_high":[0,0,1]},{})
        self.an.trust.promote_external_for_tests_only(poly,"SIGNED_PROJECT_VERIFIED"); rp=self.an.analyze(poly,enforce_kbk=False)
        self.check("04_polynomial_index_start_respected", rp.get("verdict", rp.get("claims",{}).get("overall_verdict"))!="FORMAL_OBJECT_CONTRADICTION" and any(x["certificate"].get("replay_passed") for x in rp["routes"] if x["route"]=="polynomial_finite_difference"), rp)
        # 5 recurrence respects supplied definition and contradiction.
        bad=FormalObject("recurrence_sequence","bad_rec",SCOPE_FORMAL,[1,1,2,4],0,{"initial_terms":[1,1],"recurrence":{"coefficients":[1,1],"valid_for":"n >= 2"}}, {})
        self.an.trust.promote_external_for_tests_only(bad,"SIGNED_PROJECT_VERIFIED"); rb=self.an.analyze(bad,enforce_kbk=False)
        self.check("05_recurrence_contradiction_object_fatal", rb["verdict"]=="FORMAL_OBJECT_CONTRADICTION", rb)
        # 6 known exact family overrides interpolation risk.
        rf0=self.an.analyze(FormalObject.observed("fib0",fib0),enforce_kbk=False)
        self.check("06_fib0_known_not_interpolation_primary", rf0["primary_coordinate"]=="known_family_classification" and rf0["scores"]["novelty_score"]==0.0, rf0)
        # 7 six-term junk polynomial risk.
        junk=[3,8,5,13,21,7]; rj=self.an.analyze(FormalObject.observed("sixjunk",junk),enforce_kbk=False)
        self.check("07_short_junk_no_polynomial_glory", rj["primary_coordinate"]=="high_degree_polynomial_interpolation_risk" and rj["claims"]["overall_verdict"]=="NO_GTH", rj)
        # 8 OEIS returned terms must be verified - local exact collision for fib, unknown incomplete/no collision.
        self.check("08_literature_exact_collision_for_fib", rf0["literature_collision"]["verdict"]=="COLLISION_FOUND", rf0["literature_collision"])
        # 9 proof artifacts closed only narrow.
        self.check("09_closed_debt_is_narrow_replay_only", all("NARROW" in c["closure"] for c in rp["proofs"]["closed_debt"]), rp["proofs"])
        # 10 KBK artifact gating.
        rr=self.an.analyze(FormalObject.observed("randomrisk",[4,9,2,6,5,35]),enforce_kbk=False)
        badcont=self.an.continue_kbk(rr["run_id"], rr["kbk_packet"]["required_action"], None)
        self.check("10_kbk_refuses_missing_artifact", badcont["verdict"]=="KBK_REFUSED_MISSING_REQUIRED_ARTIFACT", badcont)
        # 11 artifact accepted.
        art=self.out/"dummy_artifact.json"; art.write_text(json.dumps({"type":"REPLAY_CERTIFICATE","replay_passed":True}))
        goodcont=self.an.continue_kbk(rr["run_id"], rr["kbk_packet"]["required_action"], art)
        self.check("11_kbk_accepts_verified_artifact", goodcont["verdict"]=="KBK_CONTINUATION_ACCEPTED", goodcont)
        # 12 CRT cert replay.
        crt=CertificateFactory.crt_uncovered(2,3,1,30)
        self.check("12_crt_replay_certificate", crt["replay_passed"] and CertificateFactory.verify_crt(crt), crt)
        # 13 Diophantine obstruction x^2+y^2=3 no mod4 solution.
        dio=CertificateFactory.diophantine_local(1,1,3,20)
        self.check("13_diophantine_local_obstruction_replay", dio["type"]=="LOCAL_OBSTRUCTION_CERTIFICATE" and CertificateFactory.verify_dioph(dio), dio)
        # 14 recurrence cert replay.
        cert=CertificateFactory.recurrence(fake)
        self.check("14_recurrence_replay_verifier", cert["replay_passed"] and CertificateFactory.verify_recurrence(cert), cert)
        # 15 polynomial cert replay.
        pc=CertificateFactory.polynomial(poly)
        self.check("15_polynomial_replay_verifier", pc["replay_passed"] and CertificateFactory.verify_polynomial(pc), pc)
        # 16 strong divisibility proof plan produced for fib.
        self.check("16_strong_divisibility_plan_for_fib", any(x["route"]=="strong_divisibility" and x["status"].startswith("PROOF_PLAN") for x in rf0["routes"]), rf0["routes"])
        # 17 primitive divisor conventions for fib.
        self.check("17_primitive_divisor_conventions_for_fib", any(x["route"]=="primitive_divisor" and "CONVENTIONS" in x["status"] for x in rf0["routes"]), rf0["routes"])
        # 18 fuzz source trust: random claimed statuses never external.
        for i in range(20):
            o=FormalObject("recurrence_sequence","fuzzsrc",SCOPE_FORMAL,[1,1,2,3],0,{"initial_terms":[1,1],"recurrence":{"coefficients":[1,1],"valid_for":"n >= 2"}},{"status":"OEIS_VERIFIED"+str(i)})
            rr2=self.an.analyze(o,enforce_kbk=False)
            if rr2["source_verification"]["grade"]=="EXTERNAL_VERIFIED":
                self.check("18_fuzz_source_trust", False, rr2)
        self.check("18_fuzz_source_trust", True)
        # 19 fuzz interpolation: random short should not get GTH.
        for i in range(25):
            s=[random.randint(-20,20) for _ in range(6)]
            x=self.an.analyze(FormalObject.observed("fuzzjunk",s),enforce_kbk=False)
            if x["claims"]["overall_verdict"] not in {"NO_GTH","KNOWN_BASIC_CLASSIFICATION_SUPPRESSED","CLASSIFICATION_ONLY"}: self.check("19_fuzz_no_theorem_from_junk",False,x)
            if x["claims"]["theorem_gth_allowed_routes"]: self.check("19_fuzz_no_theorem_from_junk",False,x)
        self.check("19_fuzz_no_theorem_from_junk", True)
        # 20 no world shock without hard artifact.
        self.check("20_no_world_shock_language_without_hard_artifact", "world_shock" not in json.dumps(rf0).lower(), rf0.get("hard_status"))
        summary={"version":VERSION,"selftest":"PASS","green_checks":sum(1 for r in self.results if r["pass"]),"total_checks":len(self.results),"hard_artifacts":["CRT_FINITE_TORUS_UNCOVERED_PAIR_CERTIFICATE","LOCAL_OBSTRUCTION_CERTIFICATE","RECURRENCE_REPLAY_CERTIFICATE","POLYNOMIAL_REPLAY_CERTIFICATE"]}
        (self.out/"v11_acceptance_summary.json").write_text(json.dumps({"summary":summary,"checks":self.results},indent=2,sort_keys=True))
        return summary

# ----------------------------- CLI -----------------------------------------

def default_corpus()->Path: return Path(os.environ.get("ORACLE_NT_CORPUS", str(Path.home()/".oracle_nt"/"v11_corpus.sqlite")))
def default_registry()->Path: return Path(os.environ.get("ORACLE_NT_TRUST_REGISTRY", str(Path.home()/".oracle_nt"/"v11_trust_registry.json")))

def build_an(args)->Analyzer:
    corpus=Path(args.corpus) if getattr(args,"corpus",None) else default_corpus()
    registry=Path(args.trust_registry) if getattr(args,"trust_registry",None) else default_registry()
    return Analyzer(Path(args.out), corpus, registry, online=getattr(args,"online",False), reset_context=getattr(args,"new_corpus",False))

def cmd_analyze_seq(args):
    seq=parse_ints(args.seq)
    if args.formal_recurrence:
        coeffs=parse_ints(args.formal_recurrence); init=parse_ints(args.initial_terms) or seq[:len(coeffs)]
        # CLI flag never creates formal definition, only generated extension.
        obj=FormalObject("recurrence_sequence",args.label,SCOPE_GENERATED,seq,args.index_start,{"initial_terms":init,"recurrence":{"coefficients":coeffs,"valid_for":f"n >= {args.index_start+len(coeffs)}"}}, {"status":"USER_ASSERTED_UNVERIFIED","note":args.definition_source or ""})
    else:
        obj=FormalObject.observed(args.label,seq)
    an=build_an(args); rep=an.analyze(obj,args.action,enforce_kbk=not args.override,override=args.override)
    print(json.dumps({"version":VERSION,"verdict":rep.get("verdict") or rep.get("claims",{}).get("overall_verdict"),"primary_coordinate":rep.get("primary_coordinate"),"run_id":rep.get("run_id"),"report":str(Path(args.out)/f"{args.label}.v11.report.json")},indent=2))

def cmd_analyze_object(args):
    obj=FormalObject.from_json(Path(args.object_json)); an=build_an(args); rep=an.analyze(obj,args.action,enforce_kbk=not args.override,override=args.override)
    print(json.dumps({"version":VERSION,"verdict":rep.get("verdict") or rep.get("claims",{}).get("overall_verdict"),"run_id":rep.get("run_id"),"source_verification":rep.get("source_verification"),"report":str(Path(args.out)/f"{obj.label}.v11.report.json")},indent=2))

def cmd_seal(args):
    obj=FormalObject.from_json(Path(args.object_json)); tr=TrustAuthority(Path(args.trust_registry) if args.trust_registry else default_registry()); receipt=tr.seal_local(obj); print(json.dumps({"version":VERSION,"receipt":receipt,"warning":"LOCAL_RECEIPT_SEALED is not external verification and cannot unlock theorem-grade glory."},indent=2))

def cmd_continue(args):
    an=build_an(args); res=an.continue_kbk(args.run_id,args.action,Path(args.artifact) if args.artifact else None,override=args.override); print(json.dumps(res,indent=2))

def cmd_crt(args):
    cert=CertificateFactory.crt_uncovered(args.base1,args.base2,args.c,args.max_modulus); ensure(Path(args.out)); (Path(args.out)/"crt_certificate.v11.json").write_text(json.dumps(cert,indent=2,sort_keys=True)); print(json.dumps(cert,indent=2))

def cmd_dio(args):
    cert=CertificateFactory.diophantine_local(args.A,args.B,args.C,args.bound); ensure(Path(args.out)); (Path(args.out)/"diophantine_certificate.v11.json").write_text(json.dumps(cert,indent=2,sort_keys=True)); print(json.dumps(cert,indent=2))

def cmd_verify_cert(args):
    cert=json.loads(Path(args.certificate).read_text()); typ=cert.get("type","")
    ok=False
    if typ.startswith("RECURRENCE"): ok=CertificateFactory.verify_recurrence(cert)
    elif typ.startswith("POLYNOMIAL"): ok=CertificateFactory.verify_polynomial(cert)
    elif typ.startswith("LOCAL_OBSTRUCTION") or typ.startswith("LOCAL_SCAN"): ok=CertificateFactory.verify_dioph(cert)
    elif typ.startswith("CRT"): ok=CertificateFactory.verify_crt(cert)
    print(json.dumps({"certificate":str(args.certificate),"type":typ,"replay_passed":ok},indent=2))

def cmd_selftest(args):
    summary=Acceptance(Path(args.out)).run(); print(json.dumps(summary,indent=2,sort_keys=True))

def main(argv=None):
    p=argparse.ArgumentParser(description="Oracle NT OS V11 - certificate factory")
    sub=p.add_subparsers(dest="cmd",required=True)
    def common(ap):
        ap.add_argument("--out",default="out_v11"); ap.add_argument("--corpus"); ap.add_argument("--trust-registry"); ap.add_argument("--online",action="store_true"); ap.add_argument("--new-corpus",action="store_true",help="explicitly mark a fresh corpus reset; cannot claim continuation")
    ap=sub.add_parser("analyze-seq"); common(ap); ap.add_argument("--seq",required=True); ap.add_argument("--label",default="seq"); ap.add_argument("--formal-recurrence"); ap.add_argument("--initial-terms"); ap.add_argument("--index-start",type=int,default=0); ap.add_argument("--definition-source"); ap.add_argument("--action",default="classify"); ap.add_argument("--override",action="store_true"); ap.set_defaults(func=cmd_analyze_seq)
    oj=sub.add_parser("analyze-object"); common(oj); oj.add_argument("--object-json",required=True); oj.add_argument("--action",default="classify"); oj.add_argument("--override",action="store_true"); oj.set_defaults(func=cmd_analyze_object)
    se=sub.add_parser("seal-object"); se.add_argument("--object-json",required=True); se.add_argument("--trust-registry"); se.set_defaults(func=cmd_seal)
    co=sub.add_parser("continue"); common(co); co.add_argument("--run-id",required=True); co.add_argument("--action",required=True); co.add_argument("--artifact"); co.add_argument("--override",action="store_true"); co.set_defaults(func=cmd_continue)
    cr=sub.add_parser("crt-war"); cr.add_argument("--base1",type=int,required=True); cr.add_argument("--base2",type=int,required=True); cr.add_argument("--c",type=int,required=True); cr.add_argument("--max-modulus",type=int,default=120); cr.add_argument("--out",default="crt_out_v11"); cr.set_defaults(func=cmd_crt)
    di=sub.add_parser("diophantine-local"); di.add_argument("--A",type=int,required=True); di.add_argument("--B",type=int,required=True); di.add_argument("--C",type=int,required=True); di.add_argument("--bound",type=int,default=97); di.add_argument("--out",default="dio_out_v11"); di.set_defaults(func=cmd_dio)
    vc=sub.add_parser("verify-cert"); vc.add_argument("--certificate",required=True); vc.set_defaults(func=cmd_verify_cert)
    st=sub.add_parser("selftest"); st.add_argument("--out",default="v11_selftest_out"); st.set_defaults(func=cmd_selftest)
    args=p.parse_args(argv); args.func(args)
if __name__=="__main__": main()
