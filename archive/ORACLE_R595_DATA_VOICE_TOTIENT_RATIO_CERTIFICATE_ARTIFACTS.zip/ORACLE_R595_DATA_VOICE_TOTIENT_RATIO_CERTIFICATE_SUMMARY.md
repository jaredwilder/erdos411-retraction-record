# ORACLE R595 — Data Voice Totient-Ratio Certificate

## Mission

Give the R594 inequality a data voice.

Target inequality:

```text
(p - 1)*phi(C2) > p*D
```

Ratio form:

```text
phi(C2)/C2 > p*D / ((p - 1)*C2)
```

## Chamber

```text
p <= 20,000,000
p ≡ 7 mod 8
underflow records: 5,277
```

## Extreme cases

```text
weakest multiplicative safety factor: 5.987722094488442
weakest safety p:                     10323647
actual phi(C2)/C2 at weakest:         0.2947024288559321
required ratio at weakest:            0.04921778669841722

weakest additive margin M:            496
weakest additive p:                   7

largest required ratio:               0.06111855590513829
largest required ratio p:             2155487

smallest actual phi(C2)/C2:           0.19866506746258308
smallest actual ratio p:              13218407

largest C2/phi(C2):                   5.03359756585461
largest damage p:                     13218407
```

## Distribution: safety factor

```json
{
  "8-10": 72,
  ">=10": 5164,
  "6-8": 40,
  "5-6": 1
}
```

## Data voice

The data says the inequality is not close. The weakest multiplicative safety factor is 5.987722
at p=10323647. The required totient ratio there is 0.049218, while the actual
phi(C2)/C2 ratio is 0.294702. Across all 5,277 underflow primes,
the largest required ratio is 0.061119, while the smallest actual ratio is
0.198665. The worst additive margin M is 496 at p=7.
No case is near zero; no case flips sign; no source factor q≡1 mod p appears in C2.

## GTH

The inequality is not barely surviving. In the tested chamber, the weakest multiplicative safety factor is still almost 6x.
