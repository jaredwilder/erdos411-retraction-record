# Oracle Number Theory Discovery Dossier

Created UTC: `2026-05-21T20:23:38Z`
Workbench version: `2.0.0-oracle`
Input SHA-256: `f621699e5c7e36bef81e35af21903dd103923f6baa1fd3a11f2d0aeb473170a7`

## Oracle packet

- Round: `1`
- Prior verdict: `N/A`
- One binary: **known structure OR detector failure**
- Verdict: **ESCALATION**
- Route: Exact linear recurrence, order 1
- Next binary: **true recurrence from object OR fitted recurrence artifact**
- Missing variable: Factor characteristic polynomial in Sage/PARI; inspect roots, Galois/norm signatures, and modular reductions.
- Jigsaw visible: `True`
- Jigsaw sentence: The visible picture is Exact linear recurrence, order 1: a(n) = (2)*a(n-1)
- Attack surface: Generate independent fresh terms and check all recurrence predictions.
- Referee target: Prove the recurrence and initial conditions. Then formal proof is induction.

## Sequence

```text
1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768
```

## Tool status

- sage: no
- gp: no
- lean: no
- sympy: yes | 1.14.0
- cypari2: no | No module named 'cypari2'

## Defensive gates

- **NT-BR-input**: `PASS`. Integer sequence passed basic substrate bounds
- **ZENITH-fake-diversity**: `FLAG`. Rational generating function candidate, denominator degree 1: high score rests on thin evidence
- **ZENITH-fake-diversity**: `FLAG`. Divisibility sequence candidate: high score rests on thin evidence
- **ZENITH-fake-diversity**: `FLAG`. Divisibility sequence candidate: high score rests on thin evidence
- **CLAIM-SEP**: `PASS`. Every top claim is tagged with a proof-status class

## Basic summary

```json
{
  "version": "2.0.0-oracle",
  "length": 16,
  "index_start": 0,
  "first_terms": [
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768
  ],
  "last_terms": [
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768
  ],
  "min": 1,
  "max": 32768,
  "max_abs_bits": 16,
  "gcd_terms": 1,
  "gcd_first_differences": 1,
  "monotone_non_decreasing": true,
  "monotone_increasing": true,
  "sign_profile": {
    "positive": 16
  },
  "tail_ratios": [
    "2",
    "2",
    "2",
    "2",
    "2",
    "2",
    "2",
    "2",
    "2"
  ]
}
```

## Ranked conjecture cards

### 1. Exact linear recurrence, order 1

Score: `0.950` | Confidence: `high-computational` | Claim class: `COMP` | Tags: `linear-recurrence, generating-function, exact`

**Claim:** a(n) = (2)*a(n-1)

**Measured evidence**
- Solved over Q and predicted 15/15 in-prefix terms exactly.
- Characteristic polynomial: t^1 - 2
- Coefficient denominator lcm: 1

**R667 falsifiers**
- Generate independent fresh terms and check all recurrence predictions.
- Check for shorter inhomogeneous or polynomial recurrence masquerading as homogeneous.

**Proof obligations**
- Prove the recurrence and initial conditions. Then formal proof is induction.

**Next computations**
- Factor characteristic polynomial in Sage/PARI; inspect roots, Galois/norm signatures, and modular reductions.

### 2. Rational generating function candidate, denominator degree 1

Score: `0.910` | Confidence: `high-computational` | Claim class: `COMP` | Tags: `generating-function, linear-recurrence`

**Claim:** A(x)=((1))/(1 - (2)*x^1)

**Measured evidence**
- Derived exactly from the fitted recurrence and observed initial terms.

**R667 falsifiers**
- A rational generating function candidate is only real after fresh-term verification or derivation from the object.

**Proof obligations**
- Prove Q(x)A(x)=P(x), then extract recurrence coefficients.

**Next computations**
- Use Sage to factor Q(x) and test partial fractions / closed form.

### 3. Divisibility sequence candidate

Score: `0.900` | Confidence: `high-computational` | Claim class: `COMP` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed i|j implies a_i|a_j across all checked pairs.

**Measured evidence**
- Passed 34/34 divisibility checks with index offset hypothesis 0.

**R667 falsifiers**
- Check fresh terms and zero/unit artifacts. Test strong gcd law separately.

**Proof obligations**
- Prove divisibility from recurrence, algebraic group law, or formal group valuation.

**Next computations**
- Search Lucas, Lehmer, elliptic divisibility, and Somos signatures.

### 4. Divisibility sequence candidate

Score: `0.900` | Confidence: `high-computational` | Claim class: `COMP` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed i|j implies a_i|a_j across all checked pairs.

**Measured evidence**
- Passed 34/34 divisibility checks with index offset hypothesis 1.

**R667 falsifiers**
- Check fresh terms and zero/unit artifacts. Test strong gcd law separately.

**Proof obligations**
- Prove divisibility from recurrence, algebraic group law, or formal group valuation.

**Next computations**
- Search Lucas, Lehmer, elliptic divisibility, and Somos signatures.

### 5. Strong gcd-law pressure

Score: `0.700` | Confidence: `medium-computational` | Claim class: `COMP` | Tags: `strong-divisibility, gcd-law`

**Claim:** Many checked pairs satisfy gcd(a_i,a_j)=a_gcd(i,j), suggesting a strong divisibility law.

**Measured evidence**
- Strong gcd equality held in 84 checked ordered pairs.

**R667 falsifiers**
- Audit indexing, signs, and unit factors. Require fresh terms.

**Proof obligations**
- Prove strong divisibility or identify the precise unit correction.

**Next computations**
- Run a Lucas/EDS classifier and factor primitive parts.

### 6. Strong gcd-law pressure

Score: `0.700` | Confidence: `medium-computational` | Claim class: `COMP` | Tags: `strong-divisibility, gcd-law`

**Claim:** Many checked pairs satisfy gcd(a_i,a_j)=a_gcd(i,j), suggesting a strong divisibility law.

**Measured evidence**
- Strong gcd equality held in 84 checked ordered pairs.

**R667 falsifiers**
- Audit indexing, signs, and unit factors. Require fresh terms.

**Proof obligations**
- Prove strong divisibility or identify the precise unit correction.

**Next computations**
- Run a Lucas/EDS classifier and factor primitive parts.

### 7. Smoothness cluster

Score: `0.675` | Confidence: `low` | Claim class: `COMP` | Tags: `factorization, smoothness`
Risk flags: `prefix-bias`

**Claim:** A large fraction of early terms factor over very small primes.

**Measured evidence**
- (1, 2, {2: 1})
- (2, 4, {2: 2})
- (3, 8, {2: 3})
- (4, 16, {2: 4})
- (5, 32, {2: 5})
- (6, 64, {2: 6})
- (7, 128, {2: 7})
- (8, 256, {2: 8})
- (9, 512, {2: 9})
- (10, 1024, {2: 10})
- (11, 2048, {2: 11})
- (12, 4096, {2: 12})

**R667 falsifiers**
- Factor later terms. Smooth prefixes are a classic trap.

**Proof obligations**
- Derive product/binomial/factorial structure or prove bounded prime support.

**Next computations**
- Use PARI factorint at later indices and compare largest prime factor growth.

### 8. Local obstruction candidate

Score: `0.660` | Confidence: `low` | Claim class: `COMP` | Tags: `local-obstruction, modular`

**Claim:** The prefix avoids at least one residue class pattern that may represent a modular obstruction.

**Measured evidence**
- {"hit_moduli": [{"modulus": 3, "seen": 2, "missing": [0]}, {"modulus": 4, "seen": 3, "missing": [3]}, {"modulus": 5, "seen": 4, "missing": [0]}, {"modulus": 6, "seen": 3, "missing": [0, 3, 5]}, {"modulus": 9, "seen": 6, "missing": [0, 3, 6]}, {"modulus": 11, "seen": 10, "missing": [0]}, {"modulus": 13, "seen": 12, "missing": [0]}]}

**R667 falsifiers**
- Check whether missing residues are forced by the definition or just by prefix size.

**Proof obligations**
- Prove the forbidden residue set modulo m for the actual formula or recurrence.

**Next computations**
- If studying prime/composite forcing, use CRT-cover lab and PARI primality checks.

### 9. Exact finite-difference polynomial, degree 15

Score: `0.625` | Confidence: `low` | Claim class: `COMP` | Tags: `polynomial, finite-difference`

**Claim:** The observed prefix is generated by a degree 15 polynomial in n; the 15th finite difference is constant 1.

**Measured evidence**
- Finite difference row 15 is constant for 1 consecutive positions.

**R667 falsifiers**
- Acquire terms beyond the interpolation window and verify the same finite-difference row remains constant.

**Proof obligations**
- Write the polynomial in binomial basis and prove the finite-difference identity by induction.

**Next computations**
- Use generated Sage file to express the interpolant in binomial basis.

### 10. Repeated square terms

Score: `0.620` | Confidence: `low` | Claim class: `COMP` | Tags: `squares, diophantine, norm`

**Claim:** Perfect-square terms recur in the prefix, hinting at quadratic form, norm, Pell, or elliptic structure.

**Measured evidence**
- (0, 1)
- (2, 4)
- (4, 16)
- (6, 64)
- (8, 256)
- (10, 1024)
- (12, 4096)
- (14, 16384)

**R667 falsifiers**
- Test whether square positions obey a law rather than early small-number coincidence.

**Proof obligations**
- Reduce square-term condition to a Diophantine equation and classify solutions.

**Next computations**
- Generate Pell/elliptic curve handoff and search LMFDB.

### 11. Modular finite-state structure

Score: `0.498` | Confidence: `low` | Claim class: `COMP` | Tags: `modular, automatic, finite-state`

**Claim:** The observed prefix has small visible periods modulo many small moduli.

**Measured evidence**
- mod 3: period 2
- mod 5: period 4
- mod 7: period 3
- mod 9: period 6
- mod 15: period 4
- mod 17: period 8
- mod 21: period 6
- mod 31: period 5
- mod 51: period 8
- mod 63: period 6
- mod 85: period 8

**R667 falsifiers**
- Extend the prefix. A visible period must survive beyond two full cycles.
- For recurrence sequences, prove periodicity modulo m from finite state space.

**Proof obligations**
- Prove a finite-state transition or recurrence modulo each modulus; then lift using CRT if needed.

**Next computations**
- Run Sage/PARI on larger moduli and compute period growth p^e.

### 12. p-adic valuation law candidate

Score: `0.345` | Confidence: `low` | Claim class: `COMP` | Tags: `p-adic, valuation, LTE`

**Claim:** Prime-adic valuations show repeated structure worth testing against LTE, Lucas, or formal-group laws.

**Measured evidence**
- {"p": 2, "max_v": 15, "prefix": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], "matches_vp_index": 0}

**R667 falsifiers**
- Compare against v_p(n), v_p(n+c), and recurrence-specific LTE predictions on fresh terms.

**Proof obligations**
- Identify and prove the exact valuation formula.

**Next computations**
- Use PARI to compute valuations farther out and regress v_p(a_n) against v_p(index shifts).

## Knowledge routing

```json
{
  "oeis_url": "https://oeis.org/search?q=1%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%2C1024%2C2048%2C4096%2C8192%2C16384%2C32768&fmt=json",
  "lmfdb_urls": [
    {
      "label": "LMFDB global search",
      "url": "https://www.lmfdb.org/search/?q=1%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%20divisibility%20elliptic-divisibility%20exact%20factorization%20gcd-law%20generating-function%20linear-recurrence%20local-obstruction%20lucas%20modular%20smoothness%20strong-divisibility"
    },
    {
      "label": "LMFDB elliptic curves",
      "url": "https://www.lmfdb.org/EllipticCurve/Q/"
    },
    {
      "label": "LMFDB number fields",
      "url": "https://www.lmfdb.org/NumberField/"
    },
    {
      "label": "LMFDB modular forms",
      "url": "https://www.lmfdb.org/ModularForm/"
    },
    {
      "label": "LMFDB L-functions",
      "url": "https://www.lmfdb.org/L/"
    }
  ],
  "literature_urls": [
    {
      "label": "arXiv",
      "url": "https://arxiv.org/search/?query=%221%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%2C1024%2C2048%22+divisibility+elliptic-divisibility+exact+factorization+gcd-law+generating-function+linear-recurrence+local-obstruction+lucas+modular+smoothness+strong-divisibility&searchtype=all"
    },
    {
      "label": "zbMATH",
      "url": "https://zbmath.org/?q=%221%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%2C1024%2C2048%22+divisibility+elliptic-divisibility+exact+factorization+gcd-law+generating-function+linear-recurrence+local-obstruction+lucas+modular+smoothness+strong-divisibility"
    },
    {
      "label": "Google Scholar",
      "url": "https://scholar.google.com/scholar?q=%221%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%2C1024%2C2048%22+divisibility+elliptic-divisibility+exact+factorization+gcd-law+generating-function+linear-recurrence+local-obstruction+lucas+modular+smoothness+strong-divisibility"
    },
    {
      "label": "MathSciNet",
      "url": "https://mathscinet.ams.org/mathscinet"
    }
  ],
  "online_enabled": false
}
```

## Handoff files

- sage: `/mnt/data/nt_oracle_v2/selftest_out/powers2_f621699e5c7e.sage`
- pari_gp: `/mnt/data/nt_oracle_v2/selftest_out/powers2_f621699e5c7e.gp`
- lean: `/mnt/data/nt_oracle_v2/selftest_out/powers2_f621699e5c7e.lean`
- magma_pseudocode: `/mnt/data/nt_oracle_v2/selftest_out/powers2_f621699e5c7e.magma.txt`
- json_report: `/mnt/data/nt_oracle_v2/selftest_out/powers2_f621699e5c7e.oracle.report.json`
- markdown_report: `/mnt/data/nt_oracle_v2/selftest_out/powers2_f621699e5c7e.oracle.report.md`
- kbk_packet: `/mnt/data/nt_oracle_v2/selftest_out/powers2_f621699e5c7e.kbk.packet.json`

## Rule

Nothing here is a theorem until a proof exists. The workbench is allowed to be aggressive about discovery, and brutal about proof status.