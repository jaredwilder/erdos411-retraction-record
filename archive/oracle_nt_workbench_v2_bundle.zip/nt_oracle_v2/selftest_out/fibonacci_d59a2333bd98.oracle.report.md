# Oracle Number Theory Discovery Dossier

Created UTC: `2026-05-21T20:23:37Z`
Workbench version: `2.0.0-oracle`
Input SHA-256: `d59a2333bd98948538c75ba49df77560e07d61db86230adb52b757acafefc58b`

## Oracle packet

- Round: `1`
- Prior verdict: `N/A`
- One binary: **known structure OR detector failure**
- Verdict: **ESCALATION**
- Route: Exact linear recurrence, order 2
- Next binary: **true recurrence from object OR fitted recurrence artifact**
- Missing variable: Factor characteristic polynomial in Sage/PARI; inspect roots, Galois/norm signatures, and modular reductions.
- Jigsaw visible: `True`
- Jigsaw sentence: The visible picture is Exact linear recurrence, order 2: a(n) = (1)*a(n-1) + (1)*a(n-2)
- Attack surface: Generate independent fresh terms and check all recurrence predictions.
- Referee target: Prove the recurrence and initial conditions. Then formal proof is induction.

## Sequence

```text
1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377
```

## Tool status

- sage: no
- gp: no
- lean: no
- sympy: yes | 1.14.0
- cypari2: no | No module named 'cypari2'

## Defensive gates

- **NT-BR-input**: `PASS`. Integer sequence passed basic substrate bounds
- **ZENITH-fake-diversity**: `FLAG`. Divisibility sequence candidate: high score rests on thin evidence
- **ZENITH-fake-diversity**: `FLAG`. Divisibility sequence candidate: high score rests on thin evidence
- **ZENITH-fake-diversity**: `FLAG`. Rational generating function candidate, denominator degree 2: high score rests on thin evidence
- **CLAIM-SEP**: `PASS`. Every top claim is tagged with a proof-status class

## Basic summary

```json
{
  "version": "2.0.0-oracle",
  "length": 14,
  "index_start": 0,
  "first_terms": [
    1,
    1,
    2,
    3,
    5,
    8,
    13,
    21,
    34,
    55,
    89,
    144,
    233,
    377
  ],
  "last_terms": [
    5,
    8,
    13,
    21,
    34,
    55,
    89,
    144,
    233,
    377
  ],
  "min": 1,
  "max": 377,
  "max_abs_bits": 9,
  "gcd_terms": 1,
  "gcd_first_differences": 1,
  "monotone_non_decreasing": true,
  "monotone_increasing": false,
  "sign_profile": {
    "positive": 14
  },
  "tail_ratios": [
    "8/5",
    "13/8",
    "21/13",
    "34/21",
    "55/34",
    "89/55",
    "144/89",
    "233/144",
    "377/233"
  ]
}
```

## Ranked conjecture cards

### 1. Exact linear recurrence, order 2

Score: `0.924` | Confidence: `high-computational` | Claim class: `COMP` | Tags: `linear-recurrence, generating-function, exact`

**Claim:** a(n) = (1)*a(n-1) + (1)*a(n-2)

**Measured evidence**
- Solved over Q and predicted 12/12 in-prefix terms exactly.
- Characteristic polynomial: t^2 - 1*t - 1
- Coefficient denominator lcm: 1

**R667 falsifiers**
- Generate independent fresh terms and check all recurrence predictions.
- Check for shorter inhomogeneous or polynomial recurrence masquerading as homogeneous.

**Proof obligations**
- Prove the recurrence and initial conditions. Then formal proof is induction.

**Next computations**
- Factor characteristic polynomial in Sage/PARI; inspect roots, Galois/norm signatures, and modular reductions.

### 2. Divisibility sequence candidate

Score: `0.900` | Confidence: `high-computational` | Claim class: `COMP` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed i|j implies a_i|a_j across all checked pairs.

**Measured evidence**
- Passed 27/27 divisibility checks with index offset hypothesis 0.

**R667 falsifiers**
- Check fresh terms and zero/unit artifacts. Test strong gcd law separately.

**Proof obligations**
- Prove divisibility from recurrence, algebraic group law, or formal group valuation.

**Next computations**
- Search Lucas, Lehmer, elliptic divisibility, and Somos signatures.

### 3. Divisibility sequence candidate

Score: `0.900` | Confidence: `high-computational` | Claim class: `COMP` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed i|j implies a_i|a_j across all checked pairs.

**Measured evidence**
- Passed 27/27 divisibility checks with index offset hypothesis 1.

**R667 falsifiers**
- Check fresh terms and zero/unit artifacts. Test strong gcd law separately.

**Proof obligations**
- Prove divisibility from recurrence, algebraic group law, or formal group valuation.

**Next computations**
- Search Lucas, Lehmer, elliptic divisibility, and Somos signatures.

### 4. Rational generating function candidate, denominator degree 2

Score: `0.846` | Confidence: `medium-computational` | Claim class: `COMP` | Tags: `generating-function, linear-recurrence`

**Claim:** A(x)=((1))/(1 - (1)*x^1 - (1)*x^2)

**Measured evidence**
- Derived exactly from the fitted recurrence and observed initial terms.

**R667 falsifiers**
- A rational generating function candidate is only real after fresh-term verification or derivation from the object.

**Proof obligations**
- Prove Q(x)A(x)=P(x), then extract recurrence coefficients.

**Next computations**
- Use Sage to factor Q(x) and test partial fractions / closed form.

### 5. Strong gcd-law pressure

Score: `0.780` | Confidence: `medium-computational` | Claim class: `COMP` | Tags: `strong-divisibility, gcd-law`

**Claim:** Many checked pairs satisfy gcd(a_i,a_j)=a_gcd(i,j), suggesting a strong divisibility law.

**Measured evidence**
- Strong gcd equality held in 196 checked ordered pairs.

**R667 falsifiers**
- Audit indexing, signs, and unit factors. Require fresh terms.

**Proof obligations**
- Prove strong divisibility or identify the precise unit correction.

**Next computations**
- Run a Lucas/EDS classifier and factor primitive parts.

### 6. Strong gcd-law pressure

Score: `0.780` | Confidence: `medium-computational` | Claim class: `COMP` | Tags: `strong-divisibility, gcd-law`

**Claim:** Many checked pairs satisfy gcd(a_i,a_j)=a_gcd(i,j), suggesting a strong divisibility law.

**Measured evidence**
- Strong gcd equality held in 196 checked ordered pairs.

**R667 falsifiers**
- Audit indexing, signs, and unit factors. Require fresh terms.

**Proof obligations**
- Prove strong divisibility or identify the precise unit correction.

**Next computations**
- Run a Lucas/EDS classifier and factor primitive parts.

### 7. Exact finite-difference polynomial, degree 13

Score: `0.625` | Confidence: `low` | Claim class: `COMP` | Tags: `polynomial, finite-difference`

**Claim:** The observed prefix is generated by a degree 13 polynomial in n; the 13th finite difference is constant -144.

**Measured evidence**
- Finite difference row 13 is constant for 1 consecutive positions.

**R667 falsifiers**
- Acquire terms beyond the interpolation window and verify the same finite-difference row remains constant.

**Proof obligations**
- Write the polynomial in binomial basis and prove the finite-difference identity by induction.

**Next computations**
- Use generated Sage file to express the interpolant in binomial basis.

### 8. Local obstruction candidate

Score: `0.540` | Confidence: `low` | Claim class: `COMP` | Tags: `local-obstruction, modular`

**Claim:** The prefix avoids at least one residue class pattern that may represent a modular obstruction.

**Measured evidence**
- {"hit_moduli": [{"modulus": 8, "seen": 6, "missing": [4, 6]}, {"modulus": 9, "seen": 8, "missing": [6]}, {"modulus": 10, "seen": 8, "missing": [0, 6]}, {"modulus": 12, "seen": 9, "missing": [4, 6, 11]}]}

**R667 falsifiers**
- Check whether missing residues are forced by the definition or just by prefix size.

**Proof obligations**
- Prove the forbidden residue set modulo m for the actual formula or recurrence.

**Next computations**
- If studying prime/composite forcing, use CRT-cover lab and PARI primality checks.

### 9. Smoothness cluster

Score: `0.525` | Confidence: `low` | Claim class: `COMP` | Tags: `factorization, smoothness`
Risk flags: `prefix-bias`

**Claim:** A large fraction of early terms factor over very small primes.

**Measured evidence**
- (2, 2, {2: 1})
- (3, 3, {3: 1})
- (4, 5, {5: 1})
- (5, 8, {2: 3})
- (6, 13, {13: 1})
- (7, 21, {3: 1, 7: 1})
- (8, 34, {2: 1, 17: 1})
- (9, 55, {5: 1, 11: 1})
- (11, 144, {2: 4, 3: 2})

**R667 falsifiers**
- Factor later terms. Smooth prefixes are a classic trap.

**Proof obligations**
- Derive product/binomial/factorial structure or prove bounded prime support.

**Next computations**
- Use PARI factorint at later indices and compare largest prime factor growth.

### 10. Primitive prime divisor pressure

Score: `0.450` | Confidence: `low` | Claim class: `C` | Tags: `primitive-divisors, zsigmondy`

**Claim:** New prime divisors appear repeatedly, suggesting Zsigmondy/Lucas/EDS style structure or its failure boundary.

**Measured evidence**
- (2, [2])
- (3, [3])
- (4, [5])
- (6, [13])
- (7, [7])
- (8, [17])
- (9, [11])
- (10, [89])
- (12, [233])
- (13, [29])

**R667 falsifiers**
- Check primitive part after removing earlier prime support, and compare to known Zsigmondy exceptions.

**Proof obligations**
- Connect the sequence to a setting with a primitive divisor theorem or isolate exceptions.

**Next computations**
- Compute primitive parts in PARI and search literature for matching primitive divisor theorem.

### 11. Prime-rich prefix

Score: `0.430` | Confidence: `low` | Claim class: `OPEN` | Tags: `primality, open-risk`
Risk flags: `bunyakovsky-risk`

**Claim:** Multiple observed terms are prime.

**Measured evidence**
- (2, 2)
- (3, 3)
- (4, 5)
- (6, 13)
- (10, 89)
- (12, 233)

**R667 falsifiers**
- Prime-producing prefixes are not theorems. Extend terms and compare density to random controls of same size.

**Proof obligations**
- State primality pattern as OPEN unless a classical theorem applies.

**Next computations**
- Run PARI isprime/ispseudoprime at larger generated indices.

### 12. Repeated square terms

Score: `0.420` | Confidence: `low` | Claim class: `COMP` | Tags: `squares, diophantine, norm`

**Claim:** Perfect-square terms recur in the prefix, hinting at quadratic form, norm, Pell, or elliptic structure.

**Measured evidence**
- (0, 1)
- (1, 1)
- (11, 144)

**R667 falsifiers**
- Test whether square positions obey a law rather than early small-number coincidence.

**Proof obligations**
- Reduce square-term condition to a Diophantine equation and classify solutions.

**Next computations**
- Generate Pell/elliptic curve handoff and search LMFDB.

### 13. p-adic valuation law candidate

Score: `0.370` | Confidence: `low` | Claim class: `COMP` | Tags: `p-adic, valuation, LTE`

**Claim:** Prime-adic valuations show repeated structure worth testing against LTE, Lucas, or formal-group laws.

**Measured evidence**
- {"p": 2, "max_v": 4, "prefix": [0, 0, 1, 0, 0, 3, 0, 0, 1, 0, 0, 4, 0, 0], "matches_vp_index": 6}
- {"p": 3, "max_v": 2, "prefix": [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0], "matches_vp_index": 8}

**R667 falsifiers**
- Compare against v_p(n), v_p(n+c), and recurrence-specific LTE predictions on fresh terms.

**Proof obligations**
- Identify and prove the exact valuation formula.

**Next computations**
- Use PARI to compute valuations farther out and regress v_p(a_n) against v_p(index shifts).

### 14. Modular finite-state structure

Score: `0.336` | Confidence: `low` | Claim class: `COMP` | Tags: `modular, automatic, finite-state`

**Claim:** The observed prefix has small visible periods modulo many small moduli.

**Measured evidence**
- mod 2: period 3
- mod 4: period 6

**R667 falsifiers**
- Extend the prefix. A visible period must survive beyond two full cycles.
- For recurrence sequences, prove periodicity modulo m from finite state space.

**Proof obligations**
- Prove a finite-state transition or recurrence modulo each modulus; then lift using CRT if needed.

**Next computations**
- Run Sage/PARI on larger moduli and compute period growth p^e.

## Knowledge routing

```json
{
  "oeis_url": "https://oeis.org/search?q=1%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%2C89%2C144%2C233%2C377&fmt=json",
  "lmfdb_urls": [
    {
      "label": "LMFDB global search",
      "url": "https://www.lmfdb.org/search/?q=1%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%20divisibility%20elliptic-divisibility%20exact%20finite-difference%20gcd-law%20generating-function%20linear-recurrence%20local-obstruction%20lucas%20modular%20polynomial%20strong-divisibility"
    },
    {
      "label": "LMFDB elliptic curves",
      "url": "https://www.lmfdb.org/EllipticCurve/Q/"
    },
    {
      "label": "LMFDB number fields",
      "url": "https://www.lmfdb.org/NumberField/"
    },
    {
      "label": "LMFDB modular forms",
      "url": "https://www.lmfdb.org/ModularForm/"
    },
    {
      "label": "LMFDB L-functions",
      "url": "https://www.lmfdb.org/L/"
    }
  ],
  "literature_urls": [
    {
      "label": "arXiv",
      "url": "https://arxiv.org/search/?query=%221%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%2C89%2C144%22+divisibility+elliptic-divisibility+exact+finite-difference+gcd-law+generating-function+linear-recurrence+local-obstruction+lucas+modular+polynomial+strong-divisibility&searchtype=all"
    },
    {
      "label": "zbMATH",
      "url": "https://zbmath.org/?q=%221%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%2C89%2C144%22+divisibility+elliptic-divisibility+exact+finite-difference+gcd-law+generating-function+linear-recurrence+local-obstruction+lucas+modular+polynomial+strong-divisibility"
    },
    {
      "label": "Google Scholar",
      "url": "https://scholar.google.com/scholar?q=%221%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%2C89%2C144%22+divisibility+elliptic-divisibility+exact+finite-difference+gcd-law+generating-function+linear-recurrence+local-obstruction+lucas+modular+polynomial+strong-divisibility"
    },
    {
      "label": "MathSciNet",
      "url": "https://mathscinet.ams.org/mathscinet"
    }
  ],
  "online_enabled": false
}
```

## Handoff files

- sage: `/mnt/data/nt_oracle_v2/selftest_out/fibonacci_d59a2333bd98.sage`
- pari_gp: `/mnt/data/nt_oracle_v2/selftest_out/fibonacci_d59a2333bd98.gp`
- lean: `/mnt/data/nt_oracle_v2/selftest_out/fibonacci_d59a2333bd98.lean`
- magma_pseudocode: `/mnt/data/nt_oracle_v2/selftest_out/fibonacci_d59a2333bd98.magma.txt`
- json_report: `/mnt/data/nt_oracle_v2/selftest_out/fibonacci_d59a2333bd98.oracle.report.json`
- markdown_report: `/mnt/data/nt_oracle_v2/selftest_out/fibonacci_d59a2333bd98.oracle.report.md`
- kbk_packet: `/mnt/data/nt_oracle_v2/selftest_out/fibonacci_d59a2333bd98.kbk.packet.json`

## Rule

Nothing here is a theorem until a proof exists. The workbench is allowed to be aggressive about discovery, and brutal about proof status.