# Oracle Number Theory Workbench V2

This is a finished computational discovery workbench for number theory. It does not pretend to prove what it has only measured. It mines structure, attacks the structure, emits proof obligations, then hands the surviving route to SageMath, PARI/GP, Lean, and Magma-style pseudocode.

## Core commands

```bash
python oracle_nt_workbench_v2.py selftest
```

```bash
python oracle_nt_workbench_v2.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --out out \
  --label fib \
  --round 1 \
  --binary "linear recurrence OR prefix artifact"
```

```bash
python oracle_nt_workbench_v2.py oracle-round \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --round 2 \
  --binary "true recurrence from object OR fitted recurrence artifact" \
  --out out
```

```bash
python oracle_nt_workbench_v2.py formula \
  --formula "n*n+n+1" \
  --terms 40 \
  --index-start 0 \
  --out out \
  --binary "polynomial law OR interpolation artifact"
```

```bash
python oracle_nt_workbench_v2.py crt-lab \
  --base1 2 \
  --base2 3 \
  --c 1 \
  --max-modulus 150
```

## What V2 adds

- Oracle round packet: one binary, verdict, route, next binary, missing variable, jigsaw status, attack surface, referee target.
- Defensive gates: input gate, overfit gate, fake-diversity warning, claim-separation gate.
- Stronger invariant mining: exact finite differences, rational interpolation, exact linear recurrences, rational generating functions, modular periodicity, local obstruction scan, divisibility and strong gcd law pressure, p-adic valuation profiles, smoothness, primitive prime divisor pressure, square-term Diophantine routing.
- Output handoffs: `.sage`, `.gp`, `.lean`, `.magma.txt`, JSON report, Markdown dossier, KBK packet.
- Online mode: OEIS JSON query plus LMFDB, arXiv, zbMATH, Scholar routing links.

## Philosophy

The machine is allowed to be aggressive in discovery and brutal in proof status. Every proposed claim is tagged as computational, classical, conditional, open, sieve-needed, or exact. No fake proof is emitted.
