#!/usr/bin/env python3
"""
oracle_nt_workbench_v2.py

A ruthless number theory discovery workbench.

This is the layer between raw intuition and formal proof:

    formal object -> hard computation -> invariant mining -> falsification
    -> literature/database routing -> proof obligations -> Sage/PARI/Lean handoff

The governing rule is simple: prose does not do math. Tools do math.

Round 2 upgrades over the first workbench
-----------------------------------------
1. Oracle loop state: one binary per round, KBK packet, jigsaw gate, GTH packet.
2. Defensive gates for number theory: input bounds, overfit pressure, fake diversity,
   circularity, literature quarantine, and fresh-term falsification.
3. Stronger invariant mining: exact recurrences, rational generating functions,
   p-adic/LTE signatures, strong divisibility, modular periods, polynomial bases,
   algebraic/norm heuristics, finite obstruction scans, CRT-cover toy lab.
4. External workbench handoffs: Sage, PARI/GP, Lean, Magma-style pseudocode, LMFDB/OEIS/arXiv links.
5. Reproducible dossiers: JSON, Markdown, conjecture cards, run manifest, and next-round packet.

Plain Python works. SymPy, SageMath, PARI/GP, and network access make it stronger.

Usage
-----
python oracle_nt_workbench_v2.py selftest
python oracle_nt_workbench_v2.py analyze-seq --seq "1,1,2,3,5,8,13,21,34,55" --out out --label fib
python oracle_nt_workbench_v2.py oracle-round --seq "1,1,2,3,5,8,13,21,34,55" --round 1 --binary "linear recurrence OR polynomial" --out out
python oracle_nt_workbench_v2.py formula --formula "n*n+n+1" --terms 30 --index-start 0 --out out

This file intentionally refuses fake proof. It emits claims as computational, conditional,
open, classical, or exact, and tells you what would actually close them.
"""

from __future__ import annotations

import argparse
import dataclasses
import fractions
import hashlib
import itertools
import json
import math
import os
import random
import re
import shutil
import statistics
import subprocess
import sys
import textwrap
import time
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import sympy as sp  # type: ignore
except Exception:  # pragma: no cover
    sp = None

Fraction = fractions.Fraction

VERSION = "2.0.0-oracle"

# ---------------------------------------------------------------------------
# Exact arithmetic core
# ---------------------------------------------------------------------------


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def parse_int_sequence(raw: str) -> List[int]:
    if not raw or not raw.strip():
        raise ValueError("Empty sequence")
    found = re.findall(r"[-+]?\d+", raw)
    if not found:
        raise ValueError("No integers found")
    return [int(x) for x in found]


def gcd_list(values: Iterable[int]) -> int:
    g = 0
    for v in values:
        g = math.gcd(g, abs(int(v)))
    return g


def lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return abs(a // math.gcd(a, b) * b)


def lcm_list(values: Iterable[int]) -> int:
    out = 1
    for v in values:
        out = lcm(out, int(v))
    return out


def differences(seq: Sequence[int], order: int = 1) -> List[int]:
    cur = [int(x) for x in seq]
    for _ in range(order):
        cur = [cur[i + 1] - cur[i] for i in range(len(cur) - 1)]
    return cur


def finite_difference_table(seq: Sequence[int], max_order: Optional[int] = None) -> List[List[int]]:
    if max_order is None:
        max_order = max(0, len(seq) - 1)
    table = [[int(x) for x in seq]]
    cur = list(table[0])
    for _ in range(max_order):
        if len(cur) <= 1:
            break
        cur = differences(cur)
        table.append(cur)
    return table


def is_square(n: int) -> bool:
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def valuation(n: int, p: int) -> Optional[int]:
    if p <= 1:
        raise ValueError("p must be greater than 1")
    if n == 0:
        return None
    n = abs(int(n))
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k


def primes_upto(n: int) -> List[int]:
    if n < 2:
        return []
    sieve = bytearray(b"\x01") * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for p in range(2, math.isqrt(n) + 1):
        if sieve[p]:
            start = p * p
            sieve[start:n + 1:p] = b"\x00" * (((n - start) // p) + 1)
    return [i for i in range(n + 1) if sieve[i]]


def trial_factor(n: int) -> Dict[int, int]:
    n = int(n)
    if n == 0:
        return {0: 1}
    out: Dict[int, int] = {}
    if n < 0:
        out[-1] = 1
        n = -n
    if n == 1:
        return out
    if sp is not None:
        try:
            return {**out, **{int(k): int(v) for k, v in sp.factorint(n).items()}}
        except Exception:
            pass
    while n % 2 == 0:
        out[2] = out.get(2, 0) + 1
        n //= 2
    d = 3
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def modular_period(seq: Sequence[int], modulus: int, max_period: Optional[int] = None) -> Optional[int]:
    if modulus <= 1 or len(seq) < 2:
        return None
    residues = [int(x) % modulus for x in seq]
    n = len(residues)
    if max_period is None:
        max_period = max(1, n // 2)
    for p in range(1, max_period + 1):
        if all(residues[i] == residues[i + p] for i in range(n - p)):
            return p
    return None


def solve_linear_fraction(A: List[List[Fraction]], b: List[Fraction]) -> Optional[List[Fraction]]:
    n = len(A)
    if n == 0 or len(b) != n or any(len(r) != n for r in A):
        return None
    M = [list(A[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            return None
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r == col:
                continue
            f = M[r][col]
            if f != 0:
                M[r] = [M[r][c] - f * M[col][c] for c in range(n + 1)]
    return [M[i][-1] for i in range(n)]


def frac_str(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f"{x.numerator}/{x.denominator}"


def rational_ratios(seq: Sequence[int], limit: int = 16) -> List[Optional[str]]:
    out: List[Optional[str]] = []
    for a, b in zip(seq[1:], seq[:-1]):
        out.append(None if b == 0 else frac_str(Fraction(a, b)))
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


@dataclass(order=True)
class Hypothesis:
    sort_index: float = field(init=False, repr=False)
    score: float
    title: str
    claim: str
    evidence: List[str] = field(default_factory=list)
    falsifiers: List[str] = field(default_factory=list)
    proof_obligations: List[str] = field(default_factory=list)
    next_computations: List[str] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)
    claim_class: str = "COMP"
    risk_flags: List[str] = field(default_factory=list)
    source: str = "workbench"

    def __post_init__(self) -> None:
        self.sort_index = -float(self.score)

    @property
    def confidence(self) -> str:
        if self.score >= 0.86 and not self.risk_flags:
            return "high-computational"
        if self.score >= 0.68:
            return "medium-computational"
        return "low"

    def to_dict(self) -> Dict[str, Any]:
        d = dataclasses.asdict(self)
        d.pop("sort_index", None)
        d["confidence"] = self.confidence
        return d


@dataclass
class AuditFinding:
    gate: str
    verdict: str
    detail: str
    blocking: bool = False
    measurement: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


@dataclass
class ToolStatus:
    name: str
    available: bool
    path: Optional[str] = None
    detail: Optional[str] = None


@dataclass
class OraclePacket:
    round_number: int
    prior_verdict: str
    one_binary: str
    verdict: str
    route: str
    next_binary: str
    missing_variable: str
    jigsaw_visible: bool
    jigsaw_sentence: str
    gth_claim: Optional[str]
    attack_surface: str
    referee_target: str

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)


# ---------------------------------------------------------------------------
# External adapters
# ---------------------------------------------------------------------------


class ExternalTools:
    def __init__(self, timeout_seconds: int = 20) -> None:
        self.timeout_seconds = timeout_seconds
        self._status: Optional[Dict[str, ToolStatus]] = None

    def status(self) -> Dict[str, ToolStatus]:
        if self._status is not None:
            return self._status
        out: Dict[str, ToolStatus] = {}
        for exe in ["sage", "gp", "lean"]:
            p = shutil.which(exe)
            out[exe] = ToolStatus(exe, p is not None, p)
        out["sympy"] = ToolStatus("sympy", sp is not None, None, getattr(sp, "__version__", None) if sp else None)
        try:
            import cypari2  # type: ignore
            out["cypari2"] = ToolStatus("cypari2", True, None, getattr(cypari2, "__version__", None))
        except Exception as exc:
            out["cypari2"] = ToolStatus("cypari2", False, None, str(exc))
        self._status = out
        return out

    def run_gp(self, code: str) -> Dict[str, Any]:
        st = self.status().get("gp")
        if not st or not st.available:
            return {"ok": False, "error": "gp executable not found"}
        try:
            proc = subprocess.run([st.path or "gp", "-q"], input=code + "\n\\q\n", text=True,
                                  capture_output=True, timeout=self.timeout_seconds)
            return {"ok": proc.returncode == 0, "stdout": proc.stdout.strip(), "stderr": proc.stderr.strip(), "returncode": proc.returncode}
        except Exception as exc:
            return {"ok": False, "error": repr(exc)}

    def run_sage(self, code: str) -> Dict[str, Any]:
        st = self.status().get("sage")
        if not st or not st.available:
            return {"ok": False, "error": "sage executable not found"}
        try:
            proc = subprocess.run([st.path or "sage", "-c", code], text=True,
                                  capture_output=True, timeout=self.timeout_seconds)
            return {"ok": proc.returncode == 0, "stdout": proc.stdout.strip(), "stderr": proc.stderr.strip(), "returncode": proc.returncode}
        except Exception as exc:
            return {"ok": False, "error": repr(exc)}


class WebClient:
    def __init__(self, timeout_seconds: int = 15) -> None:
        self.timeout_seconds = timeout_seconds

    def json(self, url: str) -> Dict[str, Any]:
        req = urllib.request.Request(url, headers={"User-Agent": f"oracle-nt-workbench/{VERSION}"})
        with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))


class KnowledgeLinks:
    @staticmethod
    def oeis_url(seq: Sequence[int]) -> str:
        q = ",".join(str(int(x)) for x in seq[:16])
        return "https://oeis.org/search?" + urllib.parse.urlencode({"q": q, "fmt": "json"})

    @staticmethod
    def lmfdb_urls(seq: Sequence[int], keywords: Optional[List[str]] = None) -> List[Dict[str, str]]:
        q = ",".join(str(int(x)) for x in seq[:10])
        k = " ".join(keywords or [])
        return [
            {"label": "LMFDB global search", "url": "https://www.lmfdb.org/search/?q=" + urllib.parse.quote((q + " " + k).strip())},
            {"label": "LMFDB elliptic curves", "url": "https://www.lmfdb.org/EllipticCurve/Q/"},
            {"label": "LMFDB number fields", "url": "https://www.lmfdb.org/NumberField/"},
            {"label": "LMFDB modular forms", "url": "https://www.lmfdb.org/ModularForm/"},
            {"label": "LMFDB L-functions", "url": "https://www.lmfdb.org/L/"},
        ]

    @staticmethod
    def literature_urls(seq: Sequence[int], keywords: Optional[List[str]] = None) -> List[Dict[str, str]]:
        q = ",".join(str(int(x)) for x in seq[:12])
        k = " ".join(keywords or [])
        query = (f'"{q}" {k}').strip()
        return [
            {"label": "arXiv", "url": "https://arxiv.org/search/?" + urllib.parse.urlencode({"query": query, "searchtype": "all"})},
            {"label": "zbMATH", "url": "https://zbmath.org/?" + urllib.parse.urlencode({"q": query})},
            {"label": "Google Scholar", "url": "https://scholar.google.com/scholar?" + urllib.parse.urlencode({"q": query})},
            {"label": "MathSciNet", "url": "https://mathscinet.ams.org/mathscinet"},
        ]


# ---------------------------------------------------------------------------
# Defensive gates adapted for number theory discovery
# ---------------------------------------------------------------------------


class NTAudit:
    @staticmethod
    def input_gate(seq: Sequence[int]) -> List[AuditFinding]:
        findings: List[AuditFinding] = []
        if len(seq) < 3:
            findings.append(AuditFinding("NT-BR-input", "REJECT", "Need at least 3 terms", True))
        if len(seq) != len([int(x) for x in seq]):
            findings.append(AuditFinding("NT-BR-input", "REJECT", "Non-integer term found", True))
        max_bits = max((abs(int(x)).bit_length() for x in seq), default=0)
        if max_bits > 100000:
            findings.append(AuditFinding("NT-BR-input", "REVIEW", f"Very large terms, max bits {max_bits}. External PARI/Sage recommended", False))
        if len(set(seq)) == 1:
            findings.append(AuditFinding("NT-BR-input", "REVIEW", "Constant sequence, many detectors will be degenerate", False))
        if not findings:
            findings.append(AuditFinding("NT-BR-input", "PASS", "Integer sequence passed basic substrate bounds", False,
                                         {"n_terms": len(seq), "max_bits": max_bits}))
        return findings

    @staticmethod
    def overfit_gate(seq: Sequence[int], hyps: Sequence[Hypothesis]) -> List[AuditFinding]:
        findings: List[AuditFinding] = []
        n = len(seq)
        for h in hyps[:12]:
            if "interpolation" in h.tags and n < 20:
                findings.append(AuditFinding("ZENITH-overfit", "FLAG", f"{h.title}: interpolation is not evidence without fresh terms", False))
            if h.score > 0.8 and len(h.evidence) <= 1:
                findings.append(AuditFinding("ZENITH-fake-diversity", "FLAG", f"{h.title}: high score rests on thin evidence", False))
        if not findings:
            findings.append(AuditFinding("ZENITH-overfit", "PASS", "No obvious high-risk overfit flags in top hypotheses", False))
        return findings

    @staticmethod
    def output_gate(hyps: Sequence[Hypothesis]) -> List[AuditFinding]:
        bad = []
        for h in hyps[:10]:
            if h.claim_class not in {"E", "C", "S", "COND", "OPEN", "COMP"}:
                bad.append(h.title)
        if bad:
            return [AuditFinding("CLAIM-SEP", "REJECT", "Invalid claim class on: " + ", ".join(bad), True)]
        return [AuditFinding("CLAIM-SEP", "PASS", "Every top claim is tagged with a proof-status class", False)]


# ---------------------------------------------------------------------------
# Discovery engines
# ---------------------------------------------------------------------------


class SequenceLab:
    def __init__(self, seq: Sequence[int], index_start: int = 0) -> None:
        self.seq = [int(x) for x in seq]
        self.index_start = int(index_start)
        self.n = len(self.seq)
        if self.n < 3:
            raise ValueError("Need at least 3 terms")

    def summary(self) -> Dict[str, Any]:
        seq = self.seq
        return {
            "version": VERSION,
            "length": len(seq),
            "index_start": self.index_start,
            "first_terms": seq[:30],
            "last_terms": seq[-10:],
            "min": min(seq),
            "max": max(seq),
            "max_abs_bits": max(abs(x).bit_length() for x in seq),
            "gcd_terms": gcd_list(seq),
            "gcd_first_differences": gcd_list(differences(seq)) if len(seq) > 1 else None,
            "monotone_non_decreasing": all(seq[i] <= seq[i + 1] for i in range(len(seq) - 1)),
            "monotone_increasing": all(seq[i] < seq[i + 1] for i in range(len(seq) - 1)),
            "sign_profile": dict(Counter("zero" if x == 0 else "positive" if x > 0 else "negative" for x in seq)),
            "tail_ratios": rational_ratios(seq[-10:]),
        }

    def transforms(self) -> Dict[str, Any]:
        seq = self.seq
        return {
            "finite_differences": finite_difference_table(seq, min(10, len(seq) - 1)),
            "visible_periods_mod_2_to_64": {str(m): modular_period(seq, m) for m in range(2, 65)},
            "residue_profiles_mod_2_to_16": {str(m): [x % m for x in seq[:50]] for m in range(2, 17)},
            "valuation_profiles_p_le_31": {str(p): [valuation(x, p) for x in seq[:50]] for p in primes_upto(31)},
            "factorizations_first_30": [
                {"n": self.index_start + i, "a_n": x, "factorization": trial_factor(x)}
                for i, x in enumerate(seq[:30])
            ],
        }

    def polynomial_mining(self) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        table = finite_difference_table(self.seq)
        for order, row in enumerate(table[1:], start=1):
            if row and len(set(row)) == 1:
                c = row[0]
                hyps.append(Hypothesis(
                    score=min(0.97, 0.60 + 0.025 * len(row)),
                    title=f"Exact finite-difference polynomial, degree {order}",
                    claim=f"The observed prefix is generated by a degree {order} polynomial in n; the {order}th finite difference is constant {c}.",
                    evidence=[f"Finite difference row {order} is constant for {len(row)} consecutive positions."],
                    falsifiers=["Acquire terms beyond the interpolation window and verify the same finite-difference row remains constant."],
                    proof_obligations=["Write the polynomial in binomial basis and prove the finite-difference identity by induction."],
                    next_computations=["Use generated Sage file to express the interpolant in binomial basis."],
                    tags=["polynomial", "finite-difference"],
                    claim_class="COMP",
                ))
                break
        if sp is not None and len(self.seq) >= 4:
            try:
                n = sp.Symbol("n")
                pts = [(self.index_start + i, v) for i, v in enumerate(self.seq)]
                poly = sp.interpolate(pts, n)
                deg = int(sp.degree(poly, n))
                if 0 <= deg <= min(10, len(self.seq) - 2):
                    # Newton/binomial basis coefficients are finite differences at first index.
                    diffs = [finite_difference_table(self.seq, deg)[k][0] for k in range(deg + 1)]
                    hyps.append(Hypothesis(
                        score=max(0.35, min(0.88, 0.76 - 0.025 * deg + 0.005 * len(self.seq))),
                        title="Exact rational interpolation with binomial basis handle",
                        claim=f"Interpolant over Q has degree {deg}: {sp.factor(poly)}",
                        evidence=["SymPy exact interpolation succeeded.", f"Newton forward coefficients begin {diffs[:8]}"],
                        falsifiers=["Interpolation alone is weak. Demand independent source terms not used in fitting."],
                        proof_obligations=["Derive the counting identity or recurrence that forces this polynomial, not just interpolation."],
                        next_computations=["Test binomial-basis integrality and finite-difference stability at fresh indices."],
                        tags=["interpolation", "polynomial", "weak-unless-validated"],
                        risk_flags=["finite-data-overfit"],
                        claim_class="COMP",
                    ))
            except Exception:
                pass
        return hyps

    def recurrence_mining(self, max_order: int = 12) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        seq = [Fraction(x) for x in self.seq]
        max_order = min(max_order, max(1, len(seq) // 2))
        for k in range(1, max_order + 1):
            coeffs = self._fit_linear_recurrence(seq, k)
            if coeffs is None:
                continue
            ok = 0
            for i in range(k, len(seq)):
                pred = sum(coeffs[j] * seq[i - j - 1] for j in range(k))
                if pred == seq[i]:
                    ok += 1
                else:
                    break
            if ok == len(seq) - k:
                claim = "a(n) = " + " + ".join(f"({frac_str(coeffs[j])})*a(n-{j+1})" for j in range(k))
                den = [c.denominator for c in coeffs]
                char = self._characteristic_polynomial_string(coeffs)
                hyps.append(Hypothesis(
                    score=min(0.95, 0.54 + 0.035 * ok - 0.018 * k),
                    title=f"Exact linear recurrence, order {k}",
                    claim=claim,
                    evidence=[f"Solved over Q and predicted {ok}/{len(seq)-k} in-prefix terms exactly.", f"Characteristic polynomial: {char}", f"Coefficient denominator lcm: {lcm_list(den)}"],
                    falsifiers=["Generate independent fresh terms and check all recurrence predictions.", "Check for shorter inhomogeneous or polynomial recurrence masquerading as homogeneous."],
                    proof_obligations=["Prove the recurrence and initial conditions. Then formal proof is induction."],
                    next_computations=["Factor characteristic polynomial in Sage/PARI; inspect roots, Galois/norm signatures, and modular reductions."],
                    tags=["linear-recurrence", "generating-function", "exact"],
                    claim_class="COMP",
                ))
                gf = self._generating_function_from_recurrence(coeffs)
                if gf:
                    hyps.append(Hypothesis(
                        score=min(0.91, 0.49 + 0.033 * ok - 0.02 * k),
                        title=f"Rational generating function candidate, denominator degree {k}",
                        claim=gf,
                        evidence=["Derived exactly from the fitted recurrence and observed initial terms."],
                        falsifiers=["A rational generating function candidate is only real after fresh-term verification or derivation from the object."],
                        proof_obligations=["Prove Q(x)A(x)=P(x), then extract recurrence coefficients."],
                        next_computations=["Use Sage to factor Q(x) and test partial fractions / closed form."],
                        tags=["generating-function", "linear-recurrence"],
                        claim_class="COMP",
                    ))
                break
        return hyps

    @staticmethod
    def _fit_linear_recurrence(seq: Sequence[Fraction], order: int) -> Optional[List[Fraction]]:
        rows: List[List[Fraction]] = []
        rhs: List[Fraction] = []
        for i in range(order, len(seq)):
            rows.append([seq[i - j - 1] for j in range(order)])
            rhs.append(seq[i])
        if len(rows) < order:
            return None
        # try early square systems first, then deterministic random-like combinations
        combos = list(itertools.combinations(range(min(len(rows), order + 5)), order))
        if len(rows) > order + 5:
            combos += list(itertools.combinations(range(len(rows) - order, len(rows)), order))[:10]
        for idxs in combos[:300]:
            A = [[rows[i][j] for j in range(order)] for i in idxs]
            b = [rhs[i] for i in idxs]
            sol = solve_linear_fraction(A, b)
            if sol is None:
                continue
            if all(sum(sol[j] * row[j] for j in range(order)) == y for row, y in zip(rows, rhs)):
                return sol
        return None

    @staticmethod
    def _characteristic_polynomial_string(coeffs: Sequence[Fraction]) -> str:
        k = len(coeffs)
        pieces = [f"t^{k}"]
        for j, c in enumerate(coeffs):
            power = k - j - 1
            sign = "-" if c >= 0 else "+"
            mag = abs(c)
            term = frac_str(mag)
            if power > 1:
                pieces.append(f" {sign} {term}*t^{power}")
            elif power == 1:
                pieces.append(f" {sign} {term}*t")
            else:
                pieces.append(f" {sign} {term}")
        return "".join(pieces)

    def _generating_function_from_recurrence(self, coeffs: Sequence[Fraction]) -> Optional[str]:
        # Denominator Q(x)=1-c1*x-...-ck*x^k. Numerator computed up to k-1.
        k = len(coeffs)
        a = [Fraction(x) for x in self.seq[:k]]
        p_coeff: List[Fraction] = []
        for n in range(k):
            val = a[n]
            for j in range(1, min(n, k) + 1):
                val -= coeffs[j - 1] * a[n - j]
            p_coeff.append(val)
        P = " + ".join(f"({frac_str(c)})*x^{i}" if i else f"({frac_str(c)})" for i, c in enumerate(p_coeff) if c != 0) or "0"
        Q = "1" + "".join(f" - ({frac_str(c)})*x^{i}" for i, c in enumerate(coeffs, start=1) if c != 0)
        return f"A(x)=({P})/({Q})"

    def modular_mining(self) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        periods = []
        for m in range(2, 97):
            p = modular_period(self.seq, m)
            if p is not None and p <= max(24, len(self.seq) // 2):
                periods.append((m, p))
        if periods:
            repeated = [f"mod {m}: period {p}" for m, p in periods[:30]]
            hyps.append(Hypothesis(
                score=min(0.82, 0.30 + 0.018 * len(periods)),
                title="Modular finite-state structure",
                claim="The observed prefix has small visible periods modulo many small moduli.",
                evidence=repeated,
                falsifiers=["Extend the prefix. A visible period must survive beyond two full cycles.", "For recurrence sequences, prove periodicity modulo m from finite state space."],
                proof_obligations=["Prove a finite-state transition or recurrence modulo each modulus; then lift using CRT if needed."],
                next_computations=["Run Sage/PARI on larger moduli and compute period growth p^e."],
                tags=["modular", "automatic", "finite-state"],
                claim_class="COMP",
            ))
        obstruction = self.local_obstruction_scan()
        if obstruction["hit_moduli"]:
            hyps.append(Hypothesis(
                score=min(0.84, 0.38 + 0.04 * len(obstruction["hit_moduli"])),
                title="Local obstruction candidate",
                claim="The prefix avoids at least one residue class pattern that may represent a modular obstruction.",
                evidence=[json.dumps(obstruction, default=str)[:1800]],
                falsifiers=["Check whether missing residues are forced by the definition or just by prefix size."],
                proof_obligations=["Prove the forbidden residue set modulo m for the actual formula or recurrence."],
                next_computations=["If studying prime/composite forcing, use CRT-cover lab and PARI primality checks."],
                tags=["local-obstruction", "modular"],
                claim_class="COMP",
            ))
        return hyps

    def local_obstruction_scan(self) -> Dict[str, Any]:
        hit = []
        for m in range(2, 61):
            residues = {x % m for x in self.seq}
            missing = sorted(set(range(m)) - residues)
            if 0 < len(missing) <= max(3, m // 5) and len(self.seq) >= min(m, 20):
                hit.append({"modulus": m, "seen": len(residues), "missing": missing[:20]})
        return {"hit_moduli": hit[:20]}

    def divisibility_mining(self) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        seq = self.seq
        for start in [0, 1]:
            total = 0
            div_pass = 0
            gcd_pass = 0
            failures = []
            for i in range(1, len(seq) + 1):
                ai = seq[i - 1]
                if ai == 0:
                    continue
                for j in range(i * 2, len(seq) + 1, i):
                    aj = seq[j - 1]
                    total += 1
                    if aj % ai == 0:
                        div_pass += 1
                    elif len(failures) < 6:
                        failures.append((i + start, j + start, ai, aj))
            for i in range(1, len(seq) + 1):
                for j in range(1, len(seq) + 1):
                    if seq[i - 1] == 0 or seq[j - 1] == 0:
                        continue
                    gidx = math.gcd(i, j)
                    if 1 <= gidx <= len(seq) and math.gcd(abs(seq[i - 1]), abs(seq[j - 1])) == abs(seq[gidx - 1]):
                        gcd_pass += 1
            if total >= 4 and div_pass == total:
                hyps.append(Hypothesis(
                    score=min(0.90, 0.50 + 0.025 * total),
                    title="Divisibility sequence candidate",
                    claim="Observed i|j implies a_i|a_j across all checked pairs.",
                    evidence=[f"Passed {div_pass}/{total} divisibility checks with index offset hypothesis {start}."],
                    falsifiers=["Check fresh terms and zero/unit artifacts. Test strong gcd law separately."],
                    proof_obligations=["Prove divisibility from recurrence, algebraic group law, or formal group valuation."],
                    next_computations=["Search Lucas, Lehmer, elliptic divisibility, and Somos signatures."],
                    tags=["divisibility", "lucas", "elliptic-divisibility"],
                    claim_class="COMP",
                ))
            if gcd_pass >= max(12, len(seq)):
                hyps.append(Hypothesis(
                    score=min(0.78, 0.28 + 0.005 * gcd_pass),
                    title="Strong gcd-law pressure",
                    claim="Many checked pairs satisfy gcd(a_i,a_j)=a_gcd(i,j), suggesting a strong divisibility law.",
                    evidence=[f"Strong gcd equality held in {gcd_pass} checked ordered pairs."],
                    falsifiers=["Audit indexing, signs, and unit factors. Require fresh terms."],
                    proof_obligations=["Prove strong divisibility or identify the precise unit correction."],
                    next_computations=["Run a Lucas/EDS classifier and factor primitive parts."],
                    tags=["strong-divisibility", "gcd-law"],
                    claim_class="COMP",
                ))
        return hyps

    def factor_and_valuation_mining(self) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        seq = self.seq
        fact_rows = [(self.index_start + i, x, trial_factor(x)) for i, x in enumerate(seq[:40])]
        smooth = []
        square = []
        prime = []
        primitive_prime_hits = []
        prior_primes: set[int] = set()
        for n, x, fx in fact_rows:
            primes = [abs(p) for p in fx if abs(p) > 1]
            if primes and max(primes) <= 17:
                smooth.append((n, x, fx))
            if is_square(x):
                square.append((n, x))
            if sp is not None and x > 1:
                try:
                    if bool(sp.isprime(x)):
                        prime.append((n, x))
                except Exception:
                    pass
            newp = [p for p in primes if p not in prior_primes]
            if newp:
                primitive_prime_hits.append((n, sorted(newp)[:5]))
            prior_primes.update(primes)
        if len(smooth) >= max(4, len(fact_rows) // 4):
            hyps.append(Hypothesis(
                score=min(0.75, 0.30 + 0.025 * len(smooth)),
                title="Smoothness cluster",
                claim="A large fraction of early terms factor over very small primes.",
                evidence=[str(x) for x in smooth[:12]],
                falsifiers=["Factor later terms. Smooth prefixes are a classic trap."],
                proof_obligations=["Derive product/binomial/factorial structure or prove bounded prime support."],
                next_computations=["Use PARI factorint at later indices and compare largest prime factor growth."],
                tags=["factorization", "smoothness"],
                risk_flags=["prefix-bias"],
                claim_class="COMP",
            ))
        if len(square) >= 3:
            hyps.append(Hypothesis(
                score=min(0.70, 0.30 + 0.04 * len(square)),
                title="Repeated square terms",
                claim="Perfect-square terms recur in the prefix, hinting at quadratic form, norm, Pell, or elliptic structure.",
                evidence=[str(x) for x in square[:15]],
                falsifiers=["Test whether square positions obey a law rather than early small-number coincidence."],
                proof_obligations=["Reduce square-term condition to a Diophantine equation and classify solutions."],
                next_computations=["Generate Pell/elliptic curve handoff and search LMFDB."],
                tags=["squares", "diophantine", "norm"],
                claim_class="COMP",
            ))
        if len(prime) >= 3:
            hyps.append(Hypothesis(
                score=min(0.66, 0.22 + 0.035 * len(prime)),
                title="Prime-rich prefix",
                claim="Multiple observed terms are prime.",
                evidence=[str(x) for x in prime[:15]],
                falsifiers=["Prime-producing prefixes are not theorems. Extend terms and compare density to random controls of same size."],
                proof_obligations=["State primality pattern as OPEN unless a classical theorem applies."],
                next_computations=["Run PARI isprime/ispseudoprime at larger generated indices."],
                tags=["primality", "open-risk"],
                claim_class="OPEN",
                risk_flags=["bunyakovsky-risk"],
            ))
        val_patterns = []
        for p in primes_upto(43):
            vals = [valuation(x, p) for x in seq[:60]]
            finite = [v for v in vals if v is not None]
            if finite and max(finite) >= 2:
                # Compare with v_p(n) shape for LTE pressure.
                idx_vals = [valuation(self.index_start + i, p) if (self.index_start + i) != 0 else None for i in range(len(vals))]
                matches = sum(1 for a, b in zip(vals, idx_vals) if a == b and a is not None)
                val_patterns.append({"p": p, "max_v": max(finite), "prefix": vals[:20], "matches_vp_index": matches})
        if val_patterns:
            hyps.append(Hypothesis(
                score=min(0.78, 0.32 + 0.025 * len(val_patterns)),
                title="p-adic valuation law candidate",
                claim="Prime-adic valuations show repeated structure worth testing against LTE, Lucas, or formal-group laws.",
                evidence=[json.dumps(v) for v in val_patterns[:12]],
                falsifiers=["Compare against v_p(n), v_p(n+c), and recurrence-specific LTE predictions on fresh terms."],
                proof_obligations=["Identify and prove the exact valuation formula."],
                next_computations=["Use PARI to compute valuations farther out and regress v_p(a_n) against v_p(index shifts)."],
                tags=["p-adic", "valuation", "LTE"],
                claim_class="COMP",
            ))
        if len(primitive_prime_hits) >= 5:
            hyps.append(Hypothesis(
                score=min(0.72, 0.25 + 0.02 * len(primitive_prime_hits)),
                title="Primitive prime divisor pressure",
                claim="New prime divisors appear repeatedly, suggesting Zsigmondy/Lucas/EDS style structure or its failure boundary.",
                evidence=[str(x) for x in primitive_prime_hits[:15]],
                falsifiers=["Check primitive part after removing earlier prime support, and compare to known Zsigmondy exceptions."],
                proof_obligations=["Connect the sequence to a setting with a primitive divisor theorem or isolate exceptions."],
                next_computations=["Compute primitive parts in PARI and search literature for matching primitive divisor theorem."],
                tags=["primitive-divisors", "zsigmondy"],
                claim_class="C",
            ))
        return hyps

    def crt_cover_lab(self, bases: Sequence[int] = (2, 3), c: int = 1, max_modulus: int = 80, k_range: int = 12, l_range: int = 12) -> Dict[str, Any]:
        """Toy CRT cover pressure lab for expressions b1^k b2^l + c modulo q.
        This does not prove covering. It identifies candidate obstruction moduli.
        """
        b1, b2 = int(bases[0]), int(bases[1])
        hits = []
        grid = [(k, l) for k in range(k_range) for l in range(l_range)]
        for q in range(2, max_modulus + 1):
            residues = {(pow(b1, k, q) * pow(b2, l, q) + c) % q for k, l in grid}
            zero_hit = 0 in residues
            density = len(residues) / q
            if zero_hit or density < 0.5:
                hits.append({"q": q, "zero_hit": zero_hit, "residue_density": round(density, 4), "n_residues": len(residues)})
        return {"expression": f"{b1}^k*{b2}^l+{c}", "grid": [k_range, l_range], "hits": hits[:50]}

    def all_hypotheses(self) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        hyps.extend(self.polynomial_mining())
        hyps.extend(self.recurrence_mining())
        hyps.extend(self.modular_mining())
        hyps.extend(self.divisibility_mining())
        hyps.extend(self.factor_and_valuation_mining())
        hyps.sort()
        return hyps


# ---------------------------------------------------------------------------
# Oracle controller
# ---------------------------------------------------------------------------


class OracleController:
    def __init__(self, seq: Sequence[int], hypotheses: Sequence[Hypothesis], audits: Sequence[AuditFinding], round_number: int, binary: str, prior: str = "N/A") -> None:
        self.seq = [int(x) for x in seq]
        self.hyps = list(hypotheses)
        self.audits = list(audits)
        self.round_number = round_number
        self.binary = binary.strip() or "structure exists OR prefix artifact"
        self.prior = prior

    def decide(self) -> OraclePacket:
        blocking = [a for a in self.audits if a.blocking]
        top = self.hyps[0] if self.hyps else None
        if blocking:
            verdict = "KILL"
            route = "Fix blocking audit before claiming any invariant."
            next_binary = "audit artifact OR real structure after repair"
            missing = blocking[0].gate
            visible = False
            sentence = "No picture yet because a blocking audit fired."
            gth = None
            attack = blocking[0].detail
            referee = "Repair the substrate or computation and rerun the same binary."
        elif top is None:
            verdict = "ESCALATION"
            route = "No strong invariant emerged from current coordinates."
            next_binary = "wrong coordinates OR insufficient terms"
            missing = "more terms or formal definition"
            visible = False
            sentence = "No picture yet."
            gth = None
            attack = "The input prefix may be too short or in the wrong coordinates."
            referee = "Acquire a definition or fresh terms, then rerun exact probes."
        else:
            strong = top.score >= 0.82 and len(top.evidence) >= 2 and "finite-data-overfit" not in top.risk_flags
            medium = top.score >= 0.65
            if strong:
                verdict = "CLOSURE" if self.round_number >= 5 else "ESCALATION"
                route = top.title
                next_binary = self._next_binary_from_top(top)
                missing = self._missing_variable(top)
                visible = True
                sentence = f"The visible picture is {top.title}: {top.claim}"
                gth = None
                if self.round_number >= 5:
                    gth = top.claim
                attack = self._attack_surface(top)
                referee = self._referee_target(top)
            elif medium:
                verdict = "ESCALATION"
                route = top.title
                next_binary = self._next_binary_from_top(top)
                missing = self._missing_variable(top)
                visible = False
                sentence = "The picture is forming but not yet decisive."
                gth = None
                attack = self._attack_surface(top)
                referee = self._referee_target(top)
            else:
                verdict = "ESCALATION"
                route = "Weak signal only."
                next_binary = "extend terms OR change coordinates"
                missing = "fresh terms"
                visible = False
                sentence = "No decisive picture yet."
                gth = None
                attack = "Low score and weak independent evidence."
                referee = "Obtain independent terms or a formal definition."
        return OraclePacket(
            round_number=self.round_number,
            prior_verdict=self.prior,
            one_binary=self.binary,
            verdict=verdict,
            route=route,
            next_binary=next_binary,
            missing_variable=missing,
            jigsaw_visible=visible,
            jigsaw_sentence=sentence,
            gth_claim=gth,
            attack_surface=attack,
            referee_target=referee,
        )

    @staticmethod
    def _next_binary_from_top(h: Hypothesis) -> str:
        if "linear-recurrence" in h.tags:
            return "true recurrence from object OR fitted recurrence artifact"
        if "polynomial" in h.tags:
            return "finite-difference law from object OR interpolation artifact"
        if "p-adic" in h.tags:
            return "LTE/formal-group valuation law OR prefix coincidence"
        if "modular" in h.tags:
            return "finite-state modular law OR short-prefix residue artifact"
        if "divisibility" in h.tags:
            return "algebraic divisibility law OR index/unit artifact"
        return "structural invariant OR prefix artifact"

    @staticmethod
    def _missing_variable(h: Hypothesis) -> str:
        if h.next_computations:
            return h.next_computations[0]
        return "fresh independent terms"

    @staticmethod
    def _attack_surface(h: Hypothesis) -> str:
        if h.falsifiers:
            return h.falsifiers[0]
        return "fresh-term falsification"

    @staticmethod
    def _referee_target(h: Hypothesis) -> str:
        if h.proof_obligations:
            return h.proof_obligations[0]
        return "formal derivation from the original object"


# ---------------------------------------------------------------------------
# Handoff generation
# ---------------------------------------------------------------------------


def generate_sage_script(seq: Sequence[int], index_start: int, top_hyps: Sequence[Hypothesis]) -> str:
    terms = ", ".join(str(int(x)) for x in seq)
    notes = "\n".join(f"# {i+1}. {h.title}: {h.claim}" for i, h in enumerate(top_hyps[:8]))
    return f'''# Auto-generated by oracle_nt_workbench_v2.py
# Purpose: exact SageMath verification and next-term attack.

from sage.all import *

seq = [{terms}]
index_start = {index_start}

print("n_terms", len(seq))
print("gcd_terms", gcd(seq))
print("first_terms", seq[:20])

# Candidate hypotheses from Python layer:
{notes}

# Finite differences
cur = list(seq)
for order in range(min(12, len(seq)-1)):
    print("diff_order", order, cur[:20])
    cur = [cur[i+1]-cur[i] for i in range(len(cur)-1)]

# Exact interpolation in polynomial ring
R = PolynomialRing(QQ, 'n')
n = R.gen()
pts = [(index_start+i, QQ(seq[i])) for i in range(len(seq))]
try:
    poly = R.lagrange_polynomial(pts)
    print("interpolating_degree", poly.degree())
    print("interpolating_poly", factor(poly))
except Exception as e:
    print("interpolation_failed", repr(e))

# Linear recurrence discovery using Berlekamp-Massey over QQ if available
try:
    from sage.matrix.berlekamp_massey import berlekamp_massey
    print("berlekamp_massey", berlekamp_massey([QQ(x) for x in seq]))
except Exception as e:
    print("berlekamp_massey_unavailable", repr(e))

# Modular periods
for m in range(2, 80):
    residues = [x % m for x in seq]
    for p in range(1, max(2, len(residues)//2)+1):
        if all(residues[i] == residues[i+p] for i in range(len(residues)-p)):
            print("period", m, p)
            break
'''


def generate_gp_script(seq: Sequence[int], top_hyps: Sequence[Hypothesis]) -> str:
    terms = ",".join(str(int(x)) for x in seq)
    notes = "\n".join(f"\\ {i+1}. {h.title}: {h.claim}" for i, h in enumerate(top_hyps[:8]))
    return f'''\\ Auto-generated by oracle_nt_workbench_v2.py
\\ Purpose: PARI/GP factorization, valuations, linear recurrence pressure.

seq = [{terms}];
print("n_terms=" Str(#seq));
print("first_terms=" Str(vector(min(#seq,20), i, seq[i])));

\\ Candidate hypotheses
{notes}

for(i=1, min(#seq, 40),
  print("factor[" Str(i) "]=" Str(factor(seq[i])));
);

for(p=[2,3,5,7,11,13,17,19,23,29,31],
  print("valuation_p=" Str(p) " " Str(vector(min(#seq,40), i, if(seq[i]==0, -1, valuation(seq[i],p)))));
);

\\ Modular period scan
for(m=2,80,
  for(per=1, max(1, #seq\\2),
    ok=1;
    for(i=1, #seq-per, if((seq[i]-seq[i+per])%m != 0, ok=0; break));
    if(ok, print("period " Str(m) " " Str(per)); break);
  );
);
'''


def generate_lean_skeleton(seq: Sequence[int], hyps: Sequence[Hypothesis]) -> str:
    terms = ", ".join(str(int(x)) for x in seq[:40])
    cards = "\n\n".join(
        f"/-\nCandidate {i+1}: {h.title}\nClaim class: {h.claim_class}\nClaim: {h.claim}\nProof obligations: {'; '.join(h.proof_obligations)}\nFalsifier: {'; '.join(h.falsifiers)}\n-/"
        for i, h in enumerate(hyps[:8])
    )
    return f'''import Mathlib

/-
Auto-generated by oracle_nt_workbench_v2.py.
No fake proof. This file is a formalization landing zone only.
Observed prefix: [{terms}]
-/

{cards}

namespace OracleNT

-- Replace with the real definition once the invariant survives fresh-term checks.
def a : Nat -> Int := fun _ => 0

-- Placeholder theorem. Do not strengthen until the computation and literature checks survive.
theorem placeholder : True := by
  trivial

end OracleNT
'''


def generate_magma_pseudocode(seq: Sequence[int], hyps: Sequence[Hypothesis]) -> str:
    terms = ", ".join(str(int(x)) for x in seq)
    notes = "\n".join(f"// {i+1}. {h.title}: {h.claim}" for i, h in enumerate(hyps[:8]))
    return f'''// Magma-style pseudocode handoff generated by oracle_nt_workbench_v2.py
seq := [{terms}];

{notes}

// Suggested next steps:
// 1. Build exact recurrence or polynomial object.
// 2. Factor characteristic polynomial or Diophantine model.
// 3. Query relevant databases and prove local/global obstruction.
'''


# ---------------------------------------------------------------------------
# Reports and workbench
# ---------------------------------------------------------------------------


@dataclass
class DiscoveryReport:
    created_utc: str
    input_hash: str
    sequence: List[int]
    summary: Dict[str, Any]
    transforms: Dict[str, Any]
    hypotheses: List[Hypothesis]
    audits: List[AuditFinding]
    oracle_packet: OraclePacket
    tools: Dict[str, ToolStatus]
    knowledge: Dict[str, Any]
    handoff_files: Dict[str, str]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "created_utc": self.created_utc,
            "input_hash": self.input_hash,
            "sequence": self.sequence,
            "summary": self.summary,
            "transforms": self.transforms,
            "hypotheses": [h.to_dict() for h in self.hypotheses],
            "audits": [a.to_dict() for a in self.audits],
            "oracle_packet": self.oracle_packet.to_dict(),
            "tools": {k: dataclasses.asdict(v) for k, v in self.tools.items()},
            "knowledge": self.knowledge,
            "handoff_files": self.handoff_files,
        }

    def markdown(self) -> str:
        lines: List[str] = []
        p = self.oracle_packet
        lines.append("# Oracle Number Theory Discovery Dossier")
        lines.append("")
        lines.append(f"Created UTC: `{self.created_utc}`")
        lines.append(f"Workbench version: `{VERSION}`")
        lines.append(f"Input SHA-256: `{self.input_hash}`")
        lines.append("")
        lines.append("## Oracle packet")
        lines.append("")
        lines.append(f"- Round: `{p.round_number}`")
        lines.append(f"- Prior verdict: `{p.prior_verdict}`")
        lines.append(f"- One binary: **{p.one_binary}**")
        lines.append(f"- Verdict: **{p.verdict}**")
        lines.append(f"- Route: {p.route}")
        lines.append(f"- Next binary: **{p.next_binary}**")
        lines.append(f"- Missing variable: {p.missing_variable}")
        lines.append(f"- Jigsaw visible: `{p.jigsaw_visible}`")
        lines.append(f"- Jigsaw sentence: {p.jigsaw_sentence}")
        if p.gth_claim:
            lines.append(f"- GTH claim: **{p.gth_claim}**")
        lines.append(f"- Attack surface: {p.attack_surface}")
        lines.append(f"- Referee target: {p.referee_target}")
        lines.append("")
        lines.append("## Sequence")
        lines.append("")
        lines.append("```text")
        lines.append(", ".join(str(x) for x in self.sequence[:100]))
        if len(self.sequence) > 100:
            lines.append(f"... {len(self.sequence)} terms total")
        lines.append("```")
        lines.append("")
        lines.append("## Tool status")
        lines.append("")
        for k, st in self.tools.items():
            mark = "yes" if st.available else "no"
            extra = f" | `{st.path}`" if st.path else ""
            if st.detail:
                extra += f" | {st.detail}"
            lines.append(f"- {k}: {mark}{extra}")
        lines.append("")
        lines.append("## Defensive gates")
        lines.append("")
        for a in self.audits:
            block = " BLOCKING" if a.blocking else ""
            lines.append(f"- **{a.gate}**: `{a.verdict}`{block}. {a.detail}")
        lines.append("")
        lines.append("## Basic summary")
        lines.append("")
        lines.append("```json")
        lines.append(json.dumps(self.summary, indent=2, default=str))
        lines.append("```")
        lines.append("")
        lines.append("## Ranked conjecture cards")
        lines.append("")
        if not self.hypotheses:
            lines.append("No ranked structural hypothesis survived the current prefix.")
        for i, h in enumerate(self.hypotheses[:15], start=1):
            lines.append(f"### {i}. {h.title}")
            lines.append("")
            lines.append(f"Score: `{h.score:.3f}` | Confidence: `{h.confidence}` | Claim class: `{h.claim_class}` | Tags: `{', '.join(h.tags)}`")
            if h.risk_flags:
                lines.append(f"Risk flags: `{', '.join(h.risk_flags)}`")
            lines.append("")
            lines.append(f"**Claim:** {h.claim}")
            lines.append("")
            lines.append("**Measured evidence**")
            for e in h.evidence:
                lines.append(f"- {e}")
            lines.append("")
            lines.append("**R667 falsifiers**")
            for f in h.falsifiers:
                lines.append(f"- {f}")
            lines.append("")
            lines.append("**Proof obligations**")
            for q in h.proof_obligations:
                lines.append(f"- {q}")
            lines.append("")
            lines.append("**Next computations**")
            for n in h.next_computations:
                lines.append(f"- {n}")
            lines.append("")
        lines.append("## Knowledge routing")
        lines.append("")
        lines.append("```json")
        lines.append(json.dumps(self.knowledge, indent=2, default=str)[:16000])
        lines.append("```")
        lines.append("")
        lines.append("## Handoff files")
        lines.append("")
        for k, v in self.handoff_files.items():
            lines.append(f"- {k}: `{v}`")
        lines.append("")
        lines.append("## Rule")
        lines.append("")
        lines.append("Nothing here is a theorem until a proof exists. The workbench is allowed to be aggressive about discovery, and brutal about proof status.")
        return "\n".join(lines)


class Workbench:
    def __init__(self, out: Path, online: bool = False, timeout_seconds: int = 20) -> None:
        self.out = out
        self.out.mkdir(parents=True, exist_ok=True)
        self.online = online
        self.tools = ExternalTools(timeout_seconds)

    def analyze(self, seq: Sequence[int], index_start: int = 0, label: str = "sequence", round_number: int = 1, binary: str = "structure exists OR prefix artifact", prior: str = "N/A") -> DiscoveryReport:
        seq = [int(x) for x in seq]
        input_hash = sha256_text(",".join(str(x) for x in seq))
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", label).strip("_") or "sequence"
        stem = f"{safe}_{input_hash[:12]}"
        lab = SequenceLab(seq, index_start=index_start)
        audits: List[AuditFinding] = []
        audits.extend(NTAudit.input_gate(seq))
        summary = lab.summary()
        transforms = lab.transforms()
        hyps = lab.all_hypotheses()
        audits.extend(NTAudit.overfit_gate(seq, hyps))
        audits.extend(NTAudit.output_gate(hyps))
        packet = OracleController(seq, hyps, audits, round_number=round_number, binary=binary, prior=prior).decide()
        knowledge = self._knowledge(seq, hyps)
        handoffs: Dict[str, str] = {}
        sage = self.out / f"{stem}.sage"
        gp = self.out / f"{stem}.gp"
        lean = self.out / f"{stem}.lean"
        magma = self.out / f"{stem}.magma.txt"
        sage.write_text(generate_sage_script(seq, index_start, hyps), encoding="utf-8")
        gp.write_text(generate_gp_script(seq, hyps), encoding="utf-8")
        lean.write_text(generate_lean_skeleton(seq, hyps), encoding="utf-8")
        magma.write_text(generate_magma_pseudocode(seq, hyps), encoding="utf-8")
        handoffs.update({"sage": str(sage), "pari_gp": str(gp), "lean": str(lean), "magma_pseudocode": str(magma)})
        report = DiscoveryReport(
            created_utc=utc_now(),
            input_hash=input_hash,
            sequence=seq,
            summary=summary,
            transforms=transforms,
            hypotheses=hyps,
            audits=audits,
            oracle_packet=packet,
            tools=self.tools.status(),
            knowledge=knowledge,
            handoff_files=handoffs,
        )
        json_path = self.out / f"{stem}.oracle.report.json"
        md_path = self.out / f"{stem}.oracle.report.md"
        packet_path = self.out / f"{stem}.kbk.packet.json"
        json_path.write_text(json.dumps(report.to_dict(), indent=2, default=str), encoding="utf-8")
        md_path.write_text(report.markdown(), encoding="utf-8")
        packet_path.write_text(json.dumps(packet.to_dict(), indent=2), encoding="utf-8")
        report.handoff_files.update({"json_report": str(json_path), "markdown_report": str(md_path), "kbk_packet": str(packet_path)})
        json_path.write_text(json.dumps(report.to_dict(), indent=2, default=str), encoding="utf-8")
        md_path.write_text(report.markdown(), encoding="utf-8")
        return report

    def _knowledge(self, seq: Sequence[int], hyps: Sequence[Hypothesis]) -> Dict[str, Any]:
        keywords = sorted({t for h in hyps[:8] for t in h.tags})[:12]
        data: Dict[str, Any] = {
            "oeis_url": KnowledgeLinks.oeis_url(seq),
            "lmfdb_urls": KnowledgeLinks.lmfdb_urls(seq, keywords),
            "literature_urls": KnowledgeLinks.literature_urls(seq, keywords),
            "online_enabled": self.online,
        }
        if self.online:
            try:
                raw = WebClient().json(KnowledgeLinks.oeis_url(seq))
                results = raw.get("results", []) if isinstance(raw, dict) else []
                data["oeis_results"] = [
                    {"id": f"A{int(r.get('number')):06d}" if r.get("number") is not None else None, "name": r.get("name"), "data": r.get("data")}
                    for r in results[:8]
                ]
            except Exception as exc:
                data["oeis_error"] = repr(exc)
        return data


# ---------------------------------------------------------------------------
# Formula generation
# ---------------------------------------------------------------------------


SAFE_GLOBALS: Dict[str, Any] = {
    "__builtins__": {},
    "abs": abs,
    "min": min,
    "max": max,
    "sum": sum,
    "pow": pow,
    "range": range,
    "math": math,
    "gcd": math.gcd,
    "isqrt": math.isqrt,
}


def generate_from_formula(formula: str, terms: int, index_start: int = 0) -> List[int]:
    code = compile(formula, "<formula>", "eval")
    out: List[int] = []
    for n in range(index_start, index_start + terms):
        v = eval(code, SAFE_GLOBALS, {"n": n})
        if not isinstance(v, int):
            if isinstance(v, float) and v.is_integer():
                v = int(v)
            else:
                raise ValueError(f"Formula produced non-integer at n={n}: {v!r}")
        out.append(int(v))
    return out


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def print_summary(report: DiscoveryReport, out: Path) -> None:
    print(f"Wrote Oracle NT dossier to: {out.resolve()}")
    print(f"Input SHA-256: {report.input_hash}")
    p = report.oracle_packet
    print(f"Oracle verdict: {p.verdict}")
    print(f"Next binary: {p.next_binary}")
    print("Top hypotheses:")
    for i, h in enumerate(report.hypotheses[:6], start=1):
        print(f"  {i}. {h.title} | score={h.score:.3f} | class={h.claim_class} | {h.claim}")
    print("Files:")
    for k, v in report.handoff_files.items():
        print(f"  {k}: {v}")


def cmd_analyze_seq(args: argparse.Namespace) -> int:
    seq = parse_int_sequence(args.seq)
    wb = Workbench(Path(args.out), online=args.online, timeout_seconds=args.timeout)
    report = wb.analyze(seq, index_start=args.index_start, label=args.label, round_number=args.round, binary=args.binary, prior=args.prior)
    if args.format == "json":
        print(json.dumps(report.to_dict(), indent=2, default=str))
    elif args.format == "md":
        print(report.markdown())
    else:
        print_summary(report, Path(args.out))
    return 0


def cmd_formula(args: argparse.Namespace) -> int:
    seq = generate_from_formula(args.formula, args.terms, args.index_start)
    wb = Workbench(Path(args.out), online=args.online, timeout_seconds=args.timeout)
    report = wb.analyze(seq, index_start=args.index_start, label=args.label or "formula", round_number=args.round, binary=args.binary, prior=args.prior)
    print(f"Generated sequence from formula: {args.formula}")
    print_summary(report, Path(args.out))
    return 0


def cmd_oracle_round(args: argparse.Namespace) -> int:
    seq = parse_int_sequence(args.seq)
    wb = Workbench(Path(args.out), online=args.online, timeout_seconds=args.timeout)
    report = wb.analyze(seq, index_start=args.index_start, label=args.label, round_number=args.round, binary=args.binary, prior=args.prior)
    print(report.markdown())
    return 0


def cmd_probe(args: argparse.Namespace) -> int:
    tools = ExternalTools(timeout_seconds=args.timeout)
    print(json.dumps({k: dataclasses.asdict(v) for k, v in tools.status().items()}, indent=2))
    if args.gp_expr:
        print(json.dumps({"gp_result": tools.run_gp(args.gp_expr)}, indent=2))
    if args.sage_code:
        print(json.dumps({"sage_result": tools.run_sage(args.sage_code)}, indent=2))
    return 0


def cmd_crt_lab(args: argparse.Namespace) -> int:
    dummy = SequenceLab([1, 2, 3], 0)
    out = dummy.crt_cover_lab(bases=(args.base1, args.base2), c=args.c, max_modulus=args.max_modulus, k_range=args.k_range, l_range=args.l_range)
    print(json.dumps(out, indent=2))
    return 0


def cmd_selftest(args: argparse.Namespace) -> int:
    tests = {
        "fibonacci": [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377],
        "squares": [n * n for n in range(16)],
        "powers2": [2 ** n for n in range(16)],
        "triangular": [n * (n + 1) // 2 for n in range(16)],
        "constant": [7] * 10,
    }
    wb = Workbench(Path(args.out), online=False, timeout_seconds=args.timeout)
    failures: List[str] = []
    for label, seq in tests.items():
        report = wb.analyze(seq, label=label, binary="known structure OR detector failure")
        titles = [h.title.lower() for h in report.hypotheses]
        if label in {"squares", "triangular"} and not any("polynomial" in t or "finite-difference" in t for t in titles):
            failures.append(f"{label}: expected polynomial hypothesis")
        if label in {"fibonacci", "powers2", "constant"} and not any("recurrence" in t for t in titles):
            failures.append(f"{label}: expected recurrence hypothesis")
    if failures:
        print("SELFTEST FAILED")
        for f in failures:
            print("-", f)
        return 1
    print(f"SELFTEST PASSED. Output: {Path(args.out).resolve()}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="oracle_nt_workbench_v2.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent("""
        Oracle number theory discovery workbench.

        This is not a theorem prover. It is the discovery, falsification, and handoff layer
        that keeps intuition away from claims until computation and proof obligations exist.
        """),
    )
    p.add_argument("--timeout", type=int, default=20, help="External tool timeout in seconds")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("analyze-seq", help="Analyze an integer sequence")
    a.add_argument("--seq", required=True)
    a.add_argument("--index-start", type=int, default=0)
    a.add_argument("--out", default="oracle_nt_out")
    a.add_argument("--label", default="sequence")
    a.add_argument("--online", action="store_true")
    a.add_argument("--format", choices=["summary", "json", "md"], default="summary")
    a.add_argument("--round", type=int, default=1)
    a.add_argument("--binary", default="structure exists OR prefix artifact")
    a.add_argument("--prior", default="N/A")
    a.set_defaults(func=cmd_analyze_seq)

    f = sub.add_parser("formula", help="Generate from restricted Python formula in n, then analyze")
    f.add_argument("--formula", required=True)
    f.add_argument("--terms", type=int, default=30)
    f.add_argument("--index-start", type=int, default=0)
    f.add_argument("--out", default="oracle_nt_out")
    f.add_argument("--label", default="formula")
    f.add_argument("--online", action="store_true")
    f.add_argument("--round", type=int, default=1)
    f.add_argument("--binary", default="formula law OR artifact")
    f.add_argument("--prior", default="N/A")
    f.set_defaults(func=cmd_formula)

    o = sub.add_parser("oracle-round", help="Run an Oracle round and print full Markdown dossier")
    o.add_argument("--seq", required=True)
    o.add_argument("--index-start", type=int, default=0)
    o.add_argument("--out", default="oracle_nt_out")
    o.add_argument("--label", default="oracle_round")
    o.add_argument("--online", action="store_true")
    o.add_argument("--round", type=int, default=1)
    o.add_argument("--binary", required=True)
    o.add_argument("--prior", default="N/A")
    o.set_defaults(func=cmd_oracle_round)

    c = sub.add_parser("crt-lab", help="Toy CRT obstruction scan for b1^k*b2^l+c modulo q")
    c.add_argument("--base1", type=int, default=2)
    c.add_argument("--base2", type=int, default=3)
    c.add_argument("--c", type=int, default=1)
    c.add_argument("--max-modulus", type=int, default=100)
    c.add_argument("--k-range", type=int, default=16)
    c.add_argument("--l-range", type=int, default=16)
    c.set_defaults(func=cmd_crt_lab)

    pr = sub.add_parser("probe", help="Show tool status and optionally run GP/Sage")
    pr.add_argument("--gp-expr", default=None)
    pr.add_argument("--sage-code", default=None)
    pr.set_defaults(func=cmd_probe)

    st = sub.add_parser("selftest", help="Run regression tests")
    st.add_argument("--out", default="oracle_nt_selftest")
    st.set_defaults(func=cmd_selftest)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
