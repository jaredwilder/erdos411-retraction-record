# Oracle NT OS V3 Benchmark Gauntlet

Passed: **5 / 5**

| Case | Expected | Top | Pass | GTH |
|---|---:|---:|---:|---:|
| fib | recurrence | exact_linear_recurrence | True | True |
| squares | polynomial | exact_linear_recurrence | True | True |
| powers2 | recurrence | exact_linear_recurrence | True | True |
| lucas | recurrence_lucas_route | exact_linear_recurrence | True | True |
| noisy_square_prefix | avoid_overconfident_polynomial | strong_divisibility | True | False |
