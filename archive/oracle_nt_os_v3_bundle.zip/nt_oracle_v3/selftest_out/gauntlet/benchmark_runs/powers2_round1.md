# Oracle NT OS V3 Report — powers2

Version: `3.0.0-oracle-nt-os`
Created: `2026-05-21T20:31:33Z`
Object ID: `9804f314042bc807fb8ed79f`
Binary: **true recurrence law OR finite-prefix artifact**

## Gun-to-head packet
Fires: **True**
Claim: Observed prefix is governed by an exact order-1 rational linear recurrence.
Referee target: prove recurrence from source definition

## Jigsaw
Level: **jigsaw_visible** | Score: `7`
Picture: Observed prefix is governed by an exact order-1 rational linear recurrence.
Missing pieces:
- prove recurrence from source definition
- finite prefix may be overfit
- recurrence may be non-minimal
- closed form may be degenerate

## Top hypotheses
### exact_linear_recurrence — score 116.0
Claim class: `COMP`
Observed prefix is governed by an exact order-1 rational linear recurrence.
Proof obligations:
- prove recurrence from source definition
- prove minimality or demote to non-minimal recurrence
- classify characteristic polynomial and degeneracies
Attack surface:
- finite prefix may be overfit
- recurrence may be non-minimal
- closed form may be degenerate

### modular_obstruction_profile — score 62
Claim class: `COMP`
Sequence avoids residue classes modulo small primes; possible obstruction or character constraint.
Proof obligations:
- prove residue avoidance from source law
- separate true obstruction from finite sample miss
- lift local constraints to global theorem route if possible
Attack surface:
- small sample residue misses are common
- local obstruction may not globalize

## Theorem routes
### linear recurrence / companion matrix
Why: exact order-1 recurrence detected on observed prefix
Applicability:
- recurrence definition must be proven from object, not inferred from finite data
- characteristic polynomial governs closed form
- degenerate roots must be checked
Obligations:
- prove recurrence for all n
- determine minimal recurrence
- factor characteristic polynomial over Q
- classify dominant roots and degeneracy

### Diophantine square/subsequence obstruction
Why: square terms detected inside sequence; may indicate Pell/norm structure or rare exceptions
Applicability:
- square pattern survives extension
- index set classified
- not a random finite accident
Obligations:
- solve a_n = y^2
- reduce to Pell/norm equation if possible
- prove completeness of square indices

## Falsification
```json
{
  "counterexample_search": {
    "extended_terms": [
      "1048576",
      "2097152",
      "4194304",
      "8388608",
      "16777216",
      "33554432",
      "67108864",
      "134217728",
      "268435456",
      "536870912",
      "1073741824",
      "2147483648",
      "4294967296",
      "8589934592",
      "17179869184",
      "34359738368",
      "68719476736",
      "137438953472",
      "274877906944",
      "549755813888",
      "1099511627776",
      "2199023255552",
      "4398046511104",
      "8796093022208",
      "17592186044416",
      "35184372088832",
      "70368744177664",
      "140737488355328",
      "281474976710656",
      "562949953421312"
    ],
    "integral_extension": true,
    "status": "extended"
  },
  "fake_family_collision": {
    "collision_rate": 0.0,
    "orders": [],
    "random_recurrence_collisions": 0,
    "target_has_recurrence": true,
    "trials": 80
  },
  "holdout_prediction": {
    "coefficients": [
      "2"
    ],
    "holdout_exact_rate": 1.0,
    "holdout_hits": 6,
    "holdout_total": 6,
    "order": 1,
    "status": "tested",
    "train_len": 14
  },
  "prefix_stability": {
    "dominant_signature_count": 11,
    "prefix_recurrences": [
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 10
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 11
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 12
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 13
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 14
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 15
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 16
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 17
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 18
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 19
      },
      {
        "coefficients": [
          "2"
        ],
        "order": 1,
        "prefix_len": 20
      }
    ],
    "stable": true
  },
  "transform_stability": {
    "drop_first_recurrence": {
      "coefficients": [
        "2"
      ],
      "length": 19,
      "order": 1
    },
    "drop_last_recurrence": {
      "coefficients": [
        "2"
      ],
      "length": 19,
      "order": 1
    },
    "even_subsequence_recurrence": {
      "coefficients": [
        "4"
      ],
      "length": 10,
      "order": 1
    },
    "first_difference_recurrence": {
      "coefficients": [
        "2"
      ],
      "length": 19,
      "order": 1
    },
    "odd_subsequence_recurrence": {
      "coefficients": [
        "4"
      ],
      "length": 10,
      "order": 1
    }
  }
}
```

## KBK packet
```json
{
  "binary": "true recurrence law OR finite-prefix artifact",
  "gth_ready": true,
  "jigsaw_piece": "Placed face piece: exact_linear_recurrence at score 116.0.",
  "killed_routes": [],
  "missing_piece": "prove recurrence from source definition",
  "next_binary": "minimal recurrence with nondegenerate characteristic roots OR reducible/degenerate recurrence",
  "notes": [],
  "round_no": 1,
  "strongest_hypothesis": "exact_linear_recurrence",
  "verdict": "CLOSURE_CANDIDATE"
}
```

## External tribunal
```json
{
  "available_tools": {
    "lean": null,
    "pari_gp": null,
    "sage": null
  },
  "executions": {},
  "handoffs": {
    "lean": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/powers2.lean",
    "pari_gp": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/powers2.gp",
    "sage": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/powers2.sage"
  }
}
```
