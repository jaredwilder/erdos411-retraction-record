# Oracle NT OS V3 Report — noisy_square_prefix

Version: `3.0.0-oracle-nt-os`
Created: `2026-05-21T20:31:34Z`
Object ID: `0ebb30923fcfe073305651a8`
Binary: **strong divisibility law OR offset coincidence**

## Gun-to-head packet
Fires: **False**
Claim: No GTH fire; picture not yet earned.
Referee target: prove strong gcd identity

## Jigsaw
Level: **not_visible** | Score: `2`
Picture: Sequence has high pressure toward strong divisibility gcd(a_m,a_n)=a_gcd(m,n).
Missing pieces:
- prove strong gcd identity
- offset convention may fake success
- zero terms can trivialize gcd
- finite prefix may miss exceptions

## Top hypotheses
### strong_divisibility — score 77.56944444444444
Claim class: `COMP`
Sequence has high pressure toward strong divisibility gcd(a_m,a_n)=a_gcd(m,n).
Proof obligations:
- prove strong gcd identity
- classify zero/sign exceptions
- derive rank-of-apparition law
Attack surface:
- offset convention may fake success
- zero terms can trivialize gcd
- finite prefix may miss exceptions

### padic_lifting_law — score 65
Claim class: `COMP`
Valuation profiles show LTE-like lifting pressure.
Proof obligations:
- derive term as x^n-y^n or equivalent
- state exact LTE branch
- handle p=2 exceptions
Attack surface:
- valuation formula may fit only dense subsequence
- 2-adic branch often exceptional

### modular_obstruction_profile — score 62
Claim class: `COMP`
Sequence avoids residue classes modulo small primes; possible obstruction or character constraint.
Proof obligations:
- prove residue avoidance from source law
- separate true obstruction from finite sample miss
- lift local constraints to global theorem route if possible
Attack surface:
- small sample residue misses are common
- local obstruction may not globalize

### exact_linear_recurrence — score 50.0
Claim class: `COMP`
Observed prefix is governed by an exact order-6 rational linear recurrence.
Proof obligations:
- prove recurrence from source definition
- prove minimality or demote to non-minimal recurrence
- classify characteristic polynomial and degeneracies
Attack surface:
- finite prefix may be overfit
- recurrence may be non-minimal
- closed form may be degenerate

## Theorem routes
### linear recurrence / companion matrix
Why: exact order-6 recurrence detected on observed prefix
Applicability:
- recurrence definition must be proven from object, not inferred from finite data
- characteristic polynomial governs closed form
- degenerate roots must be checked
Obligations:
- prove recurrence for all n
- determine minimal recurrence
- factor characteristic polynomial over Q
- classify dominant roots and degeneracy

### strong divisibility / rank of apparition
Why: gcd(a_m,a_n)=a_gcd(m,n) pressure is high
Applicability:
- sequence has nonzero terms
- gcd law survives extended terms
- primitive prime divisor behavior checked
Obligations:
- prove strong gcd identity
- define rank of apparition z(p)
- prove p divides a_n iff z(p)|n for admissible p

### LTE / p-adic lifting
Why: valuation profiles match affine v_p(n)+c behavior
Applicability:
- base congruence conditions satisfy LTE
- p odd or 2-adic exceptional branch handled
- terms expressible as x^n-y^n or x^n+y^n
Obligations:
- derive exact term factorization
- state LTE branch
- handle p=2 separately
- prove observed valuation formula

### Diophantine square/subsequence obstruction
Why: square terms detected inside sequence; may indicate Pell/norm structure or rare exceptions
Applicability:
- square pattern survives extension
- index set classified
- not a random finite accident
Obligations:
- solve a_n = y^2
- reduce to Pell/norm equation if possible
- prove completeness of square indices

## Falsification
```json
{
  "counterexample_search": {
    "extended_terms": [
      "563509315762/98011",
      "-872926250906117936/9606156121",
      "1130466222564785102046681/941508967575331",
      "-1447782120032792603797121375672/92278235421025766641",
      "1853834790781685144251218866421381859/9044282131850156414251051",
      "-2373777703599070508427411474099890655033828/886439136024765680317159759561",
      "3042568026541264417743721299742372418934818217904/86880786160923309093565145194333171",
      "-3901402739352864267570372758867407590134046171889503728/8515272732418254447569413445641788422881",
      "5003007560498148944971021041349286780288369140041799774027599/834590395777045536660725781220797325114989691",
      "-6415688222958791748711565028385841484118533319934078201706392071428/81799039280504010093654394543231566631845254604601",
      "8227246481850563452449275821536902795941820713364504139952406774219212399/8017205638921478533289160863576669077153785249051548611",
      "-10550300266502341983547105275434308701139274044167142431257751849425722860514776/785774341876333032526203945400012912920919646044791330912721",
      "13529280633267224164114203772626240981192410928885421238062576929527404680123069431194/77014529021641276850925774892600665608292255428496043134086697931",
      "-17349401253458569217462889642709678588411959821059725054911005410583885285750307600416210352/7548271003940083185436086122998683836934332246802325683614971350915241",
      "22248168610181088168095879430418088531643130458976683136871313339067621907125017186487201288786629/739813589367171493087776237001224001541770837841342742576786957074553685651",
      "-28530149370465154728794555259534096310332770575055760920260225311955539191839320719461718402500973558816/72509869707465845209026036764726965615110501587667843542693466449834081284340161",
      "36585906993303951489930348684494982118053590008327863873803980581420387081967447393947082241530678551514418647/7106764839898434954781850889347654626902595371108913013462929340214688140759463519771",
      "-46916284116901507714893543942232646582553786014464074881634101408785967723795096084915515316077112794473410945729052/696541128723285508353123987515852977637350274917755673362515167563781799363975779036275481",
      "60163541037215858301422441296326153948584852734825681633409981138843767157469047106226271622597020863201672628541936525664/68268692567297935959198035140416266191214337794964151301933474088093817937462630079124396168291",
      "-77151286351950331379276075719539094187273838553847642435607633519900978434941674352425668135538024004603293131063989495633043168/6691082827213438001296958622147338665667108461622231433253801728848163189868649836685061192850369201",
      "98935682359797909213970734029039590336119785436880942500748036478287280617671361704660839703521315180208303737128399298006010231530979/655799718978016271945116211515282809960698967432056525004638361246137322402216239143339532572457535759211",
      "-126871108787636121101516059787744179112456682487904578536623474785986640834984597428075302342596678793157145957015501238727235874819884279244/64275586256754352829612785006824383487058066496983292072229610424095165105963615814677850926959135537296029321",
      "162694367299832958902788137134266297541833111987820834176163998548813388129465484746863297601724260482863684434356995897644832387194101382063316467/6299714484610750875183178671303864649950048155435829439291296347275991227200599949612390847202191833145921129780531",
      "-208632661951046385426203329595336832613792516545552118992149876639791112175636043908217796914393481845874264293867661124012607335280946070656048756931840/617441316351184304027578524753163078206254169762421079174379246292867176169158001661460039325134023758464875850919623841",
      "267542068942978799979505044430415519921952504872878991291863776631635968355649215604071236639199160549991015896097160174966519586947616984672991256285723553570/60516040856895924822046998789582266458073177432584652390960084308410204803515344900841359914295710802590900947024483252280251",
      "-343085104627988145297212092393556978475478770118173116433722324948388299324500707563044692398424728402938632435618321278330605799076350104804925201487399919777684784/5931237680425226487733648398365747517822210193345054365490388823151592582997342469076362526560036911472736792718816628039239680761",
      "439958431519375297524271290941147502676950805616061117061002527964612598044922406160073425190925844733793400780628235395690955748281319819198966734623386198707644918332609/581326536296156873289262613172225279969272643259942123416078498945910740652152532736643367590675777730354405791163936530753920351066371",
      "-564184859249064164049689475839240315326389855249761343123731733371190875989085719477850151542712865008904391221027333542781408424605285748868753123233697472425310385786893113032/56976395148922631307953917979622971915068381038550187458133269760187657602058121886051153100929723651129765665997768583315722487528366088081",
      "723487794759696781575754850375385592847124909896050148081081162249754669890008059648763601800163654078346845880043975426080999744861378168768389917521984865880707425035315724820121659/5584313464941056017123871455100827100367767093969342422959099902465752509235318584173759566575223144770879462690107296619357276725142688658906891",
      "-927771422052953420912362212932043823836790202136149868759620862843837615191695793820174165409281367076994084463406494445435068125346199393898518716553487072104766784258243600339974299444820/547324147012337841294327765185887164934145220647029220216644340540570869182662809753454348879604195642138667017720106248959826049107960058148123293801"
    ],
    "integral_extension": false,
    "status": "extended"
  },
  "fake_family_collision": {
    "collision_rate": 0.0,
    "orders": [],
    "random_recurrence_collisions": 0,
    "target_has_recurrence": true,
    "trials": 80
  },
  "holdout_prediction": {
    "coefficients": [
      "-3",
      "6777/8",
      "-4789/2",
      "16215/8"
    ],
    "holdout_exact_rate": 0.0,
    "holdout_hits": 0,
    "holdout_total": 4,
    "order": 4,
    "status": "tested",
    "train_len": 8
  },
  "prefix_stability": {
    "dominant_signature_count": 1,
    "prefix_recurrences": [
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 6
      },
      {
        "coefficients": null,
        "order": null,
        "prefix_len": 7
      },
      {
        "coefficients": [
          "-3",
          "6777/8",
          "-4789/2",
          "16215/8"
        ],
        "order": 4,
        "prefix_len": 8
      },
      {
        "coefficients": null,
        "order": null,
        "prefix_len": 9
      },
      {
        "coefficients": [
          "-19076/6825",
          "-12251/2275",
          "-19952/2275",
          "-284407/6825",
          "199132/455"
        ],
        "order": 5,
        "prefix_len": 10
      },
      {
        "coefficients": null,
        "order": null,
        "prefix_len": 11
      },
      {
        "coefficients": [
          "-1554660/98011",
          "-4110723/98011",
          "-7766200/98011",
          "-12521091/98011",
          "-18375396/98011",
          "567197438/98011"
        ],
        "order": 6,
        "prefix_len": 12
      }
    ],
    "stable": false
  },
  "transform_stability": {
    "drop_first_recurrence": {
      "coefficients": null,
      "length": 11,
      "order": null
    },
    "drop_last_recurrence": {
      "coefficients": null,
      "length": 11,
      "order": null
    },
    "even_subsequence_recurrence": {
      "coefficients": [
        "-8305449/570161",
        "-24133161/570161",
        "994995674/570161"
      ],
      "length": 6,
      "order": 3
    },
    "first_difference_recurrence": {
      "coefficients": null,
      "length": 11,
      "order": null
    },
    "odd_subsequence_recurrence": {
      "coefficients": [
        "3",
        "-3",
        "1"
      ],
      "length": 6,
      "order": 3
    }
  }
}
```

## KBK packet
```json
{
  "binary": "strong divisibility law OR offset coincidence",
  "gth_ready": false,
  "jigsaw_piece": "Placed face piece: strong_divisibility at score 77.56944444444444.",
  "killed_routes": [
    "train-prefix recurrence as global law"
  ],
  "missing_piece": "prove strong gcd identity",
  "next_binary": "rank-of-apparition law OR finite gcd coincidence",
  "notes": [
    "Holdout prediction failed; recurrence demoted unless source definition proves it."
  ],
  "round_no": 1,
  "strongest_hypothesis": "strong_divisibility",
  "verdict": "ESCALATION"
}
```

## External tribunal
```json
{
  "available_tools": {
    "lean": null,
    "pari_gp": null,
    "sage": null
  },
  "executions": {},
  "handoffs": {
    "lean": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/noisy_square_prefix.lean",
    "pari_gp": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/noisy_square_prefix.gp",
    "sage": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/noisy_square_prefix.sage"
  }
}
```
