# Oracle NT OS V3 Report — lucas

Version: `3.0.0-oracle-nt-os`
Created: `2026-05-21T20:31:34Z`
Object ID: `6b83552193856f8a91eab2ab`
Binary: **true recurrence law OR finite-prefix artifact**

## Gun-to-head packet
Fires: **True**
Claim: Observed prefix is governed by an exact order-2 rational linear recurrence.
Referee target: prove recurrence from source definition

## Jigsaw
Level: **jigsaw_visible** | Score: `7`
Picture: Observed prefix is governed by an exact order-2 rational linear recurrence.
Missing pieces:
- prove recurrence from source definition
- finite prefix may be overfit
- recurrence may be non-minimal
- closed form may be degenerate

## Top hypotheses
### exact_linear_recurrence — score 112.0
Claim class: `COMP`
Observed prefix is governed by an exact order-2 rational linear recurrence.
Proof obligations:
- prove recurrence from source definition
- prove minimality or demote to non-minimal recurrence
- classify characteristic polynomial and degeneracies
Attack surface:
- finite prefix may be overfit
- recurrence may be non-minimal
- closed form may be degenerate

### modular_obstruction_profile — score 56
Claim class: `COMP`
Sequence avoids residue classes modulo small primes; possible obstruction or character constraint.
Proof obligations:
- prove residue avoidance from source law
- separate true obstruction from finite sample miss
- lift local constraints to global theorem route if possible
Attack surface:
- small sample residue misses are common
- local obstruction may not globalize

## Theorem routes
### linear recurrence / companion matrix
Why: exact order-2 recurrence detected on observed prefix
Applicability:
- recurrence definition must be proven from object, not inferred from finite data
- characteristic polynomial governs closed form
- degenerate roots must be checked
Obligations:
- prove recurrence for all n
- determine minimal recurrence
- factor characteristic polynomial over Q
- classify dominant roots and degeneracy

### Lucas/Lehmer/Zsigmondy primitive divisor
Why: order-2 recurrence suggests Lucas-type classification pressure
Applicability:
- integer recurrence
- nonzero discriminant
- nondegenerate alpha/beta ratio not root of unity
- exclude Bilu-Hanrot-Voutier exceptional n
Obligations:
- compute discriminant
- test nondegeneracy
- prove integer Lucas normalization
- list primitive divisor exceptions

### Diophantine square/subsequence obstruction
Why: square terms detected inside sequence; may indicate Pell/norm structure or rare exceptions
Applicability:
- square pattern survives extension
- index set classified
- not a random finite accident
Obligations:
- solve a_n = y^2
- reduce to Pell/norm equation if possible
- prove completeness of square indices

## Falsification
```json
{
  "counterexample_search": {
    "extended_terms": [
      "15127",
      "24476",
      "39603",
      "64079",
      "103682",
      "167761",
      "271443",
      "439204",
      "710647",
      "1149851",
      "1860498",
      "3010349",
      "4870847",
      "7881196",
      "12752043",
      "20633239",
      "33385282",
      "54018521",
      "87403803",
      "141422324",
      "228826127",
      "370248451",
      "599074578",
      "969323029",
      "1568397607",
      "2537720636",
      "4106118243",
      "6643838879",
      "10749957122",
      "17393796001"
    ],
    "integral_extension": true,
    "status": "extended"
  },
  "fake_family_collision": {
    "collision_rate": 0.0,
    "orders": [],
    "random_recurrence_collisions": 0,
    "target_has_recurrence": true,
    "trials": 80
  },
  "holdout_prediction": {
    "coefficients": [
      "1",
      "1"
    ],
    "holdout_exact_rate": 1.0,
    "holdout_hits": 6,
    "holdout_total": 6,
    "order": 2,
    "status": "tested",
    "train_len": 14
  },
  "prefix_stability": {
    "dominant_signature_count": 11,
    "prefix_recurrences": [
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 10
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 11
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 12
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 13
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 14
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 15
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 16
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 17
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 18
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 19
      },
      {
        "coefficients": [
          "1",
          "1"
        ],
        "order": 2,
        "prefix_len": 20
      }
    ],
    "stable": true
  },
  "transform_stability": {
    "drop_first_recurrence": {
      "coefficients": [
        "1",
        "1"
      ],
      "length": 19,
      "order": 2
    },
    "drop_last_recurrence": {
      "coefficients": [
        "1",
        "1"
      ],
      "length": 19,
      "order": 2
    },
    "even_subsequence_recurrence": {
      "coefficients": [
        "3",
        "-1"
      ],
      "length": 10,
      "order": 2
    },
    "first_difference_recurrence": {
      "coefficients": [
        "1",
        "1"
      ],
      "length": 19,
      "order": 2
    },
    "odd_subsequence_recurrence": {
      "coefficients": [
        "3",
        "-1"
      ],
      "length": 10,
      "order": 2
    }
  }
}
```

## KBK packet
```json
{
  "binary": "true recurrence law OR finite-prefix artifact",
  "gth_ready": true,
  "jigsaw_piece": "Placed face piece: exact_linear_recurrence at score 112.0.",
  "killed_routes": [],
  "missing_piece": "prove recurrence from source definition",
  "next_binary": "minimal recurrence with nondegenerate characteristic roots OR reducible/degenerate recurrence",
  "notes": [],
  "round_no": 1,
  "strongest_hypothesis": "exact_linear_recurrence",
  "verdict": "CLOSURE_CANDIDATE"
}
```

## External tribunal
```json
{
  "available_tools": {
    "lean": null,
    "pari_gp": null,
    "sage": null
  },
  "executions": {},
  "handoffs": {
    "lean": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/lucas.lean",
    "pari_gp": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/lucas.gp",
    "sage": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/lucas.sage"
  }
}
```
