# Oracle NT OS V3 Report — squares

Version: `3.0.0-oracle-nt-os`
Created: `2026-05-21T20:31:31Z`
Object ID: `28af63fcc6e2c676886926ec`
Binary: **true recurrence law OR finite-prefix artifact**

## Gun-to-head packet
Fires: **True**
Claim: Observed prefix is governed by an exact order-3 rational linear recurrence.
Referee target: prove recurrence from source definition

## Jigsaw
Level: **jigsaw_visible** | Score: `7`
Picture: Observed prefix is governed by an exact order-3 rational linear recurrence.
Missing pieces:
- prove recurrence from source definition
- finite prefix may be overfit
- recurrence may be non-minimal
- closed form may be degenerate

## Top hypotheses
### exact_linear_recurrence — score 108.0
Claim class: `COMP`
Observed prefix is governed by an exact order-3 rational linear recurrence.
Proof obligations:
- prove recurrence from source definition
- prove minimality or demote to non-minimal recurrence
- classify characteristic polynomial and degeneracies
Attack surface:
- finite prefix may be overfit
- recurrence may be non-minimal
- closed form may be degenerate

### polynomial_law — score 89
Claim class: `COMP`
Observed prefix is exactly degree-2 polynomial in n.
Proof obligations:
- prove constant finite difference persists
- rewrite in binomial integer-valued basis
- prove by induction from source object
Attack surface:
- finite interpolation can always fit short prefixes
- degree may be artifact of insufficient terms

### strong_divisibility — score 80.0
Claim class: `COMP`
Sequence has high pressure toward strong divisibility gcd(a_m,a_n)=a_gcd(m,n).
Proof obligations:
- prove strong gcd identity
- classify zero/sign exceptions
- derive rank-of-apparition law
Attack surface:
- offset convention may fake success
- zero terms can trivialize gcd
- finite prefix may miss exceptions

### padic_lifting_law — score 75
Claim class: `COMP`
Valuation profiles show LTE-like lifting pressure.
Proof obligations:
- derive term as x^n-y^n or equivalent
- state exact LTE branch
- handle p=2 exceptions
Attack surface:
- valuation formula may fit only dense subsequence
- 2-adic branch often exceptional

### modular_obstruction_profile — score 62
Claim class: `COMP`
Sequence avoids residue classes modulo small primes; possible obstruction or character constraint.
Proof obligations:
- prove residue avoidance from source law
- separate true obstruction from finite sample miss
- lift local constraints to global theorem route if possible
Attack surface:
- small sample residue misses are common
- local obstruction may not globalize

## Theorem routes
### linear recurrence / companion matrix
Why: exact order-3 recurrence detected on observed prefix
Applicability:
- recurrence definition must be proven from object, not inferred from finite data
- characteristic polynomial governs closed form
- degenerate roots must be checked
Obligations:
- prove recurrence for all n
- determine minimal recurrence
- factor characteristic polynomial over Q
- classify dominant roots and degeneracy

### strong divisibility / rank of apparition
Why: gcd(a_m,a_n)=a_gcd(m,n) pressure is high
Applicability:
- sequence has nonzero terms
- gcd law survives extended terms
- primitive prime divisor behavior checked
Obligations:
- prove strong gcd identity
- define rank of apparition z(p)
- prove p divides a_n iff z(p)|n for admissible p

### LTE / p-adic lifting
Why: valuation profiles match affine v_p(n)+c behavior
Applicability:
- base congruence conditions satisfy LTE
- p odd or 2-adic exceptional branch handled
- terms expressible as x^n-y^n or x^n+y^n
Obligations:
- derive exact term factorization
- state LTE branch
- handle p=2 separately
- prove observed valuation formula

### finite difference / polynomial integer-valued basis
Why: degree-2 polynomial law detected
Applicability:
- constant finite difference persists
- integer-valued basis coefficients verified
- not merely early-prefix interpolation
Obligations:
- prove d-th finite difference constant
- rewrite in binomial coefficient basis
- prove formula by induction

### Diophantine square/subsequence obstruction
Why: square terms detected inside sequence; may indicate Pell/norm structure or rare exceptions
Applicability:
- square pattern survives extension
- index set classified
- not a random finite accident
Obligations:
- solve a_n = y^2
- reduce to Pell/norm equation if possible
- prove completeness of square indices

## Falsification
```json
{
  "counterexample_search": {
    "extended_terms": [
      "400",
      "441",
      "484",
      "529",
      "576",
      "625",
      "676",
      "729",
      "784",
      "841",
      "900",
      "961",
      "1024",
      "1089",
      "1156",
      "1225",
      "1296",
      "1369",
      "1444",
      "1521",
      "1600",
      "1681",
      "1764",
      "1849",
      "1936",
      "2025",
      "2116",
      "2209",
      "2304",
      "2401"
    ],
    "integral_extension": true,
    "status": "extended"
  },
  "fake_family_collision": {
    "collision_rate": 0.0,
    "orders": [],
    "random_recurrence_collisions": 0,
    "target_has_recurrence": true,
    "trials": 80
  },
  "holdout_prediction": {
    "coefficients": [
      "3",
      "-3",
      "1"
    ],
    "holdout_exact_rate": 1.0,
    "holdout_hits": 6,
    "holdout_total": 6,
    "order": 3,
    "status": "tested",
    "train_len": 14
  },
  "prefix_stability": {
    "dominant_signature_count": 11,
    "prefix_recurrences": [
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 10
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 11
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 12
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 13
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 14
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 15
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 16
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 17
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 18
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 19
      },
      {
        "coefficients": [
          "3",
          "-3",
          "1"
        ],
        "order": 3,
        "prefix_len": 20
      }
    ],
    "stable": true
  },
  "transform_stability": {
    "drop_first_recurrence": {
      "coefficients": [
        "3",
        "-3",
        "1"
      ],
      "length": 19,
      "order": 3
    },
    "drop_last_recurrence": {
      "coefficients": [
        "3",
        "-3",
        "1"
      ],
      "length": 19,
      "order": 3
    },
    "even_subsequence_recurrence": {
      "coefficients": [
        "3",
        "-3",
        "1"
      ],
      "length": 10,
      "order": 3
    },
    "first_difference_recurrence": {
      "coefficients": [
        "2",
        "-1"
      ],
      "length": 19,
      "order": 2
    },
    "odd_subsequence_recurrence": {
      "coefficients": [
        "3",
        "-3",
        "1"
      ],
      "length": 10,
      "order": 3
    }
  }
}
```

## KBK packet
```json
{
  "binary": "true recurrence law OR finite-prefix artifact",
  "gth_ready": true,
  "jigsaw_piece": "Placed face piece: exact_linear_recurrence at score 108.0.",
  "killed_routes": [],
  "missing_piece": "prove recurrence from source definition",
  "next_binary": "minimal recurrence with nondegenerate characteristic roots OR reducible/degenerate recurrence",
  "notes": [],
  "round_no": 1,
  "strongest_hypothesis": "exact_linear_recurrence",
  "verdict": "CLOSURE_CANDIDATE"
}
```

## External tribunal
```json
{
  "available_tools": {
    "lean": null,
    "pari_gp": null,
    "sage": null
  },
  "executions": {},
  "handoffs": {
    "lean": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/squares.lean",
    "pari_gp": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/squares.gp",
    "sage": "/mnt/data/nt_oracle_v3/selftest_out/gauntlet/benchmark_runs/handoffs/squares.sage"
  }
}
```
