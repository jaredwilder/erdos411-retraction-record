#!/usr/bin/env python3
"""
oracle_nt_os_v3.py

Oracle Number Theory OS V3: adversarial arithmetic discovery infrastructure.

This is not a proof engine. It is a disciplined discovery operating system:
    object intake -> measured engines -> hostile falsification -> theorem routing
    -> active external tribunal handoffs -> persistent KBK corpus -> proof obligations
    -> jigsaw/GTH packet.

Design law:
    Prose does not do math. Engines measure. The Oracle ranks measured pressure.

Works with plain Python + SymPy. If SageMath / PARI-GP / Lean are installed, V3 uses
what it can; otherwise it writes runnable handoff files and records the absence.

Commands:
    python oracle_nt_os_v3.py selftest
    python oracle_nt_os_v3.py benchmark --out out
    python oracle_nt_os_v3.py analyze-seq --seq "1,1,2,3,5,8,13,21" --out out --label fib
    python oracle_nt_os_v3.py run --seq "1,1,2,3,5,8,13,21,34,55,89" --rounds 5 --out out --label fib
    python oracle_nt_os_v3.py crt-lab --base1 2 --base2 3 --c 1 --max-modulus 180 --out out
    python oracle_nt_os_v3.py corpus-list --db out/oracle_nt_corpus.sqlite
"""

from __future__ import annotations

import argparse
import dataclasses
import fractions
import hashlib
import itertools
import json
import math
import os
import random
import re
import shutil
import sqlite3
import statistics
import subprocess
import sys
import textwrap
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import sympy as sp  # type: ignore
except Exception:  # pragma: no cover
    sp = None

Fraction = fractions.Fraction
VERSION = "3.0.0-oracle-nt-os"

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------


def utc_now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def stable_json(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, default=str)


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def parse_int_sequence(raw: str) -> List[int]:
    found = re.findall(r"[-+]?\d+", raw or "")
    if not found:
        raise ValueError("No integers found in sequence input")
    return [int(x) for x in found]


def gcd_list(values: Iterable[int]) -> int:
    g = 0
    for v in values:
        g = math.gcd(g, abs(int(v)))
    return g


def lcm(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return abs(a // math.gcd(a, b) * b)


def lcm_list(values: Iterable[int]) -> int:
    out = 1
    for v in values:
        out = lcm(out, int(v))
    return out


def differences(seq: Sequence[int], order: int = 1) -> List[int]:
    cur = [int(x) for x in seq]
    for _ in range(order):
        cur = [cur[i + 1] - cur[i] for i in range(len(cur) - 1)]
    return cur


def finite_difference_table(seq: Sequence[int], max_order: Optional[int] = None) -> List[List[int]]:
    if max_order is None:
        max_order = max(0, len(seq) - 1)
    table = [[int(x) for x in seq]]
    cur = list(table[0])
    for _ in range(max_order):
        if len(cur) <= 1:
            break
        cur = differences(cur)
        table.append(cur)
    return table


def valuation(n: int, p: int) -> Optional[int]:
    if p <= 1:
        raise ValueError("p must be > 1")
    if n == 0:
        return None
    n = abs(int(n))
    out = 0
    while n % p == 0:
        n //= p
        out += 1
    return out


def is_square(n: int) -> bool:
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def primes_upto(n: int) -> List[int]:
    if n < 2:
        return []
    sieve = bytearray(b"\x01") * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for p in range(2, math.isqrt(n) + 1):
        if sieve[p]:
            sieve[p*p:n+1:p] = b"\x00" * (((n - p*p) // p) + 1)
    return [i for i in range(n + 1) if sieve[i]]


def factorint(n: int) -> Dict[int, int]:
    n = int(n)
    if n == 0:
        return {0: 1}
    sign: Dict[int, int] = {}
    if n < 0:
        sign[-1] = 1
        n = -n
    if n == 1:
        return sign
    if sp is not None:
        try:
            return {**sign, **{int(k): int(v) for k, v in sp.factorint(n).items()}}
        except Exception:
            pass
    out = dict(sign)
    while n % 2 == 0:
        out[2] = out.get(2, 0) + 1
        n //= 2
    d = 3
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def modular_period(seq: Sequence[int], modulus: int, max_period: Optional[int] = None) -> Optional[int]:
    if modulus <= 1 or len(seq) < 2:
        return None
    residues = [int(x) % modulus for x in seq]
    n = len(residues)
    if max_period is None:
        max_period = max(1, n // 2)
    for p in range(1, max_period + 1):
        ok = True
        for i in range(n - p):
            if residues[i] != residues[i+p]:
                ok = False
                break
        if ok:
            return p
    return None


def solve_linear_fraction(A: List[List[Fraction]], b: List[Fraction]) -> Optional[List[Fraction]]:
    n = len(A)
    if n == 0 or len(b) != n or any(len(r) != n for r in A):
        return None
    M = [list(A[i]) + [b[i]] for i in range(n)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            return None
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r != col and M[r][col] != 0:
                f = M[r][col]
                M[r] = [M[r][c] - f * M[col][c] for c in range(n + 1)]
    return [M[i][-1] for i in range(n)]


def berlekamp_massey_rational(seq: Sequence[int], max_order: Optional[int] = None) -> Optional[List[Fraction]]:
    """Return coefficients c_i such that a_n = sum_i c_i a_{n-i} over Q."""
    vals = [Fraction(int(x)) for x in seq]
    n = len(vals)
    if n < 4:
        return None
    if max_order is None:
        max_order = min(12, n // 2)
    for r in range(1, max_order + 1):
        rows: List[List[Fraction]] = []
        rhs: List[Fraction] = []
        for i in range(r, n):
            rows.append([vals[i-j] for j in range(1, r+1)])
            rhs.append(vals[i])
        # use first independent-looking square windows until solved
        for start in range(0, max(1, len(rows) - r + 1)):
            sol = solve_linear_fraction(rows[start:start+r], rhs[start:start+r])
            if sol is None:
                continue
            if all(sum(sol[j] * rows[i][j] for j in range(r)) == rhs[i] for i in range(len(rows))):
                return sol
    return None


def recurrence_predict(seed: Sequence[int], coeffs: Sequence[Fraction], total: int) -> List[Fraction]:
    r = len(coeffs)
    out = [Fraction(int(x)) for x in seed]
    while len(out) < total:
        out.append(sum(coeffs[j] * out[-j-1] for j in range(r)))
    return out


def polynomial_fit_degree(seq: Sequence[int], max_degree: Optional[int] = None) -> Optional[Dict[str, Any]]:
    n = len(seq)
    if n < 3:
        return None
    if max_degree is None:
        max_degree = min(8, n - 2)
    table = finite_difference_table(seq, max_degree)
    for d in range(0, len(table)):
        row = table[d]
        if row and len(set(row)) == 1:
            if sp is not None:
                x = sp.symbols("n")
                pts = [(i, int(seq[i])) for i in range(min(n, d + 3))]
                poly = sp.interpolate(pts, x).expand()
                if all(int(poly.subs(x, i)) == int(seq[i]) for i in range(n)):
                    return {"degree": d, "polynomial": str(poly), "constant_difference": int(row[0])}
            return {"degree": d, "polynomial": None, "constant_difference": int(row[0])}
    return None


def rational_generating_function_from_recurrence(seq: Sequence[int], coeffs: Sequence[Fraction]) -> Dict[str, Any]:
    """For a_n=sum c_j a_{n-j}, Q=1-c1*x-...-cr*x^r, P initial-corrected."""
    r = len(coeffs)
    # P_k = a_k - c1 a_{k-1} - ... - ck a_0 for k < r
    P: List[Fraction] = []
    for k in range(r):
        val = Fraction(int(seq[k]))
        for j in range(1, k + 1):
            val -= coeffs[j-1] * int(seq[k-j])
        P.append(val)
    Q = [Fraction(1)] + [-c for c in coeffs]
    return {"P_coeffs": [str(x) for x in P], "Q_coeffs": [str(x) for x in Q], "form": "A(x)=P(x)/Q(x)"}


def companion_characteristic(coeffs: Sequence[Fraction]) -> str:
    if sp is None:
        return "unavailable: sympy missing"
    x = sp.symbols("x")
    r = len(coeffs)
    poly = x**r - sum(sp.Rational(c.numerator, c.denominator) * x**(r-i-1) for i, c in enumerate(coeffs))
    return str(sp.factor(poly))

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class NTObject:
    object_id: str
    kind: str
    label: str
    payload: Dict[str, Any]
    created_at: str = field(default_factory=utc_now)


@dataclass
class Hypothesis:
    name: str
    claim: str
    claim_class: str
    score: float
    evidence: Dict[str, Any] = field(default_factory=dict)
    proof_obligations: List[str] = field(default_factory=list)
    theorem_routes: List[Dict[str, Any]] = field(default_factory=list)
    attack_surface: List[str] = field(default_factory=list)
    falsification: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RoundPacket:
    round_no: int
    binary: str
    verdict: str
    strongest_hypothesis: Optional[str]
    killed_routes: List[str]
    next_binary: str
    jigsaw_piece: str
    missing_piece: str
    gth_ready: bool
    notes: List[str] = field(default_factory=list)

# ---------------------------------------------------------------------------
# Persistent corpus
# ---------------------------------------------------------------------------


class CorpusStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        ensure_dir(db_path.parent)
        self.conn = sqlite3.connect(str(db_path))
        self.conn.row_factory = sqlite3.Row
        self.init()

    def init(self) -> None:
        c = self.conn.cursor()
        c.execute("""
        CREATE TABLE IF NOT EXISTS objects (
            object_id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            label TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """)
        c.execute("""
        CREATE TABLE IF NOT EXISTS runs (
            run_id TEXT PRIMARY KEY,
            object_id TEXT NOT NULL,
            version TEXT NOT NULL,
            created_at TEXT NOT NULL,
            report_json TEXT NOT NULL,
            FOREIGN KEY(object_id) REFERENCES objects(object_id)
        )
        """)
        c.execute("""
        CREATE TABLE IF NOT EXISTS hypotheses (
            hyp_id TEXT PRIMARY KEY,
            object_id TEXT NOT NULL,
            run_id TEXT NOT NULL,
            name TEXT NOT NULL,
            claim TEXT NOT NULL,
            claim_class TEXT NOT NULL,
            score REAL NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(object_id) REFERENCES objects(object_id),
            FOREIGN KEY(run_id) REFERENCES runs(run_id)
        )
        """)
        c.execute("""
        CREATE TABLE IF NOT EXISTS killed_routes (
            kill_id TEXT PRIMARY KEY,
            object_id TEXT NOT NULL,
            route TEXT NOT NULL,
            reason TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """)
        c.execute("""
        CREATE TABLE IF NOT EXISTS kbk_packets (
            packet_id TEXT PRIMARY KEY,
            object_id TEXT NOT NULL,
            run_id TEXT NOT NULL,
            round_no INTEGER NOT NULL,
            payload_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """)
        self.conn.commit()

    def upsert_object(self, obj: NTObject) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO objects(object_id,kind,label,payload_json,created_at) VALUES(?,?,?,?,?)",
            (obj.object_id, obj.kind, obj.label, stable_json(obj.payload), obj.created_at),
        )
        self.conn.commit()

    def save_run(self, object_id: str, report: Dict[str, Any]) -> str:
        run_id = sha256_text(object_id + utc_now() + stable_json(report))[:20]
        self.conn.execute(
            "INSERT INTO runs(run_id,object_id,version,created_at,report_json) VALUES(?,?,?,?,?)",
            (run_id, object_id, VERSION, utc_now(), stable_json(report)),
        )
        for hyp in report.get("hypotheses", []):
            hyp_id = sha256_text(run_id + hyp.get("name", "") + hyp.get("claim", ""))[:20]
            self.conn.execute(
                "INSERT OR REPLACE INTO hypotheses(hyp_id,object_id,run_id,name,claim,claim_class,score,payload_json,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (hyp_id, object_id, run_id, hyp.get("name", ""), hyp.get("claim", ""), hyp.get("claim_class", ""), float(hyp.get("score", 0)), stable_json(hyp), utc_now()),
            )
        self.conn.commit()
        return run_id

    def save_packet(self, object_id: str, run_id: str, packet: Dict[str, Any]) -> None:
        packet_id = sha256_text(object_id + run_id + str(packet.get("round_no")) + stable_json(packet))[:20]
        self.conn.execute(
            "INSERT OR REPLACE INTO kbk_packets(packet_id,object_id,run_id,round_no,payload_json,created_at) VALUES(?,?,?,?,?,?)",
            (packet_id, object_id, run_id, int(packet.get("round_no", 0)), stable_json(packet), utc_now()),
        )
        self.conn.commit()

    def add_kill(self, object_id: str, route: str, reason: str) -> None:
        kill_id = sha256_text(object_id + route + reason)[:20]
        self.conn.execute(
            "INSERT OR REPLACE INTO killed_routes(kill_id,object_id,route,reason,created_at) VALUES(?,?,?,?,?)",
            (kill_id, object_id, route, reason, utc_now()),
        )
        self.conn.commit()

    def list_objects(self) -> List[Dict[str, Any]]:
        rows = self.conn.execute("SELECT object_id,kind,label,created_at FROM objects ORDER BY created_at DESC").fetchall()
        return [dict(r) for r in rows]

    def prior_context(self, object_id: str) -> Dict[str, Any]:
        hyps = self.conn.execute("SELECT name,claim,claim_class,score FROM hypotheses WHERE object_id=? ORDER BY score DESC LIMIT 20", (object_id,)).fetchall()
        kills = self.conn.execute("SELECT route,reason FROM killed_routes WHERE object_id=? ORDER BY created_at DESC LIMIT 20", (object_id,)).fetchall()
        packets = self.conn.execute("SELECT round_no,payload_json FROM kbk_packets WHERE object_id=? ORDER BY round_no DESC LIMIT 5", (object_id,)).fetchall()
        return {"prior_hypotheses": [dict(r) for r in hyps], "killed_routes": [dict(r) for r in kills], "recent_packets": [{"round_no": r[0], "packet": json.loads(r[1])} for r in packets]}

# ---------------------------------------------------------------------------
# External tribunal
# ---------------------------------------------------------------------------


class ExternalTribunal:
    def __init__(self, out_dir: Path):
        self.out_dir = ensure_dir(out_dir)
        self.tools = {"sage": shutil.which("sage"), "pari_gp": shutil.which("gp"), "lean": shutil.which("lean")}

    def write_sequence_handoffs(self, seq: Sequence[int], label: str, recurrence: Optional[List[Fraction]]) -> Dict[str, Any]:
        sage_path = self.out_dir / f"{label}.sage"
        gp_path = self.out_dir / f"{label}.gp"
        lean_path = self.out_dir / f"{label}.lean"
        seq_str = ", ".join(map(str, seq))
        coeff_str = ", ".join(str(c) for c in recurrence) if recurrence else ""
        sage_path.write_text(textwrap.dedent(f"""
            # Sage handoff generated by Oracle NT OS V3
            A = [{seq_str}]
            print('length', len(A))
            print('gcd_all', gcd(A))
            print('factor_first_terms')
            for i,a in enumerate(A[:20]):
                print(i, factor(abs(a)) if a != 0 else 0)
            {'R.<x> = PolynomialRing(QQ)\ncharpoly = ' + self._sage_charpoly_expr(recurrence) + '\nprint("charpoly", factor(charpoly))\nprint("irreducible", charpoly.is_irreducible())' if recurrence else '# no recurrence detected'}
        """).strip() + "\n")
        gp_path.write_text(textwrap.dedent(f"""
            \\ PARI/GP handoff generated by Oracle NT OS V3
            A = [{seq_str}];
            print("length=", #A);
            for(i=1, min(#A,20), print(i-1, " ", factor(abs(A[i]))));
            {self._gp_charpoly_lines(recurrence) if recurrence else '\\ no recurrence detected'}
        """).strip() + "\n")
        lean_path.write_text(textwrap.dedent(f"""
            /- Lean proof-obligation skeleton generated by Oracle NT OS V3.
               This file intentionally states obligations, not fake proofs. -/
            import Mathlib

            namespace OracleNT

            def a : Nat -> Int
              | 0 => {seq[0] if seq else 0}
              | n+1 => 0 -- replace by recurrence/formal definition after route is confirmed

            /- REFEREE TARGETS:
            {chr(10).join('  - ' + x for x in self._lean_obligations(recurrence))}
            -/

            theorem oracle_primary_obligation : True := by
              trivial

            end OracleNT
        """).strip() + "\n")
        results = {"available_tools": self.tools, "handoffs": {"sage": str(sage_path), "pari_gp": str(gp_path), "lean": str(lean_path)}, "executions": {}}
        # Active execution where possible; protect from hangs.
        if self.tools["pari_gp"]:
            results["executions"]["pari_gp"] = self._run([self.tools["pari_gp"] or "gp", "-q", str(gp_path)], timeout=10)
        if self.tools["sage"]:
            results["executions"]["sage"] = self._run([self.tools["sage"] or "sage", str(sage_path)], timeout=20)
        # Lean files are skeletons with trivial theorem; checking Lean install is useful but optional.
        if self.tools["lean"]:
            results["executions"]["lean"] = self._run([self.tools["lean"] or "lean", str(lean_path)], timeout=20)
        return results

    def _run(self, cmd: List[str], timeout: int) -> Dict[str, Any]:
        try:
            p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
            return {"cmd": cmd, "returncode": p.returncode, "stdout": p.stdout[-8000:], "stderr": p.stderr[-8000:]}
        except Exception as e:
            return {"cmd": cmd, "error": repr(e)}

    def _sage_charpoly_expr(self, recurrence: Optional[List[Fraction]]) -> str:
        if not recurrence:
            return "0"
        r = len(recurrence)
        terms = [f"x^{r}"]
        for i, c in enumerate(recurrence):
            power = r - i - 1
            sign = "-" if c >= 0 else "+"
            terms.append(f" {sign} ({abs(c.numerator)}/{c.denominator})*x^{power}")
        return "".join(terms)

    def _gp_charpoly_lines(self, recurrence: Optional[List[Fraction]]) -> str:
        if not recurrence:
            return ""
        r = len(recurrence)
        expr = f"x^{r}"
        for i, c in enumerate(recurrence):
            power = r - i - 1
            sign = "-" if c >= 0 else "+"
            expr += f" {sign} ({abs(c.numerator)}/{c.denominator})*x^{power}"
        return f"charpoly = {expr}; print(\"charpoly=\", factor(charpoly));"

    def _lean_obligations(self, recurrence: Optional[List[Fraction]]) -> List[str]:
        if recurrence:
            return [
                "Define the recurrence over Nat -> Int exactly, not by finite prefix.",
                "Prove the recurrence holds for all n, not merely the observed prefix.",
                "Prove minimality or explicitly state non-minimal recurrence debt.",
                "If divisibility is claimed, prove gcd/rank-of-apparition law separately.",
            ]
        return ["No recurrence route survived; formalize the actual discovered invariant first."]

# ---------------------------------------------------------------------------
# Theorem router and proof compiler
# ---------------------------------------------------------------------------


class TheoremRouter:
    def route_sequence(self, seq: Sequence[int], engines: Dict[str, Any]) -> List[Dict[str, Any]]:
        routes: List[Dict[str, Any]] = []
        rec = engines.get("linear_recurrence")
        div = engines.get("divisibility")
        val = engines.get("padic")
        poly = engines.get("polynomial")
        if rec:
            order = rec.get("order")
            charpoly = rec.get("characteristic_polynomial")
            routes.append({
                "route": "linear recurrence / companion matrix",
                "why": f"exact order-{order} recurrence detected on observed prefix",
                "applicability_conditions": ["recurrence definition must be proven from object, not inferred from finite data", "characteristic polynomial governs closed form", "degenerate roots must be checked"],
                "obligations": ["prove recurrence for all n", "determine minimal recurrence", "factor characteristic polynomial over Q", "classify dominant roots and degeneracy"],
                "tools": ["Sage characteristic polynomial", "PARI factorization", "Lean recurrence theorem"],
                "charpoly": charpoly,
            })
            if order == 2:
                routes.append({
                    "route": "Lucas/Lehmer/Zsigmondy primitive divisor",
                    "why": "order-2 recurrence suggests Lucas-type classification pressure",
                    "applicability_conditions": ["integer recurrence", "nonzero discriminant", "nondegenerate alpha/beta ratio not root of unity", "exclude Bilu-Hanrot-Voutier exceptional n"],
                    "obligations": ["compute discriminant", "test nondegeneracy", "prove integer Lucas normalization", "list primitive divisor exceptions"],
                    "tools": ["Sage number field roots", "PARI znorder checks"],
                })
        if div and div.get("strong_divisibility_score", 0) > 0.8:
            routes.append({
                "route": "strong divisibility / rank of apparition",
                "why": "gcd(a_m,a_n)=a_gcd(m,n) pressure is high",
                "applicability_conditions": ["sequence has nonzero terms", "gcd law survives extended terms", "primitive prime divisor behavior checked"],
                "obligations": ["prove strong gcd identity", "define rank of apparition z(p)", "prove p divides a_n iff z(p)|n for admissible p"],
                "tools": ["PARI prime scans", "Lean gcd induction"],
            })
        if val and val.get("lte_candidates"):
            routes.append({
                "route": "LTE / p-adic lifting",
                "why": "valuation profiles match affine v_p(n)+c behavior",
                "applicability_conditions": ["base congruence conditions satisfy LTE", "p odd or 2-adic exceptional branch handled", "terms expressible as x^n-y^n or x^n+y^n"],
                "obligations": ["derive exact term factorization", "state LTE branch", "handle p=2 separately", "prove observed valuation formula"],
                "tools": ["PARI valuation scans", "Lean Nat.Prime valuation lemmas"],
            })
        if poly:
            routes.append({
                "route": "finite difference / polynomial integer-valued basis",
                "why": f"degree-{poly.get('degree')} polynomial law detected",
                "applicability_conditions": ["constant finite difference persists", "integer-valued basis coefficients verified", "not merely early-prefix interpolation"],
                "obligations": ["prove d-th finite difference constant", "rewrite in binomial coefficient basis", "prove formula by induction"],
                "tools": ["SymPy interpolation", "Lean finite difference induction"],
            })
        if engines.get("factorization", {}).get("square_terms"):
            routes.append({
                "route": "Diophantine square/subsequence obstruction",
                "why": "square terms detected inside sequence; may indicate Pell/norm structure or rare exceptions",
                "applicability_conditions": ["square pattern survives extension", "index set classified", "not a random finite accident"],
                "obligations": ["solve a_n = y^2", "reduce to Pell/norm equation if possible", "prove completeness of square indices"],
                "tools": ["Sage integral points", "PARI bnfisintnorm"],
            })
        return routes


class ProofObligationCompiler:
    def compile(self, hypotheses: List[Hypothesis], engines: Dict[str, Any]) -> List[Dict[str, Any]]:
        out: List[Dict[str, Any]] = []
        for h in hypotheses:
            obs = list(h.proof_obligations)
            for r in h.theorem_routes:
                obs.extend(r.get("obligations", []))
            # Deduplicate preserving order.
            seen = set()
            obs2 = []
            for o in obs:
                if o not in seen:
                    seen.add(o)
                    obs2.append(o)
            out.append({
                "hypothesis": h.name,
                "claim_class": h.claim_class,
                "minimum_formal_statement": self._formal_statement(h, engines),
                "obligations": obs2,
                "lean_strategy": self._lean_strategy(h, obs2),
                "referee_target": obs2[0] if obs2 else "find exact invariant first",
            })
        return out

    def _formal_statement(self, h: Hypothesis, engines: Dict[str, Any]) -> str:
        if h.name == "exact_linear_recurrence":
            rec = engines.get("linear_recurrence", {})
            return f"For all n >= {rec.get('order','r')}, a_n = sum_i c_i a_(n-i) with coefficients {rec.get('coefficients','?')}."
        if h.name == "polynomial_law":
            poly = engines.get("polynomial", {})
            return f"For all n in the object domain, a_n equals the integer-valued polynomial {poly.get('polynomial','P(n)')}."
        if h.name == "strong_divisibility":
            return "For all m,n >= 1, gcd(a_m,a_n)=a_gcd(m,n), after excluding zero/sign normalization cases."
        return h.claim

    def _lean_strategy(self, h: Hypothesis, obs: List[str]) -> List[str]:
        return [
            "Define the object from its source law, not from observed terms.",
            "Prove the first invariant as a theorem with all side conditions explicit.",
            "Only then import downstream theorem route; do not formalize the report prose.",
        ] + [f"Obligation: {o}" for o in obs[:8]]

# ---------------------------------------------------------------------------
# Sequence engines
# ---------------------------------------------------------------------------


class SequenceEngines:
    def analyze(self, seq: Sequence[int], label: str = "object") -> Dict[str, Any]:
        seq = [int(x) for x in seq]
        return {
            "basic": self.basic(seq),
            "linear_recurrence": self.linear_recurrence(seq),
            "polynomial": self.polynomial(seq),
            "modular": self.modular(seq),
            "padic": self.padic(seq),
            "divisibility": self.divisibility(seq),
            "factorization": self.factorization(seq),
            "transforms": self.transforms(seq),
        }

    def basic(self, seq: Sequence[int]) -> Dict[str, Any]:
        nz = [x for x in seq if x != 0]
        return {
            "length": len(seq),
            "first_terms": list(seq[:20]),
            "sha256": sha256_text(",".join(map(str, seq))),
            "min": min(seq) if seq else None,
            "max": max(seq) if seq else None,
            "gcd_all": gcd_list(seq),
            "zeros": len(seq) - len(nz),
            "monotone_non_decreasing": all(seq[i] <= seq[i+1] for i in range(len(seq)-1)),
            "sign_pattern": "nonnegative" if all(x >= 0 for x in seq) else "mixed_or_negative",
        }

    def linear_recurrence(self, seq: Sequence[int]) -> Optional[Dict[str, Any]]:
        coeffs = berlekamp_massey_rational(seq, max_order=min(12, max(1, len(seq)//2)))
        if not coeffs:
            return None
        order = len(coeffs)
        pred = recurrence_predict(seq[:order], coeffs, len(seq))
        holds = all(pred[i] == seq[i] for i in range(len(seq)))
        charpoly = companion_characteristic(coeffs)
        gf = rational_generating_function_from_recurrence(seq, coeffs)
        return {
            "order": order,
            "coefficients": [str(c) for c in coeffs],
            "holds_on_prefix": holds,
            "characteristic_polynomial": charpoly,
            "rational_generating_function": gf,
            "next_terms_from_recurrence": [str(x) for x in recurrence_predict(seq[:order], coeffs, len(seq)+8)[len(seq):]],
            "compression_score": round(max(0.0, 1.0 - (order * 2) / max(1, len(seq))), 4),
        }

    def polynomial(self, seq: Sequence[int]) -> Optional[Dict[str, Any]]:
        return polynomial_fit_degree(seq)

    def modular(self, seq: Sequence[int]) -> Dict[str, Any]:
        primes = primes_upto(43)
        periods = []
        for m in primes + [4, 8, 9, 16, 25, 27, 32, 49]:
            p = modular_period(seq, m)
            if p:
                periods.append({"modulus": m, "period": p})
        collisions = []
        for m in primes[:10]:
            residues = Counter([x % m for x in seq])
            missing = [r for r in range(m) if residues[r] == 0]
            if missing:
                collisions.append({"modulus": m, "missing_residues": missing[:20], "missing_count": len(missing)})
        return {"periods": periods, "missing_residue_profiles": collisions}

    def padic(self, seq: Sequence[int]) -> Dict[str, Any]:
        primes = primes_upto(19)
        profiles = {}
        lte_candidates = []
        for p in primes:
            vals = [valuation(x, p) for x in seq]
            finite = [v for v in vals if v is not None]
            if finite and max(finite) > 0:
                profiles[str(p)] = vals
                # Check simple LTE-like v_p(a_n) = v_p(n + shift) + c over nonzero valuations.
                for shift in range(0, 4):
                    candidate = []
                    ok_count = 0
                    for i, v in enumerate(vals):
                        if v is None:
                            candidate.append(None)
                            continue
                        vn = valuation(i + shift, p) if i + shift != 0 else None
                        candidate.append(vn)
                    pairs = [(v, candidate[i]) for i, v in enumerate(vals) if v is not None and candidate[i] is not None]
                    if len(pairs) >= max(5, len(seq)//3):
                        diffs = [a-b for a, b in pairs]
                        common = Counter(diffs).most_common(1)[0]
                        if common[1] / len(diffs) >= 0.75 and max(finite) >= 2:
                            ok_count = common[1]
                            lte_candidates.append({"p": p, "index_shift": shift, "formula": f"v_{p}(a_n) ~= v_{p}(n+{shift}) + {common[0]}", "support": ok_count, "tested": len(diffs)})
        return {"valuation_profiles": profiles, "lte_candidates": lte_candidates}

    def divisibility(self, seq: Sequence[int]) -> Dict[str, Any]:
        # Index convention: a_0..; strong divisibility usually starts at 1. Test both offsets.
        result: Dict[str, Any] = {"strong_divisibility_score": 0.0, "offsets": []}
        for offset in [0, 1]:
            checks = 0
            hits = 0
            failures = []
            n = len(seq)
            for i in range(offset, n):
                for j in range(offset, n):
                    gi = math.gcd(i - offset + 1, j - offset + 1)
                    k = offset + gi - 1
                    if 0 <= k < n and seq[i] != 0 and seq[j] != 0:
                        checks += 1
                        lhs = abs(math.gcd(seq[i], seq[j]))
                        rhs = abs(seq[k])
                        if lhs == rhs:
                            hits += 1
                        elif len(failures) < 10:
                            failures.append({"i": i, "j": j, "lhs_gcd": lhs, "rhs_term_index": k, "rhs": rhs})
            score = hits / checks if checks else 0.0
            result["offsets"].append({"offset": offset, "checks": checks, "hits": hits, "score": round(score, 4), "failures": failures})
            result["strong_divisibility_score"] = max(result["strong_divisibility_score"], score)
        return result

    def factorization(self, seq: Sequence[int]) -> Dict[str, Any]:
        facts = []
        square_terms = []
        prime_terms = []
        for i, a in enumerate(seq[:80]):
            if a != 0:
                fa = factorint(a)
                facts.append({"index": i, "value": a, "factorization": fa})
                if is_square(abs(a)):
                    square_terms.append({"index": i, "value": a})
                if abs(a) > 1 and len([p for p in fa if p > 1]) == 1 and sum(fa.values()) == 1:
                    prime_terms.append({"index": i, "value": a})
        return {"first_factorizations": facts[:30], "square_terms": square_terms, "prime_terms": prime_terms[:20]}

    def transforms(self, seq: Sequence[int]) -> Dict[str, Any]:
        transforms = {}
        if len(seq) >= 3:
            transforms["first_difference_recurrence"] = self.linear_recurrence(differences(seq))
        if all(x != 0 for x in seq) and len(seq) >= 4:
            ratios = []
            for i in range(len(seq)-1):
                ratios.append(str(Fraction(seq[i+1], seq[i])))
            transforms["successive_ratios_first"] = ratios[:20]
        absseq = [abs(x) for x in seq]
        if absseq != list(seq):
            transforms["absolute_sequence_recurrence"] = self.linear_recurrence(absseq)
        return transforms

# ---------------------------------------------------------------------------
# Adversarial falsifier and scoring
# ---------------------------------------------------------------------------


class AdversarialFalsifier:
    def attack(self, seq: Sequence[int], engines: Dict[str, Any]) -> Dict[str, Any]:
        attacks = {
            "prefix_stability": self.prefix_stability(seq),
            "holdout_prediction": self.holdout_prediction(seq, engines),
            "transform_stability": self.transform_stability(seq),
            "fake_family_collision": self.fake_family_collision(seq, engines),
            "counterexample_search": self.counterexample_search(seq, engines),
        }
        return attacks

    def prefix_stability(self, seq: Sequence[int]) -> Dict[str, Any]:
        n = len(seq)
        recs = []
        for cut in range(max(4, n//2), n+1):
            coeffs = berlekamp_massey_rational(seq[:cut], max_order=min(12, cut//2))
            recs.append({"prefix_len": cut, "order": len(coeffs) if coeffs else None, "coefficients": [str(c) for c in coeffs] if coeffs else None})
        signatures = Counter(stable_json(r.get("coefficients")) for r in recs if r.get("coefficients"))
        stable = bool(signatures and signatures.most_common(1)[0][1] >= max(2, len(recs) - 1))
        return {"stable": stable, "prefix_recurrences": recs, "dominant_signature_count": signatures.most_common(1)[0][1] if signatures else 0}

    def holdout_prediction(self, seq: Sequence[int], engines: Dict[str, Any]) -> Dict[str, Any]:
        n = len(seq)
        if n < 8:
            return {"status": "too_short"}
        split = max(4, int(n * 0.7))
        coeffs = berlekamp_massey_rational(seq[:split], max_order=min(10, split//2))
        if not coeffs:
            return {"status": "no_train_recurrence"}
        pred = recurrence_predict(seq[:len(coeffs)], coeffs, n)
        hits = sum(1 for i in range(split, n) if pred[i] == seq[i])
        total = n - split
        return {"status": "tested", "train_len": split, "order": len(coeffs), "holdout_hits": hits, "holdout_total": total, "holdout_exact_rate": hits / total if total else None, "coefficients": [str(c) for c in coeffs]}

    def transform_stability(self, seq: Sequence[int]) -> Dict[str, Any]:
        out = {}
        if len(seq) >= 8:
            trimmed = seq[1:]
            out["drop_first_recurrence"] = self._rec_sig(trimmed)
            out["drop_last_recurrence"] = self._rec_sig(seq[:-1])
            out["even_subsequence_recurrence"] = self._rec_sig(seq[::2])
            out["odd_subsequence_recurrence"] = self._rec_sig(seq[1::2])
            out["first_difference_recurrence"] = self._rec_sig(differences(seq))
        return out

    def _rec_sig(self, seq: Sequence[int]) -> Dict[str, Any]:
        coeffs = berlekamp_massey_rational(seq, max_order=min(10, max(1, len(seq)//2)))
        return {"order": len(coeffs) if coeffs else None, "coefficients": [str(c) for c in coeffs] if coeffs else None, "length": len(seq)}

    def fake_family_collision(self, seq: Sequence[int], engines: Dict[str, Any]) -> Dict[str, Any]:
        """Generate fake sequences with same length/range-ish and see if detectors over-fire."""
        n = len(seq)
        if n < 8:
            return {"status": "too_short"}
        rng = random.Random(1337 + n + sum(abs(x) for x in seq[:10]))
        maxabs = max(1, max(abs(x) for x in seq))
        target_has_rec = engines.get("linear_recurrence") is not None
        collisions = 0
        trials = 80
        orders = []
        for _ in range(trials):
            fake = [rng.randint(-maxabs, maxabs) for _ in range(n)]
            coeffs = berlekamp_massey_rational(fake, max_order=min(6, n//3))
            if coeffs:
                collisions += 1
                orders.append(len(coeffs))
        return {"trials": trials, "random_recurrence_collisions": collisions, "target_has_recurrence": target_has_rec, "collision_rate": collisions / trials, "orders": orders[:20]}

    def counterexample_search(self, seq: Sequence[int], engines: Dict[str, Any]) -> Dict[str, Any]:
        rec = engines.get("linear_recurrence")
        if not rec:
            return {"status": "no_primary_law"}
        coeffs = [Fraction(s) for s in rec["coefficients"]]
        order = len(coeffs)
        extension = recurrence_predict(seq[:order], coeffs, len(seq) + 30)
        integral = all(x.denominator == 1 for x in extension)
        return {"status": "extended", "extended_terms": [str(x) for x in extension[len(seq):]], "integral_extension": integral}


class HypothesisScorer:
    def build(self, seq: Sequence[int], engines: Dict[str, Any], falsification: Dict[str, Any], routes: List[Dict[str, Any]]) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        rec = engines.get("linear_recurrence")
        if rec:
            f_hold = falsification.get("holdout_prediction", {})
            hold_rate = f_hold.get("holdout_exact_rate")
            prefix_stable = falsification.get("prefix_stability", {}).get("stable", False)
            compression = float(rec.get("compression_score", 0))
            score = 50 + 40 * compression + (20 if prefix_stable else 0) + (10 * hold_rate if isinstance(hold_rate, (int, float)) else 0)
            hyps.append(Hypothesis(
                name="exact_linear_recurrence",
                claim=f"Observed prefix is governed by an exact order-{rec['order']} rational linear recurrence.",
                claim_class="COMP",
                score=round(score, 3),
                evidence=rec,
                proof_obligations=["prove recurrence from source definition", "prove minimality or demote to non-minimal recurrence", "classify characteristic polynomial and degeneracies"],
                theorem_routes=[r for r in routes if "recurrence" in r["route"] or "Lucas" in r["route"]],
                attack_surface=["finite prefix may be overfit", "recurrence may be non-minimal", "closed form may be degenerate"],
                falsification={"holdout": f_hold, "prefix_stability": falsification.get("prefix_stability")},
            ))
        poly = engines.get("polynomial")
        if poly:
            degree = int(poly.get("degree", 99))
            score = max(10, 95 - 3 * degree)
            hyps.append(Hypothesis(
                name="polynomial_law",
                claim=f"Observed prefix is exactly degree-{degree} polynomial in n.",
                claim_class="COMP",
                score=score,
                evidence=poly,
                proof_obligations=["prove constant finite difference persists", "rewrite in binomial integer-valued basis", "prove by induction from source object"],
                theorem_routes=[r for r in routes if "finite difference" in r["route"]],
                attack_surface=["finite interpolation can always fit short prefixes", "degree may be artifact of insufficient terms"],
                falsification={"prefix_stability": falsification.get("prefix_stability")},
            ))
        div = engines.get("divisibility", {})
        if div.get("strong_divisibility_score", 0) > 0.8:
            hyps.append(Hypothesis(
                name="strong_divisibility",
                claim="Sequence has high pressure toward strong divisibility gcd(a_m,a_n)=a_gcd(m,n).",
                claim_class="COMP",
                score=55 + 25 * float(div.get("strong_divisibility_score", 0)),
                evidence=div,
                proof_obligations=["prove strong gcd identity", "classify zero/sign exceptions", "derive rank-of-apparition law"],
                theorem_routes=[r for r in routes if "divisibility" in r["route"]],
                attack_surface=["offset convention may fake success", "zero terms can trivialize gcd", "finite prefix may miss exceptions"],
            ))
        if engines.get("padic", {}).get("lte_candidates"):
            hyps.append(Hypothesis(
                name="padic_lifting_law",
                claim="Valuation profiles show LTE-like lifting pressure.",
                claim_class="COMP",
                score=min(75, 50 + 3 * len(engines["padic"]["lte_candidates"])),
                evidence=engines["padic"],
                proof_obligations=["derive term as x^n-y^n or equivalent", "state exact LTE branch", "handle p=2 exceptions"],
                theorem_routes=[r for r in routes if "LTE" in r["route"]],
                attack_surface=["valuation formula may fit only dense subsequence", "2-adic branch often exceptional"],
            ))
        # Novelty/negative pressure: modular missing residues can itself be useful.
        miss = engines.get("modular", {}).get("missing_residue_profiles", [])
        if miss:
            hyps.append(Hypothesis(
                name="modular_obstruction_profile",
                claim="Sequence avoids residue classes modulo small primes; possible obstruction or character constraint.",
                claim_class="COMP",
                score=35 + min(30, len(miss) * 3),
                evidence={"missing_profiles": miss[:12]},
                proof_obligations=["prove residue avoidance from source law", "separate true obstruction from finite sample miss", "lift local constraints to global theorem route if possible"],
                theorem_routes=[],
                attack_surface=["small sample residue misses are common", "local obstruction may not globalize"],
            ))
        hyps.sort(key=lambda h: h.score, reverse=True)
        return hyps

# ---------------------------------------------------------------------------
# Object analysis orchestrator
# ---------------------------------------------------------------------------


class OracleNTOS:
    def __init__(self, out_dir: Path, db_path: Optional[Path] = None):
        self.out_dir = ensure_dir(out_dir)
        self.db_path = db_path or (self.out_dir / "oracle_nt_corpus.sqlite")
        self.corpus = CorpusStore(self.db_path)
        self.engines = SequenceEngines()
        self.router = TheoremRouter()
        self.falsifier = AdversarialFalsifier()
        self.scorer = HypothesisScorer()
        self.compiler = ProofObligationCompiler()
        self.tribunal = ExternalTribunal(self.out_dir / "handoffs")

    def make_sequence_object(self, seq: Sequence[int], label: str) -> NTObject:
        payload = {"sequence": list(map(int, seq))}
        object_id = sha256_text("sequence:" + ",".join(map(str, seq)))[:24]
        obj = NTObject(object_id=object_id, kind="sequence", label=label, payload=payload)
        self.corpus.upsert_object(obj)
        return obj

    def analyze_sequence(self, seq: Sequence[int], label: str, round_no: int = 1, binary: Optional[str] = None, write: bool = True) -> Dict[str, Any]:
        obj = self.make_sequence_object(seq, label)
        prior = self.corpus.prior_context(obj.object_id)
        engines = self.engines.analyze(seq, label)
        routes = self.router.route_sequence(seq, engines)
        falsification = self.falsifier.attack(seq, engines)
        hyps = self.scorer.build(seq, engines, falsification, routes)
        obligations = self.compiler.compile(hyps, engines)
        rec_coeffs = [Fraction(s) for s in engines["linear_recurrence"]["coefficients"]] if engines.get("linear_recurrence") else None
        tribunal = self.tribunal.write_sequence_handoffs(seq, label, rec_coeffs)
        packet = self.build_kbk_packet(round_no, binary or self.default_binary(hyps, engines), hyps, falsification, routes, prior)
        report = {
            "version": VERSION,
            "created_at": utc_now(),
            "object": dataclasses.asdict(obj),
            "prior_context": prior,
            "binary": binary or self.default_binary(hyps, engines),
            "engines": engines,
            "falsification": falsification,
            "theorem_routes": routes,
            "hypotheses": [dataclasses.asdict(h) for h in hyps],
            "proof_obligations": obligations,
            "external_tribunal": tribunal,
            "kbk_packet": dataclasses.asdict(packet),
            "jigsaw": self.jigsaw(hyps, falsification, obligations),
            "gth": self.gth_packet(hyps, obligations, falsification),
        }
        run_id = self.corpus.save_run(obj.object_id, report)
        report["run_id"] = run_id
        self.corpus.save_packet(obj.object_id, run_id, report["kbk_packet"])
        if write:
            self.write_report(report, self.out_dir / f"{label}_round{round_no}")
        return report

    def default_binary(self, hyps: List[Hypothesis], engines: Dict[str, Any]) -> str:
        if not hyps:
            return "hidden structure OR insufficient coordinates"
        top = hyps[0]
        if top.name == "exact_linear_recurrence":
            return "true recurrence law OR finite-prefix artifact"
        if top.name == "polynomial_law":
            return "polynomial law OR interpolation artifact"
        if top.name == "strong_divisibility":
            return "strong divisibility law OR offset coincidence"
        if top.name == "padic_lifting_law":
            return "LTE lifting law OR sparse valuation coincidence"
        return f"{top.name} OR artifact"

    def build_kbk_packet(self, round_no: int, binary: str, hyps: List[Hypothesis], falsification: Dict[str, Any], routes: List[Dict[str, Any]], prior: Dict[str, Any]) -> RoundPacket:
        killed = []
        notes = []
        hold = falsification.get("holdout_prediction", {})
        fake = falsification.get("fake_family_collision", {})
        if hold.get("status") == "tested" and hold.get("holdout_exact_rate", 0) < 1.0:
            killed.append("train-prefix recurrence as global law")
            notes.append("Holdout prediction failed; recurrence demoted unless source definition proves it.")
        if fake.get("collision_rate", 0) > 0.25:
            notes.append("Detector has high fake-family collision rate; confidence must come from proof route, not detector score.")
        top = hyps[0] if hyps else None
        if top:
            verdict = "ESCALATION" if top.score < 85 else "CLOSURE_CANDIDATE"
            missing = top.proof_obligations[0] if top.proof_obligations else "exact invariant proof"
            next_binary = self.next_binary_from_hypothesis(top, falsification)
            jigsaw_piece = f"Placed face piece: {top.name} at score {top.score}."
        else:
            verdict = "KILL"
            missing = "better coordinates or more terms"
            next_binary = "new coordinates OR genuine null"
            jigsaw_piece = "No decisive face piece placed."
        gth_ready = bool(top and top.score >= 92 and not killed and len(routes) >= 1)
        return RoundPacket(round_no=round_no, binary=binary, verdict=verdict, strongest_hypothesis=top.name if top else None, killed_routes=killed, next_binary=next_binary, jigsaw_piece=jigsaw_piece, missing_piece=missing, gth_ready=gth_ready, notes=notes)

    def next_binary_from_hypothesis(self, top: Hypothesis, falsification: Dict[str, Any]) -> str:
        if top.name == "exact_linear_recurrence":
            return "minimal recurrence with nondegenerate characteristic roots OR reducible/degenerate recurrence"
        if top.name == "strong_divisibility":
            return "rank-of-apparition law OR finite gcd coincidence"
        if top.name == "padic_lifting_law":
            return "derivable LTE factorization OR valuation coincidence"
        if top.name == "modular_obstruction_profile":
            return "true local obstruction OR finite sample residue miss"
        return "theorem route closes OR object needs richer coordinates"

    def jigsaw(self, hyps: List[Hypothesis], falsification: Dict[str, Any], obligations: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not hyps:
            return {"level": "not_visible", "picture": "No picture yet", "missing_pieces": ["more terms", "new coordinates", "object definition"]}
        top = hyps[0]
        hold = falsification.get("holdout_prediction", {})
        prefix = falsification.get("prefix_stability", {})
        points = 0
        reasons = []
        if top.score >= 85:
            points += 2; reasons.append("top hypothesis high measured score")
        if hold.get("holdout_exact_rate") == 1.0:
            points += 2; reasons.append("held-out terms survive")
        if prefix.get("stable"):
            points += 1; reasons.append("prefix stability survives")
        if top.theorem_routes:
            points += 2; reasons.append("known theorem route exists")
        level = "jigsaw_visible" if points >= 5 else "forming" if points >= 3 else "not_visible"
        missing = []
        if obligations:
            missing.append(obligations[0].get("referee_target", "proof target"))
        missing.extend(top.attack_surface[:3])
        return {"level": level, "score": points, "picture": top.claim, "reasons": reasons, "missing_pieces": missing}

    def gth_packet(self, hyps: List[Hypothesis], obligations: List[Dict[str, Any]], falsification: Dict[str, Any]) -> Dict[str, Any]:
        if not hyps:
            return {"fires": False, "reason": "no surviving hypothesis"}
        top = hyps[0]
        jig = self.jigsaw(hyps, falsification, obligations)
        fires = jig["level"] == "jigsaw_visible" and top.score >= 90
        return {
            "fires": fires,
            "claim": top.claim if fires else "No GTH fire; picture not yet earned.",
            "stake": f"Best measured hypothesis is {top.name} with score {top.score}; falsification status and theorem route determine next climb.",
            "attack_surface": top.attack_surface,
            "referee_target": obligations[0]["referee_target"] if obligations else "exact theorem route",
        }

    def write_report(self, report: Dict[str, Any], stem: Path) -> None:
        ensure_dir(stem.parent)
        json_path = Path(str(stem) + ".json")
        md_path = Path(str(stem) + ".md")
        kbk_path = Path(str(stem) + ".kbk.json")
        json_path.write_text(stable_json(report))
        kbk_path.write_text(stable_json(report["kbk_packet"]))
        md_path.write_text(self.markdown_report(report))

    def markdown_report(self, r: Dict[str, Any]) -> str:
        top = r["hypotheses"][0] if r["hypotheses"] else None
        lines = [
            f"# Oracle NT OS V3 Report — {r['object']['label']}",
            "",
            f"Version: `{VERSION}`",
            f"Created: `{r['created_at']}`",
            f"Object ID: `{r['object']['object_id']}`",
            f"Binary: **{r['binary']}**",
            "",
            "## Gun-to-head packet",
            f"Fires: **{r['gth']['fires']}**",
            f"Claim: {r['gth']['claim']}",
            f"Referee target: {r['gth']['referee_target']}",
            "",
            "## Jigsaw",
            f"Level: **{r['jigsaw']['level']}** | Score: `{r['jigsaw'].get('score')}`",
            f"Picture: {r['jigsaw']['picture']}",
            "Missing pieces:",
        ]
        lines += [f"- {m}" for m in r["jigsaw"].get("missing_pieces", [])]
        lines += ["", "## Top hypotheses"]
        for h in r["hypotheses"][:8]:
            lines += [f"### {h['name']} — score {h['score']}", f"Claim class: `{h['claim_class']}`", h["claim"], "Proof obligations:"]
            lines += [f"- {o}" for o in h.get("proof_obligations", [])]
            lines += ["Attack surface:"] + [f"- {a}" for a in h.get("attack_surface", [])] + [""]
        lines += ["## Theorem routes"]
        for route in r["theorem_routes"]:
            lines += [f"### {route['route']}", f"Why: {route['why']}", "Applicability:"]
            lines += [f"- {x}" for x in route.get("applicability_conditions", [])]
            lines += ["Obligations:"] + [f"- {x}" for x in route.get("obligations", [])] + [""]
        lines += ["## Falsification"]
        lines += ["```json", stable_json(r["falsification"]), "```", ""]
        lines += ["## KBK packet", "```json", stable_json(r["kbk_packet"]), "```", ""]
        lines += ["## External tribunal", "```json", stable_json(r["external_tribunal"]), "```", ""]
        return "\n".join(lines)

    def run_rounds(self, seq: Sequence[int], label: str, rounds: int = 5) -> Dict[str, Any]:
        binary = None
        reports = []
        for r in range(1, rounds + 1):
            report = self.analyze_sequence(seq, label=f"{label}_r{r}", round_no=r, binary=binary, write=True)
            reports.append(report)
            binary = report["kbk_packet"]["next_binary"]
            # For sequence-only runs, the data does not mutate. The binary state does.
        summary = {
            "version": VERSION,
            "created_at": utc_now(),
            "label": label,
            "rounds": rounds,
            "final_packet": reports[-1]["kbk_packet"],
            "final_gth": reports[-1]["gth"],
            "round_reports": [r["run_id"] for r in reports],
        }
        (self.out_dir / f"{label}_oracle_run_summary.json").write_text(stable_json(summary))
        (self.out_dir / f"{label}_oracle_run_summary.md").write_text("# Oracle run summary\n\n```json\n" + stable_json(summary) + "\n```\n")
        return summary

# ---------------------------------------------------------------------------
# CRT covering-sieve lab
# ---------------------------------------------------------------------------


class CRTCoverLab:
    def __init__(self, out_dir: Path):
        self.out_dir = ensure_dir(out_dir)

    def analyze(self, b1: int, b2: int, c: int, max_modulus: int = 180) -> Dict[str, Any]:
        primes = [p for p in primes_upto(max_modulus) if math.gcd(p, b1*b2) == 1 and p > 2]
        rows = []
        saturation_curve = []
        global_covered = set()
        grid_size = 0
        # Use lcm of multiplicative orders to define finite torus for each prime; scan zeros of b1^k b2^l + c mod p.
        for p in primes:
            ord1 = self.multiplicative_order(b1 % p, p)
            ord2 = self.multiplicative_order(b2 % p, p)
            if not ord1 or not ord2:
                continue
            zeros = []
            for k in range(ord1):
                a = pow(b1, k, p)
                for ell in range(ord2):
                    if (a * pow(b2, ell, p) + c) % p == 0:
                        zeros.append((k, ell))
            coverage = len(zeros) / (ord1 * ord2)
            rows.append({"p": p, "ord_b1": ord1, "ord_b2": ord2, "zeros": zeros[:200], "zero_count": len(zeros), "torus_size": ord1*ord2, "coverage": coverage})
        # Combined coverage over a projected torus based on first useful primes.
        useful = [r for r in rows if r["zero_count"] > 0][:8]
        if useful:
            K = lcm_list([r["ord_b1"] for r in useful])
            L = lcm_list([r["ord_b2"] for r in useful])
            if K * L <= 200000:
                covered = set()
                for idx, r in enumerate(useful):
                    for k in range(K):
                        for ell in range(L):
                            if (k % r["ord_b1"], ell % r["ord_b2"]) in set(map(tuple, r["zeros"])):
                                covered.add((k, ell))
                    saturation_curve.append({"prime_index": idx+1, "p": r["p"], "covered": len(covered), "total": K*L, "coverage": len(covered)/(K*L)})
                global_covered = covered
                grid_size = K * L
        report = {
            "expression": f"{b1}^k * {b2}^l + ({c})",
            "prime_rows": rows,
            "useful_prime_count": len(useful),
            "saturation_curve": saturation_curve,
            "finite_torus_total": grid_size,
            "finite_torus_covered": len(global_covered),
            "finite_torus_coverage": len(global_covered)/grid_size if grid_size else None,
            "verdict": self.verdict(len(global_covered), grid_size),
            "proof_obligations": [
                "If finite torus coverage < 1, prove uncovered class lifts or find additional modulus family.",
                "If finite torus coverage = 1, test lift-composability across prime powers and CRT compatibility.",
                "Separate finite cover from infinite prime-forcing; terminal-column certificates do not automatically lift.",
            ],
        }
        (self.out_dir / "crt_lab_report.json").write_text(stable_json(report))
        (self.out_dir / "crt_lab_report.md").write_text(self.markdown(report))
        return report

    def multiplicative_order(self, a: int, p: int) -> Optional[int]:
        if math.gcd(a, p) != 1:
            return None
        cur = 1
        for k in range(1, p):
            cur = (cur * a) % p
            if cur == 1:
                return k
        return None

    def verdict(self, covered: int, total: int) -> str:
        if not total:
            return "NO_FINITE_TORUS_BUILT"
        if covered == total:
            return "FINITE_COVER_CANDIDATE_REQUIRES_LIFT_TEST"
        return "FINITE_TORUS_NOT_COVERED_OBSTRUCTION_FOUND"

    def markdown(self, r: Dict[str, Any]) -> str:
        lines = [f"# CRT Cover Lab — `{r['expression']}`", "", f"Verdict: **{r['verdict']}**", f"Coverage: `{r['finite_torus_covered']} / {r['finite_torus_total']}` = `{r['finite_torus_coverage']}`", "", "## Saturation curve"]
        for s in r["saturation_curve"]:
            lines.append(f"- p={s['p']}: {s['covered']}/{s['total']} = {s['coverage']:.6f}")
        lines += ["", "## Proof obligations"] + [f"- {x}" for x in r["proof_obligations"]]
        return "\n".join(lines) + "\n"

# ---------------------------------------------------------------------------
# Benchmark gauntlet
# ---------------------------------------------------------------------------


class BenchmarkGauntlet:
    def __init__(self, out_dir: Path):
        self.out_dir = ensure_dir(out_dir)
        self.os = OracleNTOS(out_dir / "benchmark_runs", out_dir / "benchmark_corpus.sqlite")

    def run(self) -> Dict[str, Any]:
        cases = self.cases()
        results = []
        for case in cases:
            report = self.os.analyze_sequence(case["seq"], case["label"], write=True)
            top_name = report["hypotheses"][0]["name"] if report["hypotheses"] else None
            routes = [r["route"] for r in report["theorem_routes"]]
            ok = self.evaluate(case, top_name, routes, report)
            results.append({"label": case["label"], "expected": case["expected"], "top": top_name, "routes": routes, "pass": ok, "gth": report["gth"]["fires"]})
        passed = sum(1 for r in results if r["pass"])
        summary = {"version": VERSION, "created_at": utc_now(), "passed": passed, "total": len(results), "results": results}
        (self.out_dir / "benchmark_summary.json").write_text(stable_json(summary))
        (self.out_dir / "benchmark_summary.md").write_text(self.markdown(summary))
        return summary

    def cases(self) -> List[Dict[str, Any]]:
        fib = [1,1]
        for _ in range(18):
            fib.append(fib[-1]+fib[-2])
        squares = [n*n for n in range(20)]
        powers2 = [2**n for n in range(20)]
        lucas = [2,1]
        for _ in range(18):
            lucas.append(lucas[-1]+lucas[-2])
        noisy_prefix = [1, 4, 9, 16, 25, 36, 1000, 64, 81, 100, 121, 144]
        return [
            {"label": "fib", "seq": fib, "expected": "recurrence"},
            {"label": "squares", "seq": squares, "expected": "polynomial"},
            {"label": "powers2", "seq": powers2, "expected": "recurrence"},
            {"label": "lucas", "seq": lucas, "expected": "recurrence_lucas_route"},
            {"label": "noisy_square_prefix", "seq": noisy_prefix, "expected": "avoid_overconfident_polynomial"},
        ]

    def evaluate(self, case: Dict[str, Any], top_name: Optional[str], routes: List[str], report: Dict[str, Any]) -> bool:
        exp = case["expected"]
        if exp == "recurrence":
            return top_name == "exact_linear_recurrence"
        if exp == "polynomial":
            return top_name in {"polynomial_law", "exact_linear_recurrence"} and bool(report["engines"].get("polynomial"))
        if exp == "recurrence_lucas_route":
            return top_name == "exact_linear_recurrence" and any("Lucas" in r for r in routes)
        if exp == "avoid_overconfident_polynomial":
            return not report["gth"]["fires"] and report["engines"].get("polynomial") is None
        return False

    def markdown(self, s: Dict[str, Any]) -> str:
        lines = ["# Oracle NT OS V3 Benchmark Gauntlet", "", f"Passed: **{s['passed']} / {s['total']}**", "", "| Case | Expected | Top | Pass | GTH |", "|---|---:|---:|---:|---:|"]
        for r in s["results"]:
            lines.append(f"| {r['label']} | {r['expected']} | {r['top']} | {r['pass']} | {r['gth']} |")
        return "\n".join(lines) + "\n"

# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def cmd_selftest(args: argparse.Namespace) -> None:
    out = Path(args.out)
    ensure_dir(out)
    osys = OracleNTOS(out)
    fib = [1,1,2,3,5,8,13,21,34,55,89,144]
    rep = osys.analyze_sequence(fib, "selftest_fib", write=True)
    assert rep["engines"]["linear_recurrence"] is not None, "Fibonacci recurrence not detected"
    assert rep["hypotheses"], "No hypotheses produced"
    bench = BenchmarkGauntlet(out / "gauntlet").run()
    assert bench["passed"] >= 4, f"Benchmark too weak: {bench['passed']}/{bench['total']}"
    crt = CRTCoverLab(out / "crt").analyze(2, 3, 1, 80)
    assert crt["verdict"] in {"FINITE_COVER_CANDIDATE_REQUIRES_LIFT_TEST", "FINITE_TORUS_NOT_COVERED_OBSTRUCTION_FOUND", "NO_FINITE_TORUS_BUILT"}
    print(stable_json({"selftest": "PASS", "version": VERSION, "out": str(out), "benchmark": bench["passed"], "benchmark_total": bench["total"]}))


def cmd_analyze_seq(args: argparse.Namespace) -> None:
    seq = parse_int_sequence(args.seq)
    osys = OracleNTOS(Path(args.out), Path(args.db) if args.db else None)
    rep = osys.analyze_sequence(seq, args.label, round_no=args.round, binary=args.binary, write=True)
    print(stable_json({"run_id": rep["run_id"], "object_id": rep["object"]["object_id"], "top": rep["hypotheses"][0]["name"] if rep["hypotheses"] else None, "gth_fires": rep["gth"]["fires"], "out": args.out}))


def cmd_run(args: argparse.Namespace) -> None:
    seq = parse_int_sequence(args.seq)
    osys = OracleNTOS(Path(args.out), Path(args.db) if args.db else None)
    summary = osys.run_rounds(seq, args.label, rounds=args.rounds)
    print(stable_json(summary))


def cmd_benchmark(args: argparse.Namespace) -> None:
    summary = BenchmarkGauntlet(Path(args.out)).run()
    print(stable_json(summary))


def cmd_crt_lab(args: argparse.Namespace) -> None:
    rep = CRTCoverLab(Path(args.out)).analyze(args.base1, args.base2, args.c, args.max_modulus)
    print(stable_json({"verdict": rep["verdict"], "coverage": rep["finite_torus_coverage"], "out": args.out}))


def cmd_corpus_list(args: argparse.Namespace) -> None:
    store = CorpusStore(Path(args.db))
    print(stable_json(store.list_objects()))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Oracle Number Theory OS V3")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("selftest")
    s.add_argument("--out", default="oracle_nt_v3_selftest_out")
    s.set_defaults(func=cmd_selftest)
    a = sub.add_parser("analyze-seq")
    a.add_argument("--seq", required=True)
    a.add_argument("--out", default="oracle_nt_v3_out")
    a.add_argument("--label", default="sequence")
    a.add_argument("--round", type=int, default=1)
    a.add_argument("--binary", default=None)
    a.add_argument("--db", default=None)
    a.set_defaults(func=cmd_analyze_seq)
    r = sub.add_parser("run")
    r.add_argument("--seq", required=True)
    r.add_argument("--out", default="oracle_nt_v3_run")
    r.add_argument("--label", default="object")
    r.add_argument("--rounds", type=int, default=5)
    r.add_argument("--db", default=None)
    r.set_defaults(func=cmd_run)
    b = sub.add_parser("benchmark")
    b.add_argument("--out", default="oracle_nt_v3_benchmark")
    b.set_defaults(func=cmd_benchmark)
    c = sub.add_parser("crt-lab")
    c.add_argument("--base1", type=int, required=True)
    c.add_argument("--base2", type=int, required=True)
    c.add_argument("--c", type=int, required=True)
    c.add_argument("--max-modulus", type=int, default=180)
    c.add_argument("--out", default="oracle_nt_v3_crt")
    c.set_defaults(func=cmd_crt_lab)
    cl = sub.add_parser("corpus-list")
    cl.add_argument("--db", required=True)
    cl.set_defaults(func=cmd_corpus_list)
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
