# Oracle Number Theory OS V3

This is an adversarial number-theory discovery workbench. It is built around one discipline: prose does not do the math. Engines measure, hostile tests attack, theorem routers classify, and the KBK packet determines the next binary.

## What V3 adds over V2

- Persistent SQLite corpus of objects, runs, hypotheses, killed routes, and KBK packets
- Multi-round Oracle runner with next-binary state propagation
- Hostile falsifier: prefix stability, holdout prediction, transform stability, random fake-family collision, extension counterexample search
- Theorem router: recurrence/companion matrix, Lucas-Lehmer-Zsigmondy, strong divisibility/rank of apparition, LTE, finite-difference polynomial, Diophantine square/norm routes
- Proof-obligation compiler with referee targets and Lean strategy notes
- Active external tribunal: detects Sage, PARI/GP, and Lean; executes when available; always writes handoff files
- CRT covering-sieve lab with finite torus coverage and saturation curve
- Benchmark gauntlet judged on route quality, not just script health
- Jigsaw and GTH packet generation, with proof debt separated from computational claims

## Quick start

```bash
python oracle_nt_os_v3.py selftest
```

Analyze a sequence:

```bash
python oracle_nt_os_v3.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib \
  --out out
```

Run five KBK rounds:

```bash
python oracle_nt_os_v3.py run \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib \
  --rounds 5 \
  --out out
```

CRT lab:

```bash
python oracle_nt_os_v3.py crt-lab --base1 2 --base2 3 --c 1 --max-modulus 180 --out crt_out
```

Benchmark gauntlet:

```bash
python oracle_nt_os_v3.py benchmark --out bench_out
```

Corpus listing:

```bash
python oracle_nt_os_v3.py corpus-list --db out/oracle_nt_corpus.sqlite
```

## Output files

Each analysis writes:

- `*.json`: full machine-readable report
- `*.md`: human dossier
- `*.kbk.json`: next-round packet
- `handoffs/*.sage`: Sage handoff
- `handoffs/*.gp`: PARI/GP handoff
- `handoffs/*.lean`: Lean proof-obligation skeleton
- `oracle_nt_corpus.sqlite`: persistent corpus

## Important limitation

This is discovery infrastructure, not a proof oracle. It refuses fake proof. It emits computational claims, theorem routes, attack surfaces, and exact proof obligations so the next step is sharp instead of vague.
