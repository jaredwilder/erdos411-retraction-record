# ORACLE R588 — Full #411 Python Attack

## Protocol

Python does the hard math. Assistant directs and summarizes.

## Chamber A — Cambie tail, t=1

Scanned primes

\[
p \le 20,000,000,\quad p\equiv 7\pmod 8.
\]

Tested candidate primes: `317,668`.

Hits:

```json
[
  {
    "p": 7,
    "n": 20,
    "phi_3p_minus_1": 8
  },
  {
    "p": 47,
    "n": 140,
    "phi_3p_minus_1": 48
  }
]
```

Verdict:

\[
\boxed{\phi(3p-1)=p+1\text{ in this chamber only for }p=7,47.}
\]

## Chamber B — Cambie tail, t >= 2

Scanned

\[
p \le 250,000,\quad 2\le t\le 14,\quad 4p^t\le 10^{22}.
\]

Cases tested: `16,810`.

Hits: `0`.

p-source births: `0`.

descent violations: `0`.

overshoots: `16,810`.

max orbit rows: `3`.

Verdict:

\[
\boxed{\text{No hits, no p-source births, no descent violations in this chamber.}}
\]

## Integrated #411 data picture

D-branch bounded chamber from prior Python/R580/R583 ledgers:

\[
\boxed{\varphi(m)=\frac23(m+1),\quad \frac{4m+1}3\text{ prime},\quad m<2^{64}\Rightarrow m\in\{5,35\}.}
\]

T-tail R588 chamber:

\[
\boxed{t=1,\ p\le 20,000,000: p\in\{7,47\}.}
\]

\[
\boxed{t\ge2,\ p\le 250,000,\ 4p^t\le10^{22}: \text{no hits.}}
\]

## GTH data statement

The hard-data victory is bounded, not infinite:

\[
\boxed{\textbf{The six-family picture survives every Python chamber run so far.}}
\]

The infinite theorem still requires symbolic D-law and T-law; Python has now produced the strongest bounded evidence and reusable certificates for both remaining gates.
