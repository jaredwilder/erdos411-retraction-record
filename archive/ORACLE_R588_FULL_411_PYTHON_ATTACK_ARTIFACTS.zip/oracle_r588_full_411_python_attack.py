# R588 was executed in ChatGPT python_user_visible. See JSON report for parameters and outputs.
