# ORACLE R582 — Python Data Oracle for Erdős #411 D-Branch

## Fixed target
Prime-filtered D-branch: `phi(m)=2(m+1)/3` and `(4m+1)/3` prime.

## Last jigsaw pieces needed for victory
1. **D1 finite chamber certificate**: close the prime-filtered branch below `2^64`.
2. **D2 adversarial CDC search**: hunt for `d>1` births with both complementary `p` and filter `P` prime.
3. **D3 death-pattern extraction**: record whether every birth dies by composite `p` or composite `P`.
4. **D4 infinite theorem**: prove prime-filtered CDC from the death pattern.

## Python data results
- Parent-extension artifact verified: `5` rows.
- Non-chain parent escape verified: `a=194635`, `E=197`, `p=989=23*43`.
- 2^64 chamber artifact verified: `solutions=0`, `div_hits=4`.
- All 2^64 chamber hits die by composite `p` or composite `P`.
- Independent Python CDC scan: `B_limit=500000`, `prime_limit=1500`, `prefixes_generated=38904`, `prefixes_tested=38493`, `birth_count=1`, `live_counterexamples=0`.

## Data verdict
- The finite theorem through `2^64-1` is the recordable result.
- The infinite victory condition is now exactly prime-filtered CDC: every `d>1` birth dies by composite `p` or composite `P`.
