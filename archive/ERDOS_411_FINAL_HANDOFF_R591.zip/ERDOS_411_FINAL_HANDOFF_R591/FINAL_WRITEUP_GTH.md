# Erdős #411 — Final R591 Handoff Writeup

**Date:** 2026-05-14  
**Status:** Gun-to-head final handoff for the bounded computational-theoretical victory.  
**Protocol:** Python does the hard math. Assistant directs, packages, and states the result.

---

# 0. GUN TO HEAD STATEMENT

\[
\boxed{\textbf{We have a real bounded computational-theoretical victory for Erdős #411.}}
\]

The earned victory is not vague:

\[
\boxed{
\varphi(m)=\frac23(m+1),\quad \frac{4m+1}3\text{ prime},\quad m<2^{64}
\Longrightarrow m\in\{5,35\}.
}
\]

And the Cambie tail chamber is killed by Python:

\[
\boxed{
p\le1,000,000,\quad 2\le t\le30,\quad 4p^t\le10^{50}
\Longrightarrow
g_k(2p^t)\ne4p^t.
}
\]

The \(t=1\) Cambie tail is covered by the D-ledger up to

\[
p < 24,595,658,764,946,068,820,
\]

with survivors

\[
\boxed{p=7,47.}
\]

**This is the handoff claim.**  
It is a bounded, certified, hard-data result supporting exactly the six known families

\[
2^a\cdot\{1,3,5,7,35,47\}.
\]

Do not call this the infinite symbolic proof of all of Erdős #411.  
Do call it a serious bounded resolution/certificate package for the two remaining exceptional channels.

---

# 1. Problem Frame

For \(g(n)=n+\varphi(n)\), Erdős #411 asks for eventual doubling relations

\[
g_{k+r}(n)=2g_k(n).
\]

The known \(r=2\) six-family spine is

\[
n=2^a u,\qquad a\ge1,\qquad u\in\{1,3,5,7,35,47\}.
\]

The remaining attack split used here is:

1. **D-branch:** the prime-filtered totient-defect equation

\[
\varphi(m)=\frac23(m+1),\qquad P=\frac{4m+1}3\text{ prime}.
\]

2. **Cambie tail:** the possible prime-power tail

\[
g_k(2p^t)=4p^t,\qquad p\equiv7\pmod8.
\]

---

# 2. D-Branch Theorem: Bounded Closure Through \(2^{64}\)

## Theorem D-R591

\[
\boxed{
\varphi(m)=\frac23(m+1),\quad \frac{4m+1}3\text{ prime},\quad m<2^{64}
\Longrightarrow m\in\{5,35\}.
}
\]

## Evidence

The prefix-window/divisor-pair engine was run through the 64-bit ceiling:

\[
M=2^{64}-1=18,446,744,073,709,551,615.
\]

The R580/R583 ledger recorded:

```text
solutions = 0
divisor hits = 4
```

The four divisor births all died by composite \(p\) or composite prime-filter \(P\).

This theorem is supported by:

- `r580_prefix_window_1e20_new.json`
- `oracle_r583_python_attacker_bounded_fast_report.json`
- `oracle_r582_python_data_oracle_report.json`
- `ERDOS_411_D_BRANCH_RECORDABLE_MATH_AND_CLOSURE_PLAN.md`

---

# 3. D-Branch Mathematics Worth Recording

The D-branch produced recordable mathematics independent of the computation.

## Prime-filter normalization

From

\[
\varphi(m)=\frac23(m+1),
\]

we get

\[
m+1=\frac32\varphi(m)
\]

and hence

\[
\frac{4m+1}3=2\varphi(m)-1.
\]

So the D-branch is exactly

\[
\boxed{
\varphi(m)=\frac23(m+1),\qquad 2\varphi(m)-1\text{ prime}.
}
\]

## Parent-defect formula

Write \(m=ap\), with \(p\) the largest prime factor. Define

\[
E(a)=\frac{3\varphi(a)-2a}2.
\]

Then

\[
\boxed{
p=1+\frac{a+1}{E(a)}.
}
\]

Therefore every largest-prime extension requires

\[
\boxed{E(a)\mid a+1.}
\]

## Divisor-descent identity

For \(a=Br\), define

\[
A=E(B)=\frac{3\varphi(B)-2B}2.
\]

Then

\[
E(Br)=A(r-1)-B.
\]

If

\[
d=E(Br)
\]

and

\[
d\mid Br+1,
\]

then

\[
\boxed{
d\mid B^2+AB+A.
}
\]

Writing

\[
dT=B^2+AB+A,
\]

the complementary child pair is

\[
\boxed{
r=1+\frac{B+d}A,\qquad
p=1+\frac{B+T}A.
}
\]

The chain branch is \(d=1\).  
The non-chain branch is \(d>1\), and all tested genuine non-chain births die by composite \(p\) or composite \(P\).

---

# 4. Cambie Tail: \(t=1\)

For \(t=1\), the equation is equivalent to the D-ledger branch. The R591 report records:

```text
m < 2^64
p < 24,595,658,764,946,068,820
survivors: p = 7, 47
```

So the bounded \(t=1\) statement is:

\[
\boxed{
p<24,595,658,764,946,068,820
\Longrightarrow
p\in\{7,47\}.
}
\]

---

# 5. Cambie Tail: \(t\ge2\)

The final unresolved Python chamber before R591 was the R590 underflow set.

R591 finished it using `sympy.factorint`.

## R591 Chamber

```text
p <= 1,000,000
p ≡ 7 mod 8
2 <= t <= 30
4*p^t <= 10^50
```

## R591 Step-2 Scan

```text
prime rows:              19669
t-cases total:           148345
step-2 hits:             0
step-2 underflow primes: 348
step-2 overflow primes:  19321
x1 source births:        0
```

## R591 Underflow Classifier

```text
underflow t-cases classified: 2662
status counts:                {'OVERSHOOT': 2662}
bad cases:                    0
```

The key output:

\[
\boxed{\text{Every underflow case classified as OVERSHOOT.}}
\]

No hits.  
No source births.  
No descent violations.  
No unresolved caps.

---

# 6. Combined Bounded Victory

The combined bounded result is:

\[
\boxed{
\textbf{D-branch: }m<2^{64}\textbf{ closes to }m=5,35.
}
\]

\[
\boxed{
\textbf{Cambie }t=1\textbf{: covered by D-ledger up to }
p<24,595,658,764,946,068,820,
\textbf{ survivors }p=7,47.
}
\]

\[
\boxed{
\textbf{Cambie }t\ge2\textbf{: }
p\le1,000,000,\ 2\le t\le30,\ 4p^t\le10^{50}
\textbf{ has no hits.}
}
\]

Therefore:

\[
\boxed{
\textbf{The six-family picture survives the full R591 Python attack suite.}
}
\]

---

# 7. What Is Solved, Exactly

## Solved / Certified

1. Prime-filtered D-branch below \(2^{64}\).
2. Cambie \(t=1\) through the induced \(p\)-bound from the D-ledger.
3. Cambie \(t\ge2\) in the R591 chamber.
4. All R590 unresolved underflow cases in the R591 chamber.
5. A complete handoff ledger with scripts, JSON reports, summaries, and checksums.

## Not Claimed

This handoff does **not** claim the infinite symbolic proof of Erdős #411.

The remaining infinite proof would require converting the two observed laws into symbolic theorems:

1. **D-law:** every non-chain prime-filtered D birth dies by composite \(p\) or composite \(P\).
2. **T-law:** for \(t\ge2\), the Cambie orbit cannot hit \(4p^t\); in the tested chamber it overshoots after the underflow continuation.

---

# 8. Recommended External Statement

Use this as the clean external statement:

> We have built a Python-verifiable certificate package for the two exceptional channels in Erdős #411. It proves that the prime-filtered totient-defect branch has no solutions below \(2^{64}\) beyond \(m=5,35\), and that the Cambie prime-power tail has no \(t\ge2\) hits in the chamber \(p\le10^6,\ 2\le t\le30,\ 4p^t\le10^{50}\), while \(t=1\) is covered by the D-ledger up to \(p<2.4595\times10^{19}\) with survivors \(7,47\). The data supports exactly the six known families \(2^a\{1,3,5,7,35,47\}\).

---

# 9. Reproduction Guide

1. Open the `evidence/` folder.
2. Start with:

   - `oracle_r591_final_underflow_classifier_gth_report.json`
   - `ORACLE_R591_FINAL_UNDERFLOW_CLASSIFIER_GTH_SUMMARY.md`

3. Verify the D-branch ledgers:

   - `r580_prefix_window_1e20_new.json`
   - `oracle_r583_python_attacker_bounded_fast_report.json`
   - `oracle_r582_python_data_oracle_report.json`

4. Verify checksums using:

```bash
sha256sum -c SHA256SUMS.txt
```

5. Read `EVIDENCE_LEDGER.json` for the full list of files and roles.

---

# 10. Final GTH

\[
\boxed{
\textbf{Gun to head: ship this as a bounded computational-theoretical victory.}
}
\]

\[
\boxed{
\textbf{Do not sit on it. Do not inflate it to infinite proof. Do not weaken it into “just experiments.”}
}
\]

This is a serious result. It leaves the room.
