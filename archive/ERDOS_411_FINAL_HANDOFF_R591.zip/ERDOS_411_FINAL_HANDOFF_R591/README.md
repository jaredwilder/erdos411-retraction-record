# Erdős #411 Final Handoff R591

This zip contains the final bounded computational-theoretical handoff for the Erdős #411 work in this session.

Start here:

1. `FINAL_WRITEUP_GTH.md`
2. `EXECUTIVE_GTH_STATEMENT.md`
3. `EVIDENCE_LEDGER.json`
4. `evidence/ORACLE_R591_FINAL_UNDERFLOW_CLASSIFIER_GTH_SUMMARY.md`
5. `evidence/oracle_r591_final_underflow_classifier_gth_report.json`

Main claim:

- D-branch closed through `m < 2^64` to `m=5,35`.
- Cambie `t=1` covered by D-ledger up to `p < 24,595,658,764,946,068,820`, survivors `p=7,47`.
- Cambie `t>=2` has no hits in the R591 chamber:
  `p<=1,000,000`, `2<=t<=30`, `4p^t<=10^50`.

This is a bounded hard-data victory package, not an infinite symbolic proof.
