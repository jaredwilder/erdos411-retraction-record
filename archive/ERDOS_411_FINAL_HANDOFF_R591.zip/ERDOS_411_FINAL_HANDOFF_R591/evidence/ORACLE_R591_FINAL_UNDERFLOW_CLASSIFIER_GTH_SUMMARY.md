# ORACLE R591 — Final Underflow Classifier + GTH

## Python worker result

This round directly finished the unresolved R590 underflow chamber using `sympy.factorint`.

## Chamber

```text
p <= 1,000,000
p ≡ 7 mod 8
2 <= t <= 30
4*p^t <= 10^50
```

## Step-2 scan

```text
prime rows:             19,669
t-cases total:          148,345
step-2 hits:            0
step-2 underflow primes:348
step-2 overflow primes: 19,321
x1 source births:       0
```

## Underflow classifier

```text
underflow t-cases classified: 2,662
status counts:                {'OVERSHOOT': 2662}
bad cases:                    0
```

Every underflow case classified as:

```text
OVERSHOOT
```

No hits. No source births. No descent violations. No unresolved caps.

## t=1 via D-ledger

```text
m < 2^64
p < 24,595,658,764,946,068,820
survivors: p = 7, 47
```

## GTH bounded victory statement

Within the R591 Python chamber:

```text
t=1: covered by D-ledger, survivors p=7,47
t>=2: p<=1,000,000, 2<=t<=30, 4p^t<=10^50
      no hits, no source births, no descent violations,
      every underflow overshoots.
```

## Verdict

VICTORY at the bounded hard-data scope.
