# Executive GTH Statement

Gun to head:

We have a bounded computational-theoretical victory for Erdős #411.

The package proves/certifies the two remaining exceptional channels at the following hard-data scope:

1. Prime-filtered D-branch:
   phi(m)=2(m+1)/3 and (4m+1)/3 prime, m<2^64
   implies m in {5,35}.

2. Cambie tail t=1:
   covered by the D-ledger up to p < 24,595,658,764,946,068,820,
   survivors p=7,47.

3. Cambie tail t>=2:
   p<=1,000,000, 2<=t<=30, 4p^t<=10^50:
   no hits, no source births, no descent violations, every underflow overshoots.

This supports exactly the six-family picture:
2^a * {1,3,5,7,35,47}.

Call it what it is:
a serious bounded certificate package and research note.

Do not call it:
a complete infinite symbolic proof of Erdős #411.
