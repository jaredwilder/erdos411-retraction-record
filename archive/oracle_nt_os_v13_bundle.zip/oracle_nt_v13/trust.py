from __future__ import annotations
import json, hashlib, time
from pathlib import Path
from typing import Any, Dict
from .objects import FormalObject
TRUST_SALT='oracle_nt_v13_local_receipt_not_external'
EXTERNAL_TERM_SOURCES={'OEIS_EXACT_VERIFIED'}
EXTERNAL_DEFINITION_SOURCES={'SIGNED_PROJECT_DEFINITION_VERIFIED','LITERATURE_RECURRENCE_VERIFIED','LEAN_FORMALLY_VERIFIED','REMOTE_REPRODUCIBLE_DEFINITION_VERIFIED'}
def canon(x:Any)->str: return json.dumps(x,sort_keys=True,separators=(',',':'))
def sha256_obj(x:Any)->str: return hashlib.sha256(canon(x).encode()).hexdigest()
def ensure(p:Path): p.mkdir(parents=True,exist_ok=True)
def now(): return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
class TrustAuthority:
    '''V13 trust is claim-specific and analyzer-issued. Input source labels are never trusted as verification.'''
    def __init__(self, registry:Path):
        self.registry=registry; ensure(registry.parent)
        if not registry.exists(): registry.write_text(json.dumps({'registry_mode':'UNTRUSTED_LOCAL','local_receipts':{},'definition_receipts':{}},indent=2))
        self.db=json.loads(registry.read_text())
    def save(self): self.registry.write_text(json.dumps(self.db,indent=2,sort_keys=True))
    def object_hash(self,obj:FormalObject)->str: return sha256_obj(obj.payload_for_receipt())
    def claim_hash(self,obj:FormalObject, claim:str)->str: return sha256_obj({'object_hash':self.object_hash(obj),'claim':claim})
    def seal_local(self,obj:FormalObject)->Dict[str,Any]:
        h=self.object_hash(obj); rec={'object_hash':h,'trust_class':'LOCAL_RECEIPT_SEALED','grade':'LOCAL_ONLY','issued_by':'local_v13_tool','issued_at':now(),'receipt_hash':hashlib.sha256((h+TRUST_SALT).encode()).hexdigest()}
        self.db.setdefault('local_receipts',{})[h]=rec; self.save(); return rec
    def verify(self,obj:FormalObject, literature_report:Dict[str,Any]|None=None, lean_verified:bool=False)->Dict[str,Any]:
        schema_ok,schema_errors=obj.validate_schema(); h=self.object_hash(obj)
        claimed=obj.source.get('status') or obj.source.get('trust_class') or 'NONE'
        out={'object_hash':h,'claimed_input_status':claimed,'schema_valid':schema_ok,'schema_errors':schema_errors,'object_trust_class':'UNTRUSTED_LOCAL','object_grade':'NONE','external_verified':False,'registry_mode':self.db.get('registry_mode','UNTRUSTED_LOCAL'),
             'claim_trust':{
                 'term_identity':{'trust_class':'UNVERIFIED','grade':'NONE','claim_hash':self.claim_hash(obj,'term_identity')},
                 'recurrence_definition':{'trust_class':'LOCAL_ONLY','grade':'LOCAL_ONLY','claim_hash':self.claim_hash(obj,'recurrence_definition')},
                 'polynomial_definition':{'trust_class':'LOCAL_ONLY','grade':'LOCAL_ONLY','claim_hash':self.claim_hash(obj,'polynomial_definition')},
                 'minimality':{'trust_class':'UNPROVEN','grade':'NONE','claim_hash':self.claim_hash(obj,'minimality')},
                 'strong_divisibility':{'trust_class':'PROOF_PLAN_ONLY','grade':'NONE','claim_hash':self.claim_hash(obj,'strong_divisibility')},
                 'primitive_divisor':{'trust_class':'PREFIX_AUDIT_ONLY','grade':'NONE','claim_hash':self.claim_hash(obj,'primitive_divisor')},
                 'formal_proof':{'trust_class':'NOT_CHECKED','grade':'NONE','claim_hash':self.claim_hash(obj,'formal_proof')}
             }}
        if not schema_ok: return out
        if h in self.db.get('local_receipts',{}):
            out.update({'object_trust_class':'LOCAL_RECEIPT_SEALED','object_grade':'LOCAL_ONLY','local_receipt':True,'local_receipt_detail':self.db['local_receipts'][h]})
        else:
            out.update({'object_trust_class':'LOCAL_SCHEMA_VALID','object_grade':'LOCAL_ONLY','local_receipt':False})
        # OEIS term match verifies term identity only. It never verifies a submitted recurrence/polynomial definition.
        if literature_report and literature_report.get('exact_collision') and (not obj.source.get('oeis_id') or obj.source.get('oeis_id')==literature_report.get('matched_oeis')):
            out['claim_trust']['term_identity'].update({'trust_class':'OEIS_EXACT_VERIFIED','grade':'EXTERNAL_VERIFIED','matched_oeis':literature_report.get('matched_oeis')})
        # External recurrence/polynomial definition trust cannot be self asserted. Only trusted registry receipts can mark it.
        def_recs=self.db.get('definition_receipts',{})
        for claim in ['recurrence_definition','polynomial_definition']:
            key=self.claim_hash(obj,claim)
            if key in def_recs and def_recs[key].get('verified_by') in EXTERNAL_DEFINITION_SOURCES:
                out['claim_trust'][claim].update({'trust_class':def_recs[key]['verified_by'],'grade':'EXTERNAL_VERIFIED','receipt':def_recs[key]})
        if lean_verified:
            out['claim_trust']['formal_proof'].update({'trust_class':'LEAN_FORMALLY_VERIFIED','grade':'EXTERNAL_VERIFIED'})
        out['external_verified']=any(v.get('grade')=='EXTERNAL_VERIFIED' for v in out['claim_trust'].values())
        return out
