from __future__ import annotations
from pathlib import Path
from typing import Dict, Any
from .objects import FormalObject, SCOPE_FORMAL, SCOPE_GENERATED
from .trust import TrustAuthority
from .literature import Literature, KnownFamilies
from .mathutils import polynomial_profile, find_recurrence
from .certificates import recurrence_certificate, polynomial_certificate
from .routes import strong_divisibility_plan, primitive_divisor_audit

def analyze(obj:FormalObject, out:Path, trust:TrustAuthority, lit:Literature)->Dict[str,Any]:
    out.mkdir(parents=True,exist_ok=True)
    terms=obj.terms; fams=KnownFamilies().classify(terms) if terms else []
    lit_report=lit.exact_prefix(terms) if terms else {'exact_collision':False,'search_complete':False}
    trust_report=trust.verify(obj, lit_report)
    schema_ok,schema_errors=obj.validate_schema()
    report={'version':'13.0.0-oracle-nt-os-hard-math-core','object':obj.to_dict(),'schema':{'valid':schema_ok,'errors':schema_errors},'source_trust':trust_report,'known_families':fams,'literature':lit_report,'routes':{},'certificates':{},'claims':{},'scores':{},'proof_status':{}}
    if not schema_ok:
        report['overall_verdict']='SCHEMA_INVALID'; return report
    object_hash=trust_report['object_hash']
    # Formal/local certificates are narrow and claim-specific.
    if obj.object_type=='polynomial_sequence' and obj.scope==SCOPE_FORMAL:
        coeffs=[int(x) for x in obj.definition.get('formula_coefficients_low_to_high',[])]
        cert=polynomial_certificate(coeffs,obj.index_start,terms, object_hash, trust_report['claim_trust']['polynomial_definition']['claim_hash']); report['certificates']['polynomial']=cert
        if not cert.get('replay_passed'):
            report['overall_verdict']='FORMAL_OBJECT_CONTRADICTION'; return report
        report['routes']['polynomial_definition']={'status':'POLYNOMIAL_PREFIX_CONFORMANCE_CERTIFIED','claim_trust':trust_report['claim_trust']['polynomial_definition']}
    if obj.object_type=='recurrence_sequence' and obj.scope==SCOPE_FORMAL:
        rec=obj.definition.get('recurrence',{}); coeffs=[int(x) for x in rec.get('coefficients',[])]; init=[int(x) for x in obj.definition.get('initial_terms',[])]
        cert=recurrence_certificate(coeffs,init,obj.index_start,rec.get('valid_for',''),terms, object_hash, trust_report['claim_trust']['recurrence_definition']['claim_hash']); report['certificates']['recurrence']=cert
        if not cert.get('replay_passed'):
            report['overall_verdict']='FORMAL_OBJECT_CONTRADICTION'; return report
        report['routes']['linear_recurrence']={'status':'RECURRENCE_PREFIX_CONFORMANCE_CERTIFIED','claim_trust':trust_report['claim_trust']['recurrence_definition'],'certificate_scope':cert.get('certificate_scope'),'minimality_status':'NOT_PROVEN'}
    allowed=[]; primary='unclassified'; verdict='NO_GTH_UNCLASSIFIED'; novelty=0.0; research=0.0
    if fams:
        primary='known_family_classification'; verdict='KNOWN_BASIC_CLASSIFICATION_SUPPRESSED'; novelty=0.0; research=0.05
        fam=fams[0]
        report['routes']['strong_divisibility']=strong_divisibility_plan(fam)
        report['routes']['primitive_divisor']=primitive_divisor_audit(terms,fam)
    else:
        pp=polynomial_profile(terms); rec=find_recurrence(terms) if terms else None
        report['routes']['polynomial_profile']=pp; report['routes']['recurrence_profile']=rec
        if pp.get('interpolation_risk'):
            primary='high_degree_polynomial_interpolation_risk'; verdict='NO_GTH_INTERPOLATION_RISK'
        elif pp.get('detected'):
            primary='polynomial_finite_difference'; verdict='CLASSIFICATION_ONLY_PREFIX_CERTIFIED'; research=0.2
        elif rec and rec.get('interpolation_risk'):
            primary='high_order_recurrence_interpolation_risk'; verdict='NO_GTH_INTERPOLATION_RISK'
        elif rec:
            primary='linear_recurrence_prefix'; verdict='CLASSIFICATION_ONLY_PREFIX_CERTIFIED'; research=0.2
    # Claim-specific trust: only recurrence_definition trust unlocks recurrence route, not OEIS term identity.
    rec_trust=trust_report['claim_trust']['recurrence_definition']
    if obj.scope==SCOPE_FORMAL and report['certificates'].get('recurrence',{}).get('replay_passed') and rec_trust.get('grade')=='EXTERNAL_VERIFIED':
        allowed.append('RECURRENCE_DEFINITION_CONFORMANCE_ROUTE')
        verdict='ROUTE_SPECIFIC_DEFINITION_ROUTE_ALLOWED_NOT_FORMALLY_VERIFIED'
    term_trust=trust_report['claim_trust']['term_identity']
    report['primary_coordinate']=primary; report['overall_verdict']=verdict
    report['claims']={'allowed_route_claims':allowed,'claim_trust_summary':{k:v.get('trust_class') for k,v in trust_report['claim_trust'].items()},'forbidden_claims_without_more_work':['minimality','novelty','strong divisibility theorem','primitive divisor theorem','formal verification'],'oeis_term_match_does_not_verify_recurrence_definition': term_trust.get('grade')=='EXTERNAL_VERIFIED' and rec_trust.get('grade')!='EXTERNAL_VERIFIED'}
    report['scores']={'novelty_score':novelty,'research_value_score':research,'literature_collision':1.0 if lit_report.get('exact_collision') else 0.0,'known_boring':1.0 if fams else 0.0}
    report['proof_status']={'lean_skeleton_emitted':False,'lean_compile_attempted':False,'lean_compile_passed':False,'formal_proof_verified':False}
    return report
