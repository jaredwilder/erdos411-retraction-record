VERSION='13.0.0-oracle-nt-os-hard-math-core'
