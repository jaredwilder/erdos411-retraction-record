# Race 5 Referee Forge Repair Packet

## Verdict

**SCIENCE_DOWNGRADED_TO_INTERNAL_EVIDENCE_PENDING_NONTRIVIALITY_TEST**

Race 5 remains useful, but it does **not** pass the full process as science yet. The computation is real; the promotion was premature.

## Selected Binary

Is Race 5 tight-cell survival automatic from finite projection/fiber definitions, or nontrivial under q3 danger closure?

## Candidate Pressure / Selection

The selected candidate was not “run deeper.” It was the repair audit itself:

- C1 selected: Referee Forge repair of Race 5.
- C2 rejected: run depth-4 immediately, because that repeats bounded enumeration before proving Race 5 has referee value.
- C3 rejected: write theorem narrative, because prose-only theorem routes are banned.
- C4 rejected for now: family transfer, high value but depends on resolving whether Race 5 is automatic or nontrivial.

## Race 5 Raw Computation

- Replayed branches: 26
- Skipped branches: 75
- Branches destroying parent tight cells: 0
- Branches destroying any initial cell: 0
- Maximum initial cells destroyed: 0
- Minimum parent tight survival ratio: 1.0

The computation is valid as bounded evidence. It is **not** yet a theorem route.

## Referee Forge Gate Results

| Gate | Status |
|---|---|
| ONE_BINARY_GATE | PASS |
| EXTERNAL_ADJUDICATOR_GATE | PASS_CERTIFICATE_REPLAY_AND_BRANCH_CSV_PRESENT |
| FRONTIER_DELTA_GATE | PARTIAL_INTERNAL_DELTA_ONLY |
| REFEREE_VALUE_GATE | FAIL_PENDING_NONTRIVIALITY_PROOF |
| FIELD_COLLISION_GATE | FAIL_PRELIMINARY_SEARCH_ONLY_NO_FORMAL_LIT_REVIEW |
| FORMALIZATION_TAX_GATE | PARTIAL_LEAN_STUB_EMITTED_NOT_PROVED |
| FAMILY_TRANSFER_GATE | FAIL_NOT_RUN |
| PROOF_FAILURE_LEDGER_GATE | PASS_REPAIR_FAILURE_RECORDED |
| MINIMUM_PUBLISHABLE_UNIT_GATE | FAIL_NO_MPU_MOVEMENT_UNTIL_NONTRIVIALITY_RESOLVED |
| REPRESENTATION_MUTATION_GATE | PASS_FOUR_REPRESENTATIONS_EMITTED |
| CONJECTURE_COMPILER_GATE | PASS_MINIMAL_AND_MAXIMAL_CLAIMS_EMITTED |
| REWARD_UPDATE_GATE | DOWNGRADE_RACE5_FROM_SCIENCE_TO_INTERNAL_EVIDENCE |

## Representation Mutation

1. **Finite quotient projection:** project final exponent cells back to the initial 60×60 residual lattice.
2. **Fiber map:** count surviving final lifts over each initial residual cell.
3. **Coverage graph:** initial cells connected to surviving final lift cells.
4. **Residue-cell geometry:** exponent residue pairs under period lattices.

## Field Collision

Preliminary search says this touches active/nearby terrain: Erdős-Graham problem #203 is open and explicitly concerns whether some m coprime to 6 makes all m·2^k·3^l+1 composite. Covering systems and finite/lattice covering formulations are real neighboring literatures. That is enough to prevent “internal only” dismissal, but **not** enough to claim field novelty.

## Formalization Tax

A Lean stub was emitted: `tight_fiber_survival_lemma_stub.lean`.

It is a tax stub, not a proof. It defines the direction of the next proof/counterexample object.

## Proof-Failure Ledger

The previous Race 5 summary failed at this exact bridge:

> Enumeration showed survival, but did not distinguish automatic fiber nonemptiness from nontrivial obstruction-preservation.

New constraint learned:

> Before running depth-4, construct a synthetic tight-cell kill test. If such a kill is possible in the abstract but actual danger masks fail to kill, Race 5 survival is nontrivial. If no compatible mask can kill, Race 5 was automatic.

## Next Executable Attack

**Synthetic tight-cell kill test.**

Generate artificial final masks compatible with the same projection/fiber framework and test whether a one-lift fiber can be destroyed. This separates automatic projection behavior from genuine arithmetic survival.

## Next KBK Binary

Can we construct a synthetic closure family where a tight one-lift cell is destroyed? If yes, Race 5 survival is nontrivial; if no, identify the automatic monotonicity/fiber lemma.
