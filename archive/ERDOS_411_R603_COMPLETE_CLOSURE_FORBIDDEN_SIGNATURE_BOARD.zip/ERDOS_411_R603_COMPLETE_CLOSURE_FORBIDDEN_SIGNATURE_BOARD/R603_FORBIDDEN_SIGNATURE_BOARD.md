# R603 — Complete Closure Forbidden-Signature Board

## Goal

```text
Completing the r=2 case of Erdős Problem #411
```

## GTH position

The Cambie `t>=2` closure has been reduced to a finite theorem board.

## Data lock from R602

```text
prime tested:                 317,668
strict underflows:            5,277
odd-damage failures:          0
Lemma B gap failures:         0
minimal forbidden signatures: 10
forbidden signature hits:     0
```

## Worst observed enemy

```text
p:              13218407
odd damage:     2.516798782927305
target ceiling: 2.6666666666666665
odd primes:     [3, 5, 7, 11, 23, 2161, 275309]
factor C2:      {'2': 2, '3': 1, '5': 1, '7': 1, '11': 2, '23': 1, '2161': 1, '275309': 1}
```

## Closure rule

A Lemma B failure requires one minimal forbidden signature to divide `odd(C2)`.

Python found zero in the shock chamber.

Therefore complete Cambie closure is the finite proof board:

```text
Prove FS-01 through FS-10 impossible.
```

## Forbidden-signature theorem cards

### FS-01

```text
Forbidden signature: [3, 5, 7, 11, 13, 43]
Damage:              2.6688368055555554
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [13, 43]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 43) all dividing odd(C2).
```

### FS-02

```text
Forbidden signature: [3, 5, 7, 11, 13, 41]
Damage:              2.6719401041666666
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [13, 41]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 41) all dividing odd(C2).
```

### FS-03

```text
Forbidden signature: [3, 5, 7, 11, 17, 23]
Damage:              2.6728515625
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [17]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 17, 23) all dividing odd(C2).
```

### FS-04

```text
Forbidden signature: [3, 5, 7, 11, 13, 37]
Damage:              2.679181134259259
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [13, 37]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 37) all dividing odd(C2).
```

### FS-05

```text
Forbidden signature: [3, 5, 7, 11, 13, 31]
Damage:              2.6936631944444445
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [13, 31]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 31) all dividing odd(C2).
```

### FS-06

```text
Forbidden signature: [3, 5, 7, 11, 17, 19]
Damage:              2.6986762152777777
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [17, 19]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 17, 19) all dividing odd(C2).
```

### FS-07

```text
Forbidden signature: [3, 5, 7, 11, 13, 29]
Damage:              2.6998697916666665
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [13, 29]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 29) all dividing odd(C2).
```

### FS-08

```text
Forbidden signature: [3, 5, 7, 11, 13, 23]
Damage:              2.7252604166666665
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [13]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 23) all dividing odd(C2).
```

### FS-09

```text
Forbidden signature: [3, 5, 7, 11, 13, 19]
Damage:              2.751591435185185
Observed R602 hits:  0
Best overlap p:      1711967
Missing from best:   [3]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 19) all dividing odd(C2).
```

### FS-10

```text
Forbidden signature: [3, 5, 7, 11, 13, 17]
Damage:              2.7696940104166665
Observed R602 hits:  0
Best overlap p:      13218407
Missing from best:   [13, 17]
```

Theorem card:

```text
No strict-underflow prime p has (3, 5, 7, 11, 13, 17) all dividing odd(C2).
```


## GTH

This is complete-closure shape: a finite board, not an amorphous open end.

The internet-famous path is:

```text
Kill FS-01 through FS-10.
Combine with Lemma A.
Cambie t>=2 closes.
Combine with D-branch closure.
r=2 closes to six families.
```
