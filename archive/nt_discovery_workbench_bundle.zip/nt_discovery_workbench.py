#!/usr/bin/env python3
"""
nt_discovery_workbench.py

A serious number-theory discovery workbench for integer sequences and arithmetic patterns.

Purpose
-------
This is not a proof engine and not a toy OEIS wrapper. It is the missing layer between
raw model intuition and formal proof:

    data -> computational probes -> invariant mining -> external database checks
    -> falsification -> proof obligations -> Sage/PARI/Lean handoff

It is designed to run with plain Python first, then automatically upgrades itself when
SymPy, PARI/GP, cypari2, or SageMath are available.

Core ideas
----------
1. Separate measurement from theorem claims.
2. Rank hypotheses by repeated, independent evidence.
3. Generate falsifiers before generating prose.
4. Emit proof obligations that can be attacked in Sage, PARI/GP, or Lean.
5. Record every computational assumption in a reproducible JSON and Markdown report.

Install options
---------------
Plain Python only:
    python nt_discovery_workbench.py analyze-seq --seq "1,1,2,3,5,8,13"

With stronger tools:
    pip install sympy requests
    sudo apt install pari-gp sagemath   # platform dependent

Optional online checks:
    python nt_discovery_workbench.py analyze-seq --seq "1,1,2,3,5,8,13" --online

Author note
-----------
This file intentionally treats LLM output as untrusted. It gives you machinery.
"""

from __future__ import annotations

import argparse
import dataclasses
import fractions
import hashlib
import json
import math
import os
import re
import shutil
import statistics
import subprocess
import sys
import textwrap
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

try:
    import sympy as sp  # type: ignore
except Exception:  # pragma: no cover
    sp = None

Fraction = fractions.Fraction


# ---------------------------------------------------------------------------
# Small, reliable arithmetic core
# ---------------------------------------------------------------------------


def parse_int_sequence(raw: str) -> List[int]:
    """Parse a sequence from comma, whitespace, bracketed, or JSON-ish text."""
    if not raw or not raw.strip():
        raise ValueError("Empty sequence.")
    found = re.findall(r"[-+]?\d+", raw)
    if not found:
        raise ValueError(f"No integers found in input: {raw!r}")
    return [int(x) for x in found]


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def is_square(n: int) -> bool:
    if n < 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def safe_div(a: int, b: int) -> Optional[Fraction]:
    if b == 0:
        return None
    return Fraction(a, b)


def differences(seq: Sequence[int], order: int = 1) -> List[int]:
    cur = list(seq)
    for _ in range(order):
        cur = [cur[i + 1] - cur[i] for i in range(len(cur) - 1)]
    return cur


def finite_difference_table(seq: Sequence[int], max_order: Optional[int] = None) -> List[List[int]]:
    if max_order is None:
        max_order = max(0, len(seq) - 1)
    table = [list(seq)]
    cur = list(seq)
    for _ in range(max_order):
        if len(cur) <= 1:
            break
        cur = differences(cur)
        table.append(cur)
    return table


def gcd_list(values: Iterable[int]) -> int:
    g = 0
    for v in values:
        g = math.gcd(g, abs(v))
    return g


def valuation(n: int, p: int) -> Optional[int]:
    """p-adic valuation v_p(n). Returns None for n=0 because it is infinite."""
    if p <= 1:
        raise ValueError("p must be prime-like and greater than 1")
    if n == 0:
        return None
    n = abs(n)
    k = 0
    while n % p == 0:
        n //= p
        k += 1
    return k


def trial_factor(n: int) -> Dict[int, int]:
    """Small but dependable factorization fallback. SymPy upgrades it automatically."""
    if n == 0:
        return {0: 1}
    if n < 0:
        n = -n
    if n == 1:
        return {}
    if sp is not None:
        try:
            return {int(k): int(v) for k, v in sp.factorint(n).items()}
        except Exception:
            pass
    out: Dict[int, int] = {}
    while n % 2 == 0:
        out[2] = out.get(2, 0) + 1
        n //= 2
    d = 3
    while d * d <= n:
        while n % d == 0:
            out[d] = out.get(d, 0) + 1
            n //= d
        d += 2
    if n > 1:
        out[n] = out.get(n, 0) + 1
    return out


def primes_upto(n: int) -> List[int]:
    if n < 2:
        return []
    sieve = bytearray(b"\x01") * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for p in range(2, math.isqrt(n) + 1):
        if sieve[p]:
            start = p * p
            sieve[start:n + 1:p] = b"\x00" * (((n - start) // p) + 1)
    return [i for i in range(n + 1) if sieve[i]]


def modular_period(values: Sequence[int], modulus: int, max_period: Optional[int] = None) -> Optional[int]:
    """Return smallest visible period modulo m, if the observed prefix supports one."""
    if modulus <= 1 or len(values) < 2:
        return None
    residues = [v % modulus for v in values]
    n = len(residues)
    if max_period is None:
        max_period = n // 2
    for p in range(1, max_period + 1):
        ok = True
        for i in range(n - p):
            if residues[i] != residues[i + p]:
                ok = False
                break
        if ok:
            return p
    return None


def rational_ratios(seq: Sequence[int], limit: int = 12) -> List[Optional[str]]:
    out: List[Optional[str]] = []
    for a, b in zip(seq[1:], seq[:-1]):
        q = safe_div(a, b)
        out.append(None if q is None else str(q))
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------------------
# Hypothesis model
# ---------------------------------------------------------------------------


@dataclass(order=True)
class Hypothesis:
    sort_index: float = field(init=False, repr=False)
    score: float
    title: str
    claim: str
    evidence: List[str] = field(default_factory=list)
    falsifiers: List[str] = field(default_factory=list)
    proof_obligations: List[str] = field(default_factory=list)
    next_computations: List[str] = field(default_factory=list)
    confidence: str = "low"
    tags: List[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.sort_index = -self.score
        if self.score >= 0.82:
            self.confidence = "high-computational"
        elif self.score >= 0.58:
            self.confidence = "medium-computational"
        else:
            self.confidence = "low"

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self) | {"sort_index": None}


# ---------------------------------------------------------------------------
# External tool adapters
# ---------------------------------------------------------------------------


@dataclass
class ToolStatus:
    name: str
    available: bool
    path: Optional[str] = None
    detail: Optional[str] = None


class ExternalTools:
    """Thin wrappers around stronger number-theory tools."""

    def __init__(self, timeout_seconds: int = 20) -> None:
        self.timeout_seconds = timeout_seconds
        self._status_cache: Optional[Dict[str, ToolStatus]] = None

    def status(self) -> Dict[str, ToolStatus]:
        if self._status_cache is not None:
            return self._status_cache
        statuses: Dict[str, ToolStatus] = {}
        for name in ["sage", "gp"]:
            path = shutil.which(name)
            statuses[name] = ToolStatus(name=name, available=path is not None, path=path)
        statuses["sympy"] = ToolStatus(
            name="sympy",
            available=sp is not None,
            path=None,
            detail=(getattr(sp, "__version__", None) if sp is not None else None),
        )
        try:
            import cypari2  # type: ignore
            statuses["cypari2"] = ToolStatus("cypari2", True, None, getattr(cypari2, "__version__", None))
        except Exception as exc:
            statuses["cypari2"] = ToolStatus("cypari2", False, None, str(exc))
        self._status_cache = statuses
        return statuses

    def run_gp(self, expr: str) -> Dict[str, Any]:
        status = self.status().get("gp")
        if not status or not status.available:
            return {"ok": False, "error": "gp executable not found"}
        code = expr.strip()
        if not code.endswith(";"):
            code += ";"
        try:
            proc = subprocess.run(
                [status.path or "gp", "-q"],
                input=code + "\n\\q\n",
                text=True,
                capture_output=True,
                timeout=self.timeout_seconds,
            )
            return {
                "ok": proc.returncode == 0,
                "stdout": proc.stdout.strip(),
                "stderr": proc.stderr.strip(),
                "returncode": proc.returncode,
            }
        except Exception as exc:
            return {"ok": False, "error": repr(exc)}

    def run_sage(self, code: str) -> Dict[str, Any]:
        status = self.status().get("sage")
        if not status or not status.available:
            return {"ok": False, "error": "sage executable not found"}
        try:
            proc = subprocess.run(
                [status.path or "sage", "-c", code],
                text=True,
                capture_output=True,
                timeout=self.timeout_seconds,
            )
            return {
                "ok": proc.returncode == 0,
                "stdout": proc.stdout.strip(),
                "stderr": proc.stderr.strip(),
                "returncode": proc.returncode,
            }
        except Exception as exc:
            return {"ok": False, "error": repr(exc)}


# ---------------------------------------------------------------------------
# Online database clients, intentionally conservative
# ---------------------------------------------------------------------------


class WebClient:
    def __init__(self, timeout_seconds: int = 15, user_agent: str = "nt-discovery-workbench/1.0") -> None:
        self.timeout_seconds = timeout_seconds
        self.user_agent = user_agent

    def get_json(self, url: str) -> Dict[str, Any]:
        req = urllib.request.Request(url, headers={"User-Agent": self.user_agent})
        with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        return json.loads(raw)

    def get_text(self, url: str) -> str:
        req = urllib.request.Request(url, headers={"User-Agent": self.user_agent})
        with urllib.request.urlopen(req, timeout=self.timeout_seconds) as resp:
            return resp.read().decode("utf-8", errors="replace")


class OEISClient:
    def __init__(self, web: Optional[WebClient] = None) -> None:
        self.web = web or WebClient()

    def search_sequence(self, seq: Sequence[int], limit_terms: int = 16) -> Dict[str, Any]:
        query = ",".join(str(x) for x in list(seq)[:limit_terms])
        url = "https://oeis.org/search?" + urllib.parse.urlencode({"q": query, "fmt": "json"})
        try:
            data = self.web.get_json(url)
            results = data.get("results", []) if isinstance(data, dict) else []
            clean = []
            for r in results[:8]:
                clean.append({
                    "number": r.get("number"),
                    "id": f"A{int(r.get('number')):06d}" if r.get("number") is not None else None,
                    "name": r.get("name"),
                    "data": r.get("data"),
                    "url": f"https://oeis.org/A{int(r.get('number')):06d}" if r.get("number") is not None else None,
                })
            return {"ok": True, "url": url, "results": clean}
        except Exception as exc:
            return {"ok": False, "url": url, "error": repr(exc)}


class LMFDBHelper:
    """LMFDB is broad. This helper generates targeted lookup URLs and optional text probes."""

    BASE = "https://www.lmfdb.org"

    @staticmethod
    def urls_for_sequence(seq: Sequence[int]) -> List[Dict[str, str]]:
        terms = ",".join(str(x) for x in seq[:10])
        return [
            {"label": "LMFDB global search", "url": f"https://www.lmfdb.org/search/?q={urllib.parse.quote(terms)}"},
            {"label": "Elliptic curves over Q", "url": "https://www.lmfdb.org/EllipticCurve/Q/"},
            {"label": "Number fields", "url": "https://www.lmfdb.org/NumberField/"},
            {"label": "Modular forms", "url": "https://www.lmfdb.org/ModularForm/"},
            {"label": "L-functions", "url": "https://www.lmfdb.org/L/"},
        ]


class LiteratureHelper:
    @staticmethod
    def search_urls(seq: Sequence[int], keywords: Optional[List[str]] = None) -> List[Dict[str, str]]:
        terms = ",".join(str(x) for x in seq[:12])
        key = " ".join(keywords or [])
        q = f'"{terms}" {key}'.strip()
        return [
            {"label": "arXiv search", "url": "https://arxiv.org/search/?" + urllib.parse.urlencode({"query": q, "searchtype": "all"})},
            {"label": "Google Scholar search", "url": "https://scholar.google.com/scholar?" + urllib.parse.urlencode({"q": q})},
            {"label": "zbMATH search", "url": "https://zbmath.org/?" + urllib.parse.urlencode({"q": q})},
            {"label": "MathSciNet manual search", "url": "https://mathscinet.ams.org/mathscinet"},
        ]


# ---------------------------------------------------------------------------
# Discovery engines
# ---------------------------------------------------------------------------


class SequenceAnalyzer:
    def __init__(self, seq: Sequence[int], index_start: int = 0) -> None:
        if len(seq) < 3:
            raise ValueError("Need at least 3 terms for meaningful analysis.")
        self.seq = [int(x) for x in seq]
        self.index_start = index_start
        self.n = len(seq)

    def basic_summary(self) -> Dict[str, Any]:
        seq = self.seq
        abs_nonzero = [abs(x) for x in seq if x != 0]
        return {
            "length": len(seq),
            "index_start": self.index_start,
            "first_terms": seq[:20],
            "last_terms": seq[-10:],
            "min": min(seq),
            "max": max(seq),
            "gcd_all_terms": gcd_list(seq),
            "gcd_differences": gcd_list(differences(seq)) if len(seq) > 1 else None,
            "signs": dict(Counter("zero" if x == 0 else "positive" if x > 0 else "negative" for x in seq)),
            "monotone_non_decreasing": all(seq[i] <= seq[i + 1] for i in range(len(seq) - 1)),
            "monotone_increasing": all(seq[i] < seq[i + 1] for i in range(len(seq) - 1)),
            "rough_growth_ratio_tail": rational_ratios(seq[-8:], limit=7),
            "max_abs_bits": max((x.bit_length() for x in abs_nonzero), default=0),
        }

    def polynomial_hypotheses(self) -> List[Hypothesis]:
        table = finite_difference_table(self.seq)
        hyps: List[Hypothesis] = []
        for order, row in enumerate(table[1:], start=1):
            if not row:
                continue
            if len(set(row)) == 1:
                degree = order
                constant = row[0]
                hyps.append(Hypothesis(
                    score=min(0.95, 0.55 + 0.06 * len(self.seq)),
                    title=f"Polynomial sequence of degree {degree}",
                    claim=f"The observed terms fit a polynomial in n of degree {degree} with constant {degree}th finite difference {constant}.",
                    evidence=[f"Finite difference order {degree} is constant across {len(row)} observed positions."],
                    falsifiers=["Compute at least 5 more terms from the alleged source and check whether the same finite difference stays constant."],
                    proof_obligations=["Derive the closed polynomial formula and prove by finite-difference induction."],
                    next_computations=["Interpolate exact polynomial over Q and test extrapolated terms."],
                    tags=["finite-difference", "polynomial"],
                ))
                break
        if sp is not None and len(self.seq) >= 4:
            try:
                n = sp.Symbol("n")
                pts = [(self.index_start + i, v) for i, v in enumerate(self.seq)]
                poly = sp.interpolate(pts, n)
                deg = int(sp.degree(poly, n))
                if deg <= min(8, len(self.seq) - 2):
                    hyps.append(Hypothesis(
                        score=max(0.35, 0.75 - 0.05 * deg),
                        title="Exact interpolation candidate",
                        claim=f"A degree {deg} rational polynomial interpolates all observed points: {sp.factor(poly)}",
                        evidence=["SymPy exact rational interpolation succeeded."],
                        falsifiers=["Interpolation always fits finite data. Demand out-of-sample terms or a structural derivation."],
                        proof_obligations=["Prove the source recurrence or counting argument implies the polynomial formula."],
                        next_computations=["Ask Sage to simplify the polynomial in binomial-coefficient basis."],
                        tags=["interpolation", "weak-unless-validated"],
                    ))
            except Exception:
                pass
        return hyps

    def recurrence_hypotheses(self, max_order: int = 8) -> List[Hypothesis]:
        seq = [Fraction(x) for x in self.seq]
        hyps: List[Hypothesis] = []
        max_order = min(max_order, max(1, len(seq) // 2))
        for k in range(1, max_order + 1):
            coeffs = self._fit_linear_recurrence(seq, k)
            if coeffs is None:
                continue
            ok_count = 0
            fail_at = None
            for i in range(k, len(seq)):
                pred = sum(coeffs[j] * seq[i - j - 1] for j in range(k))
                if pred == seq[i]:
                    ok_count += 1
                else:
                    fail_at = i
                    break
            if fail_at is None and ok_count >= max(3, len(seq) - k):
                coeff_str = [str(c) for c in coeffs]
                score = min(0.92, 0.45 + 0.05 * ok_count - 0.025 * k)
                hyps.append(Hypothesis(
                    score=score,
                    title=f"Linear recurrence candidate, order {k}",
                    claim=f"a(n) = " + " + ".join([f"({coeff_str[j]})*a(n-{j+1})" for j in range(k)]),
                    evidence=[f"The recurrence exactly predicts {ok_count} in-sample positions after solving over Q."],
                    falsifiers=["Generate fresh terms independently and check the recurrence. Low-order recurrences can overfit short sequences."],
                    proof_obligations=["Find characteristic polynomial, prove initial conditions, then prove recurrence by induction or generating functions."],
                    next_computations=["Use Sage/PARI to factor the characteristic polynomial and inspect roots/modular reductions."],
                    tags=["linear-recurrence", "generating-function"],
                ))
                break
        return hyps

    @staticmethod
    def _fit_linear_recurrence(seq: Sequence[Fraction], order: int) -> Optional[List[Fraction]]:
        rows: List[List[Fraction]] = []
        rhs: List[Fraction] = []
        for i in range(order, len(seq)):
            rows.append([seq[i - j - 1] for j in range(order)])
            rhs.append(seq[i])
            if len(rows) >= order + 3:
                break
        if len(rows) < order:
            return None
        # Try all square systems from available rows to avoid singular first choice.
        import itertools
        for idxs in itertools.combinations(range(len(rows)), order):
            A = [[rows[i][j] for j in range(order)] for i in idxs]
            b = [rhs[i] for i in idxs]
            sol = solve_linear_fraction(A, b)
            if sol is None:
                continue
            if all(sum(sol[j] * row[j] for j in range(order)) == y for row, y in zip(rows, rhs)):
                return sol
        return None

    def modular_hypotheses(self, max_modulus: int = 36) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        interesting: List[str] = []
        for m in range(2, max_modulus + 1):
            p = modular_period(self.seq, m)
            if p is not None and p <= max(12, len(self.seq) // 3):
                interesting.append(f"mod {m}: visible period {p}")
        if interesting:
            score = min(0.8, 0.35 + 0.03 * len(interesting))
            hyps.append(Hypothesis(
                score=score,
                title="Modular periodic structure",
                claim="The sequence shows repeated residue behavior over several small moduli.",
                evidence=interesting[:20],
                falsifiers=["Visible modular periods on a short prefix may collapse. Extend terms and retest."],
                proof_obligations=["Prove periodicity modulo m using recurrence, automaton, or finite-state argument."],
                next_computations=["Search for automatic/regular sequence signatures and compare with OEIS hits."],
                tags=["modular", "periodicity"],
            ))
        return hyps

    def divisibility_hypotheses(self) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        seq = self.seq
        # Divisibility sequence test: i | j => a_i | a_j, ignoring zero and indexing ambiguity.
        for start in [0, 1]:
            passes = 0
            total = 0
            failures = []
            for i in range(1, len(seq) + 1):
                ai = seq[i - 1]
                if ai == 0:
                    continue
                for j in range(i * 2, len(seq) + 1, i):
                    aj = seq[j - 1]
                    total += 1
                    if aj % ai == 0:
                        passes += 1
                    elif len(failures) < 5:
                        failures.append((i + start, j + start, ai, aj))
            if total and passes == total and total >= 4:
                hyps.append(Hypothesis(
                    score=min(0.86, 0.5 + 0.04 * total),
                    title="Divisibility-sequence candidate",
                    claim="Observed index divisibility appears to imply term divisibility.",
                    evidence=[f"Passed {passes}/{total} divisibility checks under index_start adjustment {start}."],
                    falsifiers=["Extend the sequence and test all i | j pairs again. Check whether zeros/trivial units drive the result."],
                    proof_obligations=["Prove strong divisibility or divisibility from algebraic group/recurrence structure."],
                    next_computations=["Check gcd(a_m,a_n)=a_gcd(m,n), Lucas/Elliptic divisibility signatures."],
                    tags=["divisibility", "lucas", "elliptic-divisibility"],
                ))
        # Common factor and valuations.
        primes = primes_upto(31)
        val_patterns: List[str] = []
        for p in primes:
            vals = [valuation(x, p) for x in seq]
            finite = [v for v in vals if v is not None]
            if finite and max(finite) >= 2:
                val_patterns.append(f"v_{p} reaches {max(finite)} with pattern {vals[:16]}")
        if val_patterns:
            hyps.append(Hypothesis(
                score=min(0.7, 0.28 + 0.04 * len(val_patterns)),
                title="p-adic valuation structure",
                claim="Prime-adic valuations show nontrivial repeated structure worth mining.",
                evidence=val_patterns[:12],
                falsifiers=["Compare v_p(a_n) against v_p(n), Lucas valuations, LTE predictions, and random baselines."],
                proof_obligations=["Identify exact valuation formula or prove bounds."],
                next_computations=["Run PARI valuation/factorization at larger n and search for LTE-compatible forms."],
                tags=["p-adic", "valuation"],
            ))
        return hyps

    def factor_hypotheses(self, limit_terms: int = 20) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        facts = []
        smooth_hits = []
        square_hits = []
        prime_hits = []
        for idx, x in enumerate(self.seq[:limit_terms], start=self.index_start):
            fx = trial_factor(x)
            facts.append((idx, x, fx))
            if x != 0:
                largest = max([abs(p) for p in fx.keys() if p not in (0, 1)], default=1)
                if largest <= 13:
                    smooth_hits.append((idx, x, fx))
            if is_square(x):
                square_hits.append((idx, x))
            if sp is not None and x > 1:
                try:
                    if bool(sp.isprime(x)):
                        prime_hits.append((idx, x))
                except Exception:
                    pass
        if smooth_hits and len(smooth_hits) >= max(3, limit_terms // 4):
            hyps.append(Hypothesis(
                score=min(0.72, 0.3 + 0.04 * len(smooth_hits)),
                title="Smoothness cluster",
                claim="Many observed terms factor over a very small prime set.",
                evidence=[str(t) for t in smooth_hits[:10]],
                falsifiers=["Smoothness in early terms often vanishes. Factor later terms and compare with random-size controls."],
                proof_obligations=["Prove the sequence is built from products/binomial coefficients, or bound prime support."],
                next_computations=["Use PARI factorint at larger terms and inspect prime support growth."],
                tags=["factorization", "smoothness"],
            ))
        if len(square_hits) >= 3:
            hyps.append(Hypothesis(
                score=min(0.65, 0.25 + 0.05 * len(square_hits)),
                title="Square terms recur",
                claim="Several terms are perfect squares; this may signal norm, elliptic, or quadratic-form structure.",
                evidence=[str(t) for t in square_hits[:12]],
                falsifiers=["Check square indices against a predicted law. Random small sequences often contain early squares."],
                proof_obligations=["Classify n such that a(n) is square, or connect to a known Diophantine equation."],
                next_computations=["Search OEIS and LMFDB; test Pell/elliptic curve interpretations."],
                tags=["squares", "diophantine"],
            ))
        if len(prime_hits) >= 3:
            hyps.append(Hypothesis(
                score=min(0.62, 0.22 + 0.04 * len(prime_hits)),
                title="Prime-producing positions",
                claim="Multiple observed terms are prime.",
                evidence=[str(t) for t in prime_hits[:12]],
                falsifiers=["Prime-rich prefixes are seductive. Test density and structural primality conditions at larger n."],
                proof_obligations=["Prove any claimed primality pattern or state it only as computational data."],
                next_computations=["Run PARI ispseudoprime/isprime on extended terms."],
                tags=["primality", "risk-overfit"],
            ))
        return hyps

    def all_hypotheses(self) -> List[Hypothesis]:
        hyps: List[Hypothesis] = []
        hyps.extend(self.polynomial_hypotheses())
        hyps.extend(self.recurrence_hypotheses())
        hyps.extend(self.modular_hypotheses())
        hyps.extend(self.divisibility_hypotheses())
        hyps.extend(self.factor_hypotheses())
        hyps.sort()
        return hyps

    def transform_pack(self) -> Dict[str, Any]:
        seq = self.seq
        table = finite_difference_table(seq, max_order=min(8, len(seq) - 1))
        factors = []
        for i, x in enumerate(seq[:20], start=self.index_start):
            factors.append({"n": i, "a_n": x, "factorization": trial_factor(x)})
        return {
            "finite_differences": table,
            "ratios": rational_ratios(seq, limit=20),
            "absolute_values": [abs(x) for x in seq[:30]],
            "mod_profiles": {str(m): [x % m for x in seq[:30]] for m in range(2, 13)},
            "visible_mod_periods": {str(m): modular_period(seq, m) for m in range(2, 37)},
            "factorizations_first_terms": factors,
            "valuation_profiles": {str(p): [valuation(x, p) for x in seq[:30]] for p in primes_upto(19)},
        }


def solve_linear_fraction(A: List[List[Fraction]], b: List[Fraction]) -> Optional[List[Fraction]]:
    """Gaussian elimination over Q."""
    n = len(A)
    if n == 0 or any(len(row) != n for row in A) or len(b) != n:
        return None
    M = [list(row) + [b[i]] for i, row in enumerate(A)]
    for col in range(n):
        pivot = None
        for r in range(col, n):
            if M[r][col] != 0:
                pivot = r
                break
        if pivot is None:
            return None
        if pivot != col:
            M[col], M[pivot] = M[pivot], M[col]
        pv = M[col][col]
        M[col] = [x / pv for x in M[col]]
        for r in range(n):
            if r == col:
                continue
            factor = M[r][col]
            if factor:
                M[r] = [M[r][c] - factor * M[col][c] for c in range(n + 1)]
    return [M[i][-1] for i in range(n)]


# ---------------------------------------------------------------------------
# Sage, PARI, and Lean handoff generation
# ---------------------------------------------------------------------------


def generate_sage_script(seq: Sequence[int], index_start: int = 0) -> str:
    seq_literal = repr([int(x) for x in seq])
    return f"""# Auto-generated by nt_discovery_workbench.py
# Run with: sage this_file.sage

from sage.all import *

seq = {seq_literal}
R.<x> = PolynomialRing(QQ)
print("length", len(seq))
print("first terms", seq[:20])

# Exact interpolation
pts = [(i + {index_start}, QQ(seq[i])) for i in range(len(seq))]
try:
    poly = R.lagrange_polynomial(pts)
    print("interpolation_degree", poly.degree())
    print("interpolation_factor", factor(poly))
except Exception as e:
    print("interpolation_error", repr(e))

# Guess recurrence using Sage if available
try:
    from sage.rings.berlekamp_massey import berlekamp_massey
    F = GF(1000003)
    bm = berlekamp_massey([F(a) for a in seq])
    print("berlekamp_massey_mod_1000003", bm)
except Exception as e:
    print("berlekamp_massey_error", repr(e))

# Factor first terms
for i, a in enumerate(seq[:30], start={index_start}):
    if a != 0:
        print("factor", i, factor(Integer(a)))
    else:
        print("factor", i, 0)
"""


def generate_gp_script(seq: Sequence[int]) -> str:
    seq_vec = ",".join(str(int(x)) for x in seq)
    return f"""\\ Auto-generated by nt_discovery_workbench.py
\\ Run with: gp -q this_file.gp

seq = [{seq_vec}];
print("length = ", #seq);
print("first terms = ", vector(min(#seq,20), i, seq[i]));

for(i=1, min(#seq,30),
  if(seq[i] != 0,
    print("factor ", i-1, " ", factor(seq[i])),
    print("factor ", i-1, " 0")
  )
);

\\ Characteristic polynomial helper placeholder:
\\ After a recurrence is found, paste Vec([c1,c2,...,ck]) below.
\\ charpoly_from_coeffs(c) = Pol(concat([1], vector(#c, i, -c[i])));
"""


def generate_lean_skeleton(seq: Sequence[int], top_hypotheses: Sequence[Hypothesis]) -> str:
    terms = ", ".join(str(int(x)) for x in seq[:20])
    claims = "\n".join([f"/- Candidate: {h.title}\nClaim: {h.claim}\nProof obligations: {'; '.join(h.proof_obligations)} -/" for h in top_hypotheses[:5]])
    return f"""import Mathlib

/-
Auto-generated Lean handoff skeleton.
This is intentionally not a fake proof. Fill in definitions only after the computational
hypothesis survives independent term generation and literature checks.

Observed first terms: [{terms}]
-/

{claims}

namespace NTDiscovery

-- Replace this with the real definition once found.
def a : Nat -> Int := fun _ => 0

-- Example theorem shape. Do not prove until the invariant is real.
theorem placeholder_observed_terms : True := by
  trivial

end NTDiscovery
"""


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------


@dataclass
class DiscoveryReport:
    input_hash: str
    created_utc: str
    sequence: List[int]
    summary: Dict[str, Any]
    transforms: Dict[str, Any]
    hypotheses: List[Hypothesis]
    tools: Dict[str, ToolStatus]
    online: Dict[str, Any] = field(default_factory=dict)
    handoff_files: Dict[str, str] = field(default_factory=dict)

    def to_jsonable(self) -> Dict[str, Any]:
        return {
            "input_hash": self.input_hash,
            "created_utc": self.created_utc,
            "sequence": self.sequence,
            "summary": self.summary,
            "transforms": self.transforms,
            "hypotheses": [h.to_dict() for h in self.hypotheses],
            "tools": {k: dataclasses.asdict(v) for k, v in self.tools.items()},
            "online": self.online,
            "handoff_files": self.handoff_files,
        }

    def markdown(self) -> str:
        lines: List[str] = []
        lines.append("# Number Theory Discovery Report")
        lines.append("")
        lines.append(f"Created UTC: `{self.created_utc}`")
        lines.append(f"Input SHA-256: `{self.input_hash}`")
        lines.append("")
        lines.append("## Sequence")
        lines.append("")
        lines.append("```text")
        lines.append(", ".join(str(x) for x in self.sequence[:80]))
        if len(self.sequence) > 80:
            lines.append(f"... ({len(self.sequence)} terms total)")
        lines.append("```")
        lines.append("")
        lines.append("## Tool Status")
        lines.append("")
        for name, st in self.tools.items():
            mark = "yes" if st.available else "no"
            detail = f" | {st.detail}" if st.detail else ""
            path = f" | `{st.path}`" if st.path else ""
            lines.append(f"- {name}: {mark}{path}{detail}")
        lines.append("")
        lines.append("## Basic Summary")
        lines.append("")
        lines.append("```json")
        lines.append(json.dumps(self.summary, indent=2, default=str))
        lines.append("```")
        lines.append("")
        lines.append("## Ranked Hypotheses")
        lines.append("")
        if not self.hypotheses:
            lines.append("No strong structural hypotheses found from the current prefix. Extend the sequence or provide a definition.")
        for i, h in enumerate(self.hypotheses, start=1):
            lines.append(f"### {i}. {h.title}")
            lines.append("")
            lines.append(f"Score: `{h.score:.3f}` | Confidence: `{h.confidence}` | Tags: `{', '.join(h.tags)}`")
            lines.append("")
            lines.append(f"**Claim:** {h.claim}")
            lines.append("")
            lines.append("**Evidence**")
            for e in h.evidence:
                lines.append(f"- {e}")
            lines.append("")
            lines.append("**Falsifiers**")
            for f in h.falsifiers:
                lines.append(f"- {f}")
            lines.append("")
            lines.append("**Proof obligations**")
            for p in h.proof_obligations:
                lines.append(f"- {p}")
            lines.append("")
            lines.append("**Next computations**")
            for n in h.next_computations:
                lines.append(f"- {n}")
            lines.append("")
        if self.online:
            lines.append("## Online Checks")
            lines.append("")
            lines.append("```json")
            lines.append(json.dumps(self.online, indent=2, default=str)[:12000])
            lines.append("```")
            lines.append("")
        lines.append("## Handoff Files")
        lines.append("")
        for label, path in self.handoff_files.items():
            lines.append(f"- {label}: `{path}`")
        lines.append("")
        lines.append("## Rule of Engagement")
        lines.append("")
        lines.append("Nothing above is a theorem. The machine is allowed to propose. Proof starts only after the hypothesis survives fresh terms, database checks, and a formal proof route.")
        return "\n".join(lines)


class Workbench:
    def __init__(self, output_dir: Path, online: bool = False, timeout_seconds: int = 20) -> None:
        self.output_dir = output_dir
        self.online = online
        self.tools = ExternalTools(timeout_seconds=timeout_seconds)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def analyze_sequence(self, seq: Sequence[int], index_start: int = 0, label: str = "sequence") -> DiscoveryReport:
        analyzer = SequenceAnalyzer(seq, index_start=index_start)
        summary = analyzer.basic_summary()
        transforms = analyzer.transform_pack()
        hypotheses = analyzer.all_hypotheses()
        tool_status = self.tools.status()
        created = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        input_hash = sha256_text(",".join(str(x) for x in seq))
        safe_label = re.sub(r"[^A-Za-z0-9_.-]+", "_", label).strip("_") or "sequence"
        stem = f"{safe_label}_{input_hash[:12]}"

        online_data: Dict[str, Any] = {}
        if self.online:
            online_data["oeis"] = OEISClient().search_sequence(seq)
            online_data["lmfdb_urls"] = LMFDBHelper.urls_for_sequence(seq)
            online_data["literature_urls"] = LiteratureHelper.search_urls(seq)
        else:
            online_data["disabled"] = True
            online_data["lmfdb_urls"] = LMFDBHelper.urls_for_sequence(seq)
            online_data["literature_urls"] = LiteratureHelper.search_urls(seq)

        sage_path = self.output_dir / f"{stem}.sage"
        gp_path = self.output_dir / f"{stem}.gp"
        lean_path = self.output_dir / f"{stem}.lean"
        sage_path.write_text(generate_sage_script(seq, index_start=index_start), encoding="utf-8")
        gp_path.write_text(generate_gp_script(seq), encoding="utf-8")
        lean_path.write_text(generate_lean_skeleton(seq, hypotheses), encoding="utf-8")

        report = DiscoveryReport(
            input_hash=input_hash,
            created_utc=created,
            sequence=[int(x) for x in seq],
            summary=summary,
            transforms=transforms,
            hypotheses=hypotheses,
            tools=tool_status,
            online=online_data,
            handoff_files={"sage": str(sage_path), "pari_gp": str(gp_path), "lean": str(lean_path)},
        )

        json_path = self.output_dir / f"{stem}.report.json"
        md_path = self.output_dir / f"{stem}.report.md"
        json_path.write_text(json.dumps(report.to_jsonable(), indent=2, default=str), encoding="utf-8")
        md_path.write_text(report.markdown(), encoding="utf-8")
        report.handoff_files["json_report"] = str(json_path)
        report.handoff_files["markdown_report"] = str(md_path)
        # Rewrite after paths are complete.
        json_path.write_text(json.dumps(report.to_jsonable(), indent=2, default=str), encoding="utf-8")
        md_path.write_text(report.markdown(), encoding="utf-8")
        return report


# ---------------------------------------------------------------------------
# Formula scanner for a(n) definitions
# ---------------------------------------------------------------------------


SAFE_GLOBALS: Dict[str, Any] = {
    "__builtins__": {},
    "abs": abs,
    "min": min,
    "max": max,
    "sum": sum,
    "pow": pow,
    "range": range,
    "math": math,
    "gcd": math.gcd,
    "isqrt": math.isqrt,
}


def generate_from_formula(formula: str, n_terms: int, index_start: int = 0) -> List[int]:
    """
    Generate sequence from a restricted Python expression in n.

    Example:
        --formula "(n*n+n+2)//2"
    """
    seq: List[int] = []
    code = compile(formula, "<formula>", "eval")
    for n in range(index_start, index_start + n_terms):
        val = eval(code, SAFE_GLOBALS, {"n": n})
        if not isinstance(val, int):
            if isinstance(val, float) and val.is_integer():
                val = int(val)
            else:
                raise ValueError(f"Formula returned non-integer at n={n}: {val!r}")
        seq.append(int(val))
    return seq


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def cmd_probe(args: argparse.Namespace) -> int:
    tools = ExternalTools(timeout_seconds=args.timeout)
    print(json.dumps({k: dataclasses.asdict(v) for k, v in tools.status().items()}, indent=2))
    if args.gp_expr:
        print(json.dumps({"gp_result": tools.run_gp(args.gp_expr)}, indent=2))
    if args.sage_code:
        print(json.dumps({"sage_result": tools.run_sage(args.sage_code)}, indent=2))
    return 0


def cmd_analyze_seq(args: argparse.Namespace) -> int:
    seq = parse_int_sequence(args.seq)
    wb = Workbench(Path(args.out), online=args.online, timeout_seconds=args.timeout)
    report = wb.analyze_sequence(seq, index_start=args.index_start, label=args.label)
    if args.format == "json":
        print(json.dumps(report.to_jsonable(), indent=2, default=str))
    elif args.format == "md":
        print(report.markdown())
    else:
        top = report.hypotheses[:5]
        print(f"Wrote report bundle to: {Path(args.out).resolve()}")
        print(f"Input SHA-256: {report.input_hash}")
        print("Top hypotheses:")
        for i, h in enumerate(top, start=1):
            print(f"  {i}. {h.title} | score={h.score:.3f} | {h.claim}")
        print("Files:")
        for k, v in report.handoff_files.items():
            print(f"  {k}: {v}")
    return 0


def cmd_formula(args: argparse.Namespace) -> int:
    seq = generate_from_formula(args.formula, args.terms, index_start=args.index_start)
    wb = Workbench(Path(args.out), online=args.online, timeout_seconds=args.timeout)
    label = args.label or "formula"
    report = wb.analyze_sequence(seq, index_start=args.index_start, label=label)
    print(f"Generated sequence from formula: {args.formula}")
    print(f"Wrote report bundle to: {Path(args.out).resolve()}")
    print(f"Input SHA-256: {report.input_hash}")
    for k, v in report.handoff_files.items():
        print(f"  {k}: {v}")
    return 0


def cmd_selftest(args: argparse.Namespace) -> int:
    tests = {
        "fibonacci": [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144],
        "squares": [n * n for n in range(12)],
        "powers2": [2 ** n for n in range(12)],
        "triangular": [n * (n + 1) // 2 for n in range(12)],
    }
    wb = Workbench(Path(args.out), online=False, timeout_seconds=args.timeout)
    failures: List[str] = []
    for label, seq in tests.items():
        report = wb.analyze_sequence(seq, label=label)
        titles = [h.title.lower() for h in report.hypotheses]
        if label in ("squares", "triangular") and not any("polynomial" in t for t in titles):
            failures.append(f"{label}: expected polynomial hypothesis")
        if label in ("fibonacci", "powers2") and not any("recurrence" in t for t in titles):
            failures.append(f"{label}: expected recurrence hypothesis")
    if failures:
        print("SELFTEST FAILED")
        for f in failures:
            print("-", f)
        return 1
    print(f"SELFTEST PASSED. Bundles written to {Path(args.out).resolve()}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="nt_discovery_workbench.py",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description=textwrap.dedent("""
        Number-theory discovery infrastructure.

        This is the layer before proof. It mines structure, attacks itself with falsifiers,
        generates Sage/PARI/Lean handoff files, and creates reproducible reports.
        """),
    )
    p.add_argument("--timeout", type=int, default=20, help="Timeout in seconds for external tool calls.")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("analyze-seq", help="Analyze an integer sequence.")
    a.add_argument("--seq", required=True, help="Sequence terms, comma or whitespace separated.")
    a.add_argument("--index-start", type=int, default=0, help="Index assigned to the first term.")
    a.add_argument("--out", default="nt_discovery_out", help="Output directory.")
    a.add_argument("--label", default="sequence", help="Output label.")
    a.add_argument("--online", action="store_true", help="Enable OEIS lookup. Also emits LMFDB/literature URLs.")
    a.add_argument("--format", choices=["summary", "json", "md"], default="summary")
    a.set_defaults(func=cmd_analyze_seq)

    f = sub.add_parser("formula", help="Generate terms from a restricted Python formula in n, then analyze.")
    f.add_argument("--formula", required=True, help="Expression in n returning an integer.")
    f.add_argument("--terms", type=int, default=30)
    f.add_argument("--index-start", type=int, default=0)
    f.add_argument("--out", default="nt_discovery_out")
    f.add_argument("--label", default=None)
    f.add_argument("--online", action="store_true")
    f.set_defaults(func=cmd_formula)

    pr = sub.add_parser("probe", help="Show available external tools and optionally run a GP/Sage command.")
    pr.add_argument("--gp-expr", default=None)
    pr.add_argument("--sage-code", default=None)
    pr.set_defaults(func=cmd_probe)

    st = sub.add_parser("selftest", help="Run built-in regression checks.")
    st.add_argument("--out", default="nt_discovery_selftest")
    st.set_defaults(func=cmd_selftest)

    return p


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
