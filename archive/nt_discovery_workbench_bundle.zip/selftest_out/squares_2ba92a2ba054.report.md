# Number Theory Discovery Report

Created UTC: `2026-05-21T20:16:06Z`
Input SHA-256: `2ba92a2ba05498b9b203c0f8eb238701180030a0b76b0492c2129f60f54fd1f9`

## Sequence

```text
0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100, 121
```

## Tool Status

- sage: no
- gp: no
- sympy: yes | 1.14.0
- cypari2: no | No module named 'cypari2'

## Basic Summary

```json
{
  "length": 12,
  "index_start": 0,
  "first_terms": [
    0,
    1,
    4,
    9,
    16,
    25,
    36,
    49,
    64,
    81,
    100,
    121
  ],
  "last_terms": [
    4,
    9,
    16,
    25,
    36,
    49,
    64,
    81,
    100,
    121
  ],
  "min": 0,
  "max": 121,
  "gcd_all_terms": 1,
  "gcd_differences": 1,
  "signs": {
    "zero": 1,
    "positive": 11
  },
  "monotone_non_decreasing": true,
  "monotone_increasing": true,
  "rough_growth_ratio_tail": [
    "25/16",
    "36/25",
    "49/36",
    "64/49",
    "81/64",
    "100/81",
    "121/100"
  ],
  "max_abs_bits": 7
}
```

## Ranked Hypotheses

### 1. Polynomial sequence of degree 2

Score: `0.950` | Confidence: `high-computational` | Tags: `finite-difference, polynomial`

**Claim:** The observed terms fit a polynomial in n of degree 2 with constant 2th finite difference 2.

**Evidence**
- Finite difference order 2 is constant across 10 observed positions.

**Falsifiers**
- Compute at least 5 more terms from the alleged source and check whether the same finite difference stays constant.

**Proof obligations**
- Derive the closed polynomial formula and prove by finite-difference induction.

**Next computations**
- Interpolate exact polynomial over Q and test extrapolated terms.

### 2. Linear recurrence candidate, order 3

Score: `0.825` | Confidence: `high-computational` | Tags: `linear-recurrence, generating-function`

**Claim:** a(n) = (3)*a(n-1) + (-3)*a(n-2) + (1)*a(n-3)

**Evidence**
- The recurrence exactly predicts 9 in-sample positions after solving over Q.

**Falsifiers**
- Generate fresh terms independently and check the recurrence. Low-order recurrences can overfit short sequences.

**Proof obligations**
- Find characteristic polynomial, prove initial conditions, then prove recurrence by induction or generating functions.

**Next computations**
- Use Sage/PARI to factor the characteristic polynomial and inspect roots/modular reductions.

### 3. Smoothness cluster

Score: `0.720` | Confidence: `medium-computational` | Tags: `factorization, smoothness`

**Claim:** Many observed terms factor over a very small prime set.

**Evidence**
- (1, 1, {})
- (2, 4, {2: 2})
- (3, 9, {3: 2})
- (4, 16, {2: 4})
- (5, 25, {5: 2})
- (6, 36, {2: 2, 3: 2})
- (7, 49, {7: 2})
- (8, 64, {2: 6})
- (9, 81, {3: 4})
- (10, 100, {2: 2, 5: 2})

**Falsifiers**
- Smoothness in early terms often vanishes. Factor later terms and compare with random-size controls.

**Proof obligations**
- Prove the sequence is built from products/binomial coefficients, or bound prime support.

**Next computations**
- Use PARI factorint at larger terms and inspect prime support growth.

### 4. Exact interpolation candidate

Score: `0.650` | Confidence: `medium-computational` | Tags: `interpolation, weak-unless-validated`

**Claim:** A degree 2 rational polynomial interpolates all observed points: n**2

**Evidence**
- SymPy exact rational interpolation succeeded.

**Falsifiers**
- Interpolation always fits finite data. Demand out-of-sample terms or a structural derivation.

**Proof obligations**
- Prove the source recurrence or counting argument implies the polynomial formula.

**Next computations**
- Ask Sage to simplify the polynomial in binomial-coefficient basis.

### 5. Square terms recur

Score: `0.650` | Confidence: `medium-computational` | Tags: `squares, diophantine`

**Claim:** Several terms are perfect squares; this may signal norm, elliptic, or quadratic-form structure.

**Evidence**
- (0, 0)
- (1, 1)
- (2, 4)
- (3, 9)
- (4, 16)
- (5, 25)
- (6, 36)
- (7, 49)
- (8, 64)
- (9, 81)
- (10, 100)
- (11, 121)

**Falsifiers**
- Check square indices against a predicted law. Random small sequences often contain early squares.

**Proof obligations**
- Classify n such that a(n) is square, or connect to a known Diophantine equation.

**Next computations**
- Search OEIS and LMFDB; test Pell/elliptic curve interpretations.

### 6. Modular periodic structure

Score: `0.560` | Confidence: `low` | Tags: `modular, periodicity`

**Claim:** The sequence shows repeated residue behavior over several small moduli.

**Evidence**
- mod 2: visible period 2
- mod 3: visible period 3
- mod 4: visible period 2
- mod 5: visible period 5
- mod 6: visible period 6
- mod 8: visible period 4
- mod 12: visible period 6

**Falsifiers**
- Visible modular periods on a short prefix may collapse. Extend terms and retest.

**Proof obligations**
- Prove periodicity modulo m using recurrence, automaton, or finite-state argument.

**Next computations**
- Search for automatic/regular sequence signatures and compare with OEIS hits.

### 7. p-adic valuation structure

Score: `0.480` | Confidence: `low` | Tags: `p-adic, valuation`

**Claim:** Prime-adic valuations show nontrivial repeated structure worth mining.

**Evidence**
- v_2 reaches 6 with pattern [None, 0, 2, 0, 4, 0, 2, 0, 6, 0, 2, 0]
- v_3 reaches 4 with pattern [None, 0, 0, 2, 0, 0, 2, 0, 0, 4, 0, 0]
- v_5 reaches 2 with pattern [None, 0, 0, 0, 0, 2, 0, 0, 0, 0, 2, 0]
- v_7 reaches 2 with pattern [None, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0]
- v_11 reaches 2 with pattern [None, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2]

**Falsifiers**
- Compare v_p(a_n) against v_p(n), Lucas valuations, LTE predictions, and random baselines.

**Proof obligations**
- Identify exact valuation formula or prove bounds.

**Next computations**
- Run PARI valuation/factorization at larger n and search for LTE-compatible forms.

## Online Checks

```json
{
  "disabled": true,
  "lmfdb_urls": [
    {
      "label": "LMFDB global search",
      "url": "https://www.lmfdb.org/search/?q=0%2C1%2C4%2C9%2C16%2C25%2C36%2C49%2C64%2C81"
    },
    {
      "label": "Elliptic curves over Q",
      "url": "https://www.lmfdb.org/EllipticCurve/Q/"
    },
    {
      "label": "Number fields",
      "url": "https://www.lmfdb.org/NumberField/"
    },
    {
      "label": "Modular forms",
      "url": "https://www.lmfdb.org/ModularForm/"
    },
    {
      "label": "L-functions",
      "url": "https://www.lmfdb.org/L/"
    }
  ],
  "literature_urls": [
    {
      "label": "arXiv search",
      "url": "https://arxiv.org/search/?query=%220%2C1%2C4%2C9%2C16%2C25%2C36%2C49%2C64%2C81%2C100%2C121%22&searchtype=all"
    },
    {
      "label": "Google Scholar search",
      "url": "https://scholar.google.com/scholar?q=%220%2C1%2C4%2C9%2C16%2C25%2C36%2C49%2C64%2C81%2C100%2C121%22"
    },
    {
      "label": "zbMATH search",
      "url": "https://zbmath.org/?q=%220%2C1%2C4%2C9%2C16%2C25%2C36%2C49%2C64%2C81%2C100%2C121%22"
    },
    {
      "label": "MathSciNet manual search",
      "url": "https://mathscinet.ams.org/mathscinet"
    }
  ]
}
```

## Handoff Files

- sage: `/mnt/data/nt_workbench/selftest_out/squares_2ba92a2ba054.sage`
- pari_gp: `/mnt/data/nt_workbench/selftest_out/squares_2ba92a2ba054.gp`
- lean: `/mnt/data/nt_workbench/selftest_out/squares_2ba92a2ba054.lean`
- json_report: `/mnt/data/nt_workbench/selftest_out/squares_2ba92a2ba054.report.json`
- markdown_report: `/mnt/data/nt_workbench/selftest_out/squares_2ba92a2ba054.report.md`

## Rule of Engagement

Nothing above is a theorem. The machine is allowed to propose. Proof starts only after the hypothesis survives fresh terms, database checks, and a formal proof route.