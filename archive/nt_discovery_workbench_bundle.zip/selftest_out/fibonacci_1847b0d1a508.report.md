# Number Theory Discovery Report

Created UTC: `2026-05-21T20:16:06Z`
Input SHA-256: `1847b0d1a508c6208adbd4a9080dba8550b2569877b20d90a3d70bc06358a0d1`

## Sequence

```text
1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144
```

## Tool Status

- sage: no
- gp: no
- sympy: yes | 1.14.0
- cypari2: no | No module named 'cypari2'

## Basic Summary

```json
{
  "length": 12,
  "index_start": 0,
  "first_terms": [
    1,
    1,
    2,
    3,
    5,
    8,
    13,
    21,
    34,
    55,
    89,
    144
  ],
  "last_terms": [
    2,
    3,
    5,
    8,
    13,
    21,
    34,
    55,
    89,
    144
  ],
  "min": 1,
  "max": 144,
  "gcd_all_terms": 1,
  "gcd_differences": 1,
  "signs": {
    "positive": 12
  },
  "monotone_non_decreasing": true,
  "monotone_increasing": false,
  "rough_growth_ratio_tail": [
    "8/5",
    "13/8",
    "21/13",
    "34/21",
    "55/34",
    "89/55",
    "144/89"
  ],
  "max_abs_bits": 8
}
```

## Ranked Hypotheses

### 1. Polynomial sequence of degree 11

Score: `0.950` | Confidence: `high-computational` | Tags: `finite-difference, polynomial`

**Claim:** The observed terms fit a polynomial in n of degree 11 with constant 11th finite difference -55.

**Evidence**
- Finite difference order 11 is constant across 1 observed positions.

**Falsifiers**
- Compute at least 5 more terms from the alleged source and check whether the same finite difference stays constant.

**Proof obligations**
- Derive the closed polynomial formula and prove by finite-difference induction.

**Next computations**
- Interpolate exact polynomial over Q and test extrapolated terms.

### 2. Linear recurrence candidate, order 2

Score: `0.900` | Confidence: `high-computational` | Tags: `linear-recurrence, generating-function`

**Claim:** a(n) = (1)*a(n-1) + (1)*a(n-2)

**Evidence**
- The recurrence exactly predicts 10 in-sample positions after solving over Q.

**Falsifiers**
- Generate fresh terms independently and check the recurrence. Low-order recurrences can overfit short sequences.

**Proof obligations**
- Find characteristic polynomial, prove initial conditions, then prove recurrence by induction or generating functions.

**Next computations**
- Use Sage/PARI to factor the characteristic polynomial and inspect roots/modular reductions.

### 3. Divisibility-sequence candidate

Score: `0.860` | Confidence: `high-computational` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed index divisibility appears to imply term divisibility.

**Evidence**
- Passed 23/23 divisibility checks under index_start adjustment 0.

**Falsifiers**
- Extend the sequence and test all i | j pairs again. Check whether zeros/trivial units drive the result.

**Proof obligations**
- Prove strong divisibility or divisibility from algebraic group/recurrence structure.

**Next computations**
- Check gcd(a_m,a_n)=a_gcd(m,n), Lucas/Elliptic divisibility signatures.

### 4. Divisibility-sequence candidate

Score: `0.860` | Confidence: `high-computational` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed index divisibility appears to imply term divisibility.

**Evidence**
- Passed 23/23 divisibility checks under index_start adjustment 1.

**Falsifiers**
- Extend the sequence and test all i | j pairs again. Check whether zeros/trivial units drive the result.

**Proof obligations**
- Prove strong divisibility or divisibility from algebraic group/recurrence structure.

**Next computations**
- Check gcd(a_m,a_n)=a_gcd(m,n), Lucas/Elliptic divisibility signatures.

### 5. Smoothness cluster

Score: `0.700` | Confidence: `medium-computational` | Tags: `factorization, smoothness`

**Claim:** Many observed terms factor over a very small prime set.

**Evidence**
- (0, 1, {})
- (1, 1, {})
- (2, 2, {2: 1})
- (3, 3, {3: 1})
- (4, 5, {5: 1})
- (5, 8, {2: 3})
- (6, 13, {13: 1})
- (7, 21, {3: 1, 7: 1})
- (9, 55, {5: 1, 11: 1})
- (11, 144, {2: 4, 3: 2})

**Falsifiers**
- Smoothness in early terms often vanishes. Factor later terms and compare with random-size controls.

**Proof obligations**
- Prove the sequence is built from products/binomial coefficients, or bound prime support.

**Next computations**
- Use PARI factorint at larger terms and inspect prime support growth.

### 6. Prime-producing positions

Score: `0.420` | Confidence: `low` | Tags: `primality, risk-overfit`

**Claim:** Multiple observed terms are prime.

**Evidence**
- (2, 2)
- (3, 3)
- (4, 5)
- (6, 13)
- (10, 89)

**Falsifiers**
- Prime-rich prefixes are seductive. Test density and structural primality conditions at larger n.

**Proof obligations**
- Prove any claimed primality pattern or state it only as computational data.

**Next computations**
- Run PARI ispseudoprime/isprime on extended terms.

### 7. Modular periodic structure

Score: `0.410` | Confidence: `low` | Tags: `modular, periodicity`

**Claim:** The sequence shows repeated residue behavior over several small moduli.

**Evidence**
- mod 2: visible period 3
- mod 4: visible period 6

**Falsifiers**
- Visible modular periods on a short prefix may collapse. Extend terms and retest.

**Proof obligations**
- Prove periodicity modulo m using recurrence, automaton, or finite-state argument.

**Next computations**
- Search for automatic/regular sequence signatures and compare with OEIS hits.

### 8. Square terms recur

Score: `0.400` | Confidence: `low` | Tags: `squares, diophantine`

**Claim:** Several terms are perfect squares; this may signal norm, elliptic, or quadratic-form structure.

**Evidence**
- (0, 1)
- (1, 1)
- (11, 144)

**Falsifiers**
- Check square indices against a predicted law. Random small sequences often contain early squares.

**Proof obligations**
- Classify n such that a(n) is square, or connect to a known Diophantine equation.

**Next computations**
- Search OEIS and LMFDB; test Pell/elliptic curve interpretations.

### 9. p-adic valuation structure

Score: `0.360` | Confidence: `low` | Tags: `p-adic, valuation`

**Claim:** Prime-adic valuations show nontrivial repeated structure worth mining.

**Evidence**
- v_2 reaches 4 with pattern [0, 0, 1, 0, 0, 3, 0, 0, 1, 0, 0, 4]
- v_3 reaches 2 with pattern [0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 2]

**Falsifiers**
- Compare v_p(a_n) against v_p(n), Lucas valuations, LTE predictions, and random baselines.

**Proof obligations**
- Identify exact valuation formula or prove bounds.

**Next computations**
- Run PARI valuation/factorization at larger n and search for LTE-compatible forms.

## Online Checks

```json
{
  "disabled": true,
  "lmfdb_urls": [
    {
      "label": "LMFDB global search",
      "url": "https://www.lmfdb.org/search/?q=1%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55"
    },
    {
      "label": "Elliptic curves over Q",
      "url": "https://www.lmfdb.org/EllipticCurve/Q/"
    },
    {
      "label": "Number fields",
      "url": "https://www.lmfdb.org/NumberField/"
    },
    {
      "label": "Modular forms",
      "url": "https://www.lmfdb.org/ModularForm/"
    },
    {
      "label": "L-functions",
      "url": "https://www.lmfdb.org/L/"
    }
  ],
  "literature_urls": [
    {
      "label": "arXiv search",
      "url": "https://arxiv.org/search/?query=%221%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%2C89%2C144%22&searchtype=all"
    },
    {
      "label": "Google Scholar search",
      "url": "https://scholar.google.com/scholar?q=%221%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%2C89%2C144%22"
    },
    {
      "label": "zbMATH search",
      "url": "https://zbmath.org/?q=%221%2C1%2C2%2C3%2C5%2C8%2C13%2C21%2C34%2C55%2C89%2C144%22"
    },
    {
      "label": "MathSciNet manual search",
      "url": "https://mathscinet.ams.org/mathscinet"
    }
  ]
}
```

## Handoff Files

- sage: `/mnt/data/nt_workbench/selftest_out/fibonacci_1847b0d1a508.sage`
- pari_gp: `/mnt/data/nt_workbench/selftest_out/fibonacci_1847b0d1a508.gp`
- lean: `/mnt/data/nt_workbench/selftest_out/fibonacci_1847b0d1a508.lean`
- json_report: `/mnt/data/nt_workbench/selftest_out/fibonacci_1847b0d1a508.report.json`
- markdown_report: `/mnt/data/nt_workbench/selftest_out/fibonacci_1847b0d1a508.report.md`

## Rule of Engagement

Nothing above is a theorem. The machine is allowed to propose. Proof starts only after the hypothesis survives fresh terms, database checks, and a formal proof route.