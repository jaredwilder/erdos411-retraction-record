# Number Theory Discovery Report

Created UTC: `2026-05-21T20:16:06Z`
Input SHA-256: `c8fdd21090e3a477176886c3226c569b635bd25d9f5372136bf9a938f772f5d5`

## Sequence

```text
0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66
```

## Tool Status

- sage: no
- gp: no
- sympy: yes | 1.14.0
- cypari2: no | No module named 'cypari2'

## Basic Summary

```json
{
  "length": 12,
  "index_start": 0,
  "first_terms": [
    0,
    1,
    3,
    6,
    10,
    15,
    21,
    28,
    36,
    45,
    55,
    66
  ],
  "last_terms": [
    3,
    6,
    10,
    15,
    21,
    28,
    36,
    45,
    55,
    66
  ],
  "min": 0,
  "max": 66,
  "gcd_all_terms": 1,
  "gcd_differences": 1,
  "signs": {
    "zero": 1,
    "positive": 11
  },
  "monotone_non_decreasing": true,
  "monotone_increasing": true,
  "rough_growth_ratio_tail": [
    "3/2",
    "7/5",
    "4/3",
    "9/7",
    "5/4",
    "11/9",
    "6/5"
  ],
  "max_abs_bits": 7
}
```

## Ranked Hypotheses

### 1. Polynomial sequence of degree 2

Score: `0.950` | Confidence: `high-computational` | Tags: `finite-difference, polynomial`

**Claim:** The observed terms fit a polynomial in n of degree 2 with constant 2th finite difference 1.

**Evidence**
- Finite difference order 2 is constant across 10 observed positions.

**Falsifiers**
- Compute at least 5 more terms from the alleged source and check whether the same finite difference stays constant.

**Proof obligations**
- Derive the closed polynomial formula and prove by finite-difference induction.

**Next computations**
- Interpolate exact polynomial over Q and test extrapolated terms.

### 2. Linear recurrence candidate, order 3

Score: `0.825` | Confidence: `high-computational` | Tags: `linear-recurrence, generating-function`

**Claim:** a(n) = (3)*a(n-1) + (-3)*a(n-2) + (1)*a(n-3)

**Evidence**
- The recurrence exactly predicts 9 in-sample positions after solving over Q.

**Falsifiers**
- Generate fresh terms independently and check the recurrence. Low-order recurrences can overfit short sequences.

**Proof obligations**
- Find characteristic polynomial, prove initial conditions, then prove recurrence by induction or generating functions.

**Next computations**
- Use Sage/PARI to factor the characteristic polynomial and inspect roots/modular reductions.

### 3. Smoothness cluster

Score: `0.720` | Confidence: `medium-computational` | Tags: `factorization, smoothness`

**Claim:** Many observed terms factor over a very small prime set.

**Evidence**
- (1, 1, {})
- (2, 3, {3: 1})
- (3, 6, {2: 1, 3: 1})
- (4, 10, {2: 1, 5: 1})
- (5, 15, {3: 1, 5: 1})
- (6, 21, {3: 1, 7: 1})
- (7, 28, {2: 2, 7: 1})
- (8, 36, {2: 2, 3: 2})
- (9, 45, {3: 2, 5: 1})
- (10, 55, {5: 1, 11: 1})

**Falsifiers**
- Smoothness in early terms often vanishes. Factor later terms and compare with random-size controls.

**Proof obligations**
- Prove the sequence is built from products/binomial coefficients, or bound prime support.

**Next computations**
- Use PARI factorint at larger terms and inspect prime support growth.

### 4. Exact interpolation candidate

Score: `0.650` | Confidence: `medium-computational` | Tags: `interpolation, weak-unless-validated`

**Claim:** A degree 2 rational polynomial interpolates all observed points: n*(n + 1)/2

**Evidence**
- SymPy exact rational interpolation succeeded.

**Falsifiers**
- Interpolation always fits finite data. Demand out-of-sample terms or a structural derivation.

**Proof obligations**
- Prove the source recurrence or counting argument implies the polynomial formula.

**Next computations**
- Ask Sage to simplify the polynomial in binomial-coefficient basis.

### 5. Modular periodic structure

Score: `0.440` | Confidence: `low` | Tags: `modular, periodicity`

**Claim:** The sequence shows repeated residue behavior over several small moduli.

**Evidence**
- mod 2: visible period 4
- mod 3: visible period 3
- mod 5: visible period 5

**Falsifiers**
- Visible modular periods on a short prefix may collapse. Extend terms and retest.

**Proof obligations**
- Prove periodicity modulo m using recurrence, automaton, or finite-state argument.

**Next computations**
- Search for automatic/regular sequence signatures and compare with OEIS hits.

### 6. Square terms recur

Score: `0.400` | Confidence: `low` | Tags: `squares, diophantine`

**Claim:** Several terms are perfect squares; this may signal norm, elliptic, or quadratic-form structure.

**Evidence**
- (0, 0)
- (1, 1)
- (8, 36)

**Falsifiers**
- Check square indices against a predicted law. Random small sequences often contain early squares.

**Proof obligations**
- Classify n such that a(n) is square, or connect to a known Diophantine equation.

**Next computations**
- Search OEIS and LMFDB; test Pell/elliptic curve interpretations.

### 7. p-adic valuation structure

Score: `0.360` | Confidence: `low` | Tags: `p-adic, valuation`

**Claim:** Prime-adic valuations show nontrivial repeated structure worth mining.

**Evidence**
- v_2 reaches 2 with pattern [None, 0, 0, 1, 1, 0, 0, 2, 2, 0, 0, 1]
- v_3 reaches 2 with pattern [None, 0, 1, 1, 0, 1, 1, 0, 2, 2, 0, 1]

**Falsifiers**
- Compare v_p(a_n) against v_p(n), Lucas valuations, LTE predictions, and random baselines.

**Proof obligations**
- Identify exact valuation formula or prove bounds.

**Next computations**
- Run PARI valuation/factorization at larger n and search for LTE-compatible forms.

## Online Checks

```json
{
  "disabled": true,
  "lmfdb_urls": [
    {
      "label": "LMFDB global search",
      "url": "https://www.lmfdb.org/search/?q=0%2C1%2C3%2C6%2C10%2C15%2C21%2C28%2C36%2C45"
    },
    {
      "label": "Elliptic curves over Q",
      "url": "https://www.lmfdb.org/EllipticCurve/Q/"
    },
    {
      "label": "Number fields",
      "url": "https://www.lmfdb.org/NumberField/"
    },
    {
      "label": "Modular forms",
      "url": "https://www.lmfdb.org/ModularForm/"
    },
    {
      "label": "L-functions",
      "url": "https://www.lmfdb.org/L/"
    }
  ],
  "literature_urls": [
    {
      "label": "arXiv search",
      "url": "https://arxiv.org/search/?query=%220%2C1%2C3%2C6%2C10%2C15%2C21%2C28%2C36%2C45%2C55%2C66%22&searchtype=all"
    },
    {
      "label": "Google Scholar search",
      "url": "https://scholar.google.com/scholar?q=%220%2C1%2C3%2C6%2C10%2C15%2C21%2C28%2C36%2C45%2C55%2C66%22"
    },
    {
      "label": "zbMATH search",
      "url": "https://zbmath.org/?q=%220%2C1%2C3%2C6%2C10%2C15%2C21%2C28%2C36%2C45%2C55%2C66%22"
    },
    {
      "label": "MathSciNet manual search",
      "url": "https://mathscinet.ams.org/mathscinet"
    }
  ]
}
```

## Handoff Files

- sage: `/mnt/data/nt_workbench/selftest_out/triangular_c8fdd21090e3.sage`
- pari_gp: `/mnt/data/nt_workbench/selftest_out/triangular_c8fdd21090e3.gp`
- lean: `/mnt/data/nt_workbench/selftest_out/triangular_c8fdd21090e3.lean`
- json_report: `/mnt/data/nt_workbench/selftest_out/triangular_c8fdd21090e3.report.json`
- markdown_report: `/mnt/data/nt_workbench/selftest_out/triangular_c8fdd21090e3.report.md`

## Rule of Engagement

Nothing above is a theorem. The machine is allowed to propose. Proof starts only after the hypothesis survives fresh terms, database checks, and a formal proof route.