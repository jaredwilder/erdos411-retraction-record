# Number Theory Discovery Report

Created UTC: `2026-05-21T20:16:06Z`
Input SHA-256: `6082ae318cb4f5dc0e9fd97c1ec882c26820db2a2200ab3d1fd64440d9b7689c`

## Sequence

```text
1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048
```

## Tool Status

- sage: no
- gp: no
- sympy: yes | 1.14.0
- cypari2: no | No module named 'cypari2'

## Basic Summary

```json
{
  "length": 12,
  "index_start": 0,
  "first_terms": [
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048
  ],
  "last_terms": [
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048
  ],
  "min": 1,
  "max": 2048,
  "gcd_all_terms": 1,
  "gcd_differences": 1,
  "signs": {
    "positive": 12
  },
  "monotone_non_decreasing": true,
  "monotone_increasing": true,
  "rough_growth_ratio_tail": [
    "2",
    "2",
    "2",
    "2",
    "2",
    "2",
    "2"
  ],
  "max_abs_bits": 12
}
```

## Ranked Hypotheses

### 1. Polynomial sequence of degree 11

Score: `0.950` | Confidence: `high-computational` | Tags: `finite-difference, polynomial`

**Claim:** The observed terms fit a polynomial in n of degree 11 with constant 11th finite difference 1.

**Evidence**
- Finite difference order 11 is constant across 1 observed positions.

**Falsifiers**
- Compute at least 5 more terms from the alleged source and check whether the same finite difference stays constant.

**Proof obligations**
- Derive the closed polynomial formula and prove by finite-difference induction.

**Next computations**
- Interpolate exact polynomial over Q and test extrapolated terms.

### 2. Linear recurrence candidate, order 1

Score: `0.920` | Confidence: `high-computational` | Tags: `linear-recurrence, generating-function`

**Claim:** a(n) = (2)*a(n-1)

**Evidence**
- The recurrence exactly predicts 11 in-sample positions after solving over Q.

**Falsifiers**
- Generate fresh terms independently and check the recurrence. Low-order recurrences can overfit short sequences.

**Proof obligations**
- Find characteristic polynomial, prove initial conditions, then prove recurrence by induction or generating functions.

**Next computations**
- Use Sage/PARI to factor the characteristic polynomial and inspect roots/modular reductions.

### 3. Divisibility-sequence candidate

Score: `0.860` | Confidence: `high-computational` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed index divisibility appears to imply term divisibility.

**Evidence**
- Passed 23/23 divisibility checks under index_start adjustment 0.

**Falsifiers**
- Extend the sequence and test all i | j pairs again. Check whether zeros/trivial units drive the result.

**Proof obligations**
- Prove strong divisibility or divisibility from algebraic group/recurrence structure.

**Next computations**
- Check gcd(a_m,a_n)=a_gcd(m,n), Lucas/Elliptic divisibility signatures.

### 4. Divisibility-sequence candidate

Score: `0.860` | Confidence: `high-computational` | Tags: `divisibility, lucas, elliptic-divisibility`

**Claim:** Observed index divisibility appears to imply term divisibility.

**Evidence**
- Passed 23/23 divisibility checks under index_start adjustment 1.

**Falsifiers**
- Extend the sequence and test all i | j pairs again. Check whether zeros/trivial units drive the result.

**Proof obligations**
- Prove strong divisibility or divisibility from algebraic group/recurrence structure.

**Next computations**
- Check gcd(a_m,a_n)=a_gcd(m,n), Lucas/Elliptic divisibility signatures.

### 5. Smoothness cluster

Score: `0.720` | Confidence: `medium-computational` | Tags: `factorization, smoothness`

**Claim:** Many observed terms factor over a very small prime set.

**Evidence**
- (0, 1, {})
- (1, 2, {2: 1})
- (2, 4, {2: 2})
- (3, 8, {2: 3})
- (4, 16, {2: 4})
- (5, 32, {2: 5})
- (6, 64, {2: 6})
- (7, 128, {2: 7})
- (8, 256, {2: 8})
- (9, 512, {2: 9})

**Falsifiers**
- Smoothness in early terms often vanishes. Factor later terms and compare with random-size controls.

**Proof obligations**
- Prove the sequence is built from products/binomial coefficients, or bound prime support.

**Next computations**
- Use PARI factorint at larger terms and inspect prime support growth.

### 6. Modular periodic structure

Score: `0.560` | Confidence: `low` | Tags: `modular, periodicity`

**Claim:** The sequence shows repeated residue behavior over several small moduli.

**Evidence**
- mod 3: visible period 2
- mod 5: visible period 4
- mod 7: visible period 3
- mod 9: visible period 6
- mod 15: visible period 4
- mod 21: visible period 6
- mod 31: visible period 5

**Falsifiers**
- Visible modular periods on a short prefix may collapse. Extend terms and retest.

**Proof obligations**
- Prove periodicity modulo m using recurrence, automaton, or finite-state argument.

**Next computations**
- Search for automatic/regular sequence signatures and compare with OEIS hits.

### 7. Square terms recur

Score: `0.550` | Confidence: `low` | Tags: `squares, diophantine`

**Claim:** Several terms are perfect squares; this may signal norm, elliptic, or quadratic-form structure.

**Evidence**
- (0, 1)
- (2, 4)
- (4, 16)
- (6, 64)
- (8, 256)
- (10, 1024)

**Falsifiers**
- Check square indices against a predicted law. Random small sequences often contain early squares.

**Proof obligations**
- Classify n such that a(n) is square, or connect to a known Diophantine equation.

**Next computations**
- Search OEIS and LMFDB; test Pell/elliptic curve interpretations.

### 8. p-adic valuation structure

Score: `0.320` | Confidence: `low` | Tags: `p-adic, valuation`

**Claim:** Prime-adic valuations show nontrivial repeated structure worth mining.

**Evidence**
- v_2 reaches 11 with pattern [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

**Falsifiers**
- Compare v_p(a_n) against v_p(n), Lucas valuations, LTE predictions, and random baselines.

**Proof obligations**
- Identify exact valuation formula or prove bounds.

**Next computations**
- Run PARI valuation/factorization at larger n and search for LTE-compatible forms.

## Online Checks

```json
{
  "disabled": true,
  "lmfdb_urls": [
    {
      "label": "LMFDB global search",
      "url": "https://www.lmfdb.org/search/?q=1%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512"
    },
    {
      "label": "Elliptic curves over Q",
      "url": "https://www.lmfdb.org/EllipticCurve/Q/"
    },
    {
      "label": "Number fields",
      "url": "https://www.lmfdb.org/NumberField/"
    },
    {
      "label": "Modular forms",
      "url": "https://www.lmfdb.org/ModularForm/"
    },
    {
      "label": "L-functions",
      "url": "https://www.lmfdb.org/L/"
    }
  ],
  "literature_urls": [
    {
      "label": "arXiv search",
      "url": "https://arxiv.org/search/?query=%221%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%2C1024%2C2048%22&searchtype=all"
    },
    {
      "label": "Google Scholar search",
      "url": "https://scholar.google.com/scholar?q=%221%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%2C1024%2C2048%22"
    },
    {
      "label": "zbMATH search",
      "url": "https://zbmath.org/?q=%221%2C2%2C4%2C8%2C16%2C32%2C64%2C128%2C256%2C512%2C1024%2C2048%22"
    },
    {
      "label": "MathSciNet manual search",
      "url": "https://mathscinet.ams.org/mathscinet"
    }
  ]
}
```

## Handoff Files

- sage: `/mnt/data/nt_workbench/selftest_out/powers2_6082ae318cb4.sage`
- pari_gp: `/mnt/data/nt_workbench/selftest_out/powers2_6082ae318cb4.gp`
- lean: `/mnt/data/nt_workbench/selftest_out/powers2_6082ae318cb4.lean`
- json_report: `/mnt/data/nt_workbench/selftest_out/powers2_6082ae318cb4.report.json`
- markdown_report: `/mnt/data/nt_workbench/selftest_out/powers2_6082ae318cb4.report.md`

## Rule of Engagement

Nothing above is a theorem. The machine is allowed to propose. Proof starts only after the hypothesis survives fresh terms, database checks, and a formal proof route.