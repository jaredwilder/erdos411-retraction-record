# NT Discovery Workbench

Run:

```bash
python nt_discovery_workbench.py selftest
python nt_discovery_workbench.py analyze-seq --seq "1,1,2,3,5,8,13,21,34,55" --out out --label fib
python nt_discovery_workbench.py analyze-seq --seq "1,1,2,3,5,8,13,21,34,55" --online --out out --label fib_online
python nt_discovery_workbench.py formula --formula "n*n+n+1" --terms 30 --out out --label quadratic_probe
python nt_discovery_workbench.py probe --gp-expr "factor(2^127-1)"
```

Outputs per run:

- JSON report
- Markdown report
- Sage handoff script
- PARI/GP handoff script
- Lean skeleton

The workbench is designed to prevent fake theorem vibes. It ranks hypotheses, lists falsifiers, emits proof obligations, and only then hands the surviving claim to Sage/PARI/Lean.
