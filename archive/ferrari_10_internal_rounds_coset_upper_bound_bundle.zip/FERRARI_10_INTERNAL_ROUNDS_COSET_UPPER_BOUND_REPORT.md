# Ferrari 10 Internal Rounds: Coset Upper-Bound Obstruction

## Verdict

`PROMOTE_COSET_UNION_UPPER_BOUND_OBSTRUCTION`

## Active binary

Can skipped and expanded q3 branches be reduced to the same coset-cover certificate, or does one produce a full target-subfiber cover?

## Result

- Branches tested: **106**
- Replayed Race8 branches: **52**
- Previously skipped Race8 branches repaired: **54**
- Target cells: **(20,20)** and **(40,40)**
- Full-cover candidates found: **0**
- Minimum surviving lower bound: **6** for both target cells

## Why this is better than the previous round

The previous test relied on explicit enumeration and left skipped branches unresolved. This round uses a finite-group upper-bound certificate. It proves noncoverage whenever the sum of all individual danger-modulus coset sizes is smaller than the target subfiber quotient. That resolves the skipped branches without brute-forcing the giant fibers.

## Exact mathematical object

For a target subfiber

```text
k = k0 + 120a
l = l0 + 240b
```

a modulus `p` covers a lift exactly when

```text
(2^120)^a (3^240)^b = -(2^k0 3^l0)^(-1) mod p.
```

Let

```text
H_p = <2^120, 3^240> in F_p*.
```

If the right side is not in `H_p`, then `p` covers zero lifts.

If it is in `H_p`, then `p` covers one coset of the kernel, of size

```text
|domain| / |H_p|.
```

Therefore a full branch cover is impossible if

```text
sum_p |domain| / |H_p| < |domain|
```

over the moduli whose cosets are nonempty.

That strict inequality held for every tested branch-cell pair.

## Worst cases

```json
{
  "(20,20)": {
    "q3": 577,
    "source": "replayed",
    "upper_bound_covered": 0,
    "domain_size": 6,
    "quotient": [
      6,
      1
    ],
    "member_moduli": []
  },
  "(40,40)": {
    "q3": 577,
    "source": "replayed",
    "upper_bound_covered": 0,
    "domain_size": 6,
    "quotient": [
      6,
      1
    ],
    "member_moduli": []
  }
}
```

## Ten internal rounds

| Round | Binary | Verdict | Result |
|---:|---|---|---|
| 1 | Are the Race8 skipped branches still unresolved? | `PROMOTE_REPAIR_TARGET` | 106 total branches imported; skipped branches included, not ignored. |
| 2 | Can a single modulus hit a subfiber be expressed algebraically? | `PROMOTE_COSET_EQUATION` | p-hit iff (2^120)^a(3^240)^b=C_p. |
| 3 | Can noncoverage be certified without full enumeration? | `PROMOTE_UPPER_BOUND_CERTIFICATE` | If sum of individual coset sizes < quotient size, branch cannot fully cover. |
| 4 | Do all 52 replayed branches pass the upper-bound noncover test? | `PROMOTE_REPLAYED_NONCOVER` | 52/52 replayed branches proven noncover for both target cells. |
| 5 | Do the 54 previously skipped branches pass the same noncover test? | `PROMOTE_SKIPPED_BRANCH_REPAIR` | 54/54 skipped branches proven noncover for both target cells. |
| 6 | Does any branch have even a possible full cover under the upper bound? | `PROMOTE_ZERO_FULL_COVER_CANDIDATES` | 0 candidate full covers across 212 branch-cell tests. |
| 7 | What is the tightest surviving lower bound? | `PROMOTE_TIGHT_BOUND` | Minimum surviving lower bound is 6 for both cells, at q3=577. |
| 8 | Is the certificate stronger than previous enumeration? | `PROMOTE_STRONGER_METHOD` | Previously skipped fibers are resolved by group-size upper bound, not enumerated. |
| 9 | Is the result still bounded? | `DEMOTE_GLOBAL_CLAIM` | No claim beyond q3 301..997, no unbounded depth, no arbitrary moduli. |
| 10 | Does this produce a valuable next theorem target? | `PROMOTE_COSET_UNION_UPPER_BOUND_OBSTRUCTION` | Target lemma: actual Race8 danger closures cannot fully cover the two diagonal subfibers because coset-size union upper bound is strictly below quotient size. |

## What was tested

- All 52 replayed Race8 actual danger-closure branches.
- All 54 Race8 skipped branches, repaired by upper-bound certificate.
- Both target diagonal subfibers.
- Exact subgroup membership and coset-size upper bounds for every branch modulus.

## What was not tested

- q3 outside Race8 range 301..997 in this certificate
- unbounded recursive depth
- arbitrary non-danger modulus combinations

## Next binary

Can the coset-size upper-bound obstruction be promoted from the Race8 q3 range into a general lemma for all actual danger-closure branches generated from the parent family?

## Replay

```bash
python verify_coset_upper_bound_certificate.py coset_upper_bound_certificate.json
```

Expected output:

```text
REPLAY_CHECK_PASSED 106 {'(20,20)': 6, '(40,40)': 6}
```
