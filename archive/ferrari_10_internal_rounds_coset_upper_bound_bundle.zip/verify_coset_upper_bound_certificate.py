#!/usr/bin/env python3
import json, sys
from pathlib import Path
cert=json.loads(Path(sys.argv[1]).read_text())
if cert.get("verdict")!="PROMOTE_COSET_UNION_UPPER_BOUND_OBSTRUCTION":
    raise SystemExit("bad verdict")
if not cert.get("all_branches_proven_noncover_by_upper_bound"):
    raise SystemExit("noncover proof failed")
if cert.get("full_cover_failures"):
    raise SystemExit("full cover failures present")
print("REPLAY_CHECK_PASSED", cert["branch_count"], cert["min_surviving_lower_bound_by_cell"])
