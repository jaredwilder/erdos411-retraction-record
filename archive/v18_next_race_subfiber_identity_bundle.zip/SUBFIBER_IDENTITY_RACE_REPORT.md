# Ferrari Next Race: Protected Subfiber Identity Test

## Verdict

`DEMOTE_FIXED_LIFT_IDENTITY_PROMOTE_SUBFIBER_AVOIDANCE`

## Active binary

Do the protected lifted subfibers avoid danger masks by an explicit residue identity, or are they selected survivors without a closed-form reason?

## Result

The fixed-lift identity **fails** for the `(20,20)` seed.

The branch `q3 = 353` includes modulus `353`, and:

```text
2^80 * 3^80 + 1 = 6^80 + 1 ≡ 0 mod 353
ord_353(6) = 32
```

So the exact fixed lift `(80,80)` is coverable. It is not the protected object.

But the subfiber object survives:

```text
(20,20): k ≡ 80 mod 120, l ≡ 80 mod 240
(40,40): k ≡ 40 mod 120, l ≡ 160 mod 240
```

In the `q3=353` branch, `(80,80)` dies, but shifted lifts survive, e.g. for `(20,20)`:

```text
(80,320), (80,560), (80,800), ...
```

## Fixed-seed order criterion

For `(20,20)` seed `(80,80)`:

```text
F = 6^80 + 1
F ≡ 0 mod p iff ord_p(6) ∈ {32,160}
```

For `(40,40)` seed `(40,160)`:

```text
F = 2^40 * 3^160 + 1 = 162^40 + 1
F ≡ 0 mod p iff ord_p(162) ∈ {16,80}
```

Across `447` tested final moduli from Race8 replayed/skipped metadata, the order criteria matched direct residue checks with `0` mismatches.

## What was tested

- Race8 replayed q3 branches: `52`
- Race8 skipped q3 final-moduli metadata rows: `54`
- Fixed seed coverage for `(80,80)` and `(40,160)`
- Direct residue/order criteria across all final moduli in those rows
- Sample surviving lifts from replayed branch certificates

## What was not tested

- Full final-moduli reconstruction for q3 > 2999
- Formal proof of subfiber avoidance
- All residual cells
- Unbounded recursive depth

## Earned interpretation

The prior claim should not be stated as fixed-coordinate protection. The fixed coordinate `(80,80)` is destroyed by a real adversarial branch.

The live object is sharper:

```text
Subfiber avoidance: actual q-danger masks may cover individual lifts, but do not cover every lift in the protected subfiber class in the tested branches.
```

## Exact next binary

Can the subfiber avoidance be characterized as a finite cyclic hitting-set condition over `(u,v)` lift coordinates, and can an adversarial modulus family hit every lift in one target subfiber?
