# Oracle NT OS V12 — Verifier Core / Certificate Boundary

V12 is a trust-boundary and certificate-verification release. It removes the V11 failure class where local/test trust or self-reported artifacts could unlock claim grades.

## Contract closures

- No production external-trust promotion method ships in `TrustAuthority`.
- User JSON source labels are treated as claims, never verified status.
- Local seals are local receipts only. They do not unlock theorem-grade claims.
- KBK continuation calls the real certificate verifier. It ignores self-reported `replay_passed` fields.
- Empty CRT certificates fail.
- Recurrence certificates parse and enforce `valid_for`.
- Route status and claim grade are separated.
- Polynomial certificates respect `index_start`.
- Canonical Fibonacci `0,1,1,2,...` is a known-family classification, not interpolation-risk primary.
- Six-term junk is blocked as interpolation risk.
- Strong divisibility emits a structured proof object for canonical Fibonacci/Lucas, without pretending it is Lean-verified.
- Primitive divisor emits a canonical prefix audit for Fibonacci/Lucas, without pretending it proves BHV.
- CRT and Diophantine modules emit replayable certificate objects with verifiers.

## Run selftest

```bash
python oracle_nt_os_v12.py selftest --out selftest_out
```

Expected summary:

```json
{
  "version": "12.0.0-oracle-nt-os-verifier-core",
  "selftest": "PASS",
  "green_checks": 30,
  "total_checks": 30
}
```

## Hostile tests

Fake source does not unlock external verification:

```bash
python oracle_nt_os_v12.py analyze-seq \
  --seq "1,1,2,3,5,8,13,21,34,55,89,144" \
  --label fib_fake_source \
  --formal-recurrence "1,1" \
  --definition-source "lol trust me bro" \
  --out hostile_fake_source
```

Short junk becomes interpolation risk:

```bash
python oracle_nt_os_v12.py analyze-seq \
  --seq "3,8,5,13,21,7" \
  --label sixjunk \
  --out hostile_sixjunk
```

KBK rejects fake artifacts:

```bash
python oracle_nt_os_v12.py kbk-init \
  --corpus hostile_kbk.sqlite \
  --run-id r1 \
  --required-type RECURRENCE_REPLAY_CERTIFICATE \
  --required-action prove_rec

python oracle_nt_os_v12.py kbk-continue \
  --corpus hostile_kbk.sqlite \
  --run-id r1 \
  --artifact fake_art.json
```

## Certificate commands

CRT finite-moduli noncover certificate:

```bash
python oracle_nt_os_v12.py crt-war \
  --base1 2 --base2 3 --c 1 \
  --moduli 5 7 11 \
  --out crt_out
```

Diophantine local obstruction certificate:

```bash
python oracle_nt_os_v12.py diophantine-local \
  --A 1 --B 1 --C 3 \
  --bound 10 \
  --out dio_out
```

## Honest boundary

V12 still does not claim to shock the world by itself. It is the first version in this series where fake trust, fake KBK artifacts, empty CRT certificates, and invalid recurrence `valid_for` are mechanically rejected by replay verifiers.
