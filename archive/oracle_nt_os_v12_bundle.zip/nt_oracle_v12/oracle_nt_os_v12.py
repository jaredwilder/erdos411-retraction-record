#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, tempfile, shutil, subprocess, sys, os, zipfile
from pathlib import Path
from oracle_nt_v12.objects import FormalObject, SCOPE_FORMAL, SCOPE_GENERATED
from oracle_nt_v12.mathutils import parse_ints, primes_upto
from oracle_nt_v12.trust import TrustAuthority
from oracle_nt_v12.literature import Literature
from oracle_nt_v12.analysis import analyze
from oracle_nt_v12.certificates import (verify_any_certificate, crt_uncovered_certificate, diophantine_local_certificate, recurrence_certificate, polynomial_certificate, verify_crt_certificate)
from oracle_nt_v12.kbk import create_requirement, continue_with_artifact, status as kbk_status
VERSION='12.0.0-oracle-nt-os-verifier-core'

def write_report(report:dict,out:Path,label:str):
    out.mkdir(parents=True,exist_ok=True)
    p=out/f'{label}.v12.report.json'; p.write_text(json.dumps(report,indent=2,sort_keys=True))
    (out/f'{label}.v12.report.md').write_text('# Oracle NT OS V12 Report\n\n```json\n'+json.dumps({'verdict':report.get('overall_verdict'),'primary_coordinate':report.get('primary_coordinate'),'claims':report.get('claims')},indent=2)+'\n```\n')
    return p

def cmd_analyze(args):
    out=Path(args.out); corpus=Path(args.corpus or out/'oracle_nt_v12_corpus.sqlite'); trust=TrustAuthority(Path(args.trust_registry or out/'trust_registry.json')); lit=Literature(out/'oeis_cache.json', online=args.online)
    if args.object_json:
        obj=FormalObject.from_json(Path(args.object_json))
    else:
        terms=parse_ints(args.seq)
        if args.formal_recurrence:
            coeffs=parse_ints(args.formal_recurrence); init=parse_ints(args.initial_terms) if args.initial_terms else terms[:len(coeffs)]
            # CLI recurrence is never a formal definition. It is generated extension only.
            obj=FormalObject('recurrence_sequence',args.label,SCOPE_GENERATED,terms,0,{'initial_terms':init,'recurrence':{'coefficients':coeffs,'valid_for':args.valid_for or f'n >= {len(coeffs)}'}},{'user_definition_source':args.definition_source or 'none','status':'USER_ASSERTED_UNVERIFIED'})
        else:
            obj=FormalObject.observed(args.label, terms)
    rep=analyze(obj,out,trust,lit); path=write_report(rep,out,obj.label)
    print(json.dumps({'report':str(path),'verdict':rep.get('overall_verdict'),'primary_coordinate':rep.get('primary_coordinate'),'trust_grade':rep.get('source_trust',{}).get('grade')},indent=2))

def cmd_seal(args):
    obj=FormalObject.from_json(Path(args.object_json)); trust=TrustAuthority(Path(args.trust_registry)); rec=trust.seal_local(obj); print(json.dumps({'local_receipt':rec,'external_verified':False,'warning':'local receipt is not external verification and does not unlock theorem-grade claims'},indent=2))

def cmd_verify_cert(args):
    cert=json.loads(Path(args.certificate).read_text()); print(json.dumps(verify_any_certificate(cert, expected_type=args.expected_type),indent=2,sort_keys=True))

def cmd_crt(args):
    moduli=args.moduli or primes_upto(args.max_modulus)
    cert=crt_uncovered_certificate(args.base1,args.base2,args.c,moduli,args.search_bound)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); p=out/'crt_certificate.v12.json'; p.write_text(json.dumps(cert,indent=2,sort_keys=True)); print(json.dumps({'certificate':str(p),'verification':verify_any_certificate(cert)},indent=2))

def cmd_dio(args):
    cert=None
    for m in range(2,args.bound+1):
        c=diophantine_local_certificate(args.A,args.B,args.C,m)
        if c.get('obstruction'):
            cert=c; break
    if cert is None: cert=diophantine_local_certificate(args.A,args.B,args.C,args.bound)
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); p=out/'diophantine_certificate.v12.json'; p.write_text(json.dumps(cert,indent=2,sort_keys=True)); print(json.dumps({'certificate':str(p),'verification':verify_any_certificate(cert)},indent=2))

def cmd_kbk_init(args):
    create_requirement(Path(args.corpus),args.run_id,args.required_type,args.required_action); print(json.dumps({'created':args.run_id,'required_type':args.required_type,'required_action':args.required_action},indent=2))

def cmd_kbk_continue(args):
    print(json.dumps(continue_with_artifact(Path(args.corpus),args.run_id,Path(args.artifact)),indent=2,sort_keys=True))

def cmd_kbk_status(args): print(json.dumps(kbk_status(Path(args.corpus)),indent=2,sort_keys=True))

def cmd_selftest(args):
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True); checks=[]
    def ck(name, ok, detail=None): checks.append({'name':name,'passed':bool(ok),'detail':detail})
    trust=TrustAuthority(out/'trust.json'); lit=Literature(out/'oeis.json')
    # 1 no promotion method in production authority
    ck('no_production_external_promotion_backdoor', not hasattr(trust,'promote_external_for_tests_only'))
    # 2 fake verified JSON ignored
    fake=FormalObject('recurrence_sequence','fake',SCOPE_FORMAL,[1,1,2,3,5,8],0,{'initial_terms':[1,1],'recurrence':{'coefficients':[1,1],'valid_for':'n >= 2'}},{'status':'SIGNED_PROJECT_VERIFIED'})
    rep=analyze(fake,out,trust,lit); ck('fake_verified_json_cannot_unlock_theorem', rep['source_trust']['grade']!='EXTERNAL_VERIFIED' and 'RECURRENCE_DEFINITION_CONFORMANCE_ROUTE' not in rep['claims']['allowed_route_claims'], rep['source_trust'])
    # 3 local seal not external
    trust.seal_local(fake); rep2=analyze(fake,out,trust,lit); ck('local_seal_not_external_verification', rep2['source_trust']['grade']=='LOCAL_ONLY' and rep2['overall_verdict']!='ROUTE_SPECIFIC_THEOREM_ROUTE_ALLOWED_NOT_FORMALLY_VERIFIED')
    # 4 CLI generated equivalence not formal: test object directly from CLI logic
    gen=FormalObject('recurrence_sequence','cli_gen',SCOPE_GENERATED,[1,1,2,3],0,{'initial_terms':[1,1],'recurrence':{'coefficients':[1,1],'valid_for':'n >= 2'}},{'status':'USER_ASSERTED_UNVERIFIED'})
    repg=analyze(gen,out,trust,lit); ck('cli_formal_recurrence_is_generated_extension_only', repg['object']['scope']==SCOPE_GENERATED and repg['overall_verdict']!='ROUTE_SPECIFIC_THEOREM_ROUTE_ALLOWED_NOT_FORMALLY_VERIFIED')
    # 5 fake KBK artifact fails
    corpus=out/'kbk.sqlite'; create_requirement(corpus,'r1','RECURRENCE_REPLAY_CERTIFICATE','prove recurrence conformance'); fake_art=out/'fake_art.json'; fake_art.write_text(json.dumps({'type':'REPLAY_CERTIFICATE','replay_passed':True,'claim':'RH'})); kres=continue_with_artifact(corpus,'r1',fake_art); ck('kbk_rejects_fake_self_reported_artifact', not kres['artifact_verified'], kres)
    # 6 real KBK artifact passes
    cert=recurrence_certificate([1,1],[1,1],0,'n >= 2',[1,1,2,3,5,8]); cp=out/'real_rec_cert.json'; cp.write_text(json.dumps(cert)); kres2=continue_with_artifact(corpus,'r1',cp); ck('kbk_accepts_real_replayed_artifact', kres2['artifact_verified'], kres2)
    # 7 empty CRT fails
    empty={'type':'CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE','base1':2,'base2':3,'c':1,'moduli':[5],'uncovered_pair':{'k':0,'l':0},'checks':[]}; ck('empty_crt_certificate_fails', not verify_any_certificate(empty)['replay_passed'], verify_any_certificate(empty))
    # 8 CRT real cert passes
    crt=crt_uncovered_certificate(2,3,1,[5,7,11],32); ck('crt_real_certificate_replays', crt.get('replay_passed') and verify_any_certificate(crt)['replay_passed'], crt)
    # 9 invalid valid_for fails
    bad=recurrence_certificate([1,1],[1,1],0,'n >= 100',[1,1,2,3,5,8]); ck('recurrence_valid_for_enforced', not bad['replay_passed'] and bad['failure']=='no_terms_in_valid_for_range_checked', bad)
    # 10 malformed valid_for fails
    bad2=recurrence_certificate([1,1],[1,1],0,'after two',[1,1,2,3]); ck('recurrence_invalid_valid_for_fails', not bad2['replay_passed'] and bad2['failure']=='invalid_valid_for', bad2)
    # 11 route status consistent
    ck('local_only_route_cannot_theorem_gth', rep2['source_trust']['grade']=='LOCAL_ONLY' and not rep2['claims']['allowed_route_claims'])
    # 12 polynomial index_start respected
    poly=FormalObject('polynomial_sequence','n2',SCOPE_FORMAL,[1,4,9,16,25],1,{'formula_coefficients_low_to_high':[0,0,1]},{})
    polyr=analyze(poly,out,trust,lit); ck('polynomial_index_start_respected', polyr['overall_verdict']!='FORMAL_OBJECT_CONTRADICTION', polyr.get('certificates'))
    # 13 polynomial mismatch fatal
    badpoly=FormalObject('polynomial_sequence','badn2',SCOPE_FORMAL,[1,4,10],1,{'formula_coefficients_low_to_high':[0,0,1]},{})
    badpolyr=analyze(badpoly,out,trust,lit); ck('polynomial_mismatch_fatal', badpolyr['overall_verdict']=='FORMAL_OBJECT_CONTRADICTION')
    # 14 Fibonacci known beats interpolation risk
    fib=FormalObject.observed('fib0',[0,1,1,2,3,5,8,13,21,34]); fibr=analyze(fib,out,trust,lit); ck('fib0_known_family_primary_not_interpolation', fibr['primary_coordinate']=='known_family_classification' and fibr['scores']['novelty_score']==0.0, fibr)
    # 15 six junk interpolation risk
    junk=FormalObject.observed('sixjunk',[3,8,5,13,21,7]); jr=analyze(junk,out,trust,lit); ck('six_term_junk_blocked_as_interpolation_risk', jr['overall_verdict']=='NO_GTH_INTERPOLATION_RISK', jr)
    # 16 OEIS local exact verified for fib
    ck('oeis_exact_collision_terms_verified', fibr['literature']['exact_collision'] and fibr['literature']['matched_oeis']=='A000045')
    # 17 proof statuses separated
    ck('lean_statuses_split_and_not_verified_by_default', not fibr['proof_status']['formal_proof_verified'] and fibr['proof_status']['lean_compile_attempted']==False, fibr['proof_status'])
    # 18 strong divisibility structured proof plan exists for canonical fib
    ck('strong_divisibility_structured_plan_for_fib', fibr['routes']['strong_divisibility']['status']=='PROOF_PLAN_COMPLETE_NOT_FORMALLY_VERIFIED', fibr['routes']['strong_divisibility'])
    # 19 primitive divisor canonical audit exists
    ck('primitive_divisor_canonical_audit_for_fib', fibr['routes']['primitive_divisor']['status']=='CANONICAL_PREFIX_AUDIT_COMPLETE', fibr['routes']['primitive_divisor'])
    # 20 Diophantine obstruction cert real for x^2+y^2=3 mod 4
    dio=diophantine_local_certificate(1,1,3,4); ck('diophantine_local_obstruction_certificate_replays', dio.get('obstruction') and verify_any_certificate(dio)['replay_passed'], dio)
    # fuzz source/trust/certificate fields
    for i in range(10):
        o=FormalObject('recurrence_sequence',f'fuzz{i}',SCOPE_FORMAL,[1,1,2,3],0,{'initial_terms':[1,1],'recurrence':{'coefficients':[1,1],'valid_for':'n >= 2'}},{'status':['OEIS_EXACT_VERIFIED','SIGNED_PROJECT_VERIFIED','LEAN_FORMALLY_VERIFIED'][i%3]})
        rr=analyze(o,out,trust,lit); ck(f'fuzz_fake_external_status_{i}', rr['source_trust']['grade']!='EXTERNAL_VERIFIED')
    passed=sum(c['passed'] for c in checks); result={'version':VERSION,'selftest':'PASS' if passed==len(checks) else 'FAIL','green_checks':passed,'total_checks':len(checks),'checks':checks,'hard_artifacts':['CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE','LOCAL_OBSTRUCTION_CERTIFICATE','RECURRENCE_REPLAY_CERTIFICATE','POLYNOMIAL_REPLAY_CERTIFICATE','STRONG_DIVISIBILITY_STRUCTURED_PROOF_PLAN','PRIMITIVE_DIVISOR_CANONICAL_PREFIX_AUDIT']}
    (out/'selftest.v12.json').write_text(json.dumps(result,indent=2,sort_keys=True)); print(json.dumps({k:result[k] for k in ['version','selftest','green_checks','total_checks','hard_artifacts']},indent=2))
    if result['selftest']!='PASS': sys.exit(1)

def main():
    ap=argparse.ArgumentParser(description='Oracle NT OS V12 verifier core')
    sub=ap.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('analyze-seq'); a.add_argument('--seq',required=True); a.add_argument('--label',default='seq'); a.add_argument('--out',default='out_v12'); a.add_argument('--corpus'); a.add_argument('--trust-registry'); a.add_argument('--formal-recurrence'); a.add_argument('--initial-terms'); a.add_argument('--definition-source'); a.add_argument('--valid-for'); a.add_argument('--object-json'); a.add_argument('--online',action='store_true'); a.set_defaults(func=cmd_analyze)
    s=sub.add_parser('seal-object'); s.add_argument('--object-json',required=True); s.add_argument('--trust-registry',required=True); s.set_defaults(func=cmd_seal)
    v=sub.add_parser('verify-cert'); v.add_argument('--certificate',required=True); v.add_argument('--expected-type'); v.set_defaults(func=cmd_verify_cert)
    c=sub.add_parser('crt-war'); c.add_argument('--base1',type=int,required=True); c.add_argument('--base2',type=int,required=True); c.add_argument('--c',type=int,required=True); c.add_argument('--max-modulus',type=int,default=50); c.add_argument('--moduli',nargs='*',type=int); c.add_argument('--search-bound',type=int,default=64); c.add_argument('--out',default='crt_v12'); c.set_defaults(func=cmd_crt)
    d=sub.add_parser('diophantine-local'); d.add_argument('--A',type=int,required=True); d.add_argument('--B',type=int,required=True); d.add_argument('--C',type=int,required=True); d.add_argument('--bound',type=int,default=97); d.add_argument('--out',default='dio_v12'); d.set_defaults(func=cmd_dio)
    k=sub.add_parser('kbk-init'); k.add_argument('--corpus',required=True); k.add_argument('--run-id',required=True); k.add_argument('--required-type',required=True); k.add_argument('--required-action',required=True); k.set_defaults(func=cmd_kbk_init)
    kc=sub.add_parser('kbk-continue'); kc.add_argument('--corpus',required=True); kc.add_argument('--run-id',required=True); kc.add_argument('--artifact',required=True); kc.set_defaults(func=cmd_kbk_continue)
    ks=sub.add_parser('kbk-status'); ks.add_argument('--corpus',required=True); ks.set_defaults(func=cmd_kbk_status)
    st=sub.add_parser('selftest'); st.add_argument('--out',default='v12_selftest_out'); st.set_defaults(func=cmd_selftest)
    args=ap.parse_args(); args.func(args)
if __name__=='__main__': main()
