VERSION='12.0.0-oracle-nt-os-verifier-core'
