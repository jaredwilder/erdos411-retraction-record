from __future__ import annotations
import json, sqlite3, time
from pathlib import Path
from typing import Dict, Any
from .certificates import verify_any_certificate
def now(): return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
def init_db(path:Path):
    path.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(path); con.execute('CREATE TABLE IF NOT EXISTS kbk(run_id TEXT PRIMARY KEY, required_type TEXT, required_action TEXT, created_at TEXT, satisfied INTEGER DEFAULT 0)'); con.commit(); con.close()
def create_requirement(path:Path, run_id:str, required_type:str, required_action:str):
    init_db(path); con=sqlite3.connect(path); con.execute('INSERT OR REPLACE INTO kbk VALUES(?,?,?,?,0)',(run_id,required_type,required_action,now())); con.commit(); con.close()
def status(path:Path)->Dict[str,Any]:
    init_db(path); con=sqlite3.connect(path); rows=con.execute('SELECT run_id, required_type, required_action, satisfied FROM kbk').fetchall(); con.close(); return {'kbk': [{'run_id':r[0],'required_type':r[1],'required_action':r[2],'satisfied':bool(r[3])} for r in rows]}
def continue_with_artifact(path:Path, run_id:str, artifact_path:Path)->Dict[str,Any]:
    init_db(path); con=sqlite3.connect(path); row=con.execute('SELECT required_type, required_action, satisfied FROM kbk WHERE run_id=?',(run_id,)).fetchone()
    if not row: con.close(); return {'verdict':'KBK_NO_SUCH_RUN','artifact_verified':False}
    required_type, action, sat=row
    cert=json.loads(artifact_path.read_text())
    ver=verify_any_certificate(cert, expected_type=required_type)
    if ver.get('replay_passed'):
        con.execute('UPDATE kbk SET satisfied=1 WHERE run_id=?',(run_id,)); con.commit(); con.close(); return {'verdict':'KBK_CONTINUATION_ACCEPTED','artifact_verified':True,'verification':ver,'required_action':action,'required_type':required_type}
    con.close(); return {'verdict':'KBK_REFUSED_ARTIFACT','artifact_verified':False,'verification':ver,'required_action':action,'required_type':required_type}
