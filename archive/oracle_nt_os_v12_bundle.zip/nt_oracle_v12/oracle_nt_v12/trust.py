from __future__ import annotations
import json, hashlib, time
from pathlib import Path
from typing import Any, Dict
from .objects import FormalObject
LOCAL_TRUST={'LOCAL_SCHEMA_VALID','LOCAL_RECEIPT_SEALED','UNTRUSTED_LOCAL','PROJECT_LOCAL'}
EXTERNAL_TRUST={'OEIS_EXACT_VERIFIED','LITERATURE_EXACT_VERIFIED','SIGNED_PROJECT_VERIFIED','LEAN_FORMALLY_VERIFIED','REMOTE_REPRODUCIBLE_VERIFIED'}
TRUST_SALT='oracle_nt_v12_local_receipt_not_external'
def canon(x:Any)->str: return json.dumps(x,sort_keys=True,separators=(',',':'))
def sha256(s:str)->str: return hashlib.sha256(s.encode()).hexdigest()
def ensure(p:Path): p.mkdir(parents=True,exist_ok=True)
def now(): return time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
class TrustAuthority:
    '''Production trust is analyzer-issued. User JSON cannot self-assign external trust. No test promotion method ships here.'''
    def __init__(self, registry:Path):
        self.registry=registry; ensure(registry.parent)
        if not registry.exists(): registry.write_text(json.dumps({'registry_mode':'UNTRUSTED_LOCAL','local_receipts':{}},indent=2))
        self.db=json.loads(registry.read_text())
    def save(self): self.registry.write_text(json.dumps(self.db,indent=2,sort_keys=True))
    def object_hash(self,obj:FormalObject)->str: return sha256(canon(obj.payload_for_receipt()))
    def seal_local(self,obj:FormalObject)->Dict[str,Any]:
        h=self.object_hash(obj); rec={'object_hash':h,'trust_class':'LOCAL_RECEIPT_SEALED','grade':'LOCAL_ONLY','issued_by':'local_v12_tool','issued_at':now(),'receipt_hash':sha256(h+TRUST_SALT)}
        self.db.setdefault('local_receipts',{})[h]=rec; self.save(); return rec
    def verify(self,obj:FormalObject, literature_report:Dict[str,Any]|None=None, lean_verified:bool=False)->Dict[str,Any]:
        schema_ok,schema_errors=obj.validate_schema(); h=self.object_hash(obj)
        claimed=obj.source.get('status') or obj.source.get('trust_class') or 'NONE'
        out={'object_hash':h,'claimed_input_status':claimed,'schema_valid':schema_ok,'schema_errors':schema_errors,'trust_class':'UNTRUSTED_LOCAL','grade':'NONE','external_verified':False,'local_receipt':False,'registry_mode':self.db.get('registry_mode','UNTRUSTED_LOCAL')}
        if not schema_ok: return out
        if h in self.db.get('local_receipts',{}):
            out.update({'local_receipt':True,'trust_class':'LOCAL_RECEIPT_SEALED','grade':'LOCAL_ONLY','local_receipt_detail':self.db['local_receipts'][h]})
        else:
            out.update({'trust_class':'LOCAL_SCHEMA_VALID','grade':'LOCAL_ONLY'})
        # Analyzer-issued external trust only from real verifiers, never from input labels or local receipts.
        if literature_report and literature_report.get('exact_collision') and obj.source.get('oeis_id')==literature_report.get('matched_oeis'):
            out.update({'trust_class':'OEIS_EXACT_VERIFIED','grade':'EXTERNAL_VERIFIED','external_verified':True})
        if lean_verified:
            out.update({'trust_class':'LEAN_FORMALLY_VERIFIED','grade':'EXTERNAL_VERIFIED','external_verified':True})
        return out
