from __future__ import annotations
from typing import List, Dict, Any
from .mathutils import factor

def strong_divisibility_plan(family:Dict[str,Any])->Dict[str,Any]:
    if family.get('family') not in {'Fibonacci','Lucas'}:
        return {'status':'NOT_CANONICAL_LUCAS_FAMILY','proof_object':None}
    return {'status':'PROOF_PLAN_COMPLETE_NOT_FORMALLY_VERIFIED','proof_object':{
        'type':'STRONG_DIVISIBILITY_STRUCTURED_PROOF_PLAN',
        'family':family.get('family'),
        'canonical_index_start':family.get('canonical_index_start'),
        'lemmas':['addition formula for Lucas/Fibonacci sequence','Euclidean reduction U_{a+b}=U_a V_b - (-Q)^b U_{a-b} (family-specific form)','rank-of-apparition divisibility criterion','gcd identity follows by Euclidean algorithm on indices'],
        'claim_target':'gcd(U_m,U_n)=U_gcd(m,n) under canonical Lucas_U hypotheses',
        'does_not_prove':['Lean-checked proof','general Lehmer cases without hypotheses']}}

def primitive_divisor_audit(seq:List[int], family:Dict[str,Any])->Dict[str,Any]:
    if family.get('family') not in {'Fibonacci','Lucas'}: return {'status':'NOT_CANONICAL_LUCAS_FAMILY'}
    # Basic internal canonical audit: factor terms and identify missing primitive primes with canonical theorem-index convention.
    prior=set(); exceptions=[]; audits=[]
    start=int(family.get('canonical_index_start',0))
    # If observed starts at F_start, theorem_n = start+pos for Fibonacci canonical indexing.
    known=set(family.get('known_exception_set',[1,2,6,12]))
    for pos,val in enumerate(seq):
        n=start+pos
        if val in (0,1,-1):
            prior |= set(factor(val).keys()); continue
        ps=set(factor(val).keys()); prim=sorted(ps-prior)
        audits.append({'theorem_index':n,'value':val,'prime_factors':sorted(ps),'primitive_prime_factors':prim})
        if not prim and n not in known: exceptions.append({'theorem_index':n,'value':val,'reason':'no primitive divisor outside known exception set'})
        prior |= ps
    return {'status':'CANONICAL_PREFIX_AUDIT_COMPLETE','theorem_family':family.get('primitive_divisor_family'),'known_exception_set':sorted(known),'unexpected_exceptions':exceptions,'audits':audits,'does_not_prove':['BHV general theorem','all-index primitive divisor result without external proof']}
