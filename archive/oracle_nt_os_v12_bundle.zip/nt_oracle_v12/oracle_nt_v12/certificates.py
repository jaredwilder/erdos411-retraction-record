from __future__ import annotations
from typing import List, Dict, Any, Optional
from .mathutils import eval_poly_low, gen_recurrence, parse_valid_for, recurrence_gf, companion_matrix

def recurrence_certificate(coeffs:List[int], initial:List[int], index_start:int, valid_for:str, terms:List[int])->Dict[str,Any]:
    vf=parse_valid_for(valid_for)
    cert={'type':'RECURRENCE_REPLAY_CERTIFICATE','claim_proves':'supplied terms conform to supplied recurrence over legal checked index range','does_not_prove':['minimality','novelty','strong divisibility','primitive divisors','formal Lean proof'],'coefficients':coeffs,'initial_terms':initial,'index_start':index_start,'valid_for':valid_for,'valid_for_min':vf,'terms':terms,'gf':recurrence_gf(coeffs,initial),'companion_matrix':companion_matrix(coeffs)}
    cert.update(verify_recurrence_certificate(cert)); return cert

def verify_recurrence_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    required={'type','coefficients','initial_terms','index_start','valid_for','terms'}
    if not required.issubset(cert): return {'replay_passed':False,'failure':'missing_fields'}
    vf=parse_valid_for(cert.get('valid_for'))
    if vf is None: return {'replay_passed':False,'failure':'invalid_valid_for'}
    coeffs=[int(x) for x in cert['coefficients']]; init=[int(x) for x in cert['initial_terms']]; terms=[int(x) for x in cert['terms']]; index_start=int(cert['index_start'])
    d=len(coeffs)
    if len(init)<d: return {'replay_passed':False,'failure':'insufficient_initial_terms'}
    # Check initial segment matches observed terms if included.
    for i,t in enumerate(terms[:len(init)]):
        if t!=init[i]: return {'replay_passed':False,'failure':'initial_terms_mismatch','position':i}
    checked=[]
    for pos in range(d,len(terms)):
        theorem_n=index_start+pos
        if theorem_n < vf: continue
        lhs=terms[pos]; rhs=sum(coeffs[i]*terms[pos-i-1] for i in range(d))
        if lhs!=rhs: return {'replay_passed':False,'failure':'recurrence_mismatch','position':pos,'theorem_n':theorem_n,'lhs':lhs,'rhs':rhs}
        checked.append(theorem_n)
    if not checked: return {'replay_passed':False,'failure':'no_terms_in_valid_for_range_checked','valid_for_min':vf,'max_observed_index':index_start+len(terms)-1}
    return {'replay_passed':True,'checked_theorem_indices':checked,'certificate_scope':'PREFIX_CONFORMANCE_CERTIFICATE'}

def polynomial_certificate(coeffs_low:List[int], index_start:int, terms:List[int])->Dict[str,Any]:
    cert={'type':'POLYNOMIAL_REPLAY_CERTIFICATE','claim_proves':'supplied terms conform to supplied polynomial formula at stated index_start','does_not_prove':['novelty','minimal formula','formal Lean proof'],'coefficients_low_to_high':coeffs_low,'index_start':index_start,'terms':terms}
    cert.update(verify_polynomial_certificate(cert)); return cert

def verify_polynomial_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    required={'type','coefficients_low_to_high','index_start','terms'}
    if not required.issubset(cert): return {'replay_passed':False,'failure':'missing_fields'}
    coeffs=[int(x) for x in cert['coefficients_low_to_high']]; idx=int(cert['index_start']); terms=[int(x) for x in cert['terms']]
    for pos,t in enumerate(terms):
        n=idx+pos; val=eval_poly_low(coeffs,n)
        if val!=t: return {'replay_passed':False,'failure':'polynomial_mismatch','position':pos,'n':n,'expected':val,'got':t}
    return {'replay_passed':True,'checked_indices':[idx+i for i in range(len(terms))],'certificate_scope':'PREFIX_CONFORMANCE_CERTIFICATE'}

def crt_uncovered_certificate(base1:int, base2:int, c:int, moduli:List[int], search_bound:int=64)->Dict[str,Any]:
    certs=[]
    for k in range(search_bound):
        for l in range(search_bound):
            vals=[]; ok=True
            for m in moduli:
                v=(pow(base1,k,m)*pow(base2,l,m)+c)%m
                vals.append({'modulus':m,'k':k,'l':l,'value_mod_m':v})
                if v==0: ok=False; break
            if ok:
                cert={'type':'CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE','claim_proves':'for the listed finite modulus set, this exponent pair is not covered by any local zero congruence','does_not_prove':['no infinite covering system','no other modulus covers this pair','global prime existence'],'base1':base1,'base2':base2,'c':c,'moduli':moduli,'uncovered_pair':{'k':k,'l':l},'checks':vals}
                cert.update(verify_crt_certificate(cert)); return cert
    return {'type':'CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE','replay_passed':False,'failure':'no_uncovered_pair_found_in_search_bound','base1':base1,'base2':base2,'c':c,'moduli':moduli}

def verify_crt_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    if cert.get('type')!='CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE': return {'replay_passed':False,'failure':'wrong_type'}
    for key in ['base1','base2','c','moduli','uncovered_pair','checks']:
        if key not in cert: return {'replay_passed':False,'failure':'missing_'+key}
    if not cert['moduli'] or not cert['checks']: return {'replay_passed':False,'failure':'empty_moduli_or_checks'}
    b1=int(cert['base1']); b2=int(cert['base2']); c=int(cert['c']); k=int(cert['uncovered_pair']['k']); l=int(cert['uncovered_pair']['l'])
    seen=[]
    for m in cert['moduli']:
        m=int(m); v=(pow(b1,k,m)*pow(b2,l,m)+c)%m; seen.append(m)
        if v==0: return {'replay_passed':False,'failure':'pair_is_covered','modulus':m,'value_mod_m':v}
    if sorted(seen)!=sorted([int(x['modulus']) for x in cert['checks']]): return {'replay_passed':False,'failure':'checks_do_not_match_moduli'}
    return {'replay_passed':True,'checked_moduli':seen,'certificate_scope':'FINITE_MODULI_NONCOVER_CERTIFICATE'}

def diophantine_local_certificate(A:int,B:int,C:int,modulus:int)->Dict[str,Any]:
    solutions=[]
    for x in range(modulus):
        for y in range(modulus):
            if (A*x*x+B*y*y-C)%modulus==0: solutions.append((x,y))
    cert={'type':'LOCAL_OBSTRUCTION_CERTIFICATE','claim_proves':'no residue pair solves A*x^2+B*y^2=C modulo m' if not solutions else 'local solutions exist modulo m','does_not_prove':['global solubility over integers','rational solubility','higher genus facts'],'A':A,'B':B,'C':C,'modulus':modulus,'solutions':solutions[:20],'solution_count':len(solutions)}
    cert.update(verify_diophantine_certificate(cert)); return cert

def verify_diophantine_certificate(cert:Dict[str,Any])->Dict[str,Any]:
    if cert.get('type')!='LOCAL_OBSTRUCTION_CERTIFICATE': return {'replay_passed':False,'failure':'wrong_type'}
    for key in ['A','B','C','modulus','solution_count']:
        if key not in cert: return {'replay_passed':False,'failure':'missing_'+key}
    A=int(cert['A']); B=int(cert['B']); C=int(cert['C']); m=int(cert['modulus'])
    if m<2: return {'replay_passed':False,'failure':'bad_modulus'}
    count=0
    for x in range(m):
        for y in range(m):
            if (A*x*x+B*y*y-C)%m==0: count+=1
    if count!=int(cert['solution_count']): return {'replay_passed':False,'failure':'solution_count_mismatch','expected':count,'got':cert['solution_count']}
    return {'replay_passed':True,'certificate_scope':'QUADRATIC_LOCAL_ONLY','obstruction':count==0}

def verify_any_certificate(cert:Dict[str,Any], expected_type:Optional[str]=None)->Dict[str,Any]:
    if expected_type and cert.get('type')!=expected_type: return {'replay_passed':False,'failure':'wrong_artifact_type','expected':expected_type,'got':cert.get('type')}
    t=cert.get('type')
    if t=='RECURRENCE_REPLAY_CERTIFICATE': return verify_recurrence_certificate(cert)
    if t=='POLYNOMIAL_REPLAY_CERTIFICATE': return verify_polynomial_certificate(cert)
    if t=='CRT_FINITE_MODULI_UNCOVERED_EXPONENT_PAIR_CERTIFICATE': return verify_crt_certificate(cert)
    if t=='LOCAL_OBSTRUCTION_CERTIFICATE': return verify_diophantine_certificate(cert)
    return {'replay_passed':False,'failure':'unknown_certificate_type'}
