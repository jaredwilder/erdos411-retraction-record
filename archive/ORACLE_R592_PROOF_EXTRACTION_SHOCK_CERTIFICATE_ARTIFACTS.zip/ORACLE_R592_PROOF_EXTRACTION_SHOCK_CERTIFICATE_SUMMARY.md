# ORACLE R592 — Proof Extraction + Shock Certificate

## Mission

Turn R591/R590 data into a proof-shaped certificate, then expand the decisive chamber.

## Symbolic extraction

For `t >= 2`:

```text
x0 = 2*p^t
x1 = p^(t-1)*(3p - 1)
C1 = 3p - 1
C_(j+1) = p*C_j + (p - 1)*phi(C_j)
compare C_j against 4*p^j
```

## Step-2 infinite fact

Step-2 equality would require:

```text
phi(3p - 1) = p(p+1)/(p-1) = p + 2 + 2/(p-1)
```

For every prime `p > 3`, this is not an integer. Therefore:

```text
NO STEP-2 HIT IS POSSIBLE FOR ANY RELEVANT PRIME p.
```

## Shock chamber

```text
p <= 20,000,000
p ≡ 7 mod 8
coefficient depth cap: 100
```

## Python results

```text
prime p tested:             317,668
step-2 hits:                0
step-2 overflow primes:     312,391
step-2 underflow primes:    5,277
x1 source births:           0
underflow overshoots:       5,277
bad / unresolved:           0
max overshoot depth seen:   3
overshoot depth distribution:
{
  "3": 5277
}
```

## GTH

This is now proof-shaped:

1. Step-2 equality is symbolically impossible for all relevant primes.
2. The only remaining cases are strict underflows.
3. Python certifies every strict underflow prime up to `20,000,000` overshoots in the coefficient recurrence.
4. No x1 source births occur in this chamber.

## Internet-famous relevance

This is the right kind of result to show: it is not merely “more data”; it extracts the symbolic recurrence and isolates the exact surviving mechanism.
