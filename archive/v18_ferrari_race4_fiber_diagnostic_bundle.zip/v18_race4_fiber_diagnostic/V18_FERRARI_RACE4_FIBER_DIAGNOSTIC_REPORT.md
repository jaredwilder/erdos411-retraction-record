# V18 Ferrari Race 4: Fiber Diagnostic for Projection Survival

## Verdict

Ferrari Mode continued from the canonical V2 document. No new framework. No reset.

## Start State

- Danger-closed family: `[5, 7, 11, 13, 31, 61]`
- Closed-family period: `60 x 60`
- Initial residual projected cells: `1749`
- Race 3 replayed depth-2 branches: `53`
- Unique final modulus families represented: `18`

## Exact Binary

Can projection survival be explained by a monotonicity/fiber lemma, making all finite-depth danger-closure extensions incapable of destroying the initial residual cells?

## What This Race Tested

Race 3 showed projection equality. Race 4 inspected the hidden fiber map.

For each replayed final modulus family, Race 4 computed:

```text
for each initial residual cell u:
    number of final uncovered lifts of u
```

## Result

```json
{
  "total_initial_cell_family_tests": 31482,
  "destroyed_initial_cell_family_tests": 0,
  "global_min_surviving_lifts_per_initial_cell": 1,
  "global_projection_survival": true,
  "tight_family_count_at_global_min": 2,
  "tight_examples_sample": [
    {
      "final_moduli": [
        5,
        7,
        11,
        13,
        17,
        31,
        41,
        61,
        97,
        241
      ],
      "q_pairs_represented": [
        [
          17,
          97
        ],
        [
          41,
          97
        ]
      ],
      "min": 1,
      "tight_cell_sample": [
        [
          0,
          0
        ]
      ]
    },
    {
      "final_moduli": [
        5,
        7,
        11,
        13,
        17,
        31,
        41,
        61,
        241
      ],
      "q_pairs_represented": [
        [
          41,
          17
        ]
      ],
      "min": 1,
      "tight_cell_sample": [
        [
          0,
          0
        ],
        [
          20,
          20
        ],
        [
          40,
          40
        ]
      ]
    }
  ]
}
```

## Stronger Earned Claim

Across all unique replayed Race-3 final modulus families, every one of the 1749 initial residual cells has at least one surviving final lift.

That means Race 3 was not just a projection-set coincidence. It is supported by direct fiber-survival counts.

## Tightness

The global minimum surviving lift count is `1`.

That matters. Cells with only one surviving lift are the vulnerable edge of the conjecture. They are now the next target, not a vague monotonicity slogan.

## What This Does Not Prove

- It does not prove unbounded depth.
- It does not cover Race 3 branches skipped by the area limit.
- It does not prove global CRT-covering impossibility.
- It does not close the monotonicity/fiber lemma.

## Next KBK Binary

```text
Can tight cells with exactly one surviving lift be characterized algebraically, or can they be targeted to produce a depth-3 counterexample branch?
```

## Artifact

- `v18_race4_fiber_diagnostic_certificate.json`
