# Oracle NT OS V15 — Frontier Battle Core

V15 is the first build aimed at producing a bounded mathematical kill event rather than only rejecting fake discovery.

Core artifact:

```text
CRT_CANDIDATE_SET_EXACT_NONCOVER_CERTIFICATE
```

It exhaustively searches every subset of a declared candidate modulus set up to a declared size bound, computes the induced exponent torus, finds the exact best coverage, and emits a replayable uncovered witness when no subset covers the torus.

This proves a narrow but real finite claim:

> Within this finite candidate set and subset-size bound, no cover exists.

It does **not** prove a global covering-system theorem. It does produce the next frontier hinge: whether the finite obstruction persists under expanded candidates or lifts into a general obstruction.

## Run

```bash
python oracle_nt_os_v15.py selftest --out v15_selftest_out
```

## CRT battle

```bash
python oracle_nt_os_v15.py crt-battle \
  --base1 2 --base2 3 --c 1 \
  --candidates 5 7 11 13 17 \
  --max-subset-size 5 \
  --out crt_battle_v15
```

## Discovery packet

```bash
python oracle_nt_os_v15.py discovery-crt-battle \
  --base1 2 --base2 3 --c 1 \
  --candidates 5 7 11 13 17 \
  --max-subset-size 5 \
  --out discovery_battle_v15
```

## Verify a certificate

```bash
python oracle_nt_os_v15.py verify-cert --certificate crt_battle_v15/crt_candidate_set_exact_noncover_certificate.v15.json
```

## Honesty boundary

V15 does not claim global EG203 closure. It claims a replayable finite search-space reduction and forces the next binary.
