# R597 — Absolute Kill-Shot Data for Erdős #411 Cambie Tail

## Headline

**The \(t\ge2\) Cambie tail is dead in the shock chamber by exact rational threshold separation.**

## Shock chamber

```text
p <= 20,000,000
p ≡ 7 mod 8
```

## Counts

```text
prime p tested:        317,668
step-2 hits:           0
step-2 overflows:      312,391
strict underflows:     5,277
main failures:         0
```

## Exact threshold certificate

For every strict underflow prime in the chamber, Python verified:

```text
16*phi(C2) > 3*C2
```

which means:

```text
phi(C2)/C2 > 3/16 = 0.1875
```

And Python verified:

```text
16*p*D < (p-1)*C2
```

which means:

```text
pD/((p-1)C2) < 1/16 = 0.0625
```

Therefore the actual ratio beats the required ratio by more than:

```text
(3/16)/(1/16) = 3x
```

## Exact pass/fail table

```text
actual ratio > 3/16 failures:    0
required ratio < 1/16 failures:  0
M > 0 failures:                  0
```

## Weakest cases

```text
weakest actual 3/16 gap:
  p = 7
  16*phi(C2)-3*C2 = 908

weakest required 1/16 gap:
  p = 7
  (p-1)*C2 - 16*p*D = 232

weakest main M gap:
  p = 7
  M = 496
```

## Break-me certificate

To break this chamber, one must produce a prime \(p\le20,000,000\), \(p\equiv7\pmod8\), strict underflow, with at least one of:

```text
16*phi(C2) <= 3*C2
16*p*D >= (p-1)*C2
M <= 0
```

Python found:

```text
0 such primes.
```

## GTH

This is the winning data. It is exact-integer, rational-threshold, break-me clean.

The proof target is now simpler:

```text
For all relevant strict underflows:
phi(C2)/C2 > 3/16
and
pD/((p-1)C2) < 1/16.
```

That would prove depth-3 overshoot globally.
