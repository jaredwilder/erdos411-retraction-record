# Erdős #411 — D-Branch Recordable Math and Closure Plan

**Status:** recordable mathematics package, not a full proof of Erdős #411.  
**Branch:** the prime-filtered `r=2` exceptional channel.  
**Core equation:**

\[
\varphi(m)=\frac23(m+1),\qquad P=\frac{4m+1}{3}=2\varphi(m)-1\text{ prime}.
\]

**Claim supported computationally through**

\[
M=2^{64}-1=18{,}446{,}744{,}073{,}709{,}551{,}615:
\]

\[
\varphi(m)=\frac23(m+1),\quad P\text{ prime},\quad m<M
\Longrightarrow m\in\{5,35\}.
\]

---

## 1. Prime-filter normalization

From

\[
\varphi(m)=\frac23(m+1)
\]

we get

\[
m+1=\frac32\varphi(m).
\]

Hence

\[
P=\frac{4m+1}{3}=2\varphi(m)-1.
\]

So the prime-filtered branch is exactly

\[
\boxed{\varphi(m)=\frac23(m+1),\qquad 2\varphi(m)-1\text{ prime}.}
\]

---

## 2. Parent-defect formula

Let

\[
m=ap
\]

with `p` the largest prime factor of `m`. Then

\[
\varphi(a)(p-1)=\frac23(ap+1).
\]

Rearranging gives

\[
p(3\varphi(a)-2a)=3\varphi(a)+2.
\]

Define

\[
E(a)=\frac{3\varphi(a)-2a}{2}.
\]

Then

\[
\boxed{p=1+\frac{a+1}{E(a)}.}
\]

Thus every largest-prime extension requires

\[
\boxed{E(a)\mid a+1.}
\]

The chain branch is `E(a)=1`, giving

\[
5\to35\to1295\to1679615.
\]

The prime filter keeps only

\[
\boxed{m=5,35.}
\]

because

\[
1295\mapsto 1727=11\cdot157,
\]

and

\[
1679615\mapsto 2239487=23\cdot97369.
\]

---

## 3. Critical-prefix window

Let

\[
Q=\max q\mid a.
\]

For `p` to be the largest prime factor, we need

\[
p>Q.
\]

Since

\[
p=1+\frac{a+1}{E(a)},
\]

we get

\[
E(a)<\frac{a+1}{Q-1}.
\]

Therefore

\[
\boxed{0<3\varphi(a)-2a<\frac{2(a+1)}{Q-1}.}
\]

Equivalently,

\[
\boxed{
\frac23<\frac{\varphi(a)}a<\frac23+\frac{2(a+1)}{3a(Q-1)}.
}
\]

This shows that every non-chain candidate must be a critical prefix whose Euler ratio lies in a tiny one-sided window above `2/3`.

---

## 4. Non-chain critical prefixes exist, but the forced extension factors

The naive lemma

\[
E(a)\mid a+1,\quad p>Q\Longrightarrow E(a)=1
\]

is false.

Counter-prefix:

\[
a=5\cdot7\cdot67\cdot83=194635,
\]

\[
\varphi(a)=4\cdot6\cdot66\cdot82=129888,
\]

\[
E(a)=\frac{3\varphi(a)-2a}{2}=197,
\]

and

\[
a+1=194636=197\cdot988.
\]

Thus

\[
p=1+\frac{a+1}{E(a)}=989=23\cdot43.
\]

So the corrected closure principle is:

\[
\boxed{
E(a)>1,
\quad E(a)\mid a+1,
\quad p=1+\frac{a+1}{E(a)}>Q
\Longrightarrow p\text{ composite}.
}
\]

This is the forced-extension compositeness target.

---

## 5. Divisor-descent identity

Write

\[
a=Br
\]

with `r` the largest prime factor of `a`. Let

\[
A=E(B)=\frac{3\varphi(B)-2B}{2}.
\]

Then

\[
E(Br)=A(r-1)-B.
\]

Set

\[
d=E(Br).
\]

If

\[
d\mid Br+1,
\]

then

\[
\boxed{d\mid L_B:=B^2+AB+A.}
\]

Proof:

\[
d=A(r-1)-B=Ar-(A+B).
\]

Then

\[
A(Br+1)-Bd=ABr+A-B(Ar-A-B)=B^2+AB+A.
\]

Thus

\[
d\mid B^2+AB+A.
\]

Writing

\[
dT=L_B,
\]

we get

\[
\boxed{r=1+\frac{B+d}{A},\qquad p=1+\frac{B+T}{A}.}
\]

This is the core recursive machine.

---

## 6. Chain branch versus non-chain branch

The chain is exactly the `d=1` branch.

For example, with `B=5`, `A=1`,

\[
L_B=5^2+5+1=31.
\]

Taking `d=1`, `T=31`,

\[
r=7,
\qquad
p=37.
\]

For `B=35`, `A=1`,

\[
L_B=1261,
\]

and `d=1` gives

\[
r=37,
\qquad
p=1297.
\]

Thus `d=1` gives the known chain.

The non-chain branch is `d>1`.

Example:

\[
B=5\cdot7\cdot67=2345,
\qquad
A=31,
\]

\[
L_B=B^2+AB+A=5571751=197\cdot28283.
\]

Taking

\[
d=197,
\qquad
T=28283,
\]

we obtain

\[
r=1+\frac{2345+197}{31}=83
\]

prime, but

\[
p=1+\frac{2345+28283}{31}=989=23\cdot43.
\]

So non-chain divisor births can occur, but the complementary forced extension factors.

---

## 7. Complementary-divisor compositeness target

The symbolic closure target is now exactly:

\[
\boxed{
\begin{aligned}
&A=E(B)>0,\\
&L_B=B^2+AB+A,\\
&1<d<\sqrt{L_B},\\
&dT=L_B,\\
&r=1+\frac{B+d}{A}\text{ prime}
\end{aligned}
\Longrightarrow
p=1+\frac{B+T}{A}\text{ composite}.
}
\]

This is the D-branch closure lemma.

If this holds, then non-chain branches die. The chain branch remains, and the prime filter keeps only `m=5,35`.

---

## 8. 64-bit computational certificate

A prefix-window/divisor-pair engine was run to the 64-bit ceiling:

\[
M=2^{64}-1.
\]

Run summary:

```text
nodes              127,644,270
prefixes tested    119,078,030
r-windows          119,031,576
r scanned          137,257,187
b tested            21,360,592
s scanned          717,575,302
divisor hits                 4
solutions                    0
max depth                    9
elapsed              20.37 sec
```

The four divisor hits all died.

### Hit 1

\[
B=5\cdot7\cdot37\cdot1613\cdot9749.
\]

Candidate:

\[
s=20339,
\qquad
p=735674000123.
\]

Death:

\[
735674000123=19\cdot75577\cdot512321.
\]

Prime filter:

\[
P=47\cdot653784524389\cdot13221643793629.
\]

### Hit 2

\[
B=5\cdot7\cdot37\cdot1979\cdot4409.
\]

Candidate:

\[
s=25247,
\qquad
p=39396965.
\]

Death:

\[
39396965=5\cdot7879393.
\]

Prime filter:

\[
P=11\cdot271\cdot5026954666077617107.
\]

### Hit 3

\[
B=5\cdot7\cdot37\cdot2903\cdot4409.
\]

Candidate:

\[
s=6305,
\qquad
p=23855.
\]

Death:

\[
23855=5\cdot13\cdot367.
\]

Prime filter:

\[
P=12417593\cdot267684195319.
\]

### Hit 4

\[
B=5\cdot7\cdot47\cdot157\cdot4547.
\]

Candidate:

\[
s=22469,
\qquad
p=95993.
\]

Death:

\[
95993=59\cdot1627.
\]

Prime filter:

\[
P=11\cdot151\cdot4421\cdot459898938287.
\]

Therefore, computationally:

\[
\boxed{
\varphi(m)=\frac23(m+1),\quad P\text{ prime},\quad m<2^{64}
\Longrightarrow m\in\{5,35\}.
}
\]

---

## 9. Recordable mathematical outputs

The work has produced recordable mathematics:

1. **Prime-filter normalization:** `P=(4m+1)/3=2φ(m)-1`.
2. **Parent-defect formula:** `p=1+(a+1)/E(a)`.
3. **Critical-prefix window:** `φ(a)/a` lies in a microscopic one-sided window above `2/3`.
4. **Non-chain escape example:** `a=5·7·67·83`, `E(a)=197`, forced extension `989=23·43`.
5. **Divisor-descent identity:** if `d=E(Br)` and `d | Br+1`, then `d | B²+AB+A`.
6. **Recursive divisor machine:** `dT=B²+AB+A`, `r=1+(B+d)/A`, `p=1+(B+T)/A`.
7. **Complementary-divisor compositeness target:** non-chain divisor births should force complementary composite `p`.
8. **64-bit computational theorem:** no prime-filtered non-chain solution below `2^64`.

These are worth recording and sharing as a serious research note.

---

## 10. Next closure attack

The only remaining symbolic target for the D-branch is:

\[
\boxed{
1<d<\sqrt{B^2+AB+A},\quad dT=B^2+AB+A,
\quad r=1+\frac{B+d}{A}\text{ prime}
\Longrightarrow
p=1+\frac{B+T}{A}\text{ composite}.
}
\]

No other D-branch target matters.
