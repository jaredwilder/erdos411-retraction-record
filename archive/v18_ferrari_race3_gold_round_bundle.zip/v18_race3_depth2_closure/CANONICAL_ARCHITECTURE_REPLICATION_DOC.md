# Canonical Architecture Replication Document

## Name

Oracle Ferrari Architecture: Discovery-Pressure Number-Theory Workbench

## Purpose

Replicate the working loop that converted adversarial criticism into a cleaner theorem coordinate, then into bounded replayable search results. This document is not branding. It is the architecture needed to rebuild the same machine on another mathematical substrate.

## Core Principle

The system does not reward a report. It rewards a replayable frontier movement.

```text
critic pressure -> exact compression -> executable search -> replay certificate -> next KBK binary
```

## Layers

### 1. Trust / Verifier Core

Role: prevent fake artifacts.

Required behavior:
- Reject self-attested theorem trust.
- Replay certificates instead of trusting `replay_passed`.
- Bind artifacts to object/claim hashes when continuing KBK.
- Separate local computation from external/literature/formal verification.

Output classes:
- `LOCAL_ONLY`
- `REPLAY_CERTIFIED_NARROW_CLAIM`
- `EXTERNAL_VERIFIED`
- `FORMALLY_VERIFIED`

### 2. Discovery Pressure Core

Role: prevent verifier-only progress.

Required packet fields:
- one selected binary
- external adjudicator
- frontier delta
- novelty/corpus comparison
- proof pressure
- failure asset on kill
- next KBK binary

Hard rejection:
```text
NO FRONTIER DELTA = NO DISCOVERY
```

### 3. Discovery Foundry

Role: generate and select attacks.

Procedure:
1. Generate candidate frontier mutations.
2. Score by heat: proof pressure, frontier magnitude, kill value, adjudicator hardness, novelty, surprise, and cost.
3. Select exactly one binary.
4. Execute only that binary.
5. Archive failures as search structure.

Candidate generation is not scatter. Executing multiple unrelated binaries is scatter.

### 4. Referee Forge

Role: stop internally impressive but externally irrelevant artifacts.

Required gates:
- referee value
- field collision
- formalization tax
- family transfer
- proof-failure ledger
- minimum publishable unit
- representation mutation
- conjecture compiler

Question:
```text
Would a hostile expert have to engage this?
```

### 5. Ferrari Track Loop

Role: use all prior layers without version-drama.

Loop:
1. Start from last earned result, not from shame.
2. Compress criticism into a theorem coordinate.
3. Run the next executable attack.
4. Emit a replayable certificate.
5. State exactly what is and is not claimed.
6. Emit the next KBK binary.

## Number-Theory Instantiation

### Base object

Expression family:
```text
2^k * 3^l + 1
```

Base modulus family:
```text
M0 = {5,7,11}
```

### Compression Lemma

For a base family `M`, define:
```text
K_M = lcm(ord_p(2) for p in M)
L_M = lcm(ord_p(3) for p in M)
```

An extension prime `q` fails to enlarge the exponent-period lattice iff:
```text
ord_q(2) | K_M and ord_q(3) | L_M
```

Equivalently:
```text
q | gcd(2^K_M - 1, 3^L_M - 1)
```

For `M0 = {5,7,11}`, `K=L=60`, and the dangerous extension primes outside the base family are:
```text
{13,31,61}
```

### Race sequence

Race 1:
- Add all dangerous primes.
- Residual cells after closure: `1749`.

Race 2:
- One-step recursive danger closure under bounded replay.
- Replayed branches: `13`.
- Destroyed original residual cells: `0`.

Race 3:
- Depth-2 recursive danger closure under bounded replay.
- Replayed branches: `53`.
- Destroyed original residual cells: `0` maximum.

## Required Artifact Schema

Each race must emit:
```json
{
  "artifact_type": "...CERTIFICATE",
  "claim": "narrow replayed claim",
  "not_claimed": ["global theorem", "unbounded depth", "skipped branches"],
  "base": {...},
  "settings": {...},
  "summary": {...},
  "branch_rows": [...],
  "sha256": "..."
}
```

## Acceptance Tests

A replication succeeds only if:
1. It reproduces the compression lemma.
2. It computes the dangerous-prime set from the gcd criterion, not from classifier labels.
3. It replays residual coverage after adding all dangerous primes.
4. It runs at least one recursive danger-closure race.
5. It states skipped bounds honestly.
6. It produces a next KBK binary that is mathematically sharper than the previous one.

## Anti-Patterns

Reject:
- new gates without new math
- world-shock language without a hard artifact
- classifier language when a gcd criterion exists
- selftest counts as progress
- prose theorem routes with no executable search
- collapse language after a successful compression

## Canonical Next Theorem Target

```text
Projection Survival Lemma:
For the danger-closed base family M* = {5,7,11,13,31,61}, every replayed finite-depth extension-danger closure preserves the projection of the residual uncovered set to the original 60×60 lattice.
```

Current status: bounded computational evidence, not theorem.

Next KBK binary:
```text
Can projection survival be proven as a monotonicity/fiber lemma, or can a bounded search find a counterexample branch that destroys an initial residual cell?
```
