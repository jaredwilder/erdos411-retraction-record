# V18 Ferrari Race 3: Depth-2 Recursive Danger-Closure Search

## Verdict

Under the bounded replay settings, no replayed depth-2 branch destroyed any original residual projected cell.

## Start State

- Base family: `[5, 7, 11]`
- Initial danger closure: `[5, 7, 11, 13, 31, 61]`
- Closed-family period: `60 × 60`
- Initial residual projected cells: `1749`

## Bounded Search Settings

- Candidate branch primes: primes <= 150, excluding the initial danger closure
- Area limit per replayed final branch: `750000` cells
- Depth rule: `q1 -> danger closure -> q2 -> danger closure -> project final uncovered set back to 60×60`

## Results

```json
{
  "tested_replayed_depth2_branches": 53,
  "skipped_area_or_depth1_limit": 393,
  "branches_destroying_original_projection": 0,
  "maximum_destroyed_initial_cells": 0,
  "minimum_projection_survival_ratio": 1.0,
  "elapsed_seconds": 6.338
}
```

## Earned Claim

Within the bounded depth-2 replay search, the residual projection from the initial danger-closed family `[5, 7, 11, 13, 31, 61]` survived every replayed recursive closure branch. This strengthens Race 2 from one-step survival to two-step bounded branch survival.

## What This Does Not Claim

- It does not prove unbounded recursive danger closure.
- It does not cover branches skipped by the area limit.
- It does not cover primes above `150`.

## Next KBK Binary

Can the projection-survival result be explained by a monotonicity/projection lemma, making all finite-depth danger-closure extensions incapable of destroying the initial residual cells?

## Referee-Grade Translation

The computational phenomenon is no longer only that `[5, 7, 11, 13, 31, 61]` leaves residual cells. The stronger bounded phenomenon is that depth-1 and depth-2 danger-closure extensions, when replayable under the area budget, preserve the original residual projection exactly. The next useful theorem target is a projection monotonicity lemma.
