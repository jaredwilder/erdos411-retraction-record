# R599 — Full Victory Proof Frontier

## No fake finish

Full infinite victory for “Completing the r=2 case of Erdős Problem #411” requires global proof, not only shock data.

The R597 data gives the right theorem. R599 reduces it to exact proof lemmas.

## Definitions

```text
delta = p + 1 - phi(3p - 1)
C2 = 4p^2 - p - 1 - (p - 1)*delta
D  = p + 1 + (p - 1)*delta
```

## Lemma 1 — required-ratio bound

We need:

```text
pD/((p - 1)C2) < 1/16
```

Equivalent exact integer inequality:

```text
16*p*D < (p - 1)*C2
```

Python/SymPy expands the gap:

```text
(p - 1)*C2 - 16*p*D
= -17*delta*p**2 + 18*delta*p - delta + 4*p**3 - 21*p**2 - 16*p + 1
```

Solving for `delta` gives the exact threshold:

```text
delta < (4*p**3 - 21*p**2 - 16*p + 1)/(17*p**2 - 18*p + 1)
```

Asymptotically:

```text
delta < (4/17)p + O(1)
```

## Lemma 2 — actual-ratio bound

We need:

```text
phi(C2)/C2 > 3/16
```

Equivalent exact integer inequality:

```text
16*phi(C2) > 3*C2
```

R597 verified this for every strict underflow prime `p <= 20,000,000`.

## Lemma 3 — depth-3 kill

If Lemma 1 and Lemma 2 hold, then:

```text
phi(C2)/C2 > 3/16 > 1/16 > pD/((p - 1)C2)
```

Therefore:

```text
(p - 1)*phi(C2) > pD
```

Therefore every strict step-2 underflow overshoots at depth 3.

## GTH

This is the honest full-victory frontier.

Full infinite victory is one global proof pair away:

```text
A. prove delta < threshold ~ (4/17)p
B. prove phi(C2)/C2 > 3/16
```

The data says both are massively true through p<=20,000,000. The proof has not been written yet.
