# Oracle NT OS V10 Report: sq_index1

Version: `10.0.0-oracle-nt-os-trust-receipts-route-certificates`

Primary coordinate: **known_family_classification**
Verdict: **ROUTE_SPECIFIC_THEOREM_GTH_ALLOWED**

## Claim Gates
```json
{
  "overall_verdict": "ROUTE_SPECIFIC_THEOREM_GTH_ALLOWED",
  "classification_gth_allowed": true,
  "theorem_gth_allowed_routes": [
    {
      "route": "polynomial_finite_difference",
      "status": "THEOREM_READY",
      "theorem_gth_allowed": true,
      "blockers": [],
      "open_conditions": []
    }
  ],
  "novelty_gth_allowed": false,
  "proof_target_gth_allowed": true,
  "route_claims": [
    {
      "route": "polynomial_finite_difference",
      "status": "THEOREM_READY",
      "theorem_gth_allowed": true,
      "blockers": [],
      "open_conditions": []
    },
    {
      "route": "linear_recurrence",
      "status": "NOT_APPLICABLE",
      "theorem_gth_allowed": false,
      "blockers": [
        "no exact recurrence detected"
      ],
      "open_conditions": []
    },
    {
      "route": "strong_divisibility",
      "status": "PROOF_OBLIGATION_EXACT",
      "theorem_gth_allowed": false,
      "blockers": [],
      "open_conditions": [
        "prove all-index gcd identity under canonical normalization via Euclidean recurrence/determinant route"
      ]
    },
    {
      "route": "primitive_divisor",
      "status": "NOT_APPLICABLE",
      "theorem_gth_allowed": false,
      "blockers": [
        "requires order-2 recurrence route"
      ],
      "open_conditions": []
    }
  ],
  "known_boring": true,
  "scope": "FORMAL_DEFINITION",
  "formal_verification_status": "THEOREM_ROUTE_READY_BUT_NOT_LEAN_VERIFIED",
  "trust_boundary": "THEOREM_ROUTE_READY is not FORMALLY_VERIFIED unless Lean successfully checks the emitted target"
}
```

## KBK
```json
{
  "required_action": "close_strong_divisibility_condition",
  "killer_next_data": "Execute closure for: prove all-index gcd identity under canonical normalization via Euclidean recurrence/determinant route",
  "no_fake_loop_rule": "continue must run required_action; classify-only is refused unless override is supplied",
  "generated_at": "2026-05-21T22:03:31Z"
}
```
