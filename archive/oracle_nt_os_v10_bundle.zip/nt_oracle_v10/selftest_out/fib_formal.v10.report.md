# Oracle NT OS V10 Report

```json
{
  "version": "10.0.0-oracle-nt-os-trust-receipts-route-certificates",
  "object": {
    "object_type": "recurrence_sequence",
    "label": "fib_formal",
    "scope": "FORMAL_DEFINITION",
    "terms": [
      1,
      1,
      2,
      3,
      5,
      8,
      13,
      21,
      34,
      55,
      89,
      144
    ],
    "index_start": 0,
    "definition": {
      "initial_terms": [
        1,
        1
      ],
      "recurrence": {
        "coefficients": [
          1,
          1
        ],
        "valid_for": "n >= 2"
      },
      "domain": "integers"
    },
    "source": {
      "status": "ANALYZER_VERIFIED_LOCAL_SCHEMA",
      "verified_by": "oracle_nt_v10",
      "issuer": "local",
      "verification_receipt": "b7741da2161e",
      "object_trust_key": "3c2a41f447d0"
    }
  },
  "verdict": "KBK_REFUSED_WRONG_ACTION",
  "required_action": "close_strong_divisibility_condition",
  "attempted_action": "classify",
  "override_available": "--override-with-reason"
}
```
