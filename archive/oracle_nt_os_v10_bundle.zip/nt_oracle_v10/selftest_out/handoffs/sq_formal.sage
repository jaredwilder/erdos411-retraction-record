# Oracle NT OS V10 Sage handoff
seq = [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
print('length', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('sage polynomial ring ready')
except Exception as e:
    print('sage setup error', e)
