# Oracle NT OS V10 Sage handoff
seq = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]
print('length', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('sage polynomial ring ready')
except Exception as e:
    print('sage setup error', e)
