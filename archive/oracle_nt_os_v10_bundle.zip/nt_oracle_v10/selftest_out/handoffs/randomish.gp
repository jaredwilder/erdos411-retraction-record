\ Oracle NT OS V10 PARI/GP handoff
seq = [2, 7, 1, 8, 2, 8, 1, 8, 2, 8, 4, 5];
print(["length", #seq]);
for(i=1, min(#seq, 20), print([i-1, seq[i], factor(abs(seq[i]))]));
