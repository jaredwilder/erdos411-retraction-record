\ Oracle NT OS V10 PARI/GP handoff
seq = [4, 9, 2, 6, 5, 35, 7, 11];
print(["length", #seq]);
for(i=1, min(#seq, 20), print([i-1, seq[i], factor(abs(seq[i]))]));
