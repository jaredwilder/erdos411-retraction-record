# Oracle NT OS V10 Sage handoff
seq = [1, 4, 9, 16, 25]
print('length', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('sage polynomial ring ready')
except Exception as e:
    print('sage setup error', e)
