\ Oracle NT OS V10 PARI/GP handoff
seq = [1, 4, 9, 16, 25];
print(["length", #seq]);
for(i=1, min(#seq, 20), print([i-1, seq[i], factor(abs(seq[i]))]));
