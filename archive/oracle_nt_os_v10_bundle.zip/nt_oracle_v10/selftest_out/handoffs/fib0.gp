\ Oracle NT OS V10 PARI/GP handoff
seq = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34];
print(["length", #seq]);
for(i=1, min(#seq, 20), print([i-1, seq[i], factor(abs(seq[i]))]));
