# Oracle NT OS V10 Sage handoff
seq = [4, 9, 2, 6, 5, 35, 7, 11]
print('length', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('sage polynomial ring ready')
except Exception as e:
    print('sage setup error', e)
