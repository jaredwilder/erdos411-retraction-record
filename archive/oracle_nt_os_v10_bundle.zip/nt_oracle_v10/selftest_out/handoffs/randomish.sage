# Oracle NT OS V10 Sage handoff
seq = [2, 7, 1, 8, 2, 8, 1, 8, 2, 8, 4, 5]
print('length', len(seq))
try:
    R.<x> = PolynomialRing(QQ)
    print('sage polynomial ring ready')
except Exception as e:
    print('sage setup error', e)
