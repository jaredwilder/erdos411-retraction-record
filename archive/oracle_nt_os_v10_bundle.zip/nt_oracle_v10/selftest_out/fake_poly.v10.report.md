# Oracle NT OS V10 Report

```json
{
  "version": "10.0.0-oracle-nt-os-trust-receipts-route-certificates",
  "object": {
    "object_type": "polynomial_sequence",
    "label": "fake_poly",
    "scope": "FORMAL_DEFINITION",
    "terms": [
      0,
      1,
      4,
      9,
      16,
      26,
      36,
      49
    ],
    "index_start": 0,
    "definition": {
      "formula_coefficients_low_to_high": [
        0,
        0,
        1
      ]
    },
    "source": {
      "status": "ANALYZER_VERIFIED_LOCAL_SCHEMA",
      "verified_by": "oracle_nt_v10",
      "issuer": "acceptance",
      "verification_receipt": "e6e3763f83d3",
      "object_trust_key": "a76354c04b56"
    }
  },
  "object_id": "f5acfadd6af8",
  "verdict": "FORMAL_OBJECT_CONTRADICTION",
  "contradiction": {
    "verdict": "FORMAL_OBJECT_CONTRADICTION",
    "reason": "terms do not match supplied polynomial definition",
    "generated_prefix": [
      0,
      1,
      4,
      9,
      16,
      25,
      36,
      49
    ],
    "observed_terms": [
      0,
      1,
      4,
      9,
      16,
      26,
      36,
      49
    ]
  },
  "claims": {
    "overall_verdict": "FORMAL_OBJECT_CONTRADICTION",
    "classification_gth_allowed": false,
    "theorem_gth_allowed_routes": [],
    "novelty_gth_allowed": false
  }
}
```
