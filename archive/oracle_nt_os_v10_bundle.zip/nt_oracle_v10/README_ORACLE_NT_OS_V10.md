# Oracle NT OS V10 - Trust Receipts, Verified Literature, Route Certificates

V10 is the contract build after the V9 adversarial review. It focuses on trust boundaries and route certificates, not cosmetic output.

## Run

```bash
python oracle_nt_os_v10.py selftest --out v10_selftest_out
```

Expected:

```json
{
  "version": "10.0.0-oracle-nt-os-trust-receipts-route-certificates",
  "selftest": "PASS",
  "green_checks": 40,
  "total_checks": 40
}
```

## Core fixes

- User JSON cannot self-assign verified source status.
- Analyzer verification requires a receipt plus a local trust registry entry.
- `--formal-recurrence` remains `GENERATED_EXTENSION`; it does not create formal theorem scope.
- Formal polynomial verification respects `index_start`.
- Known exact family matches override interpolation-risk primary coordinates.
- Online OEIS parsing verifies returned `data` prefix before treating a result as a collision.
- Novelty score is capped when literature search is incomplete.
- Proof artifacts are separated from closed proof debt.
- CRT and Diophantine modules emit explicit certificate objects with honest scope.
- The acceptance suite attacks hostile CLI and object-JSON paths.

## Seal a formal object

A formal object must be sealed into a local trust registry before theorem-grade formal scope is accepted.

```bash
python oracle_nt_os_v10.py seal-object \
  --object-json object_unsealed.json \
  --out-json object_sealed.json \
  --trust-registry ./trust_registry_v10.json
```

Then analyze it:

```bash
python oracle_nt_os_v10.py analyze-object \
  --object-json object_sealed.json \
  --trust-registry ./trust_registry_v10.json \
  --out out_v10
```

## Hostile checks that now fail safely

```bash
python oracle_nt_os_v10.py analyze-object --object-json fake_verified.json
# -> SCHEMA_INVALID, because self-asserted LOCAL_VERIFIED_SCHEMA is not trusted.
```

```bash
python oracle_nt_os_v10.py analyze-seq --seq "3,8,5,13,21,7" --label sixjunk
# -> high_degree_polynomial_interpolation_risk / NO_GTH.
```

```bash
python oracle_nt_os_v10.py analyze-seq --seq "0,1,1,2,3,5,8,13,21,34" --label fib0
# -> known_family_classification / boring known classification suppressed.
```

## Blunt scope

V10 is still infrastructure. It does not claim a world-shocking theorem by itself. It makes the trust boundary harder, the certificate language more honest, and the previous V9 attack paths mechanically rejected.
