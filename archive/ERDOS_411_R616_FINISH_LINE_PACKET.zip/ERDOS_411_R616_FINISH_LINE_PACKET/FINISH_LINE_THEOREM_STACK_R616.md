# Erdős #411 r=2 — Finish-Line Theorem Stack (R616)

## Executive claim

The six-family \(r=2\) picture

\[
2^a\{1,3,5,7,35,47\}
\]

is the correct theorem supported by every reduction, shock test, and lane-hunter result in the packet.

The honest finish-line status is:

\[
\boxed{\text{proved algebra + certified large chambers + finite named global proof targets.}}
\]

This is not a fake unconditional proof. It is a submission/audit-ready theorem stack designed so a serious referee can attack exact statements rather than vague computational folklore.

---

# I. Definitions

Let

\[
g(n)=n+\varphi(n)
\]

and let \(g_k\) be the \(k\)-fold iterate.

The \(r=2\) target is eventual equality

\[
g_{k+2}(n)=2g_k(n).
\]

The visible six families are

\[
n=2^a u,\qquad u\in\{1,3,5,7,35,47\}.
\]

---

# II. Proven algebraic lemmas

## Lemma 1 — Cambie coefficient recurrence

For the Cambie tail

\[
g_k(2p^t)=4p^t,\qquad p\equiv7\pmod8,
\]

set

\[
C_1=3p-1.
\]

As long as the \(p\)-adic exponent remains positive,

\[
C_{j+1}=pC_j+(p-1)\varphi(C_j)
\]

and

\[
g^j(2p^t)=p^{t-j}C_j.
\]

## Lemma 2 — Step-2 hit is impossible

At depth \(2\),

\[
C_2=p(3p-1)+(p-1)\varphi(3p-1).
\]

A step-2 hit requires

\[
C_2=4p^2.
\]

Thus

\[
\varphi(3p-1)=\frac{p(p+1)}{p-1}
=p+2+\frac{2}{p-1}.
\]

For every prime \(p>3\), this is not an integer.

Therefore:

\[
\boxed{\text{No Cambie }t\ge2\text{ tail has a step-2 hit.}}
\]

## Lemma 3 — \(N\)-form of the strict-underflow problem

For \(p\equiv7\pmod8\), write

\[
N=\frac{3p-1}{4}.
\]

Then

\[
\varphi(3p-1)=2\varphi(N)
\]

and

\[
C_2=4pN+2(p-1)\varphi(N).
\]

Also

\[
p=\frac{4N+1}{3}.
\]

Define

\[
D=4p^2-C_2.
\]

Then

\[
D>0
\]

if and only if

\[
(4N+1)(N+1)-3(2N-1)\varphi(N)>0.
\]

Equivalently,

\[
\frac{\varphi(N)}{N}
<
\frac{(4N+1)(N+1)}{3N(2N-1)}.
\]

The right side tends to \(2/3\).

---

# III. Certified computational theorem

## Theorem 4 — Certified exceptional-branch closure in the R591–R615 chambers

The following have been certified by executable Python artifacts included in the evidence archive.

### D-branch certificate

If

\[
\varphi(m)=\frac23(m+1),
\qquad
\frac{4m+1}{3}\text{ is prime},
\qquad
m<2^{64},
\]

then

\[
m\in\{5,35\}.
\]

### Cambie \(t=1\)

The \(t=1\) tail is absorbed by the D-ledger. In the induced range

\[
p<24,595,658,764,946,068,820,
\]

the only survivors are

\[
p=7,47.
\]

### Cambie \(t\ge2\)

For

\[
p\le20,000,000,\qquad p\equiv7\pmod8,
\]

every strict step-2 underflow overshoots by depth \(3\).

The exact depth-3 condition is

\[
(p-1)\varphi(C_2)>pD.
\]

The R597 exact rational split proves in the chamber:

\[
16\varphi(C_2)>3C_2
\]

and

\[
16pD<(p-1)C_2.
\]

Thus

\[
\frac{\varphi(C_2)}{C_2}>\frac3{16}>
\frac1{16}>
\frac{pD}{(p-1)C_2}
\]

and hence

\[
C_3>4p^3.
\]

---

# IV. Lemma A exact global target

Lemma A is the required-ratio lock

\[
\frac{pD}{(p-1)C_2}<\frac1{16}.
\]

In \(N\)-variables, Lemma A is equivalent to

\[
\boxed{
\frac{\varphi(N)}{N}>
\frac{(4N+1)(26N^2+43N+8)}
{3N(2N-1)(34N+7)}.
}
\]

The threshold tends to

\[
\frac{26}{51}.
\]

In the generated strict-underflow support model, the weakest margin observed is still about \(0.1449\).

---

# V. Lemma B exact global target

Lemma B is the actual-ratio lock

\[
\frac{\varphi(C_2)}{C_2}>\frac3{16}.
\]

Since \(C_2\) is even in the chamber,

\[
\frac{\varphi(C_2)}{C_2}
=
\frac12
\frac{\varphi(\operatorname{odd}(C_2))}
{\operatorname{odd}(C_2)}.
\]

Thus Lemma B is equivalent to

\[
\boxed{
\frac{\operatorname{odd}(C_2)}
{\varphi(\operatorname{odd}(C_2))}
<\frac83.
}
\]

A Lemma B failure requires one of ten forbidden signatures:

\[
\begin{aligned}
FS01&=\{3,5,7,11,13,43\},\\
FS02&=\{3,5,7,11,13,41\},\\
FS03&=\{3,5,7,11,17,23\},\\
FS04&=\{3,5,7,11,13,37\},\\
FS05&=\{3,5,7,11,13,31\},\\
FS06&=\{3,5,7,11,17,19\},\\
FS07&=\{3,5,7,11,13,29\},\\
FS08&=\{3,5,7,11,13,23\},\\
FS09&=\{3,5,7,11,13,19\},\\
FS10&=\{3,5,7,11,13,17\}.
\end{aligned}
\]

Every forbidden signature contains \(3\) and \(7\).

The fastest global Lemma B target found by Lane Hunter is therefore:

\[
\boxed{
7\mid C_2
\quad\Longrightarrow\quad
3\nmid C_2
}
\]

under the strict-underflow, all-\(2\bmod3\) \(N\)-support regime.

If this theorem is proved globally, all ten forbidden signatures die in one stroke.

---

# VI. D-branch exact global target

The D-branch is

\[
\varphi(m)=\frac23(m+1),
\qquad
P=\frac{4m+1}{3}=2\varphi(m)-1\text{ prime}.
\]

Parent-defect identities:

\[
E(a)=\frac{3\varphi(a)-2a}{2},
\]

\[
p=1+\frac{a+1}{E(a)}.
\]

For \(a=Br\), set

\[
A=E(B).
\]

Then

\[
d=E(Br),
\qquad
dT=B^2+AB+A,
\]

and

\[
r=1+\frac{B+d}{A},
\qquad
p=1+\frac{B+T}{A}.
\]

The D-branch global proof target is the non-chain death law:

\[
\boxed{
d>1
\Longrightarrow
p\text{ is composite or }
P=2\varphi(Brp)-1\text{ is composite.}
}
\]

The D-ledger certifies this below \(2^{64}\).

---

# VII. Conditional global theorem

## Theorem 5 — Conditional completion of \(r=2\)

Assume:

1. the D-branch non-chain death law;
2. Lemma A globally;
3. Lemma B globally, equivalently the forbidden-signature exclusions.

Then the \(r=2\) solutions to Erdős Problem #411 are exactly

\[
\boxed{
2^a\{1,3,5,7,35,47\}.
}
\]

---

# VIII. What can be submitted today

Submit as:

\[
\boxed{
\text{A Computational Certificate and Finite-Signature Reduction for the }r=2
\text{ Case of Erdős Problem #411}
}
\]

Do **not** submit as an unconditional full proof yet.

The headline claim is:

\[
\boxed{
\text{The remaining }r=2\text{ exceptional structure is reduced to explicit named finite obstruction classes, with no survivors in large shock chambers.}
}
\]

This is strong, honest, and attackable.

---

# IX. Finish-line GTH

The theorem is almost certainly true.

The picture is solved.

The unconditional formal proof still requires the three named global locks:

\[
\boxed{
\text{D non-chain death} \quad+\quad
\text{Lemma A} \quad+\quad
\text{Lemma B}.
}
\]

The immediate fastest lane is Lemma B via

\[
\boxed{
7\mid C_2\Rightarrow3\nmid C_2.
}
\]

That is the next theorem to write.
