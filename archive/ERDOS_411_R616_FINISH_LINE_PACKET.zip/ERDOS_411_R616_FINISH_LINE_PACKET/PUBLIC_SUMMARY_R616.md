# Public-facing summary

We built a Python-first attack on the r=2 case of Erdős Problem #411.

The visible solution families are:

    2^a {1,3,5,7,35,47}

The work gives:

- exact algebraic reductions;
- a large D-branch certificate;
- a Cambie-tail recurrence;
- a symbolic no-step-2-hit theorem;
- a depth-3 overshoot certificate through p <= 20,000,000;
- a reduction of the remaining Lemma B obstruction to ten explicit forbidden prime signatures.

The honest status:

    This is not yet a completed unconditional proof.
    It is a serious computational certificate and finite-signature reduction.

The next theorem target is:

    7 | C2  =>  3 ∤ C2

inside the strict-underflow all-2mod3 N-support regime.
